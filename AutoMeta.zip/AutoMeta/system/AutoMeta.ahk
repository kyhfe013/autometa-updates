﻿#Requires AutoHotkey v2.0
#SingleInstance Off          ; 多重起動は自前で検出する（Force は実行中の処理を殺すため禁止）
Persistent()
SetWorkingDir A_ScriptDir
DetectHiddenWindows false
SetTitleMatchMode 2
; ★座標の基準を画面にそろえる★
;   AHK v2 の既定は Client（＝アクティブウィンドウ基準）。
;   記録画面を操作しているときは AutoMeta の窓が前面なので、
;   MouseGetPos が「メタアナライザーではなく AutoMeta の窓」を基準に返してしまい、
;   覚えた座標が見当違いになる（2026-09-16、x1095 y67 など）。
CoordMode "Mouse", "Screen"
CoordMode "Pixel", "Screen"
ListLines false
#Warn VarUnset, Off

;==============================================================================
;  AutoMeta.ahk  --  メタアナライザー自動操作ツール
;  Phase 0 : 実機調査ツール（★このフェーズではソフトを操作しません★）
;  仕様書: 仕様書.md
;
;  目的は 3 つだけ。
;    1) 各画面のウィンドウクラスを確定し screens.ini を作る      → /trace
;    2) 「自然終了」の見分け方を実測で確定する                   → /trace
;    3) 氏名照合ゲート（G1）が実装可能かを判定する               → /listread
;
;  ★安全★ Phase 0 は【読み取り専用】です。
;    唯一の例外は /listread の「検索欄への入力テスト」で、
;    実行前に必ず確認ダイアログを出し、終了時に入力を消します。
;
;  使い方:
;    2_START.bat         調査メニューを開く
;    /setup              対象ソフト（プロセス）を特定して config に記録
;    /trace              人が手で 1 周操作する間、画面遷移とクリックを記録
;    /listread           一覧・検索欄・姓名欄が読めるかを判定（G1 の可否）
;    /inspect            今開いている全画面のコントロールを列挙
;    /watchall           対象プロセスの変化を監視
;    /doctor             自己診断レポート
;==============================================================================

; 専用アイコン（タスクバーとトレイで見分けるため）
if FileExist(A_ScriptDir "\AutoMeta.ico") {
    try TraySetIcon(A_ScriptDir "\AutoMeta.ico")
}

APP_NAME  := "AutoMeta"
APP_VER   := "2.27.1 (設定の残りをメニューで知らせる)"
APP_BUILD := "2026-09-22 20:14"      ; 配布時に自動で書き換わる（版の識別用）

; ---- ファイルパス ----------------------------------------------------------
CFG      := A_ScriptDir "\config.ini"
SCRINI   := A_ScriptDir "\screens.ini"
SCHEDINI := A_ScriptDir "\schedule.ini"
LOGDIR   := A_ScriptDir "\logs"
STATEINI := A_ScriptDir "\state.ini"
STATUSTX := A_ScriptDir "\status.txt"
STOPFILE := A_ScriptDir "\STOP"
LIVEFILE := A_ScriptDir "\live.txt"              ; 動作中の版が「いま何をしているか」を書く
REQFILE  := A_ScriptDir "\request_therapy.ini"   ; 動作中の版へ「自動セラピーをして」と頼む
LICFILE  := A_ScriptDir "\license.key"           ; 利用の期限（配布物には含めない）

; ★鍵は必ず要る（配布版の前提）★
;   以前は config.ini の LicenseRequired で切り替えていた。しかしその config.ini は
;   利用者が編集できるため 0 に戻せば鍵を無視でき、さらに配布するひな型には
;   [License] 節が無く、既定の 0 ＝ 素通りだった（2026-09-19 指摘）。
;   切り替えを設定から外し、ここに固定する。開発機にも鍵を置いて運用する。
LICENSE_REQUIRED := true

PASSFILE := A_ScriptDir "\pass.key"             ; 通行証（オンライン確認の結果。手書き換えは通らない）
; 利用確認の窓口（第 2 段階）。ここを見て「使ってよいか・いつまでか」を受け取る。
;   返事には署名が付いていて、通行証を手で書き換えても通らない。
;   つながらないときは、通行証の期限までそのまま動く（施術の予定を止めないため）。
LICENSE_URL := "https://script.google.com/macros/s/AKfycbxZPxudZIvhuJ4_AFQRhVXHZ3koyI36nO7gDK3isP_8Ybv4aMk1TUpnI4nILSEr-jQ3/exec"
PENDFILE := A_ScriptDir "\pending.txt"           ; 確認待ち（✓ を付けて消すまで残る）
REMOTEFILE := A_ScriptDir "\REMOTE_STOP"
SHOTDIR  := A_ScriptDir "\screenshots"

; ---- 設定の既定値 [セクション, キー, 既定値] --------------------------------
DEFAULTS := [
    ["Target","ExeName",          ""],
    ["Target","ExePath",          ""],               ; 落ちていたときに起動し直すため
    ["Target","LaunchWaitSec",    "120"],            ; 起動してから現れるまで待つ上限
    ["Target","TitleHint",        ""],
    ["Trace", "TickMs",           "1000"],
    ["Trace", "StallSec",         "10"],
    ["Trace", "MaxTrackedCtrls",  "60"],
    ["Trace", "MaxTextLen",       "60"],
    ["Output","LogRetentionDays", "30"],
    ["Output","DryRun",           "0"],
    ["Output","DryHopSec",        "3"],
    ["Output","LogLevel",         "INFO"],

    ; --- 画面のコントロール（実機 2026-09-13 で確定）-------------------------
    ["Ctrl","SelectCardClassNN",   "TImageButton6"],  ; カード画面「カードを選択します」
    ["Ctrl","SelectCardText",      "カードを選択します"],
    ["Ctrl","CardScanClassNN",     "TImageButton12"], ; カード画面「調査」
    ["Ctrl","CardScanText",        "調査"],
    ["Ctrl","AnamnesisNextClassNN","TImageButton1"],  ; 既往症「進む」
    ["Ctrl","AnamnesisNextText",   "進む"],
    ["Ctrl","SchemeScanClassNN",   "TImageButton4"],  ; スキーム「調査」
    ["Ctrl","SchemeScanText",      "調査"],
    ["Ctrl","SchemeBackClassNN",   "TImageButton3"],  ; スキーム「カードインデックス」
    ["Ctrl","SchemeBackText",      "カードインデックス"],
    ["Ctrl","DialogOkClassNN",     "TImageButton1"],  ; 完了ダイアログ「はい」
    ["Ctrl","LoginText",          "ログイン"],      ; 起動直後のメニュー画面を通る
    ["Ctrl","DialogOkText",        "はい"],
    ["Ctrl","RecordCountClassNN",  ""],               ; 調査履歴の件数（読めれば G2 に使う）
    ["Ctrl","AnchorLeftText",      "インタラクティブ既往症"],
    ["Ctrl","AnchorRightText",     "調査"],
    ["Ctrl","SchemeRowRefText",   "現在の分析"],
    ["Model","ModelName",         "18D"],           ; 18D / MetaAnalyzer
    ["Model","SelectedColor",     ""],              ; 空ならモデルの既定値を使う
    ["Model","NormalColor",       ""],
    ["Model","HoverTest",         "0"],            ; 1 = カーソルを当てて色が変わるかで判定
    ["Ctrl","HighlightBlueMin",   "20"],            ; （旧方式。いまは使わない）
    ["Ctrl","HighlightHitMin",    "3"],
    ["Wait","SchemeOpenRetrySec", "20"],             ; 一覧が開かないときに押し直す間隔
    ["Wait","SchemeSettleSec",    "6"],
    ["Ctrl","TherapyClickX",       ""],               ; アンカーが使えないときの予備
    ["Ctrl","TherapyClickY",       ""],
    ["Ctrl","IndicatorClass",      "TFormDiagn"],     ; セラピー実行中の指標（v4 と同じ）
    ["Ctrl","SchemeBusyTitleHint", "共振周波数を決定"], ; 調査中の Polling のウィンドウ名

    ; --- 対象者の選択 ---------------------------------------------------------
    ["Select","SearchBoxClassNN",       ""],
    ["Select","ListClassNN",            ""],
    ["Select","LastNameFieldClassNN",   ""],
    ["Select","MiddleNameFieldClassNN", ""],          ; 同姓同名の別カードを見分けるため
    ["Select","FirstNameFieldClassNN",  ""],
    ["Select","ListFirstRowX",          "0"],
    ["Select","ListFirstRowY",          "0"],
    ["Select","ListRowPitchY",          "0"],        ; 行の間隔（0 なら次の行を試さない）
    ["Select","ListMaxRows",            "5"],        ; 何行目まで試すか
    ["Select","NameSeparator",          " "],
    ["Select","VerifyPatientName",      "1"],
    ["Select","SettleChecks",           "3"],
    ; カーソルに反応したとみなす色の差（別モデルで調整できるように）
    ["Select","HoverDiffMin",           "12"],
    ["Select","SettleIntervalMs",       "300"],
    ["Select","SettleTimeoutSec",       "15"],

    ; --- 実行内容 -------------------------------------------------------------
    ["Run","LastName",            ""],
    ["Run","FirstName",           ""],
    ["Run","MiddleName",          ""],
    ; --- 利用の期限（第 1 段階：通信なし。鍵ファイルを手で配る）---
    ;   ★既定は 0（警告するだけで止めない）★
    ;   1 にすると、鍵が無い・期限切れのときに実行系を止める。
    ;   配布を始めるときに 1 にする。最初から 1 にすると、
    ;   鍵を配り忘れた瞬間に自分の運用まで止まる。
    ["License","LicenseGraceDays", "7"],             ; 期限後この日数は動く（毎回警告）
    ["License","LicenseWarnDays",  "30"],            ; この日数前から予告する
    ["Run","RunInvestigation",    "1"],
    ["Run","TherapyCount",        "3"],
    ["Run","ScanTypeName",        "詳細"],
    ["Run","ManualName",          "なし"],
    ["Run","MinScanItems",        "1"],
    ["Run","PollIntervalMs",      "3000"],
    ["Run","StableChecks",        "5"],
    ["Run","RestBetweenSec",      "0"],
    ["Run","VerifyTimeoutSec",    "30"],

    ; --- 待ち時間 -------------------------------------------------------------
    ["Wait","HomingTimeoutSec",       "120"],
    ["Wait","TransitionTimeoutSec",   "120"],
    ["Wait","AnamnesisTimeoutSec",    "60"],
    ["Wait","SchemeListWaitSec",      "90"],
    ["Wait","ScanStartTimeoutSec",    "90"],
    ["Wait","ScanOpenTimeoutSec",     "300"],
    ["Wait","ScanOpenRetrySec",       "75"],
    ["Wait","ScanStallTimeoutSec",    "300"],
    ["Wait","DialogWaitSec",          "60"],
    ["Wait","DialogGraceSec",         "8"],
    ["Wait","TherapyStartTimeoutSec", "90"],
    ["Wait","TherapyMaxSec",          "5400"],

    ; --- 安全装置 -------------------------------------------------------------
    ["Safety","BaseClicks",           "16"],
    ["Safety","MaxSameClick",         "5"],
    ["Safety","RetryGapSec",          "10"],
    ["Safety","MaxClicksExtra",       "3"],
    ["Safety","MinClickGapSec",       "2"],
    ["Safety","MaxRuntimeSec",        "28800"],
    ["Safety","MaxUnattendedCycles",  "10"],
    ["Safety","ExpectedCycleMinSec",  "180"],
    ["Safety","ExpectedCycleMaxSec",  "5400"],
    ["Safety","PlanCycleSec",        "1800"],
    ["Safety","CycleTolerancePct",    "40"],
    ["Safety","AbortOnAnomaly",       "1"],
    ["Safety","MaxConsecutiveFailures","3"],

    ["License","UserCode",            ""],             ; 利用者コード（オンライン確認に使う）

    ; ★既定で取得先が入っている★ 新しい PC に配った直後でも更新できるようにする
    ;   （公開リポジトリの URL。秘密は含まない／2026-09-22）
    ["Update","UpdateUrl",            ""],             ; 版番号だけを書いた小さなテキストの URL（空なら埋め込みを使う）
    ["Update","UpdateZipUrl",         ""],             ; 配布 zip の URL（空なら埋め込みを使う）

    ["Scheduler","SchedulerTickSec",  "60"],
    ["Scheduler","MaxJobsPerDay",     "8"],
    ["Scheduler","RestBetweenJobsSec","60"]
]

; ---- 画面の見分け方 ---------------------------------------------------------
;  2026-09-09 の実機 /trace で、対象ソフト（18D-NLS.exe）の全画面クラスが確定した。
;  推測に頼らず、まずこの表で判定する。表にないクラスだけ署名テキストで推測する。
SCREEN_CLASSES := Map(
    "TFormMenu",          "S0_Menu",        ; メインメニュー（ログイン/設定/終了）常時開いている
    "TFormPacients",      "S1_Index",       ; 患者一覧（「カードを選択します」で開く）
    "TFormCartateca",     "S2_Card",        ; カード画面（title は「カードインデックス」）
    "TpfFormEasyPolling", "S2b_Anamnesis",  ; インタラクティブ既往症（「調査」の直後に出る）
    "TpfFormPolling",     "S3_Scheme",      ; 調査のスキーム
    "TFormHardest",       "S4_ScanItem",    ; 項目ごとのスキャン画面（title に臓器名）
    "TFormDiagn",         "S5_Indicator",   ; 指標窓（title は数字。進捗の鼓動）
    "TMessageForm",       "Dialog")         ; 完了ダイアログ（「はい」1 個・title は DlgInformation）

;  未知のクラス用のフォールバック。上から順に照合し、最初に当たったものを採る。
SCREEN_SIGS := [
    ["Dialog",      ["DlgInformation"]],
    ["P1_Progress", ["心身スクリーニング"]],
    ["S4_ScanItem", ["ポーズ", "再開する", "再開"]],
    ["S3_Scheme",   ["インタラクティブ既往症", "マニュアル選択", "調査タイプ"]],
    ["S2_Card",     ["新カード", "カードを選択します", "ビュー結果", "比較分析"]],
    ["S1_Index",    ["検索"]]
]

; ---- 対象ソフトの候補（/setup の自動検出用）---------------------------------
KNOWN_EXES := ["META ANALYZER.exe", "METAANALYZER.exe", "18D-NLS.exe", "18DNLS.exe", "MetaAnalyzer.exe"]

; ---- グローバル -------------------------------------------------------------
;  ※ AutoTherapy v4 と同じ流儀。使う関数の側で必ず `global` を宣言すること。
C := Map()          ; 設定
G := {              ; 実行時状態
    mode:    "menu",
    pid:     0,
    logFile: "",
    badArgs: "",       ; 知らない指定（/xxx）。起動ログに残すだけ
    fromMenu: false,   ; メニューから始めた実行か（終わったらメニューへ戻す）
    backTo:   "more",  ; 設定を保存したあとに戻る先（more＝設定／wizard＝初期設定）
    ; --- ジョブ用（ここは ResetJobState() が毎回すべて初期化する）--- ★JOBSTATE-BEGIN★
    state:   "idle",   stateTS: "",  startTS: "",  stopping: false,
    wantSei: "",       wantMei: "",  wantMid: "",  gotSei: "",   gotMei: "",   gotMid: "",
    searched: false,   rowClicked: false,   rowTry: 1,   lastCard: "",   rowExtra: 0,
    clicks:  0,        lastClickTS: "",
    repeat:  0,        lastTarget: "",   lastTargetState: "", stateClickTS: "",
    cycle:   0,        cycleStartTS: "", durations: [], stable: 0,
    maxGap:  0,        therapySeenTS: "", runLogTS: "",
    scanBefore: "",    scanStartTS: "",  scanProgressTS: "",
    scanItems: 0,      scanSec: 0,       lastScanItem: "", dialogSeen: false,
    needCheck: "",     logLost: 0,
    optStep: 0, optTS: "", optTries: 0, optBusy: false, optWarn: "",
    optOff: 0, optLast: 0, optNoBtn: 0,
    statusTS: "",
    ; ★JOBSTATE-END★
    ; --- スケジューラ用 ---
    schedOn: false,     schedRunning: false, schedCurrent: "",
    schedDone: 0,       schedFailed: 0,      schedSkipped: 0,     schedCheck: 0,
    appLaunchTS: "",    appWarnTS: "",
    schedFailStreak: 0, schedStartTS: "",
    skipSelect: false, manualJob: false,
    ; --- 運転パネル用 ---
    panel: "",         panelState: "", panelWho: "", panelJob: "",
    panelSub: "",      panelNext: "",  panelNextTS: "", panelPend: "", panelBtns: []
}

; 確認待ちの一覧画面の作業用
PENDUI := Map()

; 予定の編集画面の作業用（一覧・編集中かどうか）
;   ★EDIT という名前は使えない★
;     AHK v2 には組み込み関数 Edit() があり、大文字小文字を区別しないため
;     EDIT := Map() が "This Func cannot be used as an output variable" で落ちる。
;     変数名は必ず AHK の組み込み関数・変数と衝突しないものにすること。
SCHEDUI := Map()

Main()

;==============================================================================
;  エントリポイント
;==============================================================================
Main() {
    global C, G, LOGDIR, APP_VER
    if !DirExist(LOGDIR)
        DirCreate(LOGDIR)
    G.logFile := LOGDIR "\" FormatTime(A_Now, "yyyy-MM-dd") ".log"
    RotateLogs()

    ParseArgs()
    ; ★利用者の設定を、更新で消さないための仕組み★
    ;   配布 zip には config.default.ini / schedule.default.ini だけを入れる。
    ;   実際に使う config.ini / schedule.ini は、無いときだけここで作る。
    ;   （以前は zip に本体名で入れていたため、上書き解凍で予定が消えていた）
    EnsureUserFile(CFG,      A_ScriptDir "\config.default.ini")
    EnsureUserFile(SCHEDINI, A_ScriptDir "\schedule.default.ini")
    LoadConfig()
    Log("INFO", "起動 mode=" G.mode " ver=" APP_VER)
    if (G.badArgs != "")
        Log("WARN", "知らない指定がありました: " G.badArgs "（メニューを開きました）")
    ; --- 利用の期限を見る（既定では止めない。記録だけ残す）---
    PassAutoRenew()                                ; 通行証を静かに取り直す（画面は出ない）
    lic := LicenseCheck()
    Log("INFO", Format("利用の期限: {1}{2}{3}", lic["state"]
        , lic["name"] = "" ? "" : "／" lic["name"]
        , lic["why"] = "" ? "" : "／" lic["why"]))
    ; ★ここでは止めない★ 実行系の入口（LicenseGate）で判定する。
    ;   起動時の mode で止めると、メニュー経由の実行を取りこぼす。

    ; ★知らせるのは、人がメニューを開いたときだけ★
    ;   夜間に無人で動いているなら、登録はすでに済んでいる（2026-09-19 指摘）。
    ;   ただし実行の入口（/run /schedule /therapy）で窓を出すと、
    ;   押されるまで運転が始まらない。夜に始めて離席したら朝まで動かない。
    ;   実行系の可否は LicenseGate が判断するので、ここでは黙る。
    if ((G.mode = "menu" || G.mode = "more" || G.mode = "code") && LicenseNudge()) {
        ModeCode()                                 ; 「いま入れる」を選んだ
        return
    }

    ; ★新しい版のお知らせも、人が開いたときだけ★
    if (G.mode = "menu" || G.mode = "more" || G.mode = "code") {
        if (nv := UpdateCheck()) {
            msg := "新しい版 " . nv . " が出ています。`n`n"
                 . "いまお使いの版: " . VerNumOnly(APP_VER) . "`n`n"
            if (UpdateUrlOf("zip") = "") {
                MsgBox(msg . "更新のしかたは、お渡しした案内をご確認ください。"
                    , APP_NAME . " - 新しい版のお知らせ", "Iconi 4096")
            } else if (MsgBox(msg . "いま更新しますか？（設定や予定はそのまま残ります）"
                    , APP_NAME . " - 新しい版のお知らせ", "YesNo Iconi 4096") = "Yes") {
                ModeUpdate()
                return
            }
        }
    }

    switch G.mode {
        case "run":      ModeRun()
        case "schedule": ModeSchedule()
        case "schededit": ModeScheduleEditor()
        case "therapy":   ModeTherapy()
        case "teachscan": ModeTeachScan()
        case "teachcount": ModeTeachCount()
        case "code":      ModeCode()
        case "verifytest": ModeVerifyTest()
        case "update":     ModeUpdate()
        case "model":      ModeModel()
        case "schemename": ModeSchemeNames()
        case "wizard":    ModeWizard()
        case "resume":    ModeResume()
        case "more":      ModeMore()
        case "dryrun":   (C["DryRun"] := "1", ModeRun())
        case "setup":    ModeSetup()
        case "trace":    ModeTrace()
        case "listread": ModeListRead()
        case "pickrow":  ModePickRow()
        case "inspect":  ModeInspect()
        case "watchall": ModeWatchAll()
        case "doctor":   ModeDoctor()
        default:         ModeMenu()
    }
}

;==============================================================================
;  INI（UTF-8）の読み書き
;  ※ Windows 標準の IniRead/IniWrite は BOM 無しファイルを ANSI として扱うため、
;     UTF-8 の設定ファイルでは日本語が壊れる。そのため自前で実装している。
;     （AutoTherapy v4 と同一実装）
;==============================================================================
IniLoad(file) {
    m := Map()
    if !FileExist(file)
        return m
    txt := ""
    try txt := FileRead(file, "UTF-8")
    catch
        return m
    txt := StrReplace(txt, Chr(0xFEFF), "")      ; BOM を除去
    sec := "Default"
    Loop Parse, txt, "`n", "`r" {
        line := Trim(A_LoopField)
        if (line = "" || SubStr(line, 1, 1) = ";" || SubStr(line, 1, 1) = "#")
            continue
        if (SubStr(line, 1, 1) = "[") {
            sec := Trim(line, "[] `t")
            continue
        }
        pos := InStr(line, "=")
        if (pos < 2)
            continue
        if !m.Has(sec)
            m[sec] := Map()
        m[sec][Trim(SubStr(line, 1, pos - 1))] := StripInlineComment(SubStr(line, pos + 1))
    }
    return m
}

; 値のうしろに書かれたコメント（" ;" 以降）を取り除く。
;   INI では「TherapyCount=0   ; 施術なし」のように書くのが自然で、README でもそう例示している。
;   ※ 直前が空白の ";" だけを対象にする（値そのものに ";" を含む場合を壊さないため）
StripInlineComment(v) {
    v := "" . v
    pos := RegExMatch(v, "[ \t];")
    if (pos > 0)
        v := SubStr(v, 1, pos - 1)
    return Trim(v)
}

; 落ちない整数変換。数字として読めなければ既定値を返す。
;   ★Integer() は数字でない文字列を渡すと例外で落ちる。設定ファイル由来の値には必ずこちらを使う
ToInt(v, def := 0) {
    t := StripInlineComment(v)
    if RegExMatch(t, "^-?\d+$")
        return Integer(t)
    return def
}

; 利用者用のファイルが無ければ、ひな型から作る。あれば触らない。
EnsureUserFile(target, sample) {
    if FileExist(target)
        return
    if !FileExist(sample)
        return
    try FileCopy(sample, target, 0)
}

IniGet(m, section, key, default := "") {
    if (m.Has(section) && m[section].Has(key) && m[section][key] != "")
        return m[section][key]
    return default
}

; 節をまるごと入れ替える。
;   キーを 1 つずつ書くと、古いキーが残り、書くたびに行が増えていく。
;   座標表のように「その節の内容がまとまって決まる」ものはこちらを使う。
;   ※ その節に書かれたコメントは消えます（機械が書く節だけに使うこと）
IniSetSection(file, section, pairs) {
    txt := ""
    if FileExist(file) {
        try txt := FileRead(file, "UTF-8")
    }
    txt := StrReplace(txt, Chr(0xFEFF), "")
    out := [], inSec := false, wrote := false
    Loop Parse, txt, "`n", "`r" {
        line := A_LoopField
        t := Trim(line)
        if (SubStr(t, 1, 1) = "[") {
            if (inSec && !wrote) {
                for pr in pairs
                    out.Push(pr[1] "=" pr[2])
                out.Push("")                       ; 次の節との間を空ける
                wrote := true
            }
            inSec := (Trim(t, "[] `t") = section)
            out.Push(line)
            continue
        }
        if (inSec)
            continue                               ; 古い中身は捨てる
        out.Push(line)
    }
    if (inSec && !wrote) {
        for pr in pairs
            out.Push(pr[1] "=" pr[2])
        wrote := true
    }
    if (!wrote) {
        out.Push("")
        out.Push("[" section "]")
        for pr in pairs
            out.Push(pr[1] "=" pr[2])
    }
    body := ""
    for line in out
        body .= line "`n"
    try FileDelete(file)
    FileAppend(CRLF(body), file, "UTF-8")
}

; ★同じ節の複数項目を、1 回の書き直しで保存する★
;   IniSet は 1 項目ごとに「削除してから書き直す」。5 項目なら 5 回。
;   state.ini は実行履歴も持つので、書き直しの回数はそのまま危険の量になる
;   （その瞬間に落ちるとファイルごと失われる）。まとめれば 1 回で済む。
IniSetMany(file, section, pairs) {
    txt := ""
    if FileExist(file) {
        try txt := FileRead(file, "UTF-8")
    }
    txt := StrReplace(txt, Chr(0xFEFF), "")
    left := Map()
    for k, v in pairs
        left[k] := v
    out := [], inSec := false, secSeen := false
    Loop Parse, txt, "`n", "`r" {
        line := A_LoopField
        t := Trim(line)
        if (SubStr(t, 1, 1) = "[") {
            if (inSec) {                          ; 節の終わりで、残りを書き足す
                for k, v in left
                    out.Push(k "=" v)
                left := Map()
            }
            inSec := (Trim(t, "[] `t") = section)
            if inSec
                secSeen := true
        } else if (inSec) {
            pos := InStr(t, "=")
            if (pos > 1) {
                k := Trim(SubStr(t, 1, pos - 1))
                if (left.Has(k)) {
                    out.Push(k "=" left[k])
                    left.Delete(k)
                    continue
                }
            }
        }
        out.Push(line)
    }
    if (left.Count > 0) {
        if (!secSeen) {
            out.Push("")
            out.Push("[" section "]")
        }
        for k, v in left
            out.Push(k "=" v)
    }
    body := ""
    for line in out
        body .= line "`r`n"
    try FileDelete(file)
    FileAppend(CRLF(body), file, "UTF-8")
}

IniSet(file, section, key, value) {
    txt := ""
    if FileExist(file) {
        try txt := FileRead(file, "UTF-8")
    }
    txt := StrReplace(txt, Chr(0xFEFF), "")
    out := [], inSec := false, done := false, secSeen := false
    Loop Parse, txt, "`n", "`r" {
        line := A_LoopField
        t := Trim(line)
        if (SubStr(t, 1, 1) = "[") {
            if (inSec && !done) {                 ; セクション末尾に追記
                out.Push(key "=" value)
                done := true
            }
            inSec := (Trim(t, "[] `t") = section)
            if inSec
                secSeen := true
        } else if (inSec && !done) {
            pos := InStr(t, "=")
            if (pos > 1 && Trim(SubStr(t, 1, pos - 1)) = key) {
                out.Push(key "=" value)
                done := true
                continue
            }
        }
        out.Push(line)
    }
    if !done {
        if !secSeen {
            out.Push("")
            out.Push("[" section "]")
        }
        out.Push(key "=" value)
    }
    body := ""
    for line in out
        body .= line "`r`n"
    try FileDelete(file)
    FileAppend(CRLF(body), file, "UTF-8")         ; BOM 付き UTF-8 / CRLF で書き戻す
}

;==============================================================================
;  引数解析 / 設定
;==============================================================================
ParseArgs() {
    global G
    static modeMap := Map("/setup",    "setup",    "/trace",   "trace"
                        , "/listread", "listread", "/inspect", "inspect"
                        , "/watchall", "watchall", "/doctor",  "doctor"
                        , "/menu",     "menu",     "/run",     "run"
                        , "/dryrun",   "dryrun",   "/pickrow", "pickrow"
                        , "/schedule", "schedule"
                        , "/schededit", "schededit"
                        , "/therapy",   "therapy"
                        , "/teachscan", "teachscan"
                        , "/teachcount", "teachcount"
                        , "/more",      "more"
                        , "/resume",    "resume"
                        , "/code",      "code"
                        , "/verifytest", "verifytest"
                        , "/update",    "update"
                        , "/model",     "model"
                        , "/schemename", "schemename"
                        , "/wizard",    "wizard")
    ; ★知らない指定を、黙ってメニューにしない★
    ;   /resume が対応表に無く、見張り（5 分ごと）とスタートアップ登録が
    ;   「復帰」ではなく「メニューを開く」を実行していた。最小化した窓が
    ;   勝手に戻るうえ、落ちた運転を一度も拾えていなかった（2026-09-19 指摘）。
    G.badArgs := ""
    for a in A_Args {
        low := StrLower(Trim(a))
        if modeMap.Has(low) {
            G.mode := modeMap[low]
            continue
        }
        if (SubStr(low, 1, 1) = "/")
            G.badArgs .= (G.badArgs = "" ? "" : " ") . low
    }
}

LoadConfig() {
    global C, CFG, DEFAULTS
    m := IniLoad(CFG)
    for row in DEFAULTS
        C[row[2]] := IniGet(m, row[1], row[2], row[3])
    ; ★モデル専用の値があれば、そちらで上書きする★
    ;   例: [Ctrl.MetaAnalyzer] ListFirstRowY=...  座標や部品名はモデルで違う。
    mdl := Trim(C.Has("ModelName") ? C["ModelName"] : "")
    if (mdl != "" && mdl != "18D") {
        for row in DEFAULTS {
            v := IniGet(m, row[1] . "." . mdl, row[2], "")
            if (Trim(v) != "")
                C[row[2]] := v
        }
    }
}

CI(k) {
    global C
    return ToInt(C.Has(k) ? C[k] : "", 0)
}
CS(k) {
    global C
    return C.Has(k) ? "" . C[k] : ""
}
CB(k) {
    global C
    v := StripInlineComment(C.Has(k) ? C[k] : "")
    return (v = "1" || v = 1 || v = true)
}
SecSince(ts) => (ts = "") ? 0 : DateDiff(A_Now, ts, "Seconds")
FmtTS(ts) => (ts = "") ? "-" : FormatTime(ts, "yyyy-MM-dd HH:mm:ss")

;==============================================================================
;  共通ヘルパ
;==============================================================================
; 全角英数・記号を半角へ。前後空白と & を除去（AutoTherapy v4 と同一）
Norm(s) {
    s := StrReplace(s, "&", "")
    s := Trim(s, " `t`r`n")
    out := ""
    Loop Parse, s {
        c := Ord(A_LoopField)
        out .= (c >= 0xFF01 && c <= 0xFF5E) ? Chr(c - 0xFEE0) : (c = 0x3000 ? " " : A_LoopField)
    }
    return Trim(out)
}

MyPid() => DllCall("GetCurrentProcessId", "uint")

; いま別の AutoMeta（実行系）が動いているか。動いていれば true
AnotherInstanceRunning() {
    ; 0x100000 = SYNCHRONIZE。開けたら存在する
    h := DllCall("OpenMutexW", "UInt", 0x100000, "Int", 0, "Str", "AutoMeta_Job_Singleton", "Ptr")
    if (h) {
        DllCall("CloseHandle", "Ptr", h)
        return true
    }
    return false
}

; いまジョブが動いているか（スケジュール運転でも、単独実行でも）
;   ★スケジュール運転中は schedRunning だけが根拠★
;     G.state はジョブが終わっても "cleanup" のまま残るため、
;     これを見ていると「待機中なのに実行中」と名乗ってしまう。
;     2026-09-15、待機中なのに自動セラピーを断られた原因。
JobInProgress() {
    global G
    if (G.schedOn)
        return G.schedRunning
    return (G.state != "" && G.state != "idle" && !G.stopping)
}

; 動作中の版が、自分の状況を書き出す。別プロセスから読むためのもの。
WriteLive() {
    global G, LIVEFILE, APP_VER
    o := "Pid=" MyPid() "`n"
      . "Ver=" APP_VER "`n"
      . "SchedOn=" (G.schedOn ? 1 : 0) "`n"
      . "Running=" (JobInProgress() ? 1 : 0) "`n"
      . "Manual=" (G.manualJob ? 1 : 0) "`n"
      . "Patient=" G.wantSei " " G.wantMei "`n"
      . "State=" G.state "`n"
      . "Cycle=" G.cycle "/" CI("TherapyCount") "`n"
      . "At=" A_Now "`n"
    try FileDelete(LIVEFILE)
    try FileAppend(CRLF(o), LIVEFILE, "UTF-8")
}

; live.txt を読む。書かれてから 5 分以上たっていたら、当てにしない。
ReadLive() {
    global LIVEFILE
    out := Map("SchedOn", "0", "Running", "0", "Manual", "0"
             , "Patient", "", "State", "", "Cycle", "", "fresh", false)
    if !FileExist(LIVEFILE)
        return out
    txt := ""
    try txt := FileRead(LIVEFILE, "UTF-8")
    txt := StrReplace(txt, Chr(0xFEFF), "")
    for line in StrSplit(txt, "`n", "`r") {
        pos := InStr(line, "=")
        if (pos > 1)
            out[Trim(SubStr(line, 1, pos - 1))] := Trim(SubStr(line, pos + 1))
    }
    if (out.Has("At") && RegExMatch(out["At"], "^\d{14}$"))
        out["fresh"] := (DateDiff(A_Now, out["At"], "Seconds") < 300)
    return out
}

; =============================================================================
;  利用の期限（ライセンス）— 第 1 段階
;   ★通信しない★ 鍵ファイルを読んで、期限と署名を見るだけ。
;   ★完全な錠前ではない★ AHK は中身が読めるので、本気の回避は防げない。
;     止められるのは「うっかりの又貸し」「期限切れの継続利用」まで（利用者に説明済み）。
;   鍵の発行は手元の _make_license.py で行う。配布物に発行機能は入れない。
; =============================================================================
; ★合言葉は廃止した（2026-09-21）★
;   ソースを一時的に公開してしまい、値が露出した。公開鍵方式へ移行し、
;   この値では何も偽造できないようにした。復活させないこと。

; 文字列の SHA-256（16 進）。Windows の暗号 API を使う
Sha256Hex(str) {
    static PROV_RSA_AES := 24, CALG_SHA_256 := 0x0000800c
    static CRYPT_VERIFYCONTEXT := 0xF0000000, HP_HASHVAL := 0x0002
    hProv := 0, hHash := 0
    if (!DllCall("advapi32\CryptAcquireContextW", "Ptr*", &hProv, "Ptr", 0, "Ptr", 0
                , "UInt", PROV_RSA_AES, "UInt", CRYPT_VERIFYCONTEXT))
        return ""
    out := ""
    if (DllCall("advapi32\CryptCreateHash", "Ptr", hProv, "UInt", CALG_SHA_256
               , "Ptr", 0, "UInt", 0, "Ptr*", &hHash)) {
        n := StrPut(str, "UTF-8") - 1
        buf := Buffer(n + 1, 0)
        StrPut(str, buf, "UTF-8")
        DllCall("advapi32\CryptHashData", "Ptr", hHash, "Ptr", buf, "UInt", n, "UInt", 0)
        size := 32
        hash := Buffer(size, 0)
        if (DllCall("advapi32\CryptGetHashParam", "Ptr", hHash, "UInt", HP_HASHVAL
                   , "Ptr", hash, "UInt*", &size, "UInt", 0)) {
            Loop size
                out .= Format("{:02x}", NumGet(hash, A_Index - 1, "UChar"))
        }
        DllCall("advapi32\CryptDestroyHash", "Ptr", hHash)
    }
    DllCall("advapi32\CryptReleaseContext", "Ptr", hProv, "UInt", 0)
    return out
}

; 鍵ファイルを読んで状態を返す。
;   state: none（未登録）/ broken（壊れている）/ forged（署名が合わない）
;          / wrongpc（別の PC 用）/ expired（期限切れ）/ grace（猶予中）
;          / soon（まもなく期限）/ ok
; ---- 通行証（オンライン確認）----------------------------------------------
; URL に載せられる形に直す（PC 名に日本語が入っても壊れないよう UTF-8 で）
UriEncode(s) {
    if (s = "")
        return ""
    n := StrPut(s, "UTF-8") - 1
    buf := Buffer(n + 1, 0)
    StrPut(s, buf, "UTF-8")
    out := ""
    Loop n {
        c  := NumGet(buf, A_Index - 1, "UChar")
        ch := Chr(c)
        if ((c >= 48 && c <= 57) || (c >= 65 && c <= 90) || (c >= 97 && c <= 122)
            || ch = "-" || ch = "_" || ch = "." || ch = "~")
            out .= ch
        else
            out .= "%" . Format("{:02X}", c)
    }
    return out
}

; 返事から 1 項目だけ取り出す（本格的な JSON 解析は要らない）
JStr(body, key) {
    if RegExMatch(body, '"' . key . '"\s*:\s*"([^"]*)"', &m)
        return m[1]
    return ""
}
JBool(body, key) {
    if RegExMatch(body, '"' . key . '"\s*:\s*(true|false)', &m)
        return (m[1] = "true")
    return false
}

; 手元の通行証を確かめる。通信はしない。
PassCheck() {
    global PASSFILE
    ng := Map("ok", false, "lic", "", "gone", false, "notice", "")
    if (!FileExist(PASSFILE))
        return ng
    m   := IniLoad(PASSFILE)
    nm  := Trim(IniGet(m, "Pass", "Name", ""))
    exp := Trim(IniGet(m, "Pass", "Expires", ""))
    unt := Trim(IniGet(m, "Pass", "Until", ""))
    pc  := Trim(IniGet(m, "Pass", "Pc", ""))
    sig  := Trim(IniGet(m, "Pass", "Sign", ""))
    sig2 := Trim(IniGet(m, "Pass", "Sign2", ""))
    if (nm = "" || exp = "" || unt = "" || sig2 = "")
        return ng
    ; ★新方式を優先する★ 公開鍵で確かめる。合言葉は移行が終わるまでの保険。
    if (sig2 = "" || !RsaVerify(Sha256Hex(nm . "|" . exp . "|" . unt . "|" . pc), sig2))
        return Map("ok", false, "lic", "", "gone", false, "notice", "broken")
    if (pc != "" && StrLower(pc) != StrLower(A_ComputerName))
        return Map("ok", false, "lic", "", "gone", false, "notice", "wrongpc")
    u := StrReplace(unt, "-", ""), e := StrReplace(exp, "-", "")
    if (StrLen(u) != 8 || StrLen(e) != 8)
        return ng
    today  := FormatTime(A_Now, "yyyyMMdd")
    notice := Trim(IniGet(m, "Pass", "Notice", ""))
    if (u < today)
        ; ★終わった理由も返す★ 文面を理由別に出し分けるため（2026-09-19 点検）。
        ;   以前は理由を捨てていたので、解約で止まった人にも
        ;   「ネットにつないでください」と案内していた。
        return Map("ok", false, "lic", "", "gone", true, "notice", notice)
    left := DateDiff(u . "000000", today . "000000", "Days")
    if (notice != "") {
        ; 終わりが決まっている。だが期限までは今までどおり動かす。
        return Map("ok", true, "lic", Map("state", "ending", "name", nm
            , "expires", exp, "days", left
            , "why", Format("{1} まで使えます（あと {2} 日）／理由: {3}"
                   , unt, left, Trim(IniGet(m, "Pass", "NoticeWhy", notice)))))
    }
    ; ★つながらない日が続いていることを、黙って進行させない★
    ;   確認できないまま残り日数が減り、ある朝いきなり止まるのが最悪（2026-09-19 指摘）。
    chk := Trim(IniGet(m, "Pass", "Checked", ""))
    if ((chk = "" || DateDiff(A_Now, chk, "Hours") >= 26) && left <= 7) {
        return Map("ok", true, "lic", Map("state", "offline", "name", nm
            , "expires", exp, "days", left
            , "why", Format("ネットにつながらず確認できていません。{1} まで（あと {2} 日）は動きます"
                   , unt, left)))
    }
    lic := Map("state", "ok", "name", nm, "expires", exp, "why", ""
             , "days", DateDiff(e . "000000", today . "000000", "Days"))
    lic["why"] := Format("期限 {1} まであと {2} 日（通行証は {3} まで）", exp, lic["days"], unt)
    if (lic["days"] <= CI("LicenseWarnDays"))
        lic["state"] := "soon"
    return Map("ok", true, "lic", lic)
}

; 窓口に問い合わせて通行証を取り直す。つながらなければ false（黙って戻る）。
PassRenew(code, &why) {
    global LICENSE_URL, PASSFILE
    why := ""
    code := Trim(code)
    if (code = "") {
        why := "利用者コードが入っていません"
        return false
    }
    url  := LICENSE_URL . "?code=" . UriEncode(code) . "&pc=" . UriEncode(A_ComputerName)
    body := ""
    try {
        http := ComObject("WinHttp.WinHttpRequest.5.1")
        http.SetTimeouts(3000, 5000, 5000, 8000)   ; 起動を待たせない（最長 8 秒）
        http.Open("GET", url, false)
        http.Send()
        body := http.ResponseText
    } catch as e {
        why := "つながりません（" . e.Message . "）"
        return false
    }
    if (!JBool(body, "ok")) {
        st  := JStr(body, "state")
        why := JStr(body, "why")
        if (why = "")
            why := "確認できませんでした"
        Log("WARN", "利用確認の返事: " . st . "／" . why)
        ; ★通行証は捨てない★
        ;   捨てるとその瞬間から実行できなくなる＝予告なしに止まる。
        ;   無人で夜通し動かす道具では、それが最も避けたいこと（2026-09-19 指摘）。
        ;   代わりに「終わりの予告」を書き、通行証の期限（最大 14 日）までは
        ;   動かし続けながら、起動のたびに残り日数を知らせる。
        if (st = "stopped" || st = "expired" || st = "unknown" || st = "wrongpc") {
            if (FileExist(PASSFILE)) {
                IniSet(PASSFILE, "Pass", "Notice",    st)
                IniSet(PASSFILE, "Pass", "NoticeWhy", why)
                IniSet(PASSFILE, "Pass", "NoticeAt",  FormatTime(A_Now, "yyyyMMddHHmmss"))
            }
        }
        return false
    }
    nm  := JStr(body, "name"), exp := JStr(body, "expires")
    unt := JStr(body, "until"), pc  := JStr(body, "pc")
    sig  := JStr(body, "sign")
    sig2 := JStr(body, "sign2")
    if (sig2 = "" || !RsaVerify(Sha256Hex(nm . "|" . exp . "|" . unt . "|" . pc), sig2)) {
        why := "返事の署名が合いません"
        return false
    }
    out := "; AutoMeta 通行証（自動で作られます。書き換えないでください）`r`n[Pass]`r`n"
         . "Code=" . code . "`r`nName=" . nm . "`r`nExpires=" . exp
         . "`r`nUntil=" . unt . "`r`nPc=" . pc . "`r`nSign=" . sig . "`r`nSign2=" . sig2
         . "`r`nChecked=" . FormatTime(A_Now, "yyyyMMddHHmmss") . "`r`n"
    try FileDelete(PASSFILE)
    try FileAppend(CRLF(out), PASSFILE, "UTF-8")
    Log("INFO", Format("利用確認 OK（公開鍵で確認）: {1}／期限 {2}／通行証は {3} まで", nm, exp, unt))
    return true
}

; 起動時に静かに取り直す。★画面は出さない★（無人で動くため）
PassAutoRenew() {
    global PASSFILE, G
    code := Trim(CS("UserCode"))
    if (code = "")
        return                                      ; コード運用をしていない（鍵ファイル運用）
    need := true
    p := PassCheck()
    if (p["ok"]) {
        m   := IniLoad(PASSFILE)
        unt := StrReplace(Trim(IniGet(m, "Pass", "Until", "")), "-", "")
        chk := Trim(IniGet(m, "Pass", "Checked", ""))
        ; ★予告を早く出すことを優先する★
        ;   人が起動したときは毎回確かめる（その場で残り日数を知らせたい）。
        ;   見張り（5 分おき）で毎回つなぐのは無駄なので、無人は 1 日 1 回。
        ;   人が開いたとき: 10 分以内に確かめていれば省く（続けて開いても遅くならない）
        ;   無人（見張り）: 1 日 1 回
        span := (G.mode = "resume") ? 86400 : 600
        need := (chk = "" || DateDiff(A_Now, chk, "Seconds") >= span)
    }
    if (!need)
        return
    why := ""
    if (!PassRenew(code, &why))
        Log("WARN", "いまは利用確認ができません（" . why . "）。通行証の期限までは動きます")
}

; --- 公開鍵で署名を確かめる（RSA-SHA256 / PKCS#1 v1.5）----------------------
;   ★ツールには公開鍵しか置かない★
;     合言葉を共有する方式は、配布物を読まれた時点で偽造できてしまう。
;     公開鍵なら、読まれても偽造できない（署名には手元の秘密鍵が要る）。
;   当面は旧方式（Sign）も受け付ける。新方式が実機で通ってから旧方式を外す。
LicensePubModulus()  => "df278720e2426124c4bcf011a1736a6cc29b4be65553de7f1f82c21ad1a5563e8fe8172dd26be31e5607d1608c32872114111ecc9b382d52e4c273c3d18252a14863ceef700ac76ea185228b2fea7b586d46fb20c040707e3a990ac046c27c499480cd9a0674263aab40e4ebae0005fb9dd9513ff05952584f0f25eabc9216b62ab352412af6690d506c6d42f3aa89917961b456a89680ac9adc76857f3fb099c9cbf066d5e483d6663c9f42042f6b2d28c2ec6022bf1487689cc213bb1cdefb0282f292007765877e54d1791d6268682ae445991895537639c19504d61a10030c231132cae789c8621199a8e2c0a6a0fcf5cfbef273c3b4203a19760c584c8f"
LicensePubExponent() => "010001"

; 16 進の文字列を、そのままのバイト列にする
HexToBuf(hex) {
    hex := Trim(hex)
    n   := StrLen(hex) // 2
    buf := Buffer(n, 0)
    Loop n
        NumPut("UChar", Integer("0x" . SubStr(hex, (A_Index - 1) * 2 + 1, 2)), buf, A_Index - 1)
    return buf
}

; 文字列の SHA-256 を 32 バイトの生データで返す（Sha256Hex の兄弟）
Sha256Buf(str) {
    static PROV_RSA_AES := 24, CALG_SHA_256 := 0x0000800c
    static CRYPT_VERIFYCONTEXT := 0xF0000000, HP_HASHVAL := 0x0002
    out := Buffer(32, 0)
    hProv := 0, hHash := 0
    if (!DllCall("advapi32\CryptAcquireContextW", "Ptr*", &hProv, "Ptr", 0, "Ptr", 0
                , "UInt", PROV_RSA_AES, "UInt", CRYPT_VERIFYCONTEXT))
        return out
    if (DllCall("advapi32\CryptCreateHash", "Ptr", hProv, "UInt", CALG_SHA_256
               , "Ptr", 0, "UInt", 0, "Ptr*", &hHash)) {
        n := StrPut(str, "UTF-8") - 1
        buf := Buffer(n + 1, 0)
        StrPut(str, buf, "UTF-8")
        DllCall("advapi32\CryptHashData", "Ptr", hHash, "Ptr", buf, "UInt", n, "UInt", 0)
        size := 32
        DllCall("advapi32\CryptGetHashParam", "Ptr", hHash, "UInt", HP_HASHVAL
               , "Ptr", out, "UInt*", &size, "UInt", 0)
        DllCall("advapi32\CryptDestroyHash", "Ptr", hHash)
    }
    DllCall("advapi32\CryptReleaseContext", "Ptr", hProv, "UInt", 0)
    return out
}

; 署名が正しいか（本文・16 進の署名）。Windows の BCrypt を使う。
RsaVerify(msg, sigHex) {
    static BCRYPT_PAD_PKCS1 := 2
    if (Trim(sigHex) = "")
        return false
    hAlg := 0, hKey := 0
    if (DllCall("bcrypt\BCryptOpenAlgorithmProvider", "Ptr*", &hAlg, "Str", "RSA"
               , "Ptr", 0, "UInt", 0) != 0)
        return false
    ; ★組み込み関数と同じ名前を変数に使わない★
    ;   mod / exp は AHK の組み込み（Mod() / Exp()）と衝突する。
    ;   過去に ci / cs で同じ失敗をしている（静的チェックが検出）。
    modBuf := HexToBuf(LicensePubModulus())
    expBuf := HexToBuf(LicensePubExponent())
    cb   := 24 + expBuf.Size + modBuf.Size
    blob := Buffer(cb, 0)
    NumPut("UInt", 0x31415352, blob, 0)         ; RSA1
    NumPut("UInt", modBuf.Size * 8, blob, 4)    ; 鍵のビット長
    NumPut("UInt", expBuf.Size, blob, 8)
    NumPut("UInt", modBuf.Size, blob, 12)
    Loop expBuf.Size
        NumPut("UChar", NumGet(expBuf, A_Index - 1, "UChar"), blob, 24 + A_Index - 1)
    Loop modBuf.Size
        NumPut("UChar", NumGet(modBuf, A_Index - 1, "UChar"), blob, 24 + expBuf.Size + A_Index - 1)
    ok := false
    if (DllCall("bcrypt\BCryptImportKeyPair", "Ptr", hAlg, "Ptr", 0, "Str", "RSAPUBLICBLOB"
               , "Ptr*", &hKey, "Ptr", blob, "UInt", cb, "UInt", 0) = 0) {
        hash := Sha256Buf(msg)
        sg   := HexToBuf(sigHex)
        alg  := Buffer(64, 0)
        StrPut("SHA256", alg, "UTF-16")
        pad  := Buffer(A_PtrSize, 0)
        NumPut("Ptr", alg.Ptr, pad, 0)
        ok := (DllCall("bcrypt\BCryptVerifySignature", "Ptr", hKey, "Ptr", pad
                     , "Ptr", hash, "UInt", 32, "Ptr", sg, "UInt", sg.Size
                     , "UInt", BCRYPT_PAD_PKCS1) = 0)
        DllCall("bcrypt\BCryptDestroyKey", "Ptr", hKey)
    }
    DllCall("bcrypt\BCryptCloseAlgorithmProvider", "Ptr", hAlg, "UInt", 0)
    return ok
}

; 公開鍵の仕組みが、この PC で正しく動くかを確かめる（実機での安全確認用）
ModeVerifyTest() {
    global APP_NAME
    msg := "TEST|動作確認用|2027-03-31|2026-10-03|LAPTOP-VVFENRIS"
    sig := "67003c6f56cccf7a823b0d4245d83d4da47dcdeea2c2fa6fc6e828a0c27481ecac0ff6b4131ffd1dad4111841e5796dc589528740721741b97df1d007d8c4074025d9ccd8d2dd9946f2037f37c5d5bd7652496bc113761c255919712c4fd527df66aa6566407a2dcac2a12f2ae65d1d4461f1d496fd1131d9da6105616481a0a23c18a98cb4ee2cb99c407d6f5197fbb380781dda90c789ade3c3c840c4a0560fbe29aa233d8b9d3717a9127079ce2c40b5e9007fa42927ce8706e07c1caf779fbe5143613556d7123489d836562504cf095cd0e0753876b08174f9040b885ccd0d6dcca65d2922974ad7b9cf2d22001456dce4ae2e830dcfda412968a13941c"
    good := RsaVerify(msg, sig)
    bad  := RsaVerify(msg . "x", sig)          ; 本文を変えたら false になるはず
    okAll := (good && !bad)
    Log(okAll ? "INFO" : "ERROR", "公開鍵の自己診断: 正しい署名=" . (good ? "OK" : "NG")
        . " ／ 改ざんを弾く=" . (bad ? "NG" : "OK"))
    ; ★三項演算子を行で割らない★ 行頭の : はラベルと紛らわしく、起動不能になる。
    ;   先に変数へ入れてから組み立てる（今夜 3 度目の同じ間違い）。
    tail := "この PC では動きませんでした。いまの方式のままにします。"
    if (okAll)
        tail := "この PC では公開鍵方式が使えます。"
    MsgBox("公開鍵のしくみの自己診断`n`n"
        . "　正しい署名を受け入れる : " . (good ? "OK" : "★NG★") . "`n"
        . "　書き換えを弾く     : " . (bad ? "★NG★" : "OK") . "`n`n"
        . tail
        , APP_NAME . " - 自己診断", okAll ? "Iconi 4096" : "Iconx 4096")
    ExitApp(okAll ? 0 : 1)
}

LicenseCheck() {
    global LICFILE
    out := Map("state", "none", "name", "", "expires", "", "days", 0, "why", "")
    ; ★通行証（オンライン確認）が生きていれば、そちらを使う★
    ;   鍵ファイルしか無い人は、これまでどおり鍵ファイルで動く。
    p := PassCheck()
    if (p["ok"])
        return p["lic"]
    ; 通行証が壊れている／別 PC のものだったときは、「未登録」ではなくそう言う
    if (!p["gone"] && p["notice"] != "" && !FileExist(LICFILE)) {
        out["state"] := (p["notice"] = "wrongpc") ? "wrongpc" : "broken"
        ; ★三項演算子を行で割らない★ 行頭の : はラベルと紛らわしく、起動不能になる
        if (p["notice"] = "wrongpc")
            out["why"] := "この利用者コードは別のパソコンに登録されています"
        else
            out["why"] := "利用の情報を読み取れません（登録し直してください）"
        return out
    }
    if (p["gone"] && !FileExist(LICFILE)) {
        n := p["notice"]
        if (n = "stopped" || n = "unknown") {
            out["state"] := "stoppedover"
            out["why"]   := "ご利用の停止により、使用できなくなりました"
        } else if (n = "expired") {
            out["state"] := "planover"
            out["why"]   := "有効期限が切れています"
        } else if (n = "wrongpc") {
            out["state"] := "wrongpc"
            out["why"]   := "この利用者コードは別のパソコンに登録されています"
        } else {
            out["state"] := "passexpired"
            out["why"]   := "確認できない日が続き、期限が切れました"
        }
        return out
    }
    if (!FileExist(LICFILE)) {
        out["why"] := "利用者コードが登録されていません"
        return out
    }
    m := IniLoad(LICFILE)
    nm  := Trim(IniGet(m, "License", "Name", ""))
    exp := Trim(IniGet(m, "License", "Expires", ""))
    mac := Trim(IniGet(m, "License", "Machine", ""))
    sig  := Trim(IniGet(m, "License", "Sign", ""))
    sig2 := Trim(IniGet(m, "License", "Sign2", ""))
    out["name"] := nm, out["expires"] := exp
    if (nm = "" || exp = "" || sig2 = "") {
        out["state"] := "broken", out["why"] := "利用の情報が足りません"
        return out
    }
    if (sig2 = "" || !RsaVerify(Sha256Hex(nm . "|" . exp . "|" . mac), sig2)) {
        out["state"] := "forged", out["why"] := "利用の情報の署名が合いません（書き換えられています）"
        return out
    }
    if (mac != "" && StrLower(mac) != StrLower(A_ComputerName)) {
        out["state"] := "wrongpc"
        out["why"] := Format("この鍵は別の PC 用です（鍵: {1} ／ この PC: {2}）", mac, A_ComputerName)
        return out
    }
    ymd := StrReplace(exp, "-", "")
    if (StrLen(ymd) != 8) {
        out["state"] := "broken", out["why"] := "期限の書き方が不正です: " exp
        return out
    }
    today := FormatTime(A_Now, "yyyyMMdd")
    out["days"] := DateDiff(ymd . "000000", today . "000000", "Days")
    if (out["days"] < 0) {
        out["state"] := (Abs(out["days"]) <= CI("LicenseGraceDays")) ? "grace" : "expired"
        out["why"] := Format("期限 {1} を {2} 日過ぎています", exp, Abs(out["days"]))
        return out
    }
    out["state"] := (out["days"] <= CI("LicenseWarnDays")) ? "soon" : "ok"
    out["why"] := Format("期限 {1} まであと {2} 日", exp, out["days"])
    return out
}

; 実行系に入る直前の関門。止めるときはここで終わる。
;   ★起動時の mode だけで見てはいけない★
;   メニューから「調査」「スケジュール運転」へ入ると、同じプロセスのまま
;   モードが変わるため、起動時の判定では素通りする（2026-09-18 に気づいた）。
;   だから実行系の入口すべてで、ここを通す。
; ★人が見ているときだけ知らせる★
;   起動のたびに窓を出すと、無人で動く夜間に「誰も押せない窓」が残る。
;   見張り・スタートアップで一度やった失敗（2026-09-18）。
;   そこで、人がメニューを開いたときにだけ呼ぶ。
;   戻り値 true = 「いまコードを入れる」を選んだ。
; --- 新しい版のお知らせ（第 1 段階：知らせるだけ）----------------------------
;   UpdateUrl には「版番号だけを書いた小さなテキスト」の URL を入れる。
;     例: https://raw.githubusercontent.com/<所有者>/<リポジトリ>/main/version.txt
;   ★取りに行くのは、人がメニューを開いたときだけ★
;     無人の運転中に通信や入れ替えを起こさない。夜中に中身が変わる方が危険。
;   ★つながらなくても何もしない★ 確認の失敗を運転に波及させない。
; ★取得先はツールに埋め込んでおく★
;   2026-09-22、他社の PC へ zip で配ったところ、config.ini に取得先が無く
;   「更新の取得先が設定されていません」で止まった。
;   設定ファイルに書いてあればそれを使い、空なら埋め込みの公開 URL を使う。
UpdateUrlOf(which) {
    v := Trim(CS(which = "zip" ? "UpdateZipUrl" : "UpdateUrl"))
    if (v != "")
        return v
    base := "https://raw.githubusercontent.com/kyhfe013/autometa-updates/main/"
    return base . (which = "zip" ? "AutoMeta.zip" : "version.txt")
}

UpdateCheck() {
    global APP_VER
    url := UpdateUrlOf("ver")
    if (url = "")
        return ""                                   ; 使わない設定
    body := ""
    try {
        http := ComObject("WinHttp.WinHttpRequest.5.1")
        http.SetTimeouts(3000, 5000, 5000, 8000)
        http.Open("GET", url, false)
        http.Send()
        body := http.ResponseText
    } catch as e {
        Log("INFO", "新しい版の確認はできませんでした（" . e.Message . "）")
        return ""
    }
    ver := ""
    Loop Parse, body, "`n", "`r" {
        t := Trim(A_LoopField)
        if (t != "" && SubStr(t, 1, 1) != ";") {
            ver := t
            break
        }
    }
    if (ver = "" || !VerNewer(ver, APP_VER))
        return ""
    Log("INFO", "新しい版があります: " . ver . "（いまは " . VerNumOnly(APP_VER) . "）")
    return ver
}

; 「2.13.0 (説明)」から「2.13.0」だけ取り出す
VerNumOnly(v) {
    v := Trim(v)
    if (p := InStr(v, " "))
        v := SubStr(v, 1, p - 1)
    return v
}

; a が b より新しいか（数字を . で区切って比べる）
VerNewer(a, b) {
    aa := StrSplit(VerNumOnly(a), "."), bb := StrSplit(VerNumOnly(b), ".")
    Loop 4 {
        x := (aa.Length >= A_Index) ? ToInt(aa[A_Index], 0) : 0
        y := (bb.Length >= A_Index) ? ToInt(bb[A_Index], 0) : 0
        if (x != y)
            return (x > y)
    }
    return false
}

; --- 新しい版に入れ替える（第 2 段階）--------------------------------------
;   ★人が選んだときだけ★ 無人の運転中には絶対に動かさない。
;   ★利用者のものには触らない★ 設定・予定・履歴・鍵・通行証は zip に入っていない。
;   ★失敗したら古いまま★ 取得や展開が途中で終わったら、何も置き換えずに戻る。
ModeUpdate() {
    global APP_NAME, APP_VER
    zipUrl := UpdateUrlOf("zip")
    if (zipUrl = "") {
        MsgBox("更新の取得先が設定されていません。`n`n設定ファイルの UpdateZipUrl をご確認ください。", APP_NAME, "Icon! 4096")
        ExitApp(1)
    }
    nv := UpdateCheck()
    if (nv = "") {
        MsgBox("お使いの版が最新です（" . VerNumOnly(APP_VER) . "）。", APP_NAME, "Iconi 4096")
        ExitApp(0)
    }
    r := MsgBox("新しい版 " . nv . " に更新します。`n`n"
        . "　いまの版: " . VerNumOnly(APP_VER) . "`n`n"
        . "設定・予定・実行履歴・鍵は、そのまま残ります。`n"
        . "更新後、自動で再起動します。よろしいですか？"
        , APP_NAME . " - 更新", "YesNo Iconi 4096")
    if (r != "Yes")
        ExitApp(0)

    tmp := A_Temp . "\AutoMeta_update"
    zip := tmp . "\new.zip"
    try DirDelete(tmp, true)
    try DirCreate(tmp)
    Log("INFO", "更新: 取得を開始します " . zipUrl)
    ok := false
    try {
        Download(zipUrl, zip)
        ok := FileExist(zip) ? true : false
    } catch as e {
        Log("WARN", "更新: 取得に失敗しました（" . e.Message . "）")
    }
    if (!ok || FileGetSize(zip) < 10000) {
        MsgBox("新しい版を取りに行けませんでした。`n`n"
            . "いまの版のまま、これまでどおりお使いいただけます。`n"
            . "インターネットにつながっているかご確認ください。"
            , APP_NAME . " - 更新", "Iconx 4096")
        ExitApp(1)
    }
    ; Windows 10 以降に標準で入っている tar で展開する
    rc := 1
    try rc := RunWait(A_ComSpec . " /c tar -xf " . Chr(34) . zip . Chr(34)
        . " -C " . Chr(34) . tmp . Chr(34), , "Hide")
    src := tmp . "\AutoMeta\system"
    if (rc != 0 || !FileExist(src . "\AutoMeta.ahk")) {
        Log("WARN", "更新: 展開に失敗しました（戻り値 " . rc . "）")
        MsgBox("新しい版を取り出せませんでした。`n`n"
            . "いまの版のまま、これまでどおりお使いいただけます。"
            , APP_NAME . " - 更新", "Iconx 4096")
        ExitApp(1)
    }
    ; ★上書きするのは zip に入っているものだけ★
    ;   設定・予定・履歴・鍵・通行証・ログは zip に無いので、触れようがない。
    n := 0
    Loop Files, src . "\*.*" {
        try {
            FileCopy(A_LoopFileFullPath, A_ScriptDir . "\" . A_LoopFileName, true)
            n++
        } catch as e {
            ; ★動作中の実行ファイルは掴まれていて置き換えられない★
            ;   AutoHotkey64.exe はまず変わらないので、失敗しても騒がない。
            if (A_LoopFileName = "AutoHotkey64.exe")
                Log("INFO", "更新: AutoHotkey64.exe は使用中のため、そのままにします")
            else
                Log("WARN", "更新: " . A_LoopFileName . " を置き換えられません（" . e.Message . "）")
        }
    }
    up := tmp . "\AutoMeta"
    Loop Files, up . "\*.bat" {
        try FileCopy(A_LoopFileFullPath, A_ScriptDir . "\..\" . A_LoopFileName, true)
    }
    Log("INFO", Format("更新: {1} 個のファイルを入れ替えました（{2} へ）", n, nv))
    try DirDelete(tmp, true)
    MsgBox("更新しました（" . nv . "）。`n`n再起動します。", APP_NAME . " - 更新", "Iconi 4096")
    try Run(Chr(34) . A_AhkPath . Chr(34) . " " . Chr(34) . A_ScriptFullPath . Chr(34) . " /menu"
          , A_ScriptDir)
    ExitApp(0)
}

LicenseNudge() {
    global APP_NAME, G
    lic := LicenseCheck()
    st  := lic["state"]
    if (st = "ok")
        return false
    if (st = "ending") {
        MsgBox("まもなく利用できなくなります。`n`n　" . lic["why"] . "`n`n"
            . "上の日付までは、これまでどおり動きます。`n"
            . "続けてお使いになる場合は、ご連絡ください。"
            , APP_NAME . " - 利用の期限", "Icon! 4096")
        return false
    }
    if (st = "offline") {
        MsgBox("インターネットにつないでください。`n`n　" . lic["why"] . "`n`n"
            . "このソフトは 2 週間に 1 度、インターネットで利用の確認をします。`n"
            . "つながった状態でこのソフトを開けば、それだけで確認は終わります。`n"
            . "（ほかの操作は要りません）"
            , APP_NAME . " - インターネットにつないでください", "Icon! 4096")
        return false
    }
    if (st = "soon" || st = "grace") {
        MsgBox("利用の期限が近づいています。`n`n　" . lic["why"] . "`n`n"
            . "更新のご連絡をお願いします。"
            , APP_NAME . " - 利用の期限", "Iconi 4096")
        return false
    }
    if (st = "none")
        msg := "まだ利用者コードが入っていません。"
    else if (st = "expired")
        msg := "利用の期限が切れています。（" . lic["why"] . "）"
    else if (st = "passexpired")
        msg := "確認できない日が続き、期限が切れました。"
    else if (st = "stoppedover")
        msg := "ご利用が停止されています。"
    else if (st = "planover")
        msg := "利用の期限が切れています。"
    else if (st = "wrongpc")
        msg := "この利用者コードは別のパソコン用です。"
    else
        msg := "利用の確認ができません。（" . lic["why"] . "）"
    r := MsgBox(msg . "`n`n"
        . "このままでは調査・セラピーを実行できません。`n"
        . "（設定や診断は、これまでどおりお使いになれます）`n`n"
        . "いま利用者コードを入れますか？"
        , APP_NAME . " - 利用の確認", "YesNo Icon! 4096")
    return (r = "Yes")
}

LicenseGate() {
    global APP_NAME, G, STATEINI
    lic := LicenseCheck()
    if (!LicenseBlocks(lic))
        return true
    ; ★同じ警告を 5 分おきに積まない★
    ;   見張りは 1 日 288 回来る。実行できない状態が続くとログが埋まる（2026-09-20 指摘）。
    ;   無人の入口では、同じ理由につき 1 日 1 回だけ残す。
    if (G.mode = "resume") {
        mark := FormatTime(A_Now, "yyyyMMdd") . "|" . lic["state"]
        if (Trim(IniGet(IniLoad(STATEINI), "License", "LastBlockLog", "")) != mark) {
            IniSet(STATEINI, "License", "LastBlockLog", mark)
            Log("WARN", "利用の期限により実行を止めました: " lic["why"] "（以後この記録は 1 日 1 回）")
        }
    } else
        Log("WARN", "利用の期限により実行を止めました: " lic["why"])
    ; ★無人の入口では窓を出さない★
    ;   /resume は見張りが 5 分ごとに呼ぶ。ここで窓を出すと、夜のあいだに
    ;   誰も押せない窓が積み上がる。起動時にすでに知らせた場合も同じ。
    if (G.mode = "resume")
        ExitApp(1)
    ; ★状態ごとに、やることを書き分ける★
    ;   「期限を確認できない」と言いながら期限は分かっている、
    ;   鍵はあるのに「置いてください」と案内する、といった食い違いを無くす。
    ;   お客様に出す文面なので、次にすることが一読で分かるようにする。
    st := lic["state"]
    if (st = "expired") {
        head := "利用の期限が切れています。"
        tell := "継続してお使いになる場合は、ご連絡をお願いします。"
    } else if (st = "forged") {
        head := "利用の情報が書き換えられています。"
        tell := "メニューの「設定 → 利用者コードを入れる」から、`n"
             . "コードを入れ直してください。"
    } else if (st = "wrongpc") {
        head := "この利用者コードは別のパソコン用です。"
        tell := "このパソコンでお使いになる場合は、ご連絡をお願いします。"
    } else if (st = "stoppedover") {
        head := "ご利用が停止されています。"
        tell := "継続してお使いになる場合は、ご連絡をお願いします。"
    } else if (st = "planover") {
        head := "利用の期限が切れています。"
        tell := "継続してお使いになる場合は、ご連絡をお願いします。"
    } else if (st = "passexpired") {
        head := "インターネットにつながないまま 2 週間が過ぎました。"
        tell := "インターネットにつないで、このソフトをもう一度開いてください。`n"
             . "それだけで元どおり使えるようになります（ほかの操作は要りません）。"
    } else if (st = "broken") {
        head := "利用の情報を読み取れません。"
        tell := "メニューの「設定 → 利用者コードを入れる」から、`n"
             . "コードを入れ直してください。"
    } else {
        head := "まだ利用者コードが入っていません。"
        tell := "メニューの「設定 → 利用者コードを入れる」からご登録ください。"
    }
    MsgBox(head "`n`n"
        . "　" lic["why"] "`n`n"
        . tell "`n`n"
        . "設定と診断の画面は、このままお使いいただけます。"
        , APP_NAME " - 利用の期限", "Iconx 4096")
    ExitApp(1)
}

; 実行してよいか。★設定では緩められない★（LICENSE_REQUIRED はソース側の固定値）
LicenseBlocks(lic) {
    global LICENSE_REQUIRED
    if (!LICENSE_REQUIRED)
        return false
    return (lic["state"] = "none" || lic["state"] = "broken" || lic["state"] = "forged"
         || lic["state"] = "wrongpc" || lic["state"] = "expired"
         || lic["state"] = "passexpired" || lic["state"] = "stoppedover"
         || lic["state"] = "planover")
}

; =============================================================================
;  落ちたあとの復帰（H-1）
;   ★中断したジョブは再開しない★
;     途中まで進んだセラピーを再開すると、二重に施術することになる。
;     どこまで終わったかは画面からは分からないので、【確認待ち】に残して人に返す。
;   再開するのは「スケジュール運転そのもの」だけ。予定の時刻が来れば普通に走る。
; =============================================================================
ResumeCheck() {
    global STATEINI, PENDFILE
    m := IniLoad(STATEINI)
    if (Trim(IniGet(m, "Scheduler", "Running", "0")) != "1")
        return false                               ; 前回はきちんと終わっている
    startedAt := Trim(IniGet(m, "Scheduler", "StartedAt", ""))
    Log("WARN", Format("前回のスケジュール運転が終了していません（開始 {1}）。落ちたものとみなします"
        , startedAt = "" ? "不明" : startedAt))
    who   := Trim(IniGet(m, "Job", "Patient", ""))
    jstat := Trim(IniGet(m, "Job", "State", ""))
    if (who != "" && jstat != "" && jstat != "idle") {
        done  := Trim(IniGet(m, "Job", "TherapyDone", "0"))
        total := Trim(IniGet(m, "Job", "TherapyTotal", "0"))
        nm := StrSplit(who, " ")
        line := FormatTime(A_Now, "yyyyMMddHHmmss") "|0|"
              . (nm.Length >= 1 ? nm[1] : "") "|" (nm.Length >= 2 ? nm[2] : "") "|"
              . Format("★途中で止まりました（{1} の段階／セラピー {2} / {3} 回）"
                     . "　ソフト側の履歴で、どこまで行われたか確認してください", jstat, done, total)
        try FileAppend(CRLF(line "`n"), PENDFILE, "UTF-8")
        Log("WARN", Format("中断したジョブを確認待ちに残しました: {1}（{2}）", who, jstat))
        IniSet(STATEINI, "Job", "State", "idle")   ; 同じ通知を繰り返さない
    }
    return true
}

; PC 起動時に自動で立ち上げる（H-2）
;   ★登録するのは /resume★
;     /schedule で登録すると、意図的に止めた翌日に勝手に走り出してしまう。
;     /resume なら「前回落ちていたときだけ拾う」という意図どおりになる。
StartupRegPath() => "HKCU\Software\Microsoft\Windows\CurrentVersion\Run"

StartupIsOn() {
    v := ""
    try v := RegRead(StartupRegPath(), "AutoMeta")
    return (Trim(v) != "")
}

StartupLabel() {
    if (StartupIsOn())
        return "PC 起動時の自動立ち上げ：登録済み（押すと解除）"
    return "PC 起動時に自動で立ち上げる（いまは未登録）"
}

ToggleStartup() {
    global APP_NAME
    if (StartupIsOn()) {
        try RegDelete(StartupRegPath(), "AutoMeta")
        Log("INFO", "スタートアップ登録を解除しました")
        MsgBox("PC 起動時の自動立ち上げを【解除】しました。", APP_NAME, "Iconi 4096")
        return
    }
    cmd := Chr(34) A_AhkPath Chr(34) " " Chr(34) A_ScriptFullPath Chr(34) " /resume"
    try {
        RegWrite(cmd, "REG_SZ", StartupRegPath(), "AutoMeta")
    } catch as e {
        Log("WARN", "スタートアップに登録できません: " e.Message)
        MsgBox("登録できませんでした。`n`n" e.Message, APP_NAME, "Iconx 4096")
        return
    }
    Log("INFO", "スタートアップに登録しました: " cmd)
    MsgBox("PC 起動時に自動で立ち上がるようにしました。`n`n"
        . "※ 立ち上がっても、運転を再開するのは【前回が落ちていたとき】だけです。`n"
        . "　 きちんと止めていた場合は、何もせずに終了します。"
        , APP_NAME, "Iconi 4096")
}

; 見張り（H-3）
;   ★新しい仕組みは作らない★
;     /resume は「動いていれば何もせず終了、落ちていれば拾う」。
;     これを数分おきに走らせれば、それがそのまま見張りになる。
;   PC が動いたままツールだけが落ちた場合を拾う（再起動を待たずに済む）。
WatchTaskName() => "AutoMeta_Watch"

WatchdogIsOn() {
    q := Chr(34)
    cmd := A_ComSpec . " /c schtasks /query /tn " . q . WatchTaskName() . q . " >nul 2>&1"
    rc := 1
    try rc := RunWait(cmd, , "Hide")
    return (rc = 0)
}

WatchdogLabel() {
    if (WatchdogIsOn())
        return "落ちていたら自動で立ち上げ直す：見張り中（押すと解除）"
    return "落ちていたら自動で立ち上げ直す（5 分ごとに確認・いまは未設定）"
}

; 見張りのタスクが AutoHotkey を直接呼ぶ形で登録できているか
;   /tr の引用符は環境で崩れることがあるので、登録したら中身を読んで確かめる。
WatchTaskRunsAhk() {
    q   := Chr(34)
    tmp := A_Temp . "\automata_watch_task.txt"
    try FileDelete(tmp)
    try RunWait(A_ComSpec . " /c schtasks /query /tn " . q . WatchTaskName() . q
        . " /fo LIST /v > " . q . tmp . q . " 2>&1", , "Hide")
    body := ""
    try body := FileRead(tmp, "CP0")            ; schtasks の出力は既定の文字コード
    try FileDelete(tmp)
    return InStr(body, "AutoHotkey") > 0
}

ToggleWatchdog() {
    global APP_NAME
    if (WatchdogIsOn()) {
        q := Chr(34)
        cmd := A_ComSpec . " /c schtasks /delete /f /tn " . q . WatchTaskName() . q . " >nul 2>&1"
        try RunWait(cmd, , "Hide")
        Log("INFO", "見張りを解除しました")
        MsgBox("見張りを【解除】しました。", APP_NAME, "Iconi 4096")
        return
    }
    ; ★黒い窓を出さない★
    ;   以前は _watch.cmd（バッチ）を登録していたため、5 分ごとに cmd.exe の窓が
    ;   画面の中央に一瞬だけ出ていた（2026-09-19 指摘。1 日 241 回）。
    ;   AutoHotkey64.exe を直接登録すれば、窓は出ない。
    q   := Chr(34)
    esc := "\" . q                                ; /tr の中で使う引用符
    tr  := esc . A_AhkPath . esc . " " . esc . A_ScriptFullPath . esc . " /resume"
    mk  := A_ComSpec . " /c schtasks /create /f /tn " . q . WatchTaskName() . q
         . " /sc minute /mo 5 /tr " . q . tr . q . " >nul 2>&1"
    rc  := 1
    how := "直接起動／黒い窓は出ません"
    try rc := RunWait(mk, , "Hide")
    ; 登録できても、引用符が崩れて中身が壊れていることがある。読んで確かめる。
    if (rc = 0 && !WatchTaskRunsAhk())
        rc := 1

    if (rc != 0) {
        ; ★通らない環境では、これまでどおり .cmd を経由する★
        ;   窓は一瞬出るが、見張りが働かないよりはよい。
        Log("WARN", "直接登録できなかったので _watch.cmd を使います")
        how := "_watch.cmd 経由／黒い窓が一瞬出ます"
        cmdFile := A_ScriptDir . "\_watch.cmd"
        body := "@echo off`r`nstart " . q . q . " " . q . A_AhkPath . q . " "
              . q . A_ScriptFullPath . q . " /resume`r`n"
        try {
            if FileExist(cmdFile)
                FileDelete(cmdFile)
            FileAppend(body, cmdFile, "CP0")       ; cmd.exe が読める文字コードで書く
        } catch as e {
            MsgBox("見張り用のファイルを作れませんでした。`n`n" . e.Message, APP_NAME, "Iconx 4096")
            return
        }
        mk := A_ComSpec . " /c schtasks /create /f /tn " . q . WatchTaskName() . q
            . " /sc minute /mo 5 /tr " . q . cmdFile . q . " >nul 2>&1"
        rc := 1
        try rc := RunWait(mk, , "Hide")
    }
    if (rc != 0) {
        Log("WARN", "見張りを設定できませんでした（schtasks の戻り値 " . rc . "）")
        MsgBox("見張りを設定できませんでした（戻り値 " . rc . "）。`n`n"
            . "Windows のタスクスケジューラが使えない環境かもしれません。"
            , APP_NAME, "Iconx 4096")
        return
    }
    ; ★どちらの方式で登録したかを残す★
    ;   あとからログだけで判断できるようにする（2026-09-19 指摘）。
    Log("INFO", "見張りを設定しました（5 分ごとに /resume ／ " . how . "）")
    MsgBox("5 分ごとに様子を見て、落ちていたら立ち上げ直します。`n`n"
        . "※ 動いているときは何もしません。`n"
        . "※ きちんと止めた場合も、勝手に動き出すことはありません。`n"
        . "※ 画面には何も出ません（黒い窓は出ません）。"
        , APP_NAME, "Iconi 4096")
}

; スタートアップから呼ばれる入口。前回落ちていたときだけ運転を再開する
ModeResume() {
    global APP_NAME
    ; ★見るのではなく、その場で鍵を取る★
    ;   「見てから取る」だと、2 つがほぼ同時に立ち上がったとき両方とも通過し、
    ;   対象ソフトを二重に起動したり、ダイアログを残したりする（2026-09-18 指摘）。
    ;   取れなければ黙って終わる。窓は出さない。
    EnsureSingleInstance(true)
    if (!ResumeCheck()) {
        Log("INFO", "前回はきちんと終わっているので、何もしません")
        ExitApp(0)
    }
    Log("INFO", "=== 落ちた前回の運転を引き継ぎます ===")
    try TrayTip("前回の運転を引き継ぎました`n中断したぶんは確認待ちに残しています", APP_NAME)
    ModeSchedule()
}

; ★G5★ 二重起動の禁止
;   2026-09-14 の実機で、スケジューラを 2 つ起動してしまい、
;   2 つの状態機械が同じ画面を取り合って誤動作した。仕様書に書いてあったのに未実装だった。
;   名前付きミューテックスで、実行系のモードは 1 つだけに制限する。
EnsureSingleInstance(quiet := false) {
    global APP_NAME
    static hMutex := 0
    ; ★このプロセスがすでに鍵を持っているなら、何もしない★
    ;   /resume が先に取り、そのあと ModeSchedule がもう一度呼ぶため。
    ;   同じ名前で作り直すと「すでに存在」と判定され、自分自身を締め出してしまう。
    if (hMutex)
        return true
    hMutex := DllCall("CreateMutexW", "Ptr", 0, "Int", 1, "Str", "AutoMeta_Job_Singleton", "Ptr")
    if (A_LastError = 183) {                        ; ERROR_ALREADY_EXISTS
        hMutex := 0
        ; ★無人の入口では窓を出さない★
        ;   見張り（5 分ごと）や自動起動で負けた側がダイアログを出すと、
        ;   深夜に誰も押せない窓が残り続ける（2026-09-18 指摘）。
        if (quiet) {
            Log("INFO", "すでに動いています。何もせず終わります")
            ExitApp(0)
        }
        MsgBox("AutoMeta はすでに実行中です。`n`n"
            . "二重に動かすと、2 つが同じ画面を取り合って誤動作します。`n`n"
            . "・セラピーだけなら、スケジュール運転を止めずに実行できます`n"
            . "　→ メニューの「▶ 自動セラピー」`n`n"
            . "・それ以外は、先に動いているものを終了してください`n"
            . "　→ 運転パネルの「止める」、または system\stop_all.bat"
            , APP_NAME, "Icon! 4096")
        ExitApp(1)
    }
}

; 対象プロセスの可視ウィンドウを z オーダー順（手前が先）で返す
TargetWindows(pid) {
    list := []
    try list := WinGetList("ahk_pid " pid)
    catch
        return []
    out := []
    for h in list {
        cls := "", ttl := ""
        try {
            cls := WinGetClass("ahk_id " h)
            ttl := WinGetTitle("ahk_id " h)
        } catch
            continue
        if (cls = "")
            continue
        ; ★ここでサイズを見て弾いてはいけない（v0.2.0 の重大なバグ）★
        ;   対象ソフトの指標ウィンドウ TFormDiagn は進行状況の更新のたびに作り直され、
        ;   その一瞬だけサイズが 0 になる（AutoTherapy v4 仕様書 §17.3）。
        ;   v0.2.0 はこれを「閉じた」と記録してしまい、実際には連続していたセラピーを
        ;   「4〜39 秒の途切れがある」と誤って報告した。AutoTherapy v4 の
        ;   IsTherapyRunning() はサイズを一切見ておらず、そちらが正しい。
        ;   サイズは情報として持つだけにして、窓の有無の判定には使わない。
        ww := 0, wh := 0
        try WinGetPos(, , &ww, &wh, "ahk_id " h)
        out.Push(Map("hwnd", h, "class", cls, "title", ttl, "w", ww, "h", wh))
    }
    return out
}

; ウィンドウのコントロールを [ClassNN, テキスト, 位置, 状態] で列挙する
DumpCtrls(hwnd) {
    rows := []
    ctrls := []
    try ctrls := WinGetControls("ahk_id " hwnd)
    catch
        return rows
    for cn in ctrls {
        tx := "", en := "?", vi := "?"
        try tx := ControlGetText(cn, "ahk_id " hwnd)
        try en := ControlGetEnabled(cn, "ahk_id " hwnd) ? "有効" : "無効"
        try vi := ControlGetVisible(cn, "ahk_id " hwnd) ? "表示" : "非表示"
        r := CtrlRect(hwnd, cn)
        rows.Push(Map("cnn", cn, "text", tx, "en", en, "vi", vi
                    , "x", r["ok"] ? r["x"] : "", "y", r["ok"] ? r["y"] : ""
                    , "w", r["ok"] ? r["w"] : "", "h", r["ok"] ? r["h"] : ""))
    }
    return rows
}

CtrlsToText(rows, indent := "       ") {
    out := ""
    withText := 0
    for r in rows {
        pos := (r["x"] = "") ? "" : Format("x{1} y{2} w{3} h{4}", r["x"], r["y"], r["w"], r["h"])
        tx  := StrReplace(StrReplace(r["text"], "`r", " "), "`n", " ")
        if (tx != "")
            withText++
        out .= Format("{1}- {2:-24} [{3}/{4}] {5:-26} : {6}`n"
             , indent, r["cnn"], r["vi"], r["en"], pos, (tx = "" ? "（テキストなし）" : tx))
    }
    out .= indent "（コントロール " rows.Length " 件 / テキストあり " withText " 件）`n"
    if (rows.Length > 0 && withText = 0)
        out .= indent "★テキストが 1 件も取れていません → 権限不足の可能性が高い（管理者版で再実行）`n"
    return out
}

; 画面を判定する。戻り値 Map("id", ..., "hit", 当たった署名テキスト)
ClassifyScreen(hwnd, rows := 0) {
    global SCREEN_CLASSES, SCREEN_SIGS
    ; まず実機で確定したクラス表を引く（推測より確実）
    cls := ""
    try cls := WinGetClass("ahk_id " hwnd)
    if (cls != "" && SCREEN_CLASSES.Has(cls))
        return Map("id", SCREEN_CLASSES[cls], "hit", "クラス既知")
    ; 表にないクラスだけ、署名テキストで推測する
    if !IsObject(rows)
        rows := DumpCtrls(hwnd)
    texts := []
    for r in rows {
        t := Norm(r["text"])
        if (t != "")
            texts.Push(t)
    }
    ttl := ""
    try ttl := Norm(WinGetTitle("ahk_id " hwnd))
    if (ttl != "")
        texts.Push(ttl)
    for sig in SCREEN_SIGS {
        id := sig[1]
        for want in sig[2] {
            w := Norm(want)
            for t in texts {
                if (t = w || InStr(t, w))
                    return Map("id", id, "hit", want)
            }
        }
    }
    return Map("id", "UNKNOWN", "hit", "")
}

; クリック位置を人間に読める形で説明する。
; 対象ソフトはボタンの一部が「描画」でコントロールが無いため、
; 「どのコントロールの何 px 右か」で表現できないと記録が読めない。
DescribeClick(hwnd, cx, cy, ctrlNN) {
    if (ctrlNN != "") {
        tx := ""
        try tx := Norm(ControlGetText(ctrlNN, "ahk_id " hwnd))
        return ctrlNN . (tx = "" ? "（テキストなし）" : "「" . tx . "」")
    }
    ; コントロールが取れない＝描画されたボタン。同じ行の左右のコントロールで位置を説明する
    rows := DumpCtrls(hwnd)
    bestLd := -1, bestLt := "", bestRd := -1, bestRt := ""
    for r in rows {
        if (r["x"] = "" || Norm(r["text"]) = "")
            continue
        rowTop := r["y"], rowBot := r["y"] + r["h"]
        if (cy < rowTop - 8 || cy > rowBot + 8)      ; 同じ行にないものは無視
            continue
        if (r["x"] + r["w"] <= cx) {
            d := cx - (r["x"] + r["w"])
            if (bestLd < 0 || d < bestLd) {
                bestLd := d, bestLt := Norm(r["text"])
            }
        }
        if (r["x"] >= cx) {
            d := r["x"] - cx
            if (bestRd < 0 || d < bestRd) {
                bestRd := d, bestRt := Norm(r["text"])
            }
        }
    }
    desc := "（コントロールなし＝描画ボタン）"
    if (bestLd >= 0)
        desc .= " 「" bestLt "」の右 " bestLd "px"
    if (bestRd >= 0)
        desc .= " / 「" bestRt "」の左 " bestRd "px"
    return desc
}

;==============================================================================
;  ログ
;==============================================================================
; ★日をまたいだら、その日のファイルへ移る★
;   ログの名前は起動時に 1 度だけ決めていた。そのため 2026-09-18 23:08 に始めた
;   運転は、翌朝 02:57 の完了まで全部 9/18 のファイルに書かれ、朝ログを見るのに
;   前日ぶんが要った（2026-09-19 指摘）。両方に継ぎ目を残し、追えるようにする。
LogRollover() {
    global G, LOGDIR
    want := LOGDIR . "\" . FormatTime(A_Now, "yyyy-MM-dd") . ".log"
    if (G.logFile = "" || want = G.logFile)
        return
    prev  := G.logFile
    stamp := FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss")
    try FileAppend(CRLF(stamp . " [INFO] 日付が変わりました。続きは " . want . " に書きます`r`n"), prev, "UTF-8")
    G.logFile := want
    try FileAppend(CRLF(stamp . " [INFO] 前日から続いている運転です（前半は " . prev . "）`r`n"), want, "UTF-8")
}

Log(level, msg) {
    global G
    LogRollover()
    line := FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss") " [" level "] " msg "`r`n"
    ; ★書けなかったら、やり直す★
    ;   ログを開いたまま見ていると書き込みが弾かれ、その行が黙って消えていた。
    ;   2026-09-17、これで 3 回も原因調査を遠回りした。
    ;   完全な記録は諦めてよいが、★欠けたことが分からない★のが問題。
    Loop 3 {
        try {
            FileAppend(CRLF(line), G.logFile, "UTF-8")
            return
        }
        Sleep(60)
    }
    G.logLost += 1
}

RotateLogs() {
    global LOGDIR, C
    days := 30
    Loop Files, LOGDIR "\*.log" {
        if (DateDiff(A_Now, A_LoopFileTimeModified, "Days") > days)
            try FileDelete(A_LoopFileFullPath)
    }
}

;==============================================================================
;  対象プロセスの特定
;==============================================================================
; ★対象ソフトが落ちていたら、起動して待つ★
;   2026-09-17 の要望。本体が落ちると、以後の予定がすべて空振りになる。
;   ★待つあいだ止まらないこと★
;     ここで Sleep して待つと、待っている間パネルも「止める」も効かなくなる。
;     そこで「起動を頼んで、いったん戻る」。次の巡回でまた見に来る。
;   立ち上がらなければ false を返す。呼び側は予定を始めない（次の機会に回す）。
EnsureTargetRunning(&why) {
    global G
    why := ""
    exe := CS("ExeName")
    if (exe = "") {
        why := "対象ソフトが設定されていません（設定 →「対象ソフトを設定する」）"
        return false
    }
    if (G.pid := FindPidByExe(exe)) {
        G.appLaunchTS := ""
        return true
    }
    if (G.appLaunchTS != "") {                     ; すでに起動を頼んである
        if (SecSince(G.appLaunchTS) < CI("LaunchWaitSec")) {
            why := "対象ソフトの起動を待っています"
            return false
        }
        why := Format("対象ソフトを起動しましたが、{1} 秒たっても現れませんでした"
            , CI("LaunchWaitSec"))
        G.appLaunchTS := ""
        return false
    }
    path := CS("ExePath")
    if (path = "" || !FileExist(path)) {
        why := "対象ソフト「" exe "」が起動しておらず、場所も分かりません"
             . "（設定 →「対象ソフトを設定する」で覚え直してください）"
        return false
    }
    ; ★自分のフォルダを作業フォルダにして起動する★
    ;   2026-09-18、場所だけ指定して起動したところ、メタアナライザー側が
    ;   「EStringListError / List index out of bounds (0)」で落ちた。
    ;   Delphi のソフトは自分のフォルダを基準に設定を読むため、
    ;   別の場所から起動されるとリストが空のまま進んでしまう。
    ;   手で起動したときは作業フォルダが自分のフォルダになるので表面化しない。
    dir := ""
    SplitPath(path, , &dir)
    Log("INFO", Format("対象ソフトが見つからないので起動します: {1}（作業フォルダ {2}）"
        , path, dir = "" ? "（不明）" : dir))
    try {
        Run(Chr(34) path Chr(34), dir)
    } catch as e {
        why := "対象ソフトを起動できませんでした: " e.Message
        return false
    }
    G.appLaunchTS := A_Now
    why := "対象ソフトを起動しました。立ち上がるのを待ちます"
    return false
}

; config に ExeName があればそれを使う。無ければ /setup へ誘導する。
EnsureTarget() {
    global C, G, APP_NAME
    exe := CS("ExeName")
    if (exe != "") {
        pid := FindPidByExe(exe)
        if (pid) {
            G.pid := pid
            return pid
        }
        MsgBox("config.ini に記録された対象ソフト「" exe "」が起動していません。`n`n"
            . "対象ソフトを起動してから、もう一度実行してください。`n"
            . "別のソフトを対象にしたい場合は「対象ソフトを設定する」を実行してください。"
            , APP_NAME, "Icon! 4096")
        ExitApp(1)
    }
    MsgBox("対象ソフトがまだ設定されていません。`n`n"
        . "先に「対象ソフトを設定する」（1_SETUP.bat）を実行してください。"
        , APP_NAME, "Icon! 4096")
    ExitApp(1)
}

; スケジュール運転の入口用。★対象ソフトが落ちていても止めない★
;   2026-09-18、夜中に PC が再起動して /resume で立ち上がっても、
;   その瞬間にメタアナライザーが落ちていれば EnsureTarget() がここで終了させ、
;   H-1〜H-3 の復帰が丸ごと無駄になることが分かった。
;   起動を頼んだうえで、見つからなくても運転だけは始める。
;   予定の直前に SchedTick がもう一度確かめる（そこで駄目なら見送り、警告は 10 分に 1 回）。
;   ※ 対面で使う「1 人だけ実行」「自動セラピー」は、人が見ているので従来どおり止める。
EnsureTargetForSchedule() {
    global G, APP_NAME
    exe := CS("ExeName")
    if (exe = "") {
        MsgBox("対象ソフトがまだ設定されていません。`n`n"
            . "先に「対象ソフトを設定する」（1_SETUP.bat）を実行してください。"
            , APP_NAME, "Icon! 4096")
        ExitApp(1)
    }
    if (G.pid := FindPidByExe(exe))
        return true
    why := ""
    EnsureTargetRunning(&why)                      ; 起動を頼む（待たずに戻る作り）
    Log("WARN", Format("対象ソフト「{1}」が起動していません（{2}）。"
        . "運転は始めます。予定の直前にもう一度確かめます", exe, why))
    return true
}

FindPidByExe(exe) {
    for h in WinGetList() {
        try {
            if (StrLower(WinGetProcessName("ahk_id " h)) = StrLower(exe))
                return WinGetPID("ahk_id " h)
        }
    }
    return 0
}

; 可視ウィンドウを持つプロセスを列挙する（自分自身と明らかな常駐物は除く）
ListCandidateProcesses() {
    static skip := Map("explorer.exe",1, "ApplicationFrameHost.exe",1, "SystemSettings.exe",1
                     , "TextInputHost.exe",1, "ShellExperienceHost.exe",1, "SearchHost.exe",1
                     , "StartMenuExperienceHost.exe",1, "AutoHotkey64.exe",1, "AutoHotkey32.exe",1)
    mine := MyPid()
    agg := Map()
    for h in WinGetList() {
        ttl := "", exe := "", pid := 0
        try {
            ttl := WinGetTitle("ahk_id " h)
            exe := WinGetProcessName("ahk_id " h)
            pid := WinGetPID("ahk_id " h)
        } catch
            continue
        if (ttl = "" || pid = mine || skip.Has(exe))
            continue
        if !agg.Has(exe)
            agg[exe] := Map("exe", exe, "pid", pid, "n", 0, "sample", ttl)
        agg[exe]["n"]++
    }
    out := []
    for k, v in agg
        out.Push(v)
    return out
}

;==============================================================================
;  /setup  対象ソフトを特定して config.ini に記録する
;==============================================================================
ModeSetup() {
    global CFG, APP_NAME, KNOWN_EXES
    cands := ListCandidateProcesses()
    if (cands.Length = 0) {
        MsgBox("ウィンドウを持つソフトが見つかりませんでした。`n対象ソフトを起動してから実行してください。"
            , APP_NAME, "Icon! 4096")
        ExitApp(1)
    }
    ; 既知の名前があれば先頭へ並べ替える
    known := [], other := []
    for c in cands {
        isKnown := false
        for k in KNOWN_EXES {
            if (StrLower(c["exe"]) = StrLower(k))
                isKnown := true
        }
        (isKnown ? known : other).Push(c)
    }
    ordered := []
    for c in known
        ordered.Push(c)
    for c in other
        ordered.Push(c)

    dlg := Gui("+AlwaysOnTop", APP_NAME " - 対象ソフトの設定" VerTag())
    dlg.MarginX := 14, dlg.MarginY := 12
    dlg.SetFont("s10", "Meiryo UI")
    dlg.Add("Text", "w760", "調査の対象にするソフトを選んでください。")
    dlg.Add("Text", "w760 cGray"
        , "ふつうは一番上（META ANALYZER.exe / 18D-NLS.exe）です。"
        . "これは記録するだけで、ソフトを操作することはありません。")
    lv := dlg.Add("ListView", "w760 h280 -Multi", ["実行ファイル", "ウィンドウ数", "ウィンドウ名の例"])
    for c in ordered
        lv.Add(, c["exe"], c["n"], c["sample"])
    lv.ModifyCol(1, 260), lv.ModifyCol(2, 90), lv.ModifyCol(3, 390)
    if (ordered.Length > 0)
        lv.Modify(1, "Select Focus")
    if (known.Length > 0)
        dlg.Add("Text", "w760 cGreen", "★ 1 行目は既知の対象ソフトです。ふつうはこれで合っています。")
    btn := dlg.Add("Button", "w200 h36 Default", "この設定を保存する")
    btn.OnEvent("Click", DoSave)
    dlg.OnEvent("Close", (*) => ExitApp(0))
    dlg.Show()
    return

    DoSave(*) {
        ; ★C（設定の入れ物）も宣言する★
        ;   抜けていたため、モデルを記録する行で「値が入っていません」になった
        ;   （2026-09-22、利用者の画面でエラー）。
        global CFG, APP_NAME, C
        r := lv.GetNext(0, "F")
        if (!r) {
            MsgBox("行を選んでください。", APP_NAME, "Icon! 4096")
            return
        }
        exe := lv.GetText(r, 1)
        IniSet(CFG, "Target", "ExeName", exe)
        ; ★モデルも一緒に記録する★
        ;   選択中の色がモデルで違うため（18D は青、Meta Analyzer はクリーム）。
        mdl := GuessModel(exe)
        if (mdl != "") {
            IniSet(CFG, "Model", "ModelName", mdl)
            C["ModelName"] := mdl
            ; Meta Analyzer は「カーソルに反応しない＝選択済み」で見分ける
            ht := (mdl = "MetaAnalyzer") ? "1" : "0"
            IniSet(CFG, "Model", "HoverTest", ht)
            C["HoverTest"] := ht
            Log("INFO", "モデルを自動で記録しました: " . mdl)
        }
        ; ★場所も控える★ 落ちていたときに起動し直せるようにする（2026-09-17）
        pth := ""
        try pth := ProcessGetPath(ordered[r]["pid"])
        if (pth != "")
            IniSet(CFG, "Target", "ExePath", pth)
        if (mdl = "") {
            ; 名前から判別できなかったときだけ、手で選んでもらう
            MsgBox("config.ini に記録しました。`n`n  対象ソフト: " exe "`n`n"
                . "モデルを自動で判別できませんでした。`n"
                . "次の画面で選んでください。", APP_NAME, "Icon! 4096")
            ModeModel()
            return
        }
        MsgBox("config.ini に記録しました。`n`n  対象ソフト: " exe "`n"
            . ("  モデル　　: " . mdl . "`n")
            . (pth = "" ? "  場所: （取得できませんでした）`n" : "  場所: " pth "`n") "`n"
            . "次は「1. 操作を記録する（/trace）」を実行してください。", APP_NAME, "Iconi 4096")
        ; ★続けてショートカットを作れるようにする★
        ;   次回からアイコンを押すだけで開ける（2026-09-19 指摘）。
        if (MsgBox("続けて、ショートカットを作りますか？`n`n"
            . "デスクトップとスタートメニューの両方に作ります。`n"
            . "次回からアイコンをダブルクリックするだけで使えます。"
            , APP_NAME, "YesNo Iconi 4096") = "Yes") {
            m2 := ""
            ok := CreateDesktopShortcut(&m2)
            MsgBox(m2, APP_NAME, ok ? "Iconi 4096" : "Icon! 4096")
        }
        ; ★保存したら閉じずに設定画面へ戻る★
        ;   続けて別の設定をしたいのに、毎回ソフトが消えていた（2026-09-22 指摘）。
        try dlg.Destroy()
        BackToSettings()
        return
    }
}
;==============================================================================
;  /trace  ★Phase 0 の主役★
;  人が手で 1 周操作する間、対象ソフトの様子を記録する。
;
;  ★v0.2 で作り直した理由（v0.1 の重大な欠陥）★
;    v0.1 は「見えているウィンドウの顔ぶれが変わったら画面が変わった」と判定し、
;    その "今の画面" のコントロールだけを見ていた。
;    ところが実機では TFormHardest / TFormDiagn が調査のあとも閉じずに残り、
;    セラピー中も顔ぶれが変わらなかったため、17 分間まったく記録できなかった。
;    「ポーズ→再開する」も 1 件も取れなかった。
;
;  v0.2 は 3 つの信号を独立に追う。どれか 1 つでも動けば記録できる。
;    (1) 窓の開閉         … どの画面がいつ開いて、いつ閉じたか
;    (2) 窓のタイトル      … TFormHardest は臓器名、TFormDiagn は数字（＝進捗の鼓動）
;    (3) 全窓のボタン文字  … ★「ポーズ」→「再開する」はここで捕まえる★
;==============================================================================
ModeTrace() {
    global C, G, SCRINI, APP_NAME, APP_VER
    pid := EnsureTarget()
    tickMs   := Max(250, CI("TickMs"))
    maxCtrls := CI("MaxTrackedCtrls")
    maxLen   := CI("MaxTextLen")
    stallSec := Max(5, CI("StallSec"))

    buf := "=== AutoMeta /trace  操作記録 ===`r`n"
         . "日時      : " FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss") "`r`n"
         . "バージョン: " APP_VER "`r`n"
         . "対象      : " CS("ExeName") " (pid " pid ")`r`n"
         . "権限      : " (A_IsAdmin ? "管理者" : "通常ユーザー") "`r`n`r`n"
         . "凡例`r`n"
         . "  [窓+]    画面が開いた          [窓-]  画面が閉じた（開いていた時間つき）`r`n"
         . "  [窓名]   タイトルが変わった    [変化] ボタンなどの文字が変わった ★本命★`r`n"
         . "  [鼓動停止] 数字タイトルが止まった（＝処理が終わった可能性）`r`n"
         . "  [クリック] 人が押した`r`n"
         . "----------------------------------------------------------------------`r`n"

    seenClasses := Map()      ; クラス → コントロール一覧を出したか
    screenMap   := Map()      ; 画面 ID → クラス
    episodes    := []         ; 閉じた窓の滞在記録
    openWins    := Map()      ; hwnd → Map("at","cls","id","title")
    titles      := Map()      ; hwnd → Map("t","at","stalled","beats")
    texts       := Map()      ; "hwnd|ClassNN" → 直前のテキスト
    prevSig     := ""
    lastClick   := Map("desc", "（記録なし）", "screen", "", "at", "")
    warnedGone  := false
    lastSave    := 0
    startTick   := A_TickCount

    dlg := Gui("+Resize", APP_NAME " - /trace 操作記録 v0.2" VerTag())
    dlg.MarginX := 14, dlg.MarginY := 10
    dlg.SetFont("s10", "Meiryo UI")
    dlg.Add("Text", "w1000"
        , "対象ソフトを【手で】ふだんどおり操作してください。ツールは見て記録するだけで、一切操作しません。")
    dlg.SetFont("s10 Bold", "Meiryo UI")
    dlg.Add("Text", "w1000 cRed"
        , "★今回ほしいのは「終わり方」です。調査を 1 回、セラピーを 1 回、どちらも最後まで自然に終わらせてください。")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w1000 cGray"
        , "  途中で「ポーズ」を押さないでください。押すと、自然に終わったのか人が止めたのか区別できなくなります。`n"
        . "  カード選択のやり方は前回の記録で判明済みなので、やり直さなくて構いません。")
    dlg.SetFont("s10", "Meiryo UI")
    stat := dlg.Add("Text", "w1000 cBlue", "監視中の画面: -")
    dlg.SetFont("s9", "Consolas")
    ed := dlg.Add("Edit", "w1000 h400 ReadOnly -Wrap +VScroll")
    dlg.SetFont("s10", "Meiryo UI")
    btn := dlg.Add("Button", "w260 h36 Default", "記録を終了して保存する")
    btn.OnEvent("Click", (*) => FinishTrace())
    dlg.OnEvent("Close", (*) => FinishTrace())
    dlg.Show()

    Hotkey("~LButton", OnClick)          ; ~ 付きなのでクリックはそのまま対象に届く
    SetTimer(TraceTick, tickMs)
    TraceTick()
    return

    ; -- 1 tick ---------------------------------------------------------------
    TraceTick() {
        wins := TargetWindows(pid)
        if (wins.Length = 0) {
            if (!warnedGone) {                      ; 毎 tick 出すと記録が埋まるので 1 回だけ
                warnedGone := true
                Emit("[警告] 対象ウィンドウが 1 つも見えません（最小化していませんか）")
            }
            return
        }
        warnedGone := false

        sig := ""
        for w in wins
            sig .= w["hwnd"] "|"
        if (sig != prevSig) {
            OnWindowSetChanged(wins)
            prevSig := sig
        }
        ; ★ v0.1 の失敗はここ。"今の画面" だけでなく【全部の窓】を見る
        for w in wins {
            TrackTitle(w)
            TrackTexts(w)
        }
        names := ""
        for w in wins
            names .= (names = "" ? "" : " / ") ClassifyScreen(w["hwnd"])["id"]
        stat.Value := "監視中の画面: " names
    }

    ; -- 窓が開いた／閉じた ----------------------------------------------------
    OnWindowSetChanged(wins) {
        now := Map()
        for w in wins
            now[w["hwnd"]] := w

        for h, w in now {
            if openWins.Has(h)
                continue
            id := ClassifyScreen(h)["id"]
            openWins[h] := Map("at", A_TickCount, "cls", w["class"], "id", id, "title", w["title"])
            Emit(Format("[窓+] {1} ({2})  title=「{3}」", id, w["class"], w["title"]))
            if (lastClick["at"] != "")
                Emit("        直前の操作: " lastClick["desc"])
            if (id != "UNKNOWN")
                screenMap[id] := w["class"]
            if !seenClasses.Has(w["class"]) {
                seenClasses[w["class"]] := true
                Emit("        --- " w["class"] " のコントロール一覧 ---")
                Emit(RTrim(CtrlsToText(DumpCtrls(h), "        "), "`n"))
            }
        }
        for h, rec in openWins.Clone() {
            if now.Has(h)
                continue
            sec := Round((A_TickCount - rec["at"]) / 1000, 1)
            Emit(Format("[窓-] {1} ({2}) が閉じました（開いていた時間 {3} 秒）", rec["id"], rec["cls"], sec))
            episodes.Push(Map("id", rec["id"], "class", rec["cls"], "sec", sec
                            , "enteredBy", lastClick["desc"]))
            openWins.Delete(h)
            if titles.Has(h)
                titles.Delete(h)
            for k in texts.Clone() {              ; 閉じた窓の記憶を捨てる（hwnd 再利用への備え）
                if (SubStr(k, 1, StrLen(h) + 1) = h "|")
                    texts.Delete(k)
            }
        }
    }

    ; -- タイトルの変化（TFormHardest は臓器名、TFormDiagn は数字＝鼓動）-------
    TrackTitle(w) {
        h := w["hwnd"], t := w["title"]
        if !titles.Has(h) {
            titles[h] := Map("t", t, "at", A_TickCount, "stalled", false, "beats", 0)
            return
        }
        rec := titles[h]
        if (rec["t"] = t) {
            ; 数字タイトルが動いていたのに止まった＝処理が終わった可能性
            if (!rec["stalled"] && rec["beats"] >= 3 && (A_TickCount - rec["at"]) > stallSec * 1000) {
                rec["stalled"] := true
                Emit(Format("[鼓動停止] {1} のタイトルが {2} 秒変化していません（title=「{3}」／それまで {4} 回変化）"
                          . "  ★処理が終わった可能性", w["class"], stallSec, t, rec["beats"]))
            }
            return
        }
        if (rec["stalled"]) {
            rec["stalled"] := false
            Emit(Format("[鼓動再開] {1} のタイトルがまた動き始めました", w["class"]))
        }
        if (IsBeat(rec["t"]) && IsBeat(t)) {
            rec["beats"] := rec["beats"] + 1       ; 数字→数字は鼓動。1 行ずつは記録しない
        } else {
            Emit(Format("[窓名] {1}: 「{2}」→「{3}」", w["class"], rec["t"], t))
        }
        rec["t"] := t, rec["at"] := A_TickCount
    }

    ; -- ボタンなどの文字の変化（★「ポーズ」→「再開する」はここ★）------------
    TrackTexts(w) {
        h := w["hwnd"]
        ctrls := []
        try ctrls := WinGetControls("ahk_id " h)
        catch
            return
        if (ctrls.Length > maxCtrls)               ; 大量コントロールの窓は追わない
            return
        for cn in ctrls {
            tx := ""
            try tx := ControlGetText(cn, "ahk_id " h)
            catch
                continue
            if (StrLen(tx) > maxLen)
                continue
            key := h "|" cn
            if !texts.Has(key) {
                texts[key] := tx
                continue
            }
            if (texts[key] != tx) {
                Emit(Format("[変化] {1} / {2}: 「{3}」→「{4}」", w["class"], cn, texts[key], tx))
                texts[key] := tx
            }
        }
    }

    ; -- 人がクリックした ------------------------------------------------------
    OnClick(*) {
        MouseGetPos(&mx, &my, &winId, &ctrlNN)
        if (!winId)
            return
        wpid := 0
        try wpid := WinGetPID("ahk_id " winId)
        if (wpid != pid)                            ; 対象ソフト以外のクリックは無視
            return
        rx := mx, ry := my
        try {
            WinGetPos(&wx, &wy, , , "ahk_id " winId)
            rx := mx - wx, ry := my - wy
        }
        scr := ClassifyScreen(winId)["id"]
        desc := DescribeClick(winId, rx, ry, ctrlNN)
        lastClick := Map("desc", desc, "screen", scr, "at", A_Now)
        Emit(Format("[クリック] {1} 上の {2}  （ウィンドウ内 x{3} y{4}）", scr, desc, rx, ry))
    }

    IsBeat(t) => RegExMatch(Trim(t), "^\d{1,5}$") > 0

    ; -- 出力 ------------------------------------------------------------------
    Emit(line) {
        buf .= FormatTime(A_Now, "HH:mm:ss") "  " line "`r`n"
        ed.Value := buf
        try SendMessage(0x0115, 7, 0, ed)          ; 末尾へスクロール
        if (A_TickCount - lastSave > 2000) {       ; 落ちても失われないよう随時保存
            SaveTrace()
            lastSave := A_TickCount
        }
    }

    SaveTrace() {
        path := A_ScriptDir "\trace.txt"
        try FileDelete(path)
        try FileAppend(CRLF(buf . ReportTail()), path, "UTF-8")
    }

    ; -- 末尾のまとめ ----------------------------------------------------------
    ReportTail() {
        out := "`r`n----------------------------------------------------------------------`r`n"
        out .= "■ 画面 ID ↔ ウィンドウクラス`r`n"
        if (screenMap.Count = 0) {
            out .= "  （まだ判定できていません）`r`n"
        } else {
            for id, cls in screenMap
                out .= Format("  {1:-16} = {2}`r`n", id, cls)
        }
        out .= "`r`n■ 閉じた窓と、開いていた時間`r`n"
        if (episodes.Length = 0) {
            out .= "  （まだありません）`r`n"
        } else {
            for e in episodes
                out .= Format("  {1:-16} {2:-22} {3:8} 秒   ← {4}`r`n"
                     , e["id"], e["class"], e["sec"], e["enteredBy"])
        }
        out .= "`r`n■ いま開いたままの窓`r`n"
        for h, rec in openWins
            out .= Format("  {1:-16} {2:-22} {3:8} 秒（継続中）`r`n"
                 , rec["id"], rec["cls"], Round((A_TickCount - rec["at"]) / 1000, 1))
        out .= "`r`n■ 見てほしいところ`r`n"
        out .= "  1) [変化] の行に「ポーズ」→「再開する」があるか`r`n"
        out .= "     それが【クリックの直後ではなく】処理の終わり際に出ていれば、自然終了の合図として使える`r`n"
        out .= "  2) [鼓動停止] が調査の終わり・セラピーの終わりに出ているか`r`n"
        out .= "  3) 調査のあと TFormHardest / TFormDiagn が [窓-] で閉じるか、開いたまま残るか`r`n"
        return out
    }

    ; -- 終了して screens.ini を書く -------------------------------------------
    FinishTrace() {
        global APP_NAME
        SetTimer(TraceTick, 0)
        try Hotkey("~LButton", "Off")
        for h, rec in openWins {
            episodes.Push(Map("id", rec["id"], "class", rec["cls"]
                            , "sec", Round((A_TickCount - rec["at"]) / 1000, 1)
                            , "enteredBy", "（最後まで開いたまま）"))
        }
        SaveTrace()
        WriteScreensIni()
        total := Round((A_TickCount - startTick) / 1000)
        MsgBox("記録を終了しました（" FmtDur(total) "）。`n`n"
            . "  trace.txt    … 操作の記録（★これを Claude に貼ってください）`n"
            . "  screens.ini  … 画面 ID ↔ クラスの対応表（自動生成）`n`n"
            . "画面が " screenMap.Count " 種類 特定できました。"
            , APP_NAME, "Iconi 4096")
        OpenFile(A_ScriptDir "\trace.txt")
        ExitApp(0)
    }

    WriteScreensIni() {
        global SCRINI
        body := "; =============================================================`r`n"
             .  ";  AutoMeta  screens.ini`r`n"
             .  ";  /trace が自動生成しました（" FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss") "）`r`n"
             .  ";  ★内容を目視で確認してから使ってください★`r`n"
             .  "; =============================================================`r`n`r`n"
             .  "[Screens]`r`n"
        for id in ["S0_Menu", "S1_Index", "S2_Card", "S2b_Anamnesis", "S3_Scheme"
                 , "S4_ScanItem", "S5_Indicator", "P1_Progress"]
            body .= id "=" (screenMap.Has(id) ? screenMap[id] : "") "`r`n"
        body .= "`r`n[Timing]`r`n; 実測値（秒）。同じ画面が複数回開いた場合は最長のものを採用`r`n"
        best := Map()
        for e in episodes {
            if (!best.Has(e["id"]) || e["sec"] > best[e["id"]])
                best[e["id"]] := e["sec"]
        }
        for id, sec in best
            body .= id "MaxSec=" sec "`r`n"
        try FileDelete(SCRINI)
        try FileAppend(CRLF(body), SCRINI, "UTF-8")
    }
}

;==============================================================================
;  Phase 1: Navigator — 画面の特定・待機・クリック
;  ★このフェーズから対象ソフトを実際に操作する。安全装置は §12 を参照★
;==============================================================================

; screens.ini（/trace が生成）を読み、画面 ID → クラスの対応を C に載せる。
; ファイルが無ければ SCREEN_CLASSES の既定値をそのまま使う。
LoadScreens() {
    global SCRINI, SCREEN_CLASSES
    m := IniLoad(SCRINI)
    if (!m.Has("Screens"))
        return
    for id, cls in m["Screens"] {
        if (Trim(cls) = "")
            continue
        SCREEN_CLASSES[Trim(cls)] := id          ; クラス → ID の向きで持つ
    }
}

; 指定した画面 ID のウィンドウを返す（無ければ 0）。手前にあるものを優先。
FindScreen(id) {
    global G
    for w in TargetWindows(G.pid) {
        if (ClassifyScreen(w["hwnd"])["id"] = id)
            return w["hwnd"]
    }
    return 0
}

; 今開いている画面 ID の一覧（重複あり）
ScreenList() {
    global G
    out := []
    for w in TargetWindows(G.pid)
        out.Push(ClassifyScreen(w["hwnd"])["id"])
    return out
}

HasScreen(id) => FindScreen(id) != 0

ScreenNames() {
    s := ""
    for id in ScreenList()
        s .= (s = "" ? "" : " / ") id
    return (s = "" ? "（なし）" : s)
}

;==============================================================================
;  クリック — 押す直前に必ず再確認する（安全装置 S4）
;==============================================================================

; コントロールをクリックする。wantText を渡すとキャプションを照合してから押す。
;   ★空文字は「読めなかった」であって「一致した」ではない。押さずに false を返す。
;     （アプリがビジーな瞬間は ControlGetText が空を返す — 仕様書 §5.3-2）
ClickCtrl(hwnd, cnn, wantText := "") {
    global G
    if (!hwnd || cnn = "")
        return false
    try {
        if (!ControlGetVisible(cnn, "ahk_id " hwnd))
            return false
        if (!ControlGetEnabled(cnn, "ahk_id " hwnd))
            return false
    } catch {
        return false
    }
    if (wantText != "") {
        got := ""
        try got := Norm(ControlGetText(cnn, "ahk_id " hwnd))
        if (got = "") {
            Log("DEBUG", "キャプションが読めないため見送り: " cnn "（アプリがビジー）")
            return false
        }
        if (got != Norm(wantText)) {
            ; ★番号がずれていても、キャプションで探し直す★
            ;   コントロール名（TImageButton4 など）は PC ごとに違う。
            ;   ひな型はこちらの環境の実測値なので、別の PC では必ずずれる。
            ;   2026-09-17、別 PC で TImageButton4 が「カードインデックス」だったため
            ;   調査を開始できず、47 回警告を出し続けて失敗した。
            rec := FindCtrlByText(hwnd, wantText)
            alt := rec.Has("cnn") ? rec["cnn"] : ""
            ; ★乗り換える前に、そちらが押せる状態かを確かめる★
            ;   もとのコントロールで済ませていた確認を、探し直した先でもやり直す。
            ok2 := false
            if (alt != "" && alt != cnn)
                try ok2 := ControlGetVisible(alt, "ahk_id " hwnd) && ControlGetEnabled(alt, "ahk_id " hwnd)
            if (ok2) {
                Log("INFO", Format("{1} は「{2}」でした。「{3}」は {4} にあるので、そちらを押します"
                    , cnn, got, wantText, alt))
                cnn := alt
            } else {
                Log("WARN", Format("キャプション不一致のため押しません: {1} 期待「{2}」実際「{3}」"
                    . "（同じ文字のボタンが見つかりません）", cnn, wantText, got))
                return false
            }
        }
    }
    if (!CountClick("ctrl:" cnn))
        return false
    if (CB("DryRun")) {
        Log("INFO", "[DryRun] 押したつもり: " cnn (wantText = "" ? "" : "「" wantText "」"))
        return true
    }
    try ControlClick(cnn, "ahk_id " hwnd, , "Left", 1, "NA")
    Log("INFO", "クリック: " cnn (wantText = "" ? "" : "「" wantText "」"))
    return true
}

; ウィンドウ内の座標をクリックする（描画ボタン用）
; ★コントロールを名指しして、その中の座標を押す★
;   ウィンドウ座標で押すと、重なっているどのコントロールが受け取るかが不確実。
;   マニュアル選択の一覧（TPanel1 x1080-1394 y240-738）は、
;   項目リスト（TCheckListBox1 x693-1411 y251-1002）と重なっている。
;   2026-09-16、「自動選択」を押したつもりが選ばれず、調査項目が 1 つに減っていた
;   （項目リストのチェックを触ってしまったと考えると辻褄が合う）。
ClickCtrlAt(hwnd, cnn, dx, dy, why := "") {
    if (!hwnd || cnn = "")
        return false
    if (!CountClick(Format("ctrl:{1}@{2},{3}", cnn, dx, dy)))
        return false
    if (CB("DryRun")) {
        Log("INFO", Format("[DryRun] 押したつもり: {1} の中 x{2} y{3} {4}", cnn, dx, dy, why))
        return true
    }
    try ControlClick(cnn, "ahk_id " hwnd, , "Left", 1, "NA X" dx " Y" dy)
    Log("INFO", Format("クリック: {1} の中 x{2} y{3} {4}", cnn, dx, dy, why))
    return true
}

ClickAt(hwnd, x, y, why := "") {
    if (!hwnd)
        return false
    if (!CountClick(Format("pos:{1},{2}", x, y)))
        return false
    if (CB("DryRun")) {
        Log("INFO", Format("[DryRun] 押したつもり: x{1} y{2} {3}", x, y, why))
        return true
    }
    try ControlClick(Format("x{1} y{2}", x, y), "ahk_id " hwnd, , "Left", 1, "NA")
    Log("INFO", Format("クリック: x{1} y{2} {3}", x, y, why))
    return true
}

; ★本物のダブルクリック★
;   ControlClick(..., 2, ...) は「押す・離す」を 2 回送るだけで、
;   Windows がダブルクリックと見なす WM_LBUTTONDBLCLK を送らない。
;   Delphi のグリッドはこれを見ているため、回数指定では行が開かない
;   （カマヤン指摘 2026-09-14）。そこでメッセージを直接組み立てて送る。
DoubleClickCtrl(hwnd, cnn, wx, wy, why := "") {
    static WM_LBUTTONDOWN := 0x201, WM_LBUTTONUP := 0x202, WM_LBUTTONDBLCLK := 0x203
    static MK_LBUTTON := 0x0001
    if (!hwnd || cnn = "")
        return false
    ; 渡ってくる座標はウィンドウ内。コントロール内の座標へ直す
    r := CtrlRect(hwnd, cnn)
    if (!r["ok"])
        return false
    px := r["x"], py := r["y"], pw := r["w"], ph := r["h"]
    rx := wx - px, ry := wy - py
    if (rx < 0 || ry < 0 || rx > pw || ry > ph) {
        Log("WARN", Format("行の座標がグリッドの外です（グリッド x{1} y{2} w{3} h{4} / 指定 x{5} y{6}）"
            , px, py, pw, ph, wx, wy))
        return false
    }
    lp := ((ry & 0xFFFF) << 16) | (rx & 0xFFFF)
    try {
        PostMessage(WM_LBUTTONDOWN,   MK_LBUTTON, lp, cnn, "ahk_id " hwnd)
        PostMessage(WM_LBUTTONUP,     0,          lp, cnn, "ahk_id " hwnd)
        PostMessage(WM_LBUTTONDBLCLK, MK_LBUTTON, lp, cnn, "ahk_id " hwnd)
        PostMessage(WM_LBUTTONUP,     0,          lp, cnn, "ahk_id " hwnd)
    } catch as e {
        Log("WARN", "ダブルクリックを送れませんでした: " e.Message)
        return false
    }
    Log("INFO", Format("ダブルクリック: {1} の x{2} y{3}（ウィンドウ内 x{4} y{5}）{6}"
        , cnn, rx, ry, wx, wy, why))
    return true
}

; 「自動セラピー」の位置を毎回計算する（v4 と同一。端末差・解像度差に追従）
;   [インタラクティブ既往症]  ←この間の中央→  [調査]
AutoTherapyPoint(hwnd, &cx, &cy, &how) {
    cx := 0, cy := 0, how := ""
    lrec := FindCtrlByText(hwnd, CS("AnchorLeftText"))
    rrec := FindCtrlByText(hwnd, CS("AnchorRightText"))
    if (lrec.Count > 0 && rrec.Count > 0) {
        sameRow := (Abs(lrec["y"] - rrec["y"]) <= 12)
        gapL := lrec["x"] + lrec["w"]
        gapR := rrec["x"]
        if (sameRow && (gapR - gapL) >= 40) {
            cx := (gapL + gapR) // 2
            cy := lrec["y"] + lrec["h"] // 2
            how := Format("アンカー計算（隙間 {1}px）", gapR - gapL)
            return true
        }
    }
    if (CS("TherapyClickX") != "" && CS("TherapyClickY") != "") {
        cx := CI("TherapyClickX"), cy := CI("TherapyClickY")
        how := "config の固定座標"
        return true
    }
    return false
}

; テキストが一致するコントロールの位置を返す（v4 と同一）
FindCtrlByText(hwnd, text) {
    rec := Map()
    want := Norm(text)
    if (want = "" || !hwnd)
        return rec
    ctrls := []
    try ctrls := WinGetControls("ahk_id " hwnd)
    catch
        return rec
    for cn in ctrls {
        t := ""
        try t := Norm(ControlGetText(cn, "ahk_id " hwnd))
        if (t != "" && t = want) {
            r := CtrlRect(hwnd, cn)
            if (r["ok"])
                rec := Map("cnn", cn, "x", r["x"], "y", r["y"], "w", r["w"], "h", r["h"])
            return rec
        }
    }
    return rec
}

;==============================================================================
;  安全装置 S1 / S2 — サーキットブレーカーと最小クリック間隔
;==============================================================================
CountClick(what) {
    global G
    ; --- S2: 最小クリック間隔（先に見る）--------------------------------------
    ;   ★見送りは「押していない」ので、繰り返しには数えない★
    ;     2026-09-14 の実機で、見送りまで数えたため実際は 2 回しか押していないのに
    ;     「4 回続けて押そうとしました」と誤検知して止まった。
    gap := CI("MinClickGapSec")
    if (gap > 0 && G.lastClickTS != "" && SecSince(G.lastClickTS) < gap) {
        Log("DEBUG", Format("最小クリック間隔 {1} 秒に満たないため見送り（前回から {2} 秒）"
            , gap, SecSince(G.lastClickTS)))
        return false
    }
    ; --- S1a: 同じ状態で同じものを【実際に】何度も押していないか ---------------
    if (what = G.lastTarget && G.state = G.lastTargetState) {
        G.repeat++
    } else {
        G.repeat := 1
        G.lastTarget := what
        G.lastTargetState := G.state
    }
    if (G.repeat > CI("MaxSameClick")) {
        Abort(Format("同じものを {1} 回押しましたが、画面が変わりません。`n`n"
            . "  状態  : {2}`n  対象  : {3}`n`n"
            . "ソフトが応答していないか、押す場所が違っている可能性があります。"
            . "暴走を防ぐため停止しました。", G.repeat, G.state, what))
        return false
    }
    ; --- S1b: 総クリック数の上限 ---------------------------------------------
    if (G.clicks >= MaxClicksTotal()) {
        Abort(Format("総クリック数が上限 {1} に達しました（直近: {2} / 状態: {3}）。`n"
            . "暴走を防ぐため停止します。", MaxClicksTotal(), what, G.state))
        return false
    }
    G.clicks++
    G.lastClickTS := A_Now
    return true
}

; ★押したあとは、間を置いてから押し直す★
;   これまでは毎 tick（1 秒ごと）に押そうとしていたため、
;   画面の切り替わりが少し遅いだけで「何度も押している」ことになっていた。
;   一度押したら RetryGapSec 秒は待ち、画面が変わるのを見守る。
TryClick(hwnd, cnn, text := "") {
    global G
    if (!hwnd || cnn = "")
        return false
    if (G.stateClickTS != "" && SecSince(G.stateClickTS) < CI("RetryGapSec"))
        return false                                ; まだ待つ
    if (ClickCtrl(hwnd, cnn, text)) {
        G.stateClickTS := A_Now
        return true
    }
    return false                                    ; 押せなかった（ビジー等）ので次の tick で再挑戦
}

; 正常な 1 実行に必要なクリックの実数（実測で 11 回）に、
; セラピー 1 回あたりの再ナビゲーション分とリトライの余裕を足す。
;   ★以前は 8 + N + 3 としていたが、正常動作ですら足りず誤停止していた（2026-09-14 修正）
MaxClicksTotal() {
    return CI("BaseClicks") + CI("TherapyCount") * 2 + CI("MaxClicksExtra")
}

;==============================================================================
;  ★G1★ 氏名照合ゲート — 本ツールで最も重要な安全装置
;
;  カード画面は項目ごとに順に書き換わり、一瞬だけ前の対象者のデータが混ざる
;  （実測・仕様書 §7.2）。値が安定するまで読まないこと。
;==============================================================================

; 姓名を「同じ値が SettleChecks 回続いたら確定」で読む。
; 確定できなければ false。
ReadPatientSettled(hwnd, &sei, &mei, &why) {
    sei := "", mei := "", why := ""
    cnSei := CS("LastNameFieldClassNN")
    cnMei := CS("FirstNameFieldClassNN")
    if (cnSei = "" || cnMei = "") {
        why := "config.ini に姓名の欄が設定されていません（/listread を実行してください）"
        return false
    }
    need  := Max(2, CI("SettleChecks"))
    wait  := Max(100, CI("SettleIntervalMs"))
    limit := Max(3, CI("SettleTimeoutSec"))
    started := A_Now
    lastS := "", lastM := "", same := 0
    Loop {
        if (SecSince(started) > limit) {
            why := Format("姓名が {1} 秒たっても安定しません（最後に読めた値: 「{2}」「{3}」）"
                , limit, lastS, lastM)
            return false
        }
        s := "", m := ""
        try s := Trim(ControlGetText(cnSei, "ahk_id " hwnd))
        try m := Trim(ControlGetText(cnMei, "ahk_id " hwnd))
        if (s != "" && m != "" && s = lastS && m = lastM) {
            same++
            if (same >= need) {
                sei := s, mei := m
                return true
            }
        } else {
            same := 1
        }
        lastS := s, lastM := m
        Sleep(wait)
    }
}

; カード画面から、ミドルネームの欄を推定する
;   姓 / 名前 / ミドルネーム の順に並んでいるので、DB 連動の入力欄の 3 番目。
;   「読み取り可否を調べる」とまったく同じ選び方。
;   ★設定が空のときだけ使い、選んだ結果は config.ini に記録する★
;   2026-09-18、欄が未登録というだけで実行できず、利用者を行き止まりにしていた。
;   カード画面は目の前に開いているのだから、その場で見つければよい。
GuessMiddleField(hwnd) {
    rows := []
    for r in DumpCtrls(hwnd) {
        if (!RegExMatch(r["cnn"], "i)dbedit") || r["y"] = "")
            continue
        rows.Push(r)
    }
    Loop Max(0, rows.Length - 1) {                 ; y の小さい順（画面の上から）
        i := A_Index
        Loop rows.Length - i {
            j := A_Index
            if (rows[j]["y"] > rows[j + 1]["y"]) {
                tmp := rows[j], rows[j] := rows[j + 1], rows[j + 1] := tmp
            }
        }
    }
    return (rows.Length >= 3) ? rows[3]["cnn"] : ""
}

; カード画面のミドルネームを読む（設定していなければ空文字）
;   ★同姓同名の別カードを見分けるために要る★
;   2026-09-18、ビフォーアフター比較用に「ミドルネームだけ違う同一人物のカード」を
;   作って使っている運用があると判明した。姓名だけでは区別できない。
ReadMiddleName(hwnd) {
    return ReadMiddleSettled(hwnd)["text"]
}

; ミドルネームを「同じ値が続いたら確定」で読む。
;   ★姓名と同じ待ち方をする★
;   2026-09-18、姓名だけ待ってミドルは 1 回読むだけだったため、
;   カード画面が書き換わる途中の【空】を読み、空欄指定と一致して素通りした。
;   ok=false は「一度も読めなかった」。空だったのか読めなかったのかを区別する。
ReadMiddleSettled(hwnd) {
    cn := CS("MiddleNameFieldClassNN")
    if (cn = "")
        return Map("ok", false, "text", "", "why", "ミドルネームの欄が設定されていません")
    need  := Max(2, CI("SettleChecks"))
    wait  := Max(100, CI("SettleIntervalMs"))
    limit := Max(3, CI("SettleTimeoutSec"))
    started := A_Now
    last := "", same := 0, got := false
    Loop {
        t := "", read := false
        try {
            t := Trim(ControlGetText(cn, "ahk_id " hwnd))
            read := true
        }
        if (read)
            got := true
        if (read && t = last) {
            same++
            if (same >= need)
                return Map("ok", true, "text", t, "why", "")
        } else {
            same := 1
        }
        last := t
        if (SecSince(started) > limit)
            return Map("ok", got, "text", last
                     , "why", got ? "" : "ミドルネームの欄を読めませんでした")
        Sleep(wait)
    }
}

; 予定の氏名と完全一致するか。しなければジョブを中止する（リトライしない）。
VerifyPatient(hwnd) {
    ; C は、ミドルネーム欄を自動で見つけたときに記録するために使う
    global G, C
    if (!CB("VerifyPatientName")) {
        Abort("VerifyPatientName=0 は許可されていません。氏名照合を省略しての実行はできません。")
        return false
    }
    if (!ReadPatientSettled(hwnd, &sei, &mei, &why)) {
        Abort("★氏名を読み取れませんでした。安全のため中止します。`n" why)
        return false
    }
    okS := (Norm(sei) = Norm(G.wantSei))
    okM := (Norm(mei) = Norm(G.wantMei))
    if (okS && okM) {
        ; ★ミドルネームまで見る★
        ;   同姓同名で、ミドルネームだけ違うカードが並んでいることがある
        ;   （ビフォーアフター比較用）。一覧は先頭行を開くので、
        ;   姓名だけでは【別のカードを開いたまま素通り】してしまう。
        cnMid := CS("MiddleNameFieldClassNN")
        ; ★空欄指定のときも欄を探す★
        ;   「欄が未登録 かつ 空欄指定」だと、以前は照合を丸ごと飛ばしていた。
        ;   空欄は「ミドルの無いカードを対象にする」という指定なので、
        ;   一番守るべき場面で無検査になっていた（2026-09-18）。
        if (cnMid = "") {
            ; ★その場で見つけて覚える★ 欄が未登録というだけで止めない
            cnMid := GuessMiddleField(hwnd)
            if (cnMid != "") {
                IniSet(CFG, ModelSec("Select"), "MiddleNameFieldClassNN", cnMid)
                C["MiddleNameFieldClassNN"] := cnMid
                Log("INFO", Format("ミドルネームの欄を見つけて記録しました: {1}（読めた値「{2}」）"
                    , cnMid, ReadMiddleName(hwnd)))
            }
        }
        if (cnMid = "") {
            if (Trim(G.wantMid) != "") {
                SaveShot("g1_no_middle_field")
                Abort(Format("予定でミドルネーム「{1}」を指定していますが、"
                    . "【ツール側の設定】で、画面のどの欄がミドルネームかを特定できませんでした。`n`n"
                    . "※ カードの内容の問題ではありません。ツールが欄の場所を知らないという意味です。`n`n"
                    . "カード画面を開いた状態で「設定 →『読み取り可否を調べる』」を"
                    . "実行してください。", G.wantMid))
                return false
            }
        } else {
            mr  := ReadMiddleSettled(hwnd)
            mid := mr["text"]
            if (!mr["ok"]) {
                ; ★読めていないなら合格にしない★ 空欄と区別がつかないため
                SaveShot("g1_middle_unread")
                Abort(Format("ミドルネームを読み取れませんでした（{1}）。`n`n"
                    . "同姓同名の別カードと区別できないため中止しました。", mr["why"]))
                return false
            }
            if (Norm(mid) != Norm(G.wantMid)) {
                ; ★同じカードが開いたら、行の間隔が足りていない★
                ;   2026-09-18、カードは 2 枚しか無いのに 3 行目まで試していた。
                ;   1 行目の下寄りと 2 行目の上寄りを指して教えると、
                ;   差が実際の行の高さより小さく記録されるため起きる。
                ;   同じ位置を踏み続けないよう、そのぶん余計に進める。
                ; ★行番号を飛ばしてはいけない★
                ;   2026-09-18、ここで rowTry を足したうえに通常の加算も走り、
                ;   2 行目の次が 4 行目になって【正解の 3 行目を読み飛ばし】、
                ;   別人のカードに到達した（照合が止めたので実害はなし）。
                ;   行番号はそのまま 1 つずつ進め、位置だけを半行ぶん下へずらす。
                card := Norm(sei) . "|" . Norm(mei) . "|" . Norm(mid)
                if (card = G.lastCard) {
                    G.rowExtra += Max(8, CI("ListRowPitchY") // 2)
                    Log("WARN", Format("同じカードがまた開きました。行の間隔（{1}px）が"
                        . "実際の行の高さより小さいようです。次から {2}px 下げて狙います"
                        , CI("ListRowPitchY"), G.rowExtra))
                }
                G.lastCard := card
                ; ★次の行を試せるなら、中止せずに戻る★
                ;   一覧は常に上から開くので、狙いのカードが 2 行目以降にある。
                if (CI("ListRowPitchY") > 0 && G.rowTry < CI("ListMaxRows")) {
                    G.rowTry++
                    G.rowClicked := false
                    ; ★検索をやり直す★
                    ;   2026-09-18、2 行目以降は検索を素通りしていた（利用者の指摘）。
                    ;   一覧に戻ると絞り込みが解除されている可能性があり、
                    ;   その場合【絞り込まれていない一覧】の行を開いてしまう。
                    ;   実際に別人（同姓の方）のカードに到達した。
                    G.searched := false
                    Log("INFO", Format("ミドルが違うので次の行を試します（{1} 行目へ／"
                        . "この行は「{2}」）", G.rowTry, mid = "" ? "なし" : mid))
                    SetState("open_index", "別の行を開きます")
                    Arm(800)
                    return false
                }
                SaveShot("g1_middle_mismatch")
                ; ★次の行を試せなかった理由を、そのまま伝える★
                ;   2026-09-22、行の間隔が未登録のまま、1 行目だけ見て中止していた。
                ;   「取り違えた」とだけ出ても、次に何をすればよいか分からない。
                hint := ""
                if (CI("ListRowPitchY") <= 0) {
                    hint := "`n`n【次にすること】`n"
                        . "　一覧の【行の間隔】が登録されていないため、1 行目しか見ていません。`n"
                        . "　設定 →「一覧の先頭行を教える」で、1 行目に続けて"
                        . "【2 行目】も教えてください。`n"
                        . "　そうすると、2 行目以降にある本来のカードを自動で探します。"
                } else if (G.rowTry >= CI("ListMaxRows")) {
                    hint := Format("`n`n{1} 行目まで試しましたが、見つかりませんでした。"
                        . "`n検索で絞り込めているか確かめてください。", CI("ListMaxRows"))
                }
                Abort(Format("★★ 別のカードが開いています（ミドルネーム違い）★★`n`n"
                    . "  予定: 「{1} {2}」ミドル「{3}」`n"
                    . "  実際: 「{4} {5}」ミドル「{6}」`n`n"
                    . "施術は一切行わずに中止しました。`n"
                    . "ビフォーアフター比較用のカードと取り違えている可能性があります。{7}"
                    , G.wantSei, G.wantMei, G.wantMid = "" ? "（なし）" : G.wantMid
                    , sei, mei, mid = "" ? "（なし）" : mid, hint))
                return false
            }
            G.gotMid := mid
        }
        Log("INFO", Format("★G1 照合 OK: 「{1} {2}」{3}", sei, mei
            , G.gotMid = "" ? "" : "ミドル「" G.gotMid "」"))
        G.gotSei := sei, G.gotMei := mei
        return true
    }
    SaveShot("g1_mismatch")
    Abort(Format("★★ 別人のカードが開いています ★★`n`n"
        . "  予定: 「{1} {2}」`n  実際: 「{3} {4}」`n`n"
        . "施術は一切行わずに中止しました。`n"
        . "同姓の方がいる場合は、schedule の氏名が正確か確認してください。"
        , G.wantSei, G.wantMei, sei, mei))
    return false
}

;==============================================================================
;  ホーミング — 想定外の場所からでも安全な起点へ戻す（G4）
;  ★原則: 閉じる／戻る方向にしか操作しない。分からない画面では絶対に押さない★
;==============================================================================
HomeStep() {
    global G
    ; 施術中なら絶対に割り込まない（G8）
    if (HasScreen("S4_ScanItem") || HasScreen("S5_Indicator")) {
        Log("INFO", "実行中の画面があります。完了を待ちます（割り込みません）")
        return "wait"
    }
    if (h := FindScreen("P1_Progress"))
        return "wait"                              ; 進捗ダイアログは消えるのを待つ
    if (h := FindScreen("Dialog")) {
        TryClick(h, CS("DialogOkClassNN"), CS("DialogOkText"))
        return "wait"
    }
    if (h := FindScreen("S1_Index"))
        return "done"                              ; ここが起点
    if (h := FindScreen("S2b_Anamnesis")) {
        TryClick(h, CS("AnamnesisNextClassNN"), CS("AnamnesisNextText"))
        return "wait"
    }
    if (h := FindScreen("S3_Scheme")) {
        ; ★部品の番号はモデルごとに違う★
        ;   TImageButton3 は 18D での番号。別モデルでは空振りして起点に戻れない
        ;   （2026-09-22 指摘）。まず文字で探し、見つからなければ番号で押す。
        rec := FindCtrlByText(h, CS("SchemeBackText"))
        if (rec.Has("cnn"))
            TryClick(h, rec["cnn"], CS("SchemeBackText"))
        else
            TryClick(h, CS("SchemeBackClassNN"), CS("SchemeBackText"))
        return "wait"
    }
    if (h := FindScreen("S2_Card"))
        return "done"                              ; カード画面も起点として使える
    if (h := FindScreen("S0_Menu")) {
        ; ★ログイン画面は押して通る★
        ;   2026-09-18 までは「ログインは自動化しない」と決めていた。
        ;   パスワードが要る前提だったが、実機では【ボタンを 1 回押すだけ】で、
        ;   認証情報は一切扱わないと分かった（利用者に確認済み）。
        ;   H-4 でソフトを自動起動する以上、ここを通れないと無人運転が成立しない。
        ;   ★ボタンは文字で探す★ TImageButton23 のような番号は PC ごとに変わる。
        rec := FindCtrlByText(h, CS("LoginText"))
        if (rec.Has("cnn")) {
            TryClick(h, rec["cnn"], CS("LoginText"))
            return "wait"
        }
        Abort(Format("メニュー画面に「{1}」のボタンが見つかりません。`n"
            . "手でログインしてから、もう一度実行してください。", CS("LoginText")))
        return "abort"
    }
    ; ★最後の手立て★
    ;   画面の種類が分からなくても、「カードインデックス」ボタンがあれば
    ;   それを押せば起点へ戻れる。諦める前に一度だけ試す。
    for hw in TargetWindows(G.pid) {
        rec := FindCtrlByText(hw, CS("SchemeBackText"))
        if (rec.Has("cnn")) {
            Log("INFO", "見覚えのない画面ですが「" . CS("SchemeBackText") . "」があるので押します")
            TryClick(hw, rec["cnn"], CS("SchemeBackText"))
            return "wait"
        }
    }
    SaveShot("unknown_screen")
    Abort("想定していない画面です: " ScreenNames()
        . "`n`n何も押さずに中止しました。screenshots フォルダに画面を保存しています。")
    return "abort"
}


;==============================================================================
;  Phase 1: ジョブの状態機械
;  1 ジョブ ＝ 1 人に対する「調査 1 回 ＋ セラピー N 回」
;
;  状態遷移（仕様書 §6）
;    homing → select → verify(G1) → scan → therapy × N → cleanup → done
;  どの状態からでも、停止指示・異常があれば abort へ抜ける。
;==============================================================================

; ★ジョブ用の状態を、毎回すべて初期化する★
;   2026-09-15、スケジュール運転の 2 件目が失敗した。
;   G.searched / G.rowClicked が前のジョブの true のままだったため、
;   検索も行のクリックもせず、60 秒待って中止していた。
;   要約に前の人の「調査 37 項目」が出ていたのも同じ原因。
;   ★ここでは wantSei / wantMei / skipSelect / manualJob は触らない★
;     （呼ぶ側が「誰に何をするか」として先に決めているため）
ResetJobState() {
    global G
    G.state := "idle", G.stateTS := "", G.startTS := "", G.stopping := false
    G.gotSei := "", G.gotMei := "", G.gotMid := ""
    G.searched := false, G.rowClicked := false, G.rowTry := 1, G.lastCard := ""
    G.rowExtra := 0
    G.clicks := 0, G.lastClickTS := ""
    G.repeat := 0, G.lastTarget := "", G.lastTargetState := "", G.stateClickTS := ""
    G.cycle := 0, G.cycleStartTS := "", G.durations := [], G.stable := 0
    G.maxGap := 0, G.therapySeenTS := "", G.runLogTS := ""
    G.scanBefore := "", G.scanStartTS := "", G.scanProgressTS := ""
    G.scanItems := 0, G.scanSec := 0, G.lastScanItem := "", G.dialogSeen := false
    G.needCheck := ""
    G.logLost   := 0
    G.optStep := 0, G.optTS := "", G.optTries := 0, G.optBusy := false, G.optWarn := ""
    G.optOff := 0, G.optLast := 0, G.optNoBtn := 0
    G.statusTS := ""
}

StartJob() {
    global G
    ResetJobState()
    ; 自動セラピーでは対象者の検索・選択を行わない（いま開いているカードが対象）
    G.state      := G.skipSelect ? "therapy_ready" : "homing"
    G.stateTS    := A_Now
    G.startTS    := A_Now
    SaveState()                                    ; 開始した時点で誰のジョブかを残す
    Log("INFO", Format("=== ジョブ開始 対象=「{1} {2}」 調査={3} セラピー={4}回 DryRun={5} ==="
        , G.wantSei, G.wantMei, CB("RunInvestigation") ? "する" : "しない"
        , CI("TherapyCount"), CB("DryRun") ? 1 : 0))
    WriteStatus(true)
    WriteLive()
    Arm(500)
}

SetState(state, note := "") {
    global G
    if (G.state = state)
        return
    Log("INFO", Format("状態: {1} → {2}{3}", G.state, state, note = "" ? "" : "（" note "）"))
    G.state        := state
    G.stateTS      := A_Now
    G.stable       := 0
    G.repeat       := 0
    G.stateClickTS := ""
    G.optStep      := 0
    G.optTries     := 0
    G.optBusy      := false
    G.optOff       := 0
    G.optLast      := 0
    G.optNoBtn     := 0
    ; ★いま誰を、どこまで進めたかを残す★
    ;   以前は「セラピー中」と「終了時」にしか書いていなかったため、
    ;   調査中に落ちると【前のジョブの人】が確認待ちに載った（2026-09-21 発見）。
    ;   状態が変わるときだけなので、書き込みは 1 ジョブあたり十数回に収まる。
    SaveState()
    WriteStatus(true)
}

Arm(ms) => SetTimer(Tick, -Abs(ms))

StateSec() {
    global G
    return SecSince(G.stateTS)
}

; 状態ごとの制限時間を超えたら中止する（G3）
StateTimedOut(sec, what) {
    if (StateSec() <= sec)
        return false
    Abort(Format("{1} が {2} 秒たっても進みませんでした。`n現在の画面: {3}"
        , what, sec, ScreenNames()))
    return true
}

;==============================================================================
;  1 tick
;==============================================================================
Tick() {
    global G
    if (G.stopping)
        return
    if (CheckStopFiles())
        return
    ; S3: 実行時間の上限
    if (SecSince(G.startTS) > CI("MaxRuntimeSec")) {
        Abort(Format("実行時間が上限 {1} を超えました。", FmtDur(CI("MaxRuntimeSec"))))
        return
    }
    if (!ProcessAlive()) {
        Abort("対象ソフトのウィンドウが見えなくなりました（終了・最小化していませんか）。")
        return
    }
    WriteStatus()

    ; --- DryRun は画面が動かないので、各状態を一巡したら次へ送る ---------------
    ;   ★氏名照合(verify)だけは本当に読ませる。ここを飛ばすと確認の意味がない
    static dryNext := Map(
        "homing",        "open_index",
        "open_index",    "search",
        "search",        "pick_row",
        "pick_row",      "verify",
        "scan_open",     "scan_anamnesis",
        "scan_anamnesis","scan_scheme",
        "scan_scheme",   "scan_type",
        "scan_type",     "scan_manual",
        "scan_manual",   "scan_go",
        "scan_go",       "scan_running",
        "scan_running",  "scan_dialog",
        "scan_dialog",   "scan_check",
        "scan_check",    "therapy_ready",
        "therapy_ready", "therapy_click",
        "therapy_click", "therapy_start")
    if (CB("DryRun") && dryNext.Has(G.state) && StateSec() >= CI("DryHopSec")) {
        SetState(dryNext[G.state], "DryRun のため次へ")
        Arm(300)
        return
    }

    switch G.state {
        case "homing":        TickHoming()
        case "open_index":    TickOpenIndex()
        case "search":        TickSearch()
        case "pick_row":      TickPickRow()
        case "verify":        TickVerify()
        case "scan_open":     TickScanOpen()
        case "scan_anamnesis":TickScanAnamnesis()
        case "scan_scheme":   TickScanScheme()
        case "scan_type":     TickScanOption("ScanType")
        case "scan_manual":   TickScanOption("Manual")
        case "scan_go":       TickScanGo()
        case "scan_running":  TickScanRunning()
        case "scan_dialog":   TickScanDialog()
        case "scan_check":    TickScanCheck()
        case "therapy_ready": TickTherapyReady()
        case "therapy_click": TickTherapyClick()
        case "therapy_start": TickTherapyStart()
        case "therapy_run":   TickTherapyRun()
        case "therapy_rest":  TickTherapyRest()
        case "cleanup":       TickCleanup()
        default:              Arm(1000)
    }
}

ProcessAlive() {
    global G
    return TargetWindows(G.pid).Length > 0
}

;==============================================================================
;  対象者を選ぶ
;==============================================================================
TickHoming() {
    if (StateTimedOut(CI("HomingTimeoutSec"), "起点の画面へ戻る処理"))
        return
    r := HomeStep()
    if (r = "abort")
        return
    if (r = "wait") {
        Arm(2000)
        return
    }
    SetState("open_index")
    Arm(300)
}

; カード画面から「カードを選択します」で患者一覧を開く
TickOpenIndex() {
    global G
    if (HasScreen("S1_Index")) {
        SetState("search")
        Arm(300)
        return
    }
    if (StateTimedOut(CI("TransitionTimeoutSec"), "患者一覧を開く処理"))
        return
    if (h := FindScreen("S2_Card"))
        TryClick(h, CS("SelectCardClassNN"), CS("SelectCardText"))
    Arm(1000)
}

; 検索欄に「姓␣名」を入れて Enter（仕様書 §7.1 で実証）
; 検索欄に入れる文字を組み立てる。
;   ★ミドルの指定があれば足す★
;   2026-09-18 に実機で確認: 「姓 名 ミドル」で検索すると
;   ミドルありのカードだけが 1 件に絞られる。
;   ※ 空欄指定（ミドルの無いカードを狙う）は検索では表現できない。
;     そちらは開いて照合し、違えば次の行へ進む方式が要る（未実装）。
SearchKey() {
    global G
    key := G.wantSei . NameSep() . G.wantMei
    if (Trim(G.wantMid) != "")
        key .= NameSep() . Trim(G.wantMid)
    return key
}

TickSearch() {
    global G
    h := FindScreen("S1_Index")
    if (!h) {
        if (CB("DryRun") && !G.searched) {
            G.searched := true
            Log("INFO", "[DryRun] 検索欄に入れるつもり: 「" SearchKey() "」")
        }
        if (StateTimedOut(CI("TransitionTimeoutSec"), "患者一覧の表示"))
            return
        Arm(500)
        return
    }
    if (G.searched) {
        SetState("pick_row")
        Arm(1200)                                   ; 絞り込みの反映を待つ
        return
    }
    cn := CS("SearchBoxClassNN")
    if (cn = "") {
        Abort("検索欄が config.ini に設定されていません（/listread を実行してください）。")
        return
    }
    key := SearchKey()
    if (CB("DryRun")) {
        Log("INFO", "[DryRun] 検索欄に入れたつもり: 「" key "」")
    } else {
        try {
            ControlSetText(key, cn, "ahk_id " h)
            ControlFocus(cn, "ahk_id " h)
            Sleep(200)
            ControlSend("{Enter}", cn, "ahk_id " h)
        } catch as e {
            Abort("検索欄に入力できませんでした: " e.Message)
            return
        }
    }
    Log("INFO", "検索: 「" key "」＋ Enter")
    G.searched := true
    Arm(1200)
}

; 姓と名のあいだの区切り。
;   INI のパーサは値を Trim するため、半角スペースをそのまま書いても消えてしまう。
;   そこでキーワードで指定する（既定は半角スペース = 実機で 1 件に絞れることを実証済み）。
NameSep() {
    v := CS("NameSeparator")
    if (v = "" || v = "space" || v = "sp")
        return " "
    if (v = "none" || v = "-")
        return ""
    if (v = "fullwidth" || v = "zen")
        return Chr(0x3000)
    return v
}

; 絞り込んだ先頭行を開く。1 件に絞れている保証はないので G1 が最終防壁。
TickPickRow() {
    global G
    h := FindScreen("S1_Index")
    if (!h) {
        if (HasScreen("S2_Card")) {                 ; もう開いた
            SetState("verify")
            Arm(500)
            return
        }
        if (StateTimedOut(CI("TransitionTimeoutSec"), "患者一覧の表示"))
            return
        Arm(500)
        return
    }
    if (StateTimedOut(CI("TransitionTimeoutSec"), "対象者の行を開く処理"))
        return
    if (!G.rowClicked) {
        x := CI("ListFirstRowX"), y := CI("ListFirstRowY")
        ; ★2 行目以降は、行の間隔ぶん下を開く★
        ;   ミドル無しのカードを狙うとき、検索では絞れないので
        ;   開いて照合し、違えば次の行を試す（2026-09-18）。
        if (G.rowTry > 1)
            y += CI("ListRowPitchY") * (G.rowTry - 1)
        y += G.rowExtra                            ; 同じ行を踏んだぶんの補正
        if (x <= 0 || y <= 0) {
            Abort("一覧の【先頭行の位置】がまだ登録されていません。`n`n"
                . "設定 →「一覧の先頭行を教える」で、1 行目（と 2 行目）を"
                . "教えてください。`n"
                . "この PC の画面に合わせて実測する必要があります"
                . "（ListFirstRowX / ListFirstRowY）。")
            return
        }
        if (!CountClick(Format("row:{1},{2}", x, y)))
            return
        if (CB("DryRun")) {
            Log("INFO", Format("[DryRun] 先頭行をダブルクリックしたつもり（x{1} y{2}）", x, y))
        } else if (!DoubleClickCtrl(h, CS("ListClassNN"), x, y, G.rowTry " 行目")) {
            Abort("一覧の先頭行を開けませんでした。`n"
                . "座標がずれている可能性があります。メニューの「一覧の先頭行を教える」で"
                . "実際の位置を記録してください。")
            return
        }
        G.rowClicked := true
    }
    Arm(1000)
}

;==============================================================================
;  ★G1★ 氏名照合
;==============================================================================
TickVerify() {
    global G
    h := FindScreen("S2_Card")
    if (!h) {
        if (StateTimedOut(CI("TransitionTimeoutSec"), "カード画面の表示"))
            return
        Arm(500)
        return
    }
    if (!VerifyPatient(h))
        return                                      ; 中で Abort 済み
    ; 調査前の履歴件数を控える（G2 の裏取り用）
    G.scanBefore := ReadRecordCount(h)
    if (G.scanBefore != "")
        Log("INFO", "調査前の履歴件数: " G.scanBefore)
    if (!CB("RunInvestigation")) {
        SetState("therapy_ready", "調査は行わない設定")
        Arm(500)
        return
    }
    SetState("scan_open")
    Arm(500)
}

; 「1/16020」のような表示から、総件数だけを取り出す。
;   ★左の数字は行カーソルの位置★
;     選択が動いただけで文字列が変わるため、そのまま比べると
;     調査していないのに「増えた」と誤判定する（2026-09-19 に画面で確認）。
;   区切りが無ければ、数字だけを拾う。
ParseCount(t) {
    t := Trim(t)
    if (t = "")
        return ""
    if (p := InStr(t, "/", , -1))
        t := SubStr(t, p + 1)
    out := ""
    Loop Parse, t
        if (A_LoopField >= "0" && A_LoopField <= "9")
            out .= A_LoopField
    return out
}

; カード画面の調査履歴の総件数（読めなければ空文字）
ReadRecordCount(hwnd) {
    cn := CS("RecordCountClassNN")
    if (cn = "")
        return ""
    t := ""
    try t := Trim(ControlGetText(cn, "ahk_id " hwnd))
    return ParseCount(t)
}

;==============================================================================
;  調査
;==============================================================================
TickScanOpen() {
    global G
    if (HasScreen("S2b_Anamnesis")) {
        SetState("scan_anamnesis")
        Arm(500)
        return
    }
    if (HasScreen("S3_Scheme")) {
        SetState("scan_scheme", "既往症画面を経由しませんでした")
        Arm(500)
        return
    }
    ; ★ここは時間がかかる★
    ;   2026-09-16、押してから画面が出るまで 60 秒を超えた（直後には出ていた）。
    ;   調査タイプによっては一覧の作り直しに時間がかかるため、長めに待つ。
    if (StateTimedOut(CI("ScanOpenTimeoutSec"), "「調査」を押して次の画面へ進む処理"))
        return
    ; ★押し直しは十分に間を置く★
    ;   同じときに 4 回押していた。処理中に押し足しても早くはならず、
    ;   むしろ二重に開くおそれがある。
    if (G.stateClickTS != "" && SecSince(G.stateClickTS) < CI("ScanOpenRetrySec")) {
        Arm(2000)
        return
    }
    if (h := FindScreen("S2_Card"))
        TryClick(h, CS("CardScanClassNN"), CS("CardScanText"))
    Arm(1000)
}

; 既往症画面は「進む」で通過するだけ（2026-09-13 合意）
;
;  ★スキーム画面は既往症画面と【同時に】現れる★
;    2026-09-13 のトレースで、19:57:25 に TpfFormPolling と TpfFormEasyPolling が
;    同じ秒に出ている。したがって「スキーム画面があるか」で次へ進む判定をしてはいけない。
;    そうすると「進む」を一度も押さないまま scan_go へ行き、
;    裏に隠れたスキーム画面の「調査」を押し続けて止まる（2026-09-14 の失敗）。
;
;    抜ける条件は【既往症画面が閉じたこと】。トレースでも「進む」の 6.0 秒後に閉じている。
TickScanAnamnesis() {
    h := FindScreen("S2b_Anamnesis")
    if (!h) {                                   ; 閉じた＝通過できた
        if (HasScreen("S3_Scheme")) {
            SetState("scan_scheme")
            Arm(500)
            return
        }
        if (StateTimedOut(CI("TransitionTimeoutSec"), "スキーム画面の表示"))
            return
        Arm(500)
        return
    }
    if (StateTimedOut(CI("AnamnesisTimeoutSec"), "既往症画面の通過"))
        return
    TryClick(h, CS("AnamnesisNextClassNN"), CS("AnamnesisNextText"))
    Arm(1000)
}

; スキーム画面のリスト読み込みを待ってから「調査」を押す
TickScanScheme() {
    global G
    ; 既往症画面が手前に残っているうちは、裏のスキーム画面を触っても何も起きない
    if (HasScreen("S2b_Anamnesis")) {
        SetState("scan_anamnesis", "既往症画面がまだ開いています")
        Arm(500)
        return
    }
    h := FindScreen("S3_Scheme")
    if (!h) {
        if (StateTimedOut(CI("TransitionTimeoutSec"), "スキーム画面の表示"))
            return
        Arm(500)
        return
    }
    ; アンカー（インタラクティブ既往症 / 調査）が両方読めたら描画が済んだとみなす
    if (!AutoTherapyPoint(h, &cx, &cy, &how)) {
        if (StateTimedOut(CI("SchemeListWaitSec"), "スキーム画面の描画"))
            return
        Arm(700)
        return
    }
    SetState("scan_type")
    Arm(300)
}

;------------------------------------------------------------------------------
;  調査タイプ／マニュアル選択を設定する
;------------------------------------------------------------------------------
;  どちらも【描画されたボタン】で、開く一覧の項目も描画。文字が一つも読めないので
;  座標で押すしかない（2026-09-15 のトレースで判明）。位置は
;  「設定 → 調査タイプ／マニュアル選択の位置を教える」で記録する。
;
;  カードによって選択が変わるため、★毎回かならず設定し直す★。
;
;  進み方（G.optStep）
;    0 ボタンを押す → 1 一覧が開くのを待つ → 2 項目を押す → 3 閉じて作り直しが終わるのを待つ
;------------------------------------------------------------------------------
TickScanOption(grp) {
    global G
    jp := (grp = "ScanType") ? "調査タイプ" : "マニュアル選択"
    want := (grp = "ScanType") ? CS("ScanTypeName") : CS("ManualName")
    if (Trim(want) = "") {
        NextAfterOption(grp, jp " は指定なし")
        Arm(300)
        return
    }
    ; 「どれも選ばない」＝青い項目を押して外す（マニュアル選択のみ）
    ;   ★青い項目は、押せば外れる★（2026-09-17 利用者に確認）
    ;   ただし一覧の「選択を解除」は【測定項目のチェックを全消し】するボタンなので、
    ;   絶対に使わない。記録もさせていない。
    noneMode := (grp = "Manual" && Trim(want) = "なし")
    idx := noneMode ? 1 : OptIndex(grp, want)
    if (!noneMode && idx = 0) {
        Log("WARN", Format("{1}「{2}」の位置が記録されていないため、設定を飛ばします"
            . "（設定 →「調査タイプ／マニュアル選択の位置を教える」）", jp, want))
        NextAfterOption(grp, jp " は位置が未記録")
        Arm(300)
        return
    }
    h := FindScreen("S3_Scheme")
    if (!h) {
        if (StateTimedOut(CI("TransitionTimeoutSec"), jp " の設定"))
            return
        Arm(500)
        return
    }
    sp := OptSpot(grp, idx)
    ; ★毎回いまの位置から計算する★ ウィンドウの大きさが変わっても追随する
    ; ★計算を優先★ 覚えた位置は、計算できないときの予備
    btn := SchemeDrawnButton(h, grp)
    if (!btn["ok"])
        btn := SpotFromAnchor(h, sp["btnAnchor"], sp["btnDX"], sp["btnDY"])
    if (!btn["ok"]) {
        ; ★ここで諦めない★
        ;   ボタンの位置は「インタラクティブ既往症／調査／現在の分析」の文字から計算している。
        ;   ソフトが一覧を作り直している間は文字が消えるので、一時的に計算できないだけ。
        ;   2026-09-17、項目を押した直後の作り直し中にこれで「基準が不明」と誤判定し、
        ;   マニュアル選択が毎回とばされていた。待てば戻る。
        G.optNoBtn++
        if (G.optNoBtn < 20) {                      ; 20 秒ほどは待つ
            Arm(1000)
            return
        }
        Log("WARN", Format("{1} のボタンの位置を計算できません（20 秒待ちました）。設定を飛ばします"
            . "／基準にしている文字: {2} ・ {3} ・ {4}"
            , jp, CS("AnchorLeftText"), CS("AnchorRightText"), CS("SchemeRowRefText")))
        G.optWarn .= (G.optWarn = "" ? "" : " / ") jp "の位置を計算できず"
        NextAfterOption(grp, jp " は基準が不明")
        Arm(300)
        return
    }
    G.optNoBtn := 0
    vis := false
    if (sp["panel"] != "") {
        try vis := ControlGetVisible(sp["panel"], "ahk_id " h)
    }
    if (StateTimedOut(CI("SchemeListWaitSec"), jp " の設定"))
        return

    switch G.optStep {
        case 0:                                     ; 一覧を開く
            if (!SchemeReady(h)) {
                Arm(1000)
                return
            }
            ; ★画面に入った直後は押さない★
            ;   2026-09-16、スキーム画面の 2 秒後に押して一覧が開かなかった。
            ;   項目が多いカードでは、描画が終わるまで押しても反応しない。
            if (StateSec() < CI("SchemeSettleSec")) {
                Arm(1000)
                return
            }
            if (CB("DryRun")) {
                Log("INFO", Format("[DryRun] {1} を「{2}」にするつもり", jp, want))
                NextAfterOption(grp, "DryRun")
                Arm(300)
                return
            }
            ; ★すでに開いているなら押さない★
            ;   押すと【閉じて】しまう。利用者が先に開けていることがある
            ;   （2026-09-17 指摘。試験中は画面を見ながら手で開けることが多い）。
            ;   これまでは必ず押していたため、開いていた一覧を閉じてしまい、
            ;   「6 秒たっても開かない」と警告して押し直していた。
            if (vis) {
                Log("INFO", jp " の一覧はすでに開いています（押さずに進みます）")
                G.optStep := 2
                Arm(300)
                return
            }
            if (ClickAt(h, btn["x"], btn["y"], jp " を開く")) {
                G.optStep  := 1
                G.optTS    := A_Now
                G.optTries += 1
            }
            Arm(800)
        case 1:                                     ; 開くのを待つ
            if (vis || sp["panel"] = "") {
                Log("INFO", jp " の一覧が開きました（" sp["panel"] "）")
                G.optStep := 2
                Arm(400)
                return
            }
            ; ★開かなければ押し直す。3 回だめなら止める★
            ;   黙って飛ばすと、カードに残っていた別の調査タイプのまま調査してしまう
            if (SecSince(G.optTS) >= CI("SchemeOpenRetrySec")) {
                if (G.optTries >= 3) {
                    ; ★ここで止めない★
                    ;   2026-09-16、位置の記録ミスで 3 件続けて失敗し、運転全体が止まった。
                    ;   調査そのものは動くのだから、警告を残して先へ進む。
                    ;   設定できなかったことは【確認待ち】にも出るので、見落とさない。
                    msg := Format("{1} を「{2}」に設定できませんでした（{3} 回押しても一覧が開かず）。"
                        . "押した位置 x{4} y{5}（基準 {6} / 一覧 {7}）。"
                        . "設定 →「調査タイプ／マニュアル選択の位置を教える」で記録し直してください"
                        , jp, want, G.optTries, btn["x"], btn["y"]
                        , sp["btnAnchor"] = "" ? "計算" : sp["btnAnchor"], sp["panel"])
                    Log("WARN", msg)
                    G.optWarn .= (G.optWarn = "" ? "" : " / ") jp "を設定できず"
                    G.optStep := 0
                    NextAfterOption(grp, jp " は設定できませんでした")
                    Arm(500)
                    return
                }
                Log("WARN", Format("{1} の一覧が 6 秒たっても開かないので、もう一度押します", jp))
                G.optStep := 0
            }
            Arm(500)
        case 2:                                     ; 何を押すか決めて、押す
            if (sp["panel"] = "") {
                Log("WARN", Format("{1} の一覧が記録されていません。設定を飛ばします", jp))
                G.optStep := 0
                NextAfterOption(grp, jp " は一覧が不明")
                return
            }
            ; ★一覧が閉じていたら、読まない・押さない★
            ;   2026-09-17、項目を外した直後に一覧が閉じたのに読み続け、
            ;   下の画面（グラフ）の色を読んで「スキーム 1 が青い」と誤判定し、
            ;   一覧ではない場所を押してしまった。
            ;   実測: 2 回目の読みは #0000FF・#FFFFFF・#6AEFEF ばかりだった。
            ;   一覧の色は #E1E1E1（通常）と #CCE4F7（選択中）である。
            if (!vis) {
                Log("INFO", jp " の一覧が閉じているので、開き直してから確かめます")
                G.optStep := 0
                Arm(800)
                return
            }
            if (noneMode) {
                ; ★どれも選ばれていない状態にする★
                ;   読む前にカーソルを一覧の外（ボタンの上）へ逃がす。
                ;   カーソルが乗っている行は薄青くなるので、選択中と間違える。
                MouseMove btn["x"], btn["y"], 0
                on := HighlightedOptIndex(h, grp)
                if (on = 0) {
                    Log("INFO", jp " は、どれも選ばれていません")
                    G.optStep := 4
                    Arm(300)
                    return
                }
                if (G.optOff >= 8) {
                    Log("WARN", jp " の選択を外しきれませんでした")
                    G.optWarn .= (G.optWarn = "" ? "" : " / ") jp "の選択を外せず"
                    G.optStep := 4
                    Arm(300)
                    return
                }
                ; ★同じものを押しても外れないなら、そこで止める★
                ;   2026-09-16、スキーム 1 を 5 回押し続けた。
                ;   マニュアル選択の項目は「動作」なので、押すたびに実害がある。
                if (on = G.optLast) {
                    Log("WARN", Format("{1}「{2}」を押しても外れないので、"
                        . "これ以上は触りません", jp, OptNameAt(grp, on)))
                    G.optWarn .= (G.optWarn = "" ? "" : " / ") jp "の選択を外せず"
                    G.optStep := 4
                    Arm(300)
                    return
                }
                G.optLast := on
                nm    := OptNameAt(grp, on)
                offSp := OptSpot(grp, on)
                if (ClickCtrlAt(h, sp["panel"], offSp["dx"], offSp["dy"]
                    , jp "「" nm "」の選択を外す")) {
                    G.optOff++
                    G.optStep := 3
                    G.optTS   := A_Now
                    G.optBusy := false
                }
                Arm(1000)
                return
            }
            ; ★調査タイプだけは「すでに選ばれていれば押さない」★
            ;   調査タイプは選択状態が残る（詳細が青いまま）。押す必要がない。
            ;   マニュアル選択は【動作の一覧】で、選択状態が残らない。
            ;   2026-09-17 の実測では、どの項目も青くならなかった（B-R ≒ 0）。
            ;   しかも色を読む点が文字の上に乗っており（自動選択 #4C555C, B-R+16）、
            ;   しきい値 20 のすぐ下。誤って「選択済み」と判定すると、
            ;   項目を選び直さないまま調査が走る（＝1 項目になる）。
            ;   マニュアル選択では判定せず、毎回かならず押す。
            MouseMove btn["x"], btn["y"], 0
            if (grp = "ScanType"
                && ItemHighlight(h, sp["panel"], sp["dx"], sp["dy"])["hit"] >= CI("HighlightHitMin")) {
                Log("INFO", Format("{1}「{2}」はすでに選ばれています", jp, want))
                G.optStep := 4
                Arm(300)
                return
            }
            ; ★一覧そのものを名指しして押す★（重なっている項目リストに入らないように）
            if (ClickCtrlAt(h, sp["panel"], sp["dx"], sp["dy"], jp "「" want "」")) {
                G.optStep := 3
                G.optTS   := A_Now
                G.optBusy := false
            }
            Arm(1000)
        case 3:                                     ; 作り直しが終わるのを待つ
            ; ★作り直しは押した直後ではなく、数秒遅れて始まる★
            ;   トレース（2026-09-15）: 詳細を押して 6 秒後にボタンの文字が消え、14 秒後に戻った。
            ;   押して 1.5 秒で「ビジーでない＝終わった」と判断すると、
            ;   これから始まる作り直しの最中に次のボタンを押してしまう。
            ;   → 「ビジーになって、戻った」を見届ける。
            ;     同じ項目を選び直したときなど作り直しが起きないこともあるので、
            ;     15 秒たっても始まらなければ、終わったものとみなす。
            ready := SchemeReady(h)
            if (!ready && !G.optBusy) {
                G.optBusy := true
                Log("INFO", jp " を反映中（ソフトが一覧を作り直しています）")
            }
            if (ready && (G.optBusy || SecSince(G.optTS) >= 15)) {
                Log("INFO", Format("{1} を反映しました（{2} 秒）", jp, SecSince(G.optTS)))
                G.optStep := noneMode ? 2 : 4      ; 外す場合は、もう一度ぜんぶ見直す
                Arm(600)
                return
            }
            Arm(1000)
        case 4:                                     ; 一覧が開いたままなら閉じて、次へ
            if (vis) {
                ClickAt(h, btn["x"], btn["y"], jp " の一覧を閉じる")
                Arm(1200)
                return
            }
            if (!SchemeReady(h)) {
                Arm(1000)
                return
            }
            G.optStep := 0
            NextAfterOption(grp, jp "＝" (noneMode ? "どれも選ばない" : want))
            Arm(800)
    }
}

; つぎの状態へ。★行き先をここに文字どおり書いておく★
;   変数で渡すと、配布前チェックが「どこからも遷移しない状態」と誤検知する。
;   読む人にとっても、この 2 つしかないことが分かるほうがよい。
NextAfterOption(grp, note := "") {
    if (grp = "ScanType")
        SetState("scan_manual", note)
    else
        SetState("scan_go", note)
}

; スキーム画面が操作を受け付けられる状態か（作り直し中はボタンの文字が消える）
SchemeReady(hwnd) {
    t := ""
    try t := Trim(ControlGetText(CS("SchemeScanClassNN"), "ahk_id " hwnd))
    return (t != "")
}

TickScanGo() {
    global G
    if (HasScreen("S2b_Anamnesis")) {           ; 同上
        SetState("scan_anamnesis", "既往症画面がまだ開いています")
        Arm(500)
        return
    }
    h := FindScreen("S3_Scheme")
    if (!h) {
        Arm(500)
        return
    }
    ; 調査が始まった＝ウィンドウ名が長い方へ変わる（仕様書 §5.3-(1)）
    if (ScanIsRunning(h)) {
        G.scanStartTS := A_Now
        SetState("scan_running")
        Arm(2000)
        return
    }
    if (StateTimedOut(CI("ScanStartTimeoutSec"), "調査の開始")) {
        return
    }
    TryClick(h, CS("SchemeScanClassNN"), CS("SchemeScanText"))
    Arm(2000)
}

; 調査中か：Polling のウィンドウ名が「実行中の名前」になっている、
; または項目スキャン画面が出ている
ScanIsRunning(hPolling := 0) {
    if (!hPolling)
        hPolling := FindScreen("S3_Scheme")
    if (hPolling) {
        t := ""
        try t := WinGetTitle("ahk_id " hPolling)
        if (t != "" && InStr(t, CS("SchemeBusyTitleHint")))
            return true
    }
    return HasScreen("S4_ScanItem")
}

TickScanRunning() {
    global G
    ; 進行の目印: 項目スキャン画面のウィンドウ名（臓器名）が変わり続ける
    now := ""
    if (h := FindScreen("S4_ScanItem")) {
        try now := WinGetTitle("ahk_id " h)
    }
    if (now != "" && now != G.lastScanItem) {
        G.lastScanItem := now
        G.scanProgressTS := A_Now
        G.scanItems++
        Log("INFO", Format("調査 {1} 項目目: {2}", G.scanItems, now))
    }
    if (G.scanProgressTS = "")
        G.scanProgressTS := A_Now

    if (ScanIsRunning()) {
        if (SecSince(G.scanProgressTS) > CI("ScanStallTimeoutSec")) {
            Abort(Format("調査の進行が {1} 以上止まっています。`n最後の項目: {2}"
                , FmtDur(CI("ScanStallTimeoutSec")), G.lastScanItem))
            return
        }
        Arm(2000)
        return
    }
    ; 実行中でなくなった → 完了ダイアログを探す
    dur := SecSince(G.scanStartTS)
    Log("INFO", Format("調査が終わったようです（{1} / {2} 項目）", FmtDur(dur), G.scanItems))
    G.scanSec := dur
    SetState("scan_dialog")
    Arm(500)
}

; 調査完了のダイアログ（「はい」1 個）を押す。
;   ★このダイアログは【毎回は出ない】★
;     2026-09-13 の 38 項目では出たが、2026-09-14 の 35 項目では出なかった（実機確認）。
;     出る条件は不明。したがって「出たら押す・出なければ待たずに進む」の両対応にする。
TickScanDialog() {
    global G
    if (h := FindScreen("Dialog")) {
        Log("INFO", "調査の完了ダイアログが出ました")
        TryClick(h, CS("DialogOkClassNN"), CS("DialogOkText"))
        G.dialogSeen := true
        Arm(800)
        return
    }
    ; 一度出て押したあとは、閉じたことを確認してすぐ進む
    if (G.dialogSeen) {
        SetState("scan_check", "ダイアログを閉じました")
        Arm(800)
        return
    }
    ; 出ないまま画面が落ち着いているなら、猶予だけ見て進む（60 秒も待たない）
    if (!ScanIsRunning() && StateSec() >= CI("DialogGraceSec")) {
        SetState("scan_check", "ダイアログは出ませんでした")
        Arm(500)
        return
    }
    if (StateSec() >= CI("DialogWaitSec")) {
        SetState("scan_check", "ダイアログの待ち時間を超えました")
        Arm(500)
        return
    }
    Arm(500)
}

; ★G2★ 本当に調査が走ったかを件数で裏取りする
TickScanCheck() {
    global G, STATEINI
    ; ダイアログが残っていれば先に片付ける（モーダルなので他は押せない）
    if (hd := FindScreen("Dialog")) {
        TryClick(hd, CS("DialogOkClassNN"), CS("DialogOkText"))
        Arm(800)
        return
    }
    h := FindScreen("S2_Card")
    if (!h) {
        ; スキーム画面に残っているなら戻す
        if (hs := FindScreen("S3_Scheme"))
            TryClick(hs, CS("SchemeBackClassNN"), CS("SchemeBackText"))
        if (StateTimedOut(CI("TransitionTimeoutSec"), "カード画面へ戻る処理"))
            return
        Arm(1000)
        return
    }
    after := ReadRecordCount(h)
    ; ★増えていなくても「止める」まではしない★
    ;   以前は Abort（＝失敗）だった。失敗が 3 回続くと運転全体が止まるので、
    ;   一覧の表示が更新されていないだけで一晩分が潰れる恐れがある。
    ;   セラピーへは進めず、確認待ちに回す（A-3 と同じ重さ）。
    if (G.scanBefore != "" && after != "" && after = G.scanBefore) {
        G.needCheck := Format("履歴件数が {1} のまま（調査の記録が増えていません）", after)
        Finish(4, Format("調査の記録が増えていません（履歴件数が「{1}」のまま）。`n`n"
            . "考えられるのは次の 3 つです。`n"
            . "  1. 項目が 1 つもチェックされていなかった`n"
            . "  2. 手動で止めた`n"
            . "  3. 一覧の表示がまだ更新されていないだけ`n`n"
            . "セラピーへは進んでいません。カードの履歴を確認してください。", after))
        return
    }
    ; ★「読めなかった」を「OK」と書かない★
    ;   件数を読めないのに「裏取り OK」と記録していたため、
    ;   何も確認していないのに確認済みに見えていた（2026-09-14）。
    ; 件数の表示は一覧の左下（例「1/16020」）。総件数だけを比べる。
    ;   設定していなければ、これまでどおり調査項目数（A-3）だけで確かめる。
    if (G.scanBefore != "" && after != "")
        Log("INFO", Format("★G2 裏取り OK: 履歴件数 {1} → {2}", G.scanBefore, after))
    ; ★調査項目が少なすぎるときは、完了にしない★
    ;   0 項目になるのは、次の 3 つのどれか（2026-09-17 利用者と整理）。
    ;     1. すでに調査済みで、調べるものが無かった
    ;     2. 手動で止めた（試験中はこれが最も多い）
    ;     3. 何らかの異常
    ;   画面からは見分けられないので、勝手に判断しない。
    ;   ★セラピーへは進まない★ 調べていないものに施術しないため。
    ;   失敗とも呼ばない（手動停止が多く、連続失敗で運転を止めてはいけない）。
    ; ★「その人の前回」と比べる★
    ;   0 項目でなくても、ふだん 50 項目の人が 3 項目で終わったらおかしい。
    ;   カード側の選択が壊れていても、件数を見なければ気づけない。
    least   := CI("MinScanItems")
    prev    := 0
    sameSet := false
    if (G.schedCurrent != "") {
        hm   := IniLoad(STATEINI)
        prev := ToInt(IniGet(hm, "History." G.schedCurrent, "LastScanItems", "0"), 0)
        ; ★前回と同じ設定のときだけ比べる★
        ;   マニュアル選択や調査タイプを変えれば、項目数は正当に半分以下になりうる。
        ;   設定が違うのに前回と比べると、正常な運転を確認待ちにしてしまう（2026-09-20 指摘）。
        sameSet := (Trim(IniGet(hm, "History." G.schedCurrent, "LastScanSig", "")) = ScanSig())
        if (prev > 0 && !sameSet)
            Log("INFO", "前回と設定が違うので、項目数の比較はしません（" . ScanSig() . "）")
    }
    if (prev > 0 && sameSet && (prev // 2) > least)
        least := prev // 2
    if (CB("RunInvestigation") && G.scanItems < least) {
        G.needCheck := Format("調査 {1} 項目（{2}）{3}", G.scanItems, FmtDur(G.scanSec)
            , (prev > 0 && sameSet) ? Format("／前回は {1} 項目", prev) : "")
        Finish(4, Format("調査が {1} 項目で終わりました（所要 {2}）。"
            . ((prev > 0 && sameSet) ? Format("`nこの方の前回は {1} 項目でした。", prev) : "") . "`n`n"
            . "考えられるのは次の 3 つです。`n"
            . "  1. すでに調査済みで、調べるものが無かった`n"
            . "  2. 手動で止めた`n"
            . "  3. 何らかの異常`n`n"
            . "どれなのかは画面からは分かりません。"
            . "セラピーへは進んでいません。カードを確認してください。"
            , G.scanItems, FmtDur(G.scanSec)))
        return
    }
    SetState("therapy_ready")
    Arm(500)
}

;==============================================================================
;  セラピー（AutoTherapy v4 の判定をそのまま流用 — 仕様書 §9.1）
;==============================================================================

; v4 の IsTherapyRunning() と同じ。★サイズを見てはいけない★（§5.3-1）
TherapyIsRunning() {
    global G
    ind := CS("IndicatorClass")
    for w in TargetWindows(G.pid) {
        if (w["class"] = ind)
            return true
    }
    return false
}

; スキーム画面まで戻ってセラピーを打てる状態にする
TickTherapyReady() {
    global G
    if (G.cycle >= CI("TherapyCount")) {
        SetState("cleanup", "指定回数を完了")
        Arm(500)
        return
    }
    if (HasScreen("S3_Scheme")) {
        SetState("therapy_click")
        Arm(500)
        return
    }
    if (HasScreen("S2b_Anamnesis")) {
        if (h := FindScreen("S2b_Anamnesis"))
            TryClick(h, CS("AnamnesisNextClassNN"), CS("AnamnesisNextText"))
        Arm(1000)
        return
    }
    if (StateTimedOut(CI("TransitionTimeoutSec"), "スキーム画面へ戻る処理"))
        return
    if (h := FindScreen("S2_Card"))
        TryClick(h, CS("CardScanClassNN"), CS("CardScanText"))
    Arm(1000)
}

TickTherapyClick() {
    global G
    ; DryRun は画面が動かない。ここで往復させず、回数だけ数えて先へ進める
    if (CB("DryRun")) {
        G.cycle++
        G.cycleStartTS := A_Now
        Log("INFO", Format("[DryRun] セラピー {1}/{2} 回目を押したつもり"
            , G.cycle, CI("TherapyCount")))
        SetState("therapy_start")
        Arm(500)
        return
    }
    h := FindScreen("S3_Scheme")
    if (!h) {
        SetState("therapy_ready")
        Arm(500)
        return
    }
    ; まだ前のセラピーが動いているなら打たない
    if (TherapyIsRunning()) {
        Log("INFO", "指標ウィンドウが残っています。落ち着くまで待ちます")
        Arm(3000)
        return
    }
    if (!AutoTherapyPoint(h, &cx, &cy, &how)) {
        if (StateTimedOut(CI("SchemeListWaitSec"), "自動セラピーの位置の特定"))
            return
        Arm(700)
        return
    }
    if (StateTimedOut(CI("TherapyStartTimeoutSec"), "セラピーの開始"))
        return
    G.cycle++
    G.cycleStartTS := A_Now
    Log("INFO", Format("--- セラピー {1}/{2} 回目 --- {3} → x{4} y{5}"
        , G.cycle, CI("TherapyCount"), how, cx, cy))
    ClickAt(h, cx, cy, "自動セラピー")
    SetState("therapy_start")
    Arm(1000)
}

; 押した結果ちゃんと始まったか（実測では 1 秒で指標が出る）
TickTherapyStart() {
    global G
    if (TherapyIsRunning()) {
        Log("INFO", Format("セラピー {1} 回目が始まりました", G.cycle))
        G.therapySeenTS := A_Now
        SetState("therapy_run")
        Arm(CI("PollIntervalMs"))
        return
    }
    if (CB("DryRun")) {
        SetState("therapy_run", "DryRun のため開始したことにする")
        Arm(1000)
        return
    }
    if (StateSec() > CI("VerifyTimeoutSec")) {
        Abort(Format("セラピーを押しましたが {1} 秒たっても始まりません。`n"
            . "クリックが効いていない可能性があります（管理者権限で実行してみてください）。"
            , CI("VerifyTimeoutSec")))
        return
    }
    Arm(500)
}

; v4 と同じ: 指標ウィンドウが StableChecks 回連続で見えなければ完了
; セラピーの完了と判定するのに、指標ウィンドウが何回続けて消えていればよいか。
;
;  ★実測した最大の途切れの 2 倍を必ず下回らないようにする★
;    途切れは 2026-09-13 に 4 秒、09-14 に 6 秒、09-15 に 7 秒と伸びている。
;    config.ini の StableChecks は固定値なので、環境が重くなると追いつかない。
;    しかも設定ファイルは更新で配り直さない方針なので、こちらから直せない。
;    そこで【そのジョブで実際に観測した途切れ】から下限を自動で引き上げる。
StableNeeded() {
    global G
    base := CI("StableChecks")
    poll := CI("PollIntervalMs") / 1000
    if (poll <= 0)
        return base
    ; 実測の最大途切れ × 2 ＋ 3 秒 を満たす回数
    need := Ceil((G.maxGap * 2 + 3) / poll)
    return Max(base, need)
}

TickTherapyRun() {
    global G
    if (CB("DryRun")) {
        SetState("therapy_rest", "DryRun")
        Arm(500)
        return
    }
    if (TherapyIsRunning()) {
        gap := SecSince(G.therapySeenTS)
        if (gap > G.maxGap) {
            G.maxGap := gap
            ; 完了と判定する閾値（下限）に対して、途切れが半分を超えたら知らせる。
            ; 閾値に迫っているなら StableChecks を増やすべきという合図
            limit := StableNeeded() * CI("PollIntervalMs") / 1000
            Log("WARN", Format("指標ウィンドウの途切れが {1} 秒（完了と判定する下限は {2} 秒）"
                , gap, Round(limit, 1)))
        }
        G.therapySeenTS := A_Now
        G.stable := 0
        if (SecSince(G.cycleStartTS) > CI("TherapyMaxSec")) {
            Abort(Format("セラピーが {1} を超えても終わりません。", FmtDur(CI("TherapyMaxSec"))))
            return
        }
        if (G.runLogTS = "" || SecSince(G.runLogTS) >= 300) {
            G.runLogTS := A_Now
            Log("INFO", Format("セラピー {1} 回目 実行中 {2} 経過", G.cycle, FmtDur(SecSince(G.cycleStartTS))))
        }
        Arm(CI("PollIntervalMs"))
        return
    }
    G.stable++
    if (G.stable < StableNeeded()) {
        Arm(CI("PollIntervalMs"))
        return
    }
    dur := SecSince(G.cycleStartTS)
    G.durations.Push(dur)
    G.runLogTS := ""
    Log("INFO", Format("cycle={1}/{2} event=cycle_done duration={3} 指標の最大途切れ={4}秒"
        , G.cycle, CI("TherapyCount"), FmtDur(dur), G.maxGap))
    if (!CheckCycleDuration(dur))
        return
    SaveState()
    SetState("therapy_rest")
    Arm(500)
}

; S5: 所要時間の異常検知。1 回目を基準に、2 回目以降のズレを見る
CheckCycleDuration(dur) {
    global G
    lo := CI("ExpectedCycleMinSec"), hi := CI("ExpectedCycleMaxSec")
    if (lo > 0 && dur < lo) {
        Abort(Format("セラピー {1} 回目が {2} で終わりました（想定の下限 {3} より短い）。`n"
            . "施術が正しく行われていない可能性があるため停止します。"
            , G.cycle, FmtDur(dur), FmtDur(lo)))
        return false
    }
    if (hi > 0 && dur > hi) {
        Abort(Format("セラピー {1} 回目が {2} かかりました（想定の上限 {3} より長い）。"
            , G.cycle, FmtDur(dur), FmtDur(hi)))
        return false
    }
    ; 1 回目を基準にした相対チェック（同一対象者内のばらつきは実測で数秒）
    if (G.durations.Length >= 2) {
        base := G.durations[1]
        tol  := Max(60, base * CI("CycleTolerancePct") // 100)
        if (Abs(dur - base) > tol) {
            Log("WARN", Format("1 回目 {1} に対して {2} 回目が {3}（差 {4} 秒）"
                , FmtDur(base), G.cycle, FmtDur(dur), Abs(dur - base)))
            if (CB("AbortOnAnomaly")) {
                Abort(Format("セラピーの所要時間が 1 回目と大きく違います。`n"
                    . "  1 回目: {1}`n  {2} 回目: {3}`n`n"
                    . "施術が同じように行われていない可能性があるため停止します。"
                    , FmtDur(base), G.cycle, FmtDur(dur)))
                return false
            }
        }
    }
    return true
}

TickTherapyRest() {
    global G
    if (StateSec() < CI("RestBetweenSec")) {
        Arm(1000)
        return
    }
    SetState("therapy_ready")
    Arm(500)
}

;==============================================================================
;  後始末
;==============================================================================
TickCleanup() {
    global G
    if (hd := FindScreen("Dialog")) {
        TryClick(hd, CS("DialogOkClassNN"), CS("DialogOkText"))
        Arm(800)
        return
    }
    if (HasScreen("S2_Card") && !HasScreen("S3_Scheme")) {
        Finish(0, "指定した内容を完了しました")
        return
    }
    if (StateTimedOut(CI("TransitionTimeoutSec"), "後始末")) {
        return
    }
    if (h := FindScreen("S3_Scheme"))
        TryClick(h, CS("SchemeBackClassNN"), CS("SchemeBackText"))
    Arm(1000)
}


;==============================================================================
;  停止・終了・状態の記録
;==============================================================================

; 停止手段 4 系統（v4 と同じ）。どれでも 5 秒以内に止まる。
;   ★止めるのは「次のクリックから」。実行中の施術は中断しない（G8）
CheckStopFiles() {
    global G, STOPFILE, REMOTEFILE
    if FileExist(STOPFILE) {
        Finish(3, "STOP ファイルを検出しました")
        return true
    }
    if FileExist(REMOTEFILE) {
        body := ""
        try body := Trim(FileRead(REMOTEFILE, "UTF-8"))
        if (InStr(body, FormatTime(A_Now, "yyyy-MM-dd"))) {
            Finish(3, "遠隔停止ファイル（REMOTE_STOP）を検出しました")
            return true
        }
    }
    return false
}

Abort(reason) {
    Log("ERROR", "中止: " StrReplace(reason, "`n", " / "))
    Finish(2, reason)
}

Finish(code, reason) {
    global G, APP_NAME, LIVEFILE
    if (G.stopping)
        return
    G.stopping := true
    SetTimer(Tick, 0)
    SaveState()
    ; --- スケジュール運転中は、ここで終了せずスケジューラへ制御を返す ---------
    if (G.schedOn) {
        summary := BuildSummary(code, reason)
        Log("INFO", "ジョブ終了 code=" code " reason=" StrReplace(reason, "`n", " / "))
        try FileAppend(CRLF("`n" summary "`n"), G.logFile, "UTF-8")
        G.stopping := false                        ; 次のジョブのために戻す
        SchedJobFinished(code, reason, summary)
        return
    }
    ClosePanel()
    try FileDelete(LIVEFILE)                       ; 単独実行はここで終わり
    summary := BuildSummary(code, reason)
    Log("INFO", "終了 code=" code " reason=" StrReplace(reason, "`n", " / "))
    try FileAppend(CRLF("`n" summary "`n"), G.logFile, "UTF-8")
    WriteStatus(true)
    icon := (code = 0) ? "Iconi 4096" : "Icon! 4096"
    MsgBox(summary, APP_NAME " - " (code = 0 ? "完了" : (code = 4 ? "要確認" : "停止")), icon)
    ; ★人がメニューから始めたなら、メニューへ戻す★
    ;   続けてもう 1 人を実行したいのに、毎回ソフトが消えていた（2026-09-22 指摘）。
    ;   状態を引きずらないよう、新しく起こし直してから自分は終わる。
    if (G.fromMenu)
        OpenMenuWindow()                       ; 二重に開かない仕組みを通す
    ExitApp(code)
}

BuildSummary(code, reason) {
    global G
    o := "=== AutoMeta 実行結果 ===`n"
    o .= "対象者     : 「" G.wantSei " " G.wantMei "」"
       . (G.gotSei = "" ? "（照合前）" : "  → 照合 OK") "`n"
    scanTxt := "実行しない設定"
    if (CB("RunInvestigation")) {
        scanTxt := (G.scanSec > 0) ? (FmtDur(G.scanSec) . " / " . G.scanItems . " 項目") : "未完了"
    }
    o .= "調査       : " . scanTxt . "`n"
    o .= "セラピー   : " G.cycle " / " CI("TherapyCount") " 回`n"
    if (G.durations.Length > 0) {
        list := ""
        for d in G.durations
            list .= (list = "" ? "" : " / ") FmtDur(d)
        o .= "各サイクル : " list "`n"
        o .= "指標の最大途切れ: " G.maxGap " 秒`n"
    }
    o .= "総クリック : " G.clicks " 回（上限 " MaxClicksTotal() "）`n"
    if (G.logLost > 0)
        o .= "★記録できなかったログ : " G.logLost " 行（ログを開いたままにしていませんか）`n"
    o .= "総所要時間 : " FmtDur(SecSince(G.startTS)) "`n"
    if (CB("DryRun"))
        o .= "`n※ DryRun のため、実際には何も押していません。`n"
    o .= "`n理由       : " reason "`n"
    o .= "`n※ 本ツールは画面の状態しか見ていません。`n"
       . "   実際の施術完了は、ソフト側の履歴で確認してください。`n"
    return o
}

WriteStatus(force := false) {
    global G, STATUSTX, APP_VER
    if (!force && G.statusTS != "" && SecSince(G.statusTS) < 20)
        return
    G.statusTS := A_Now
    WriteLive()
    o := "AutoMeta " APP_VER "   " FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss") "`n"
    o .= "状態      : " G.state (CB("DryRun") ? "（DryRun）" : "") "`n"
    o .= "対象者    : " G.wantSei " " G.wantMei
       . (G.gotSei = "" ? "" : "  （照合 OK）") "`n"
    if (CB("RunInvestigation")) {
        st := (G.scanSec > 0) ? ("完了 " . FmtDur(G.scanSec)) : (G.scanItems . " 項目目")
        o .= "調査      : " . st . "`n"
    }
    o .= "セラピー  : " G.cycle " / " CI("TherapyCount") " 回`n"
    if (G.state = "therapy_run")
        o .= "  経過    : " FmtDur(SecSince(G.cycleStartTS)) "`n"
    o .= "経過      : " FmtDur(SecSince(G.startTS)) "`n"
    o .= "画面      : " ScreenNames() "`n"
    try {
        FileDelete(STATUSTX)
    }
    try FileAppend(CRLF(o), STATUSTX, "UTF-8")
}

SaveState() {
    global G, STATEINI
    IniSetMany(STATEINI, "Job", Map(
        "Patient",      G.wantSei " " G.wantMei,
        "State",        G.state,
        "TherapyDone",  G.cycle,
        "TherapyTotal", CI("TherapyCount"),
        "StartedAt",    FmtTS(G.startTS)))
}

; 異常時に画面を保存する（原因究明用）
SaveShot(tag) {
    global G, SHOTDIR
    if !DirExist(SHOTDIR)
        DirCreate(SHOTDIR)
    ; AHK 単体では画面キャプチャができないため、代わりに全ウィンドウの
    ; コントロール一覧をテキストで残す（原因究明にはこれで足りる）
    path := SHOTDIR "\" FormatTime(A_Now, "yyyyMMdd_HHmmss") "_" tag ".txt"
    o := "=== " tag "  " FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss") " ===`n"
    o .= "状態: " G.state "  / 対象者: " G.wantSei " " G.wantMei "`n`n"
    for w in TargetWindows(G.pid) {
        o .= "── 「" w["title"] "」  class=" w["class"]
           . "  判定=" ClassifyScreen(w["hwnd"])["id"] "`n"
        o .= CtrlsToText(DumpCtrls(w["hwnd"]))
        o .= "`n"
    }
    try FileAppend(CRLF(o), path, "UTF-8")
    Log("WARN", "画面の状態を保存しました: " path)
}

;==============================================================================
;  トレイ常駐とホットキー
;==============================================================================
; メニューを【別プロセスで】開く。
;   運転中のプロセスでメニューを開くと、設定や状態を書き換えてしまう恐れがある。
;   2_START.bat と同じことを、自分自身を起動してやる。
;   （毎回エクスプローラーからファイルを選ぶのが手間、というカマヤン指摘 2026-09-15）
OpenMenuWindow() {
    global APP_NAME
    ; ★すでに開いているメニューがあるなら、そちらを前に出す★
    ;   毎回 /menu で新しいプロセスを起こしていたため、
    ;   押した回数だけ窓が増えていた（2026-09-18 指摘）。
    if (MenuWindowHwnd()) {
        try WinActivate("ahk_id " MenuWindowHwnd())
        return
    }
    try {
        Run('"' A_AhkPath '" "' A_ScriptFullPath '" /menu', A_ScriptDir)
    } catch as e {
        MsgBox("メニューを開けませんでした: " e.Message "`n`n"
            . "system\2_START.bat（または menu.bat）から開いてください。"
            , APP_NAME, "Iconx 4096")
    }
}

; いま開いている AutoMeta のメニュー窓（無ければ 0）。
;   ★自分の窓は数えない★ タイトルだけで探すと自分自身を拾ってしまう。
;   ★運転パネルと間違えない★
;     パネルのタイトルは「AutoMeta  v2.5.2」で、以前の判定
;     （APP_NAME を含み " - " を含まない）にそのまま当てはまっていた。
;     そのため運転中はメニューを開けず、パネルが前に出るだけになっていた。
MenuWindowHwnd() {
    global APP_NAME
    mine := MyPid()
    want := APP_NAME . " - メニュー"
    for h in WinGetList() {
        t := "", pid := 0
        try {
            t := WinGetTitle("ahk_id " h)
            pid := WinGetPID("ahk_id " h)
        } catch
            continue
        if (pid != mine && InStr(t, want))
            return h
    }
    return 0
}

SetupTray() {
    global G, APP_NAME
    A_TrayMenu.Delete()
    A_TrayMenu.Add("パネルを表示", (*) => RestorePanel())
    A_TrayMenu.Add("メニューを開く", (*) => OpenMenuWindow())
    A_TrayMenu.Add()
    A_TrayMenu.Add("状態を表示", (*) => MsgBox(BuildSummary(9, "（実行中）"), APP_NAME, "Iconi 4096"))
    A_TrayMenu.Add("ログを開く", (*) => OpenFile(G.logFile))
    A_TrayMenu.Add()
    A_TrayMenu.Add("終了（次のクリックから止める）", (*) => Finish(3, "トレイから停止しました"))
    A_TrayMenu.Default := "状態を表示"
    Hotkey("^!+s", (*) => Finish(3, "ホットキーで停止しました"))
    Hotkey("^!+m", (*) => OpenMenuWindow())        ; Ctrl+Alt+Shift+M でメニュー
    UpdateTrayTip()
    SetTimer(UpdateTrayTip, 5000)
}

UpdateTrayTip() {
    global G, APP_NAME
    try A_IconTip := APP_NAME "`n" G.wantSei " " G.wantMei
        . "`nセラピー " G.cycle "/" CI("TherapyCount") "`n" G.state
}

;==============================================================================
;  /run  単発実行（Phase 1 の入口）
;==============================================================================
ModeRun() {
    global G, C, APP_NAME, APP_VER, STOPFILE
    LicenseGate()                                  ; 利用の期限（止めるならここで終わる）
    EnsureSingleInstance()
    EnsureTarget()
    LoadScreens()
    try FileDelete(STOPFILE)                        ; 取り残しで動かなくならないように

    if (!Preflight(&msg)) {
        MsgBox(msg, APP_NAME " - 実行できません", "Icon! 4096")
        ExitApp(1)
    }

    dlg := Gui("+AlwaysOnTop", APP_NAME " - 実行" VerTag())
    dlg.MarginX := 18, dlg.MarginY := 14
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "w560", "1 人分を実行します（調査 1 回 ＋ セラピー N 回）")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w560 cGray", APP_VER "   対象ソフト: " CS("ExeName"))
    dlg.Add("Text", "w560 h1 0x10")

    dlg.SetFont("s10", "Meiryo UI")
    dlg.Add("Text", "w120", "姓")
    eSei := dlg.Add("Edit", "x+10 yp-4 w180", CS("LastName"))
    dlg.Add("Text", "x+20 yp+4 w60", "名")
    eMei := dlg.Add("Edit", "x+10 yp-4 w180", CS("FirstName"))
    dlg.Add("Text", "xm w120", "ミドル")
    eMid := dlg.Add("Edit", "x+10 yp-4 w180", CS("MiddleName"))
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "xm w560 cGray"
        , "  一覧の検索欄に「姓␣名」を入れて絞り込みます。開いたカードの姓名が"
        . "一致しなければ、何もせず中止します。`n"
        . "  ミドルは、同じ方の比較用カードと区別するときだけ入れます"
        . "（空欄＝ミドル無しのカードが対象）。")

    dlg.SetFont("s10", "Meiryo UI")
    cScan := dlg.Add("CheckBox", "xm w560 " (CB("RunInvestigation") ? "Checked" : "")
        , "調査を 1 回実行する")
    dlg.Add("Text", "xm w120", "セラピー回数")
    eCnt := dlg.Add("Edit", "x+10 yp-4 w60 Number", CI("TherapyCount"))
    dlg.Add("UpDown", "Range0-" . CI("MaxUnattendedCycles"), CI("TherapyCount"))
    ; 見積もりは行を分ける（横に置くと文字が切れる。2026-09-17 指摘）
    dlg.SetFont("s9", "Meiryo UI")
    lblEst := dlg.Add("Text", "xm+12 w548 cGray", "")
    dlg.SetFont("s10", "Meiryo UI")

    ; ★予定の編集画面と同じ選択肢を、ここにも出す★
    ;   ここに無いと、1 人だけ実行したときだけ設定が効かない（2026-09-17 指摘）
    stNames := OptNames("ScanType")
    mnNames := OptNames("Manual")
    stList  := [NoChangeLabel()]
    for nm in stNames
        stList.Push(nm)
    mnList := [NoChangeLabel(), NoneSelectLabel()]
    for nm in mnNames
        mnList.Push(nm)
    dlg.Add("Text", "xm w120", "調査タイプ")
    dST := dlg.Add("DropDownList", "x+10 yp-4 w140", stList)
    SelectByName(dST, stList, OptLabelOfValue(CS("ScanTypeName")))
    dlg.Add("Text", "x+16 yp+4 w110", "マニュアル選択")
    dMN := dlg.Add("DropDownList", "x+10 yp-4 w160", mnList)
    SelectByName(dMN, mnList, OptLabelOfValue(CS("ManualName")))
    if (!stNames.Length || !mnNames.Length) {
        dlg.SetFont("s9", "Meiryo UI")
        dlg.Add("Text", "xm+12 w548 cRed"
            , "※ 位置が未登録です（設定 →「調査タイプ／マニュアル選択の位置を教える」）")
        dlg.SetFont("s10", "Meiryo UI")
    }

    dlg.SetFont("s10", "Meiryo UI")
    cDry := dlg.Add("CheckBox", "xm w560 " (CB("DryRun") ? "Checked" : "")
        , "DryRun（画面は追うが、一切クリックしない）")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "xm w560 cGray"
        , "  はじめての対象者では、まず DryRun で画面遷移が想定どおりか確かめてください。")

    dlg.Add("Text", "xm w560 h1 0x10")
    dlg.SetFont("s10", "Meiryo UI")
    bGo := dlg.Add("Button", "xm w260 h40 Default", "開始する")
    bNo := dlg.Add("Button", "x+20 yp w260 h40", "やめる")
    bGo.OnEvent("Click", DoRun)
    bNo.OnEvent("Click", (*) => ExitApp(0))
    dlg.OnEvent("Close", (*) => ExitApp(0))
    eCnt.OnEvent("Change", (*) => UpdateEst())
    UpdateEst()
    dlg.Show()
    return

    UpdateEst() {
        n := ToInt(eCnt.Value, 0)
        if (n = 0) {
            lblEst.Value := "0 回 ＝ 施術は行いません（調査だけ）"
            return
        }
        lblEst.Value := Format("目安 {1}〜{2}（セラピー 1 回 6〜30 分の実測より）"
            , FmtDur(n * 360), FmtDur(n * CI("PlanCycleSec")))
    }

    DoRun(*) {
        global G, C
        sei := Trim(eSei.Value), mei := Trim(eMei.Value)
        if (sei = "" || mei = "") {
            MsgBox("姓と名の両方を入れてください。`n"
                . "同姓の方が複数いるため、姓だけでは一意に絞れません。", APP_NAME, "Icon! 4096")
            return
        }
        n := ToInt(eCnt.Value, 0)
        if (n < 0) {
            MsgBox("セラピー回数は 0 以上にしてください。", APP_NAME, "Icon! 4096")
            return
        }
        if (n = 0 && !cScan.Value) {
            MsgBox("調査もセラピーも行わない設定です。`nどちらかを有効にしてください。"
                , APP_NAME, "Icon! 4096")
            return
        }
        if (n > CI("MaxUnattendedCycles")) {
            MsgBox(Format("セラピー回数の上限は {1} 回です。", CI("MaxUnattendedCycles"))
                , APP_NAME, "Icon! 4096")
            return
        }
        C["TherapyCount"]     := n
        C["RunInvestigation"] := cScan.Value ? "1" : "0"
        C["DryRun"]           := cDry.Value ? "1" : "0"
        C["ScanTypeName"]     := (dST.Value <= 1) ? "" : stList[dST.Value]
        C["ManualName"]       := (dMN.Value = 1) ? "" : ((dMN.Value = 2) ? "なし" : mnList[dMN.Value])
        G.wantSei := sei, G.wantMei := mei, G.wantMid := Trim(eMid.Value)

        ; 警告文は先に組み立てる（行頭が ":" の継続行はラベルと紛れるため使わない）
        warn := ""
        if (!cDry.Value) {
            if (n = 0) {
                warn := "※ セラピー 0 回なので、施術は行いません（調査のみ）。`n`n"
            } else {
                warn := "★実際に施術が始まります。対象者と回数をもう一度確認してください。★`n`n"
            }
        }
        est := (n = 0) ? "（施術なし）" : Format("（目安 {1}〜{2}）", FmtDur(n * 360), FmtDur(n * CI("PlanCycleSec")))
        msg := Format("この内容で実行します。`n`n"
            . "  対象者    : 「{1} {2}」`n"
            . "  調査      : {3}`n"
            . "  セラピー  : {4} 回{5}`n"
            . "  DryRun    : {6}`n`n"
            . "{7}"
            . "開始してよろしいですか？"
            , sei, mei, cScan.Value ? "1 回実行する" : "実行しない", n
            , est
            , cDry.Value ? "はい（何も押しません）" : "いいえ（実際に操作します）"
            , warn)
        opt := "YesNo Icon? 4096" . (cDry.Value ? "" : " Default2")
        if (MsgBox(msg, APP_NAME " - 最終確認", opt) != "Yes")
            return
        dlg.Destroy()
        SetupTray()
        ShowPanel()
        StartJob()
    }
}

; 起動前の点検
; needSelect = false なら、対象者の検索に関わる設定は要求しない
;   （自動セラピーは、いま開いているカードを使うので検索しない）
Preflight(&msg, needSelect := true) {
    global G
    msg := ""
    ng := []
    if (CS("ExeName") = "")
        ng.Push("対象ソフトが設定されていません（1_SETUP.bat）")
    if (CS("LastNameFieldClassNN") = "" || CS("FirstNameFieldClassNN") = "")
        ng.Push("姓名の欄が設定されていません（メニューの「読み取り可否を調べる」を実行）")
    if (needSelect) {
        if (CS("SearchBoxClassNN") = "")
            ng.Push("検索欄が設定されていません（同上）")
        if (CI("ListFirstRowX") <= 0 || CI("ListFirstRowY") <= 0)
            ng.Push("一覧の先頭行の座標が設定されていません（config.ini の ListFirstRowX/Y）")
        if (!CB("VerifyPatientName"))
            ng.Push("VerifyPatientName=0 は許可されていません（氏名照合は省略できません）")
    }
    if (CS("IndicatorClass") = "")
        ng.Push("指標ウィンドウのクラスが設定されていません（config.ini の IndicatorClass）")
    ; 見込みの所要時間が、実行時間の上限を超えないか。
    ;   ExpectedCycleMaxSec（＝異常検知の上限 90 分）で見積もると過大になるため、
    ;   実測の上側（PlanCycleSec 既定 30 分）で見積もる
    worst := CI("TherapyCount") * CI("PlanCycleSec") + 1800
    if (CI("MaxRuntimeSec") > 0 && worst > CI("MaxRuntimeSec")) {
        ng.Push(Format("セラピー {1} 回だと最大 {2} かかる見込みで、実行時間の上限 {3} を超えます。`n"
            . "      回数を減らすか、config.ini の MaxRuntimeSec を延ばしてください"
            , CI("TherapyCount"), FmtDur(worst), FmtDur(CI("MaxRuntimeSec"))))
    }
    if (ng.Length = 0)
        return true
    msg := "次の設定が足りません。`n`n"
    for x in ng
        msg .= "  ・" x "`n"
    return false
}


;==============================================================================
;  Phase 3: スケジューラ
;  対象者ごとの予定に従い、ジョブを【1 件ずつ直列に】実行する。
;
;  ★設計の原則★
;    - 同時実行は絶対にしない（G6）
;    - 予定を大きく過ぎたものは実行しない（夜中の予定を翌朝まとめて実行しない）
;    - 1 人の失敗で全体を止めない。ただし連続して失敗するなら systemic とみなし停止
;==============================================================================

; 曜日の指定を受け取る（英語・日本語どちらでも）
;   1=日 2=月 3=火 4=水 5=木 6=金 7=土
DayNameToNum(name) {
    static m := Map("sun",1,"mon",2,"tue",3,"wed",4,"thu",5,"fri",6,"sat",7
                  , "sunday",1,"monday",2,"tuesday",3,"wednesday",4
                  , "thursday",5,"friday",6,"saturday",7
                  , "日",1,"月",2,"火",3,"水",4,"木",5,"金",6,"土",7
                  , "日曜",1,"月曜",2,"火曜",3,"水曜",4,"木曜",5,"金曜",6,"土曜",7)
    k := StrLower(Trim(name))
    return m.Has(k) ? m[k] : 0
}

DayNumToName(n) {
    static a := ["日","月","火","水","木","金","土"]
    return (n >= 1 && n <= 7) ? a[n] : "?"
}

; YYYYMMDD の曜日を返す（1=日 … 7=土）
;   FormatTime の曜日表記はロケール依存なので使わず、日数差から計算する。
;   1970-01-01 は木曜日。
WeekdayOf(ymd) {
    days := DateDiff(ymd "000000", "19700101000000", "Days")
    return Mod(Mod(days + 4, 7) + 7, 7) + 1
}

DaysInclude(spec, wd) {
    for part in StrSplit(spec, ",") {
        if (DayNameToNum(part) = wd)
            return true
    }
    return false
}

; "2026-09-20" / "20260920" どちらでも受ける
NormDate(s) {
    s := StrReplace(StrReplace(Trim(s), "-", ""), "/", "")
    return (StrLen(s) = 8) ? s : ""
}

; "21:00" → "2100"
NormTime(s) {
    s := StrReplace(Trim(s), ":", "")
    return (StrLen(s) = 4) ? s : ""
}

;==============================================================================
;  schedule.ini の読み込み
;==============================================================================
LoadSchedule(&err) {
    global SCHEDINI
    err := ""
    out := []
    if !FileExist(SCHEDINI) {
        err := "schedule.ini がありません: " SCHEDINI
        return out
    }
    m := IniLoad(SCHEDINI)
    for sec, kv in m {
        if (StrLower(SubStr(sec, 1, 8)) != "patient.")
            continue
        p := Map()
        p["key"]     := sec
        p["name"]    := SubStr(sec, 9)
        p["enabled"] := IniGet(m, sec, "Enabled", "1") = "1"
        p["sei"]     := Trim(IniGet(m, sec, "LastName", ""))
        p["mei"]     := Trim(IniGet(m, sec, "FirstName", ""))
        p["middle"]  := Trim(IniGet(m, sec, "MiddleName", ""))
        p["mode"]    := StrLower(Trim(IniGet(m, sec, "Mode", "weekly")))
        p["days"]    := IniGet(m, sec, "Days", "")
        p["time"]    := NormTime(IniGet(m, sec, "Time", ""))
        ; 時刻の扱い: at = その時刻ちょうど / queue = その時刻以降、空き次第 順番に
        p["timemode"] := (StrLower(Trim(IniGet(m, sec, "TimeMode", "at"))) = "queue")
                       ? "queue" : "at"
        p["interval"]:= ToInt(IniGet(m, sec, "IntervalDays", "0"), 0)
        p["scan"]    := IniGet(m, sec, "RunInvestigation", "1") = "1"
        ; 調査タイプ／マニュアル選択。書いていなければ既定（詳細／自動選択）
        p["scantype"] := Trim(IniGet(m, sec, "ScanType", CS("ScanTypeName")))
        p["manual"]   := Trim(IniGet(m, sec, "ManualSelect", CS("ManualName")))
        p["count"]   := ToInt(IniGet(m, sec, "TherapyCount", "1"), 1)
        p["start"]   := NormDate(IniGet(m, sec, "StartDate", ""))
        p["end"]     := NormDate(IniGet(m, sec, "EndDate", ""))
        p["maxruns"] := ToInt(IniGet(m, sec, "MaxRuns", "0"), 0)
        p["catchup"] := ToInt(IniGet(m, sec, "CatchUpWindowMin", "120"), 120)
        p["note"]    := IniGet(m, sec, "Note", "")
        p["order"]   := ToInt(IniGet(m, sec, "Order", "0"), 0)
        out.Push(p)
    }
    ; ★実行の順番は Order で決める★
    ;   AHK の Map の列挙順は仕様として保証されていない（実装上はキーの文字コード順）。
    ;   日本語のセクション名なら漢字の Unicode 番号順になり、五十音順でも画数順でもない。
    ;   つまり「ファイルに書いた順」には決してならないので、必ずここで並べ替える。
    out := SortByOrder(out)
    if (out.Length = 0)
        err := "schedule.ini に [Patient.◯◯] の予定が 1 件もありません"
    return out
}

; Order の小さい順に並べ替える（Order が無いものは末尾。同値ならもとの順）
SortByOrder(list) {
    out := []
    for item in list {
        key := (item["order"] > 0) ? item["order"] : 9000
        pos := out.Length + 1
        Loop out.Length {
            oKey := (out[A_Index]["order"] > 0) ? out[A_Index]["order"] : 9000
            if (key < oKey) {
                pos := A_Index
                break
            }
        }
        out.InsertAt(pos, item)
    }
    return out
}

; 予定の書き方が正しいか。おかしければ理由を返す。
ValidateEntry(p, &why) {
    why := ""
    if (p["sei"] = "" || p["mei"] = "") {
        why := "LastName と FirstName の両方が必要です（同姓の方がいるため姓だけでは絞れません）"
        return false
    }
    if (p["time"] = "") {
        why := "Time の書き方が不正です（例: 21:00）"
        return false
    }
    if (p["count"] < 0 || p["count"] > CI("MaxUnattendedCycles")) {
        why := Format("TherapyCount は 0〜{1} にしてください", CI("MaxUnattendedCycles"))
        return false
    }
    if (p["count"] = 0 && !p["scan"]) {
        why := "調査もセラピーも行わない設定です"
        return false
    }
    if (p["mode"] = "weekly") {
        ok := false
        for part in StrSplit(p["days"], ",") {
            if (DayNameToNum(part) > 0)
                ok := true
        }
        if (!ok) {
            why := "Days の書き方が不正です（例: Mon,Wed,Fri または 月,水,金）"
            return false
        }
    } else if (p["mode"] = "interval") {
        if (p["interval"] <= 0) {
            why := "IntervalDays は 1 以上にしてください"
            return false
        }
    } else {
        why := "Mode は weekly か interval にしてください"
        return false
    }
    return true
}

;==============================================================================
;  実行履歴（state.ini）
;==============================================================================
HistLastRun(key) {
    global STATEINI
    return IniGet(IniLoad(STATEINI), "History." key, "LastRunAt", "")
}
HistRunCount(key) {
    global STATEINI
    return ToInt(IniGet(IniLoad(STATEINI), "History." key, "RunCount", "0"), 0)
}
; ★どの設定で調べたか★ 調査タイプとマニュアル選択の組み合わせ。
;   これが前回と違えば、項目数を比べても意味がない（2026-09-20 指摘）。
ScanSig() => Trim(CS("ScanTypeName")) . "|" . Trim(CS("ManualName"))

HistRecord(key, ok) {
    global STATEINI, G
    IniSet(STATEINI, "History." key, "LastRunAt", A_Now)
    IniSet(STATEINI, "History." key, "LastResult", ok ? "ok" : "failed")
    if (ok) {
        IniSet(STATEINI, "History." key, "RunCount", HistRunCount(key) + 1)
        ; ★次回の「少なすぎないか」判定に使う★
        if (G.scanItems > 0) {
            IniSet(STATEINI, "History." key, "LastScanItems", G.scanItems)
            IniSet(STATEINI, "History." key, "LastScanSig", ScanSig())
        }
    }
}

;==============================================================================
;  「いま実行すべきか」の判定
;==============================================================================
DueNow(p, &why) {
    why := ""
    if (!p["enabled"]) {
        why := "無効（Enabled=0）"
        return false
    }
    if (!ValidateEntry(p, &vw)) {
        why := "設定が不正: " vw
        return false
    }
    now   := A_Now
    today := FormatTime(now, "yyyyMMdd")

    if (p["start"] != "" && today < p["start"]) {
        why := "開始日前（" p["start"] " から）"
        return false
    }
    if (p["end"] != "" && today > p["end"]) {
        why := "期間終了（" p["end"] " まで）"
        return false
    }
    runs := HistRunCount(p["key"])
    if (p["maxruns"] > 0 && runs >= p["maxruns"]) {
        why := Format("上限に到達（{1}/{2} 回）", runs, p["maxruns"])
        return false
    }

    dueTs := today . p["time"] . "00"
    if (now < dueTs) {
        why := "予定時刻前（" FormatTime(dueTs, "HH:mm") "）"
        return false
    }
    last := HistLastRun(p["key"])
    if (last != "" && last >= dueTs) {
        why := "この予定は実行済み"
        return false
    }
    late := DateDiff(now, dueTs, "Minutes")
    ; ★順番待ち（queue）には「遅れすぎ」がない★
    ;   時刻を決めていないのだから、その日のうちなら何時でもよい。
    ;   前の人のセラピーが長引いても見送られないようにするための区別。
    if (p["timemode"] = "at" && p["catchup"] > 0 && late > p["catchup"]) {
        why := Format("見送り（予定から {1} 分経過 / 上限 {2} 分）", late, p["catchup"])
        return false
    }

    if (p["mode"] = "weekly") {
        if (!DaysInclude(p["days"], WeekdayOf(today))) {
            why := "今日は対象の曜日ではありません"
            return false
        }
    } else {
        if (last != "") {
            elapsed := DateDiff(today "000000", FormatTime(last, "yyyyMMdd") "000000", "Days")
            if (elapsed < p["interval"]) {
                why := Format("前回から {1} 日（{2} 日おきの設定）", elapsed, p["interval"])
                return false
            }
        }
    }
    if (p["timemode"] = "queue")
        why := Format("実行する（順番待ち / {1} 以降）", FormatTime(dueTs, "HH:mm"))
    else
        why := Format("実行する（予定 {1} / {2} 分経過）", FormatTime(dueTs, "HH:mm"), late)
    return true
}

; 次にいつ実行されるかを人が読める形で
NextDueText(p) {
    if (!p["enabled"])
        return "無効"
    if (!ValidateEntry(p, &vw))
        return "設定が不正: " vw
    runs := HistRunCount(p["key"])
    if (p["maxruns"] > 0 && runs >= p["maxruns"])
        return Format("完了（{1}/{2} 回）", runs, p["maxruns"])
    today := FormatTime(A_Now, "yyyyMMdd")
    if (p["end"] != "" && today > p["end"])
        return "期間終了"
    if (p["mode"] = "weekly") {
        names := ""
        for part in StrSplit(p["days"], ",") {
            n := DayNameToNum(part)
            if (n > 0)
                names .= (names = "" ? "" : "・") DayNumToName(n)
        }
        return Format("毎週 {1}  {2}", names, TimeLabel(p))
    }
    last := HistLastRun(p["key"])
    if (last = "")
        return Format("次回 未実行（{1} 日おき  {2}）", p["interval"], TimeLabel(p))
    nextD := DateAdd(FormatTime(last, "yyyyMMdd") "000000", p["interval"], "Days")
    return Format("次回 {1}  {2}（{3} 日おき）", FormatTime(nextD, "M/d")
        , TimeLabel(p), p["interval"])
}

; 時刻の指定を人が読める形で
TimeLabel(p) {
    hhmm := FmtHHMM(p["time"])
    if (p["timemode"] != "queue")
        return hhmm
    return (p["time"] = "0000") ? "順番待ち" : "順番待ち（" hhmm " 以降）"
}

; 1 回にかかる時間の見込み（最大）。順番待ちを始めてよいかの判断に使う
EstimateMaxMin(scan, count) {
    return (scan ? 7 : 0) + count * 30
}

; 今日これから来る「時刻指定」の予定まで、あと何分か。無ければ -1
MinutesToNextTimed(list) {
    now   := A_Now
    today := FormatTime(now, "yyyyMMdd")
    best  := -1
    for p in list {
        if (!p["enabled"] || p["timemode"] = "queue")
            continue
        if (!ValidateEntry(p, &vw))
            continue
        if (p["start"] != "" && today < p["start"])
            continue
        if (p["end"] != "" && today > p["end"])
            continue
        if (p["maxruns"] > 0 && HistRunCount(p["key"]) >= p["maxruns"])
            continue
        if (p["mode"] = "weekly") {
            if (!DaysInclude(p["days"], WeekdayOf(today)))
                continue
        } else {
            last := HistLastRun(p["key"])
            if (last != "") {
                elapsed := DateDiff(today "000000", FormatTime(last, "yyyyMMdd") "000000", "Days")
                if (elapsed < p["interval"])
                    continue
            }
        }
        dueTs := today . p["time"] . "00"
        if (dueTs <= now)
            continue                                ; もう過ぎている分は別途 due 判定される
        mins := DateDiff(dueTs, now, "Minutes")
        if (best < 0 || mins < best)
            best := mins
    }
    return best
}

;==============================================================================
;  スケジューラ本体
;==============================================================================
StartScheduler() {
    global G, STATEINI
    G.schedOn      := true
    G.schedRunning := false
    G.schedCurrent := ""
    G.schedDone    := 0
    G.schedFailed  := 0
    G.schedSkipped := 0
    G.schedCheck   := 0
    G.appLaunchTS  := ""
    G.appWarnTS    := ""
    G.schedFailStreak := 0
    G.schedStartTS := A_Now
    Log("INFO", "=== スケジュール運転を開始しました ===")
    SetupTray()
    ShowPanel()
    WriteLive()
    WriteSchedStatus()
    SetTimer(WatchTherapyRequest, 1000)            ; 自動セラピーの依頼を 1 秒ごとに見る
    SetTimer(SchedTick, -1000)
    ; ★「運転中」の印を残す★
    ;   これが残ったまま次に起動したら、前回は【落ちた】ということ。
    ;   正常に終わるときは OnExit で消すので、印は電源断や強制終了でだけ残る。
    IniSet(STATEINI, "Scheduler", "Running", "1")
    IniSet(STATEINI, "Scheduler", "StartedAt", FmtTS(A_Now))
    OnExit(SchedExitMark)
}

; 正常に終わったときに「運転中」の印を消す（電源断では呼ばれない＝印が残る）
SchedExitMark(*) {
    global STATEINI
    IniSet(STATEINI, "Scheduler", "Running", "0")
    IniSet(STATEINI, "Scheduler", "StoppedAt", FmtTS(A_Now))
}

SchedTick() {
    global G, APP_NAME
    if (!G.schedOn)
        return
    if (G.schedRunning) {                          ; ジョブ実行中は何もしない（G6）
        WriteLive()
        SetTimer(SchedTick, -5000)
        return
    }
    if (CheckStopFiles())
        return
    WriteLive()
    ; ★手動の自動セラピーの依頼が最優先★
    ;   目の前にお客様がいる。予定より先に通す。
    if (TakeTherapyRequest())
        return
    ; 1 日あたりの上限
    if (CI("MaxJobsPerDay") > 0 && G.schedDone >= CI("MaxJobsPerDay")) {
        Log("INFO", Format("本日の実行上限 {1} 件に達しました", CI("MaxJobsPerDay")))
        SetTimer(SchedTick, -CI("SchedulerTickSec") * 1000)
        return
    }
    list := LoadSchedule(&err)                     ; 毎回読み直す（編集が即反映される）
    if (err != "") {
        Log("WARN", err)
        SetTimer(SchedTick, -CI("SchedulerTickSec") * 1000)
        return
    }
    ; --- 1 件だけ拾う --------------------------------------------------------
    ;   ★時刻を指定した予定が先★ 順番待ちは、その空き時間に流す。
    best := 0, bestTs := "", waiting := 0
    for p in list {
        if (!DueNow(p, &why)) {
            if (InStr(why, "見送り")) {
                Log("WARN", Format("{1}: {2}", p["key"], why))
                G.schedSkipped++
                HistRecord(p["key"], false)        ; 同じ予定を何度も見送らないよう印を付ける
            }
            continue
        }
        if (p["timemode"] = "queue") {
            if (!IsObject(waiting))
                waiting := p                        ; 並んでいる順に 1 人ずつ
            continue
        }
        ts := FormatTime(A_Now, "yyyyMMdd") . p["time"] . "00"
        if (bestTs = "" || ts < bestTs) {
            best := p, bestTs := ts
        }
    }
    ; 時刻指定が 1 件もなければ、順番待ちを始める。
    ; ただし★これから来る時刻指定の予定を遅らせないこと★を確かめる。
    if (!IsObject(best) && IsObject(waiting)) {
        need := EstimateMaxMin(waiting["scan"], waiting["count"])
        gap  := MinutesToNextTimed(list)
        if (gap >= 0 && gap < need) {
            Log("INFO", Format("順番待ちの「{1} {2}」は待機します"
                . "（あと {3} 分で時刻指定の予定 / この人の所要見込み 最大 {4} 分）"
                , waiting["sei"], waiting["mei"], gap, need))
        } else {
            best := waiting
        }
    }
    if (!IsObject(best)) {
        WriteSchedStatus()
        SetTimer(SchedTick, -CI("SchedulerTickSec") * 1000)
        return
    }
    ; ★対象ソフトがいないなら、予定を始めない★
    ;   始めれば必ず失敗し、失敗だけが積み上がる。落ちているなら起動して待つ。
    whyApp := ""
    if (!EnsureTargetRunning(&whyApp)) {
        if (G.appWarnTS = "" || SecSince(G.appWarnTS) >= 600) {
            Log(InStr(whyApp, "待ち") || InStr(whyApp, "起動しました") ? "INFO" : "WARN"
              , "予定はまだ始めません: " whyApp)
            try TrayTip("予定を開始できません`n" whyApp, APP_NAME)
            G.appWarnTS := A_Now
        }
        WriteSchedStatus()
        SetTimer(SchedTick, -CI("SchedulerTickSec") * 1000)
        return
    }
    G.appWarnTS := ""
    RunScheduled(best)
}

RunScheduled(p) {
    global G, C, APP_NAME
    G.schedRunning := true
    G.manualJob    := false
    G.skipSelect   := false                        ; 予定のジョブは必ず検索・選択から
    G.schedCurrent := p["key"]
    C["TherapyCount"]     := p["count"]
    C["RunInvestigation"] := p["scan"] ? "1" : "0"
    C["ScanTypeName"]     := p.Has("scantype") ? p["scantype"] : ""
    C["ManualName"]       := p.Has("manual")   ? p["manual"]   : ""
    G.wantSei := p["sei"], G.wantMei := p["mei"]
    G.wantMid := p.Has("middle") ? p["middle"] : ""
    Log("INFO", Format("--- スケジュール実行: {1}「{2} {3}」 調査={4} セラピー={5}回 ---"
        , p["key"], p["sei"], p["mei"], p["scan"] ? "する" : "しない", p["count"]))
    try TrayTip("開始: " p["sei"] " " p["mei"], APP_NAME)
    WriteLive()
    StartJob()
}

; ジョブが終わったときにスケジューラへ戻る（Finish から呼ばれる）
SchedJobFinished(code, reason, summary := "") {
    global G, APP_NAME
    ok  := (code = 0)
    chk := (code = 4)                              ; 要確認（調査の項目が少なすぎた）
    ; --- 手動の自動セラピーは、予定の実績とは別に扱う -------------------------
    if (G.manualJob) {
        Log("INFO", (ok ? "手動の自動セラピー 完了" : "手動の自動セラピー 失敗: ")
            . (ok ? "" : StrReplace(reason, "`n", " / ")))
        try TrayTip((ok ? "自動セラピー 完了" : "自動セラピー 停止") "`n" G.wantSei " " G.wantMei
            , APP_NAME)
        G.manualJob    := false
        G.skipSelect   := false
        G.schedRunning := false
        G.schedCurrent := ""
        G.state        := "idle"                   ; 終わったら「何もしていない」に戻す
        G.wantSei := "", G.wantMei := ""
        WriteLive()
        WriteSchedStatus()
        SetTimer(SchedTick, -CI("RestBetweenJobsSec") * 1000)
        ; ★手動のときは結果を画面で見せる（既存の自動セラピーツールと同じ）★
        ;   予定のジョブでは出さない。無人運転でダイアログを溜めないため。
        ;   先に待機へ戻してから出すので、この間もスケジュール運転は動き続ける。
        if (summary != "") {
            MsgBox(summary, APP_NAME " - 自動セラピー " (ok ? "完了" : "停止")
                , ok ? "Iconi 4096" : "Icon! 4096")
        }
        return                                     ; 連続失敗の数にも入れない
    }
    ; ★終わったことを見落とさないための控え★
    ;   この方へ結果を報告する必要がある。トレイ通知は消えてしまうので、
    ;   ✓ を付けて消すまで運転パネルに出し続ける。
    PendingAdd(ok)
    try SoundPlay(ok ? "*64" : "*48")              ; 席を外していても気づけるように
    key := G.schedCurrent
    if (key != "")
        HistRecord(key, ok)
    if (ok) {
        G.schedDone++
        G.schedFailStreak := 0
        Log("INFO", Format("スケジュール実行 完了: {1}", key))
    } else if (chk) {
        ; ★要確認は「失敗」ではない★
        ;   手動で止めた／すでに調査済み、のことが多い（2026-09-17 利用者）。
        ;   連続失敗の数にも入れない。入れると試験中に運転が止まってしまう。
        G.schedCheck++
        G.schedFailStreak := 0
        Log("WARN", Format("スケジュール実行 要確認: {1} / {2}", key
            , StrReplace(reason, "`n", " / ")))
        try TrayTip("要確認: " G.wantSei " " G.wantMei "`n" SubStr(reason, 1, 80), APP_NAME)
    } else {
        G.schedFailed++
        G.schedFailStreak++
        Log("ERROR", Format("スケジュール実行 失敗: {1} / {2}", key
            , StrReplace(reason, "`n", " / ")))
        try TrayTip("失敗: " G.wantSei " " G.wantMei "`n" SubStr(reason, 1, 80), APP_NAME)
    }
    G.schedRunning := false
    G.schedCurrent := ""
    G.state        := "idle"                       ; 終わったら「何もしていない」に戻す
    G.wantSei := "", G.wantMei := ""        ; 待機中に前の対象者を出したままにしない
    ; 連続して失敗するなら、ソフト側かPC側の問題。全体を止める
    if (G.schedFailStreak >= CI("MaxConsecutiveFailures")) {
        StopScheduler(Format("{1} 件続けて失敗しました。`n`n最後の理由:`n{2}"
            , G.schedFailStreak, reason))
        return
    }
    WriteLive()
    WriteSchedStatus()
    SetTimer(SchedTick, -CI("RestBetweenJobsSec") * 1000)
}

StopScheduler(reason) {
    global G, APP_NAME, LIVEFILE, REQFILE
    G.schedOn := false
    try FileDelete(LIVEFILE)                       ; もう受け付けない
    try FileDelete(REQFILE)
    ClosePanel()
    SetTimer(SchedTick, 0)
    SetTimer(WatchTherapyRequest, 0)
    SetTimer(Tick, 0)
    o := Format("=== スケジュール運転を終了しました ===`n`n"
        . "  実行     : {1} 件`n  要確認   : {2} 件`n  失敗     : {3} 件`n  見送り   : {4} 件`n"
        . "  稼働時間 : {5}`n`n  理由     : {6}`n"
        , G.schedDone, G.schedCheck, G.schedFailed, G.schedSkipped
        , FmtDur(SecSince(G.schedStartTS)), reason)
    Log("INFO", StrReplace(o, "`n", " / "))
    try FileAppend(CRLF("`n" o "`n"), G.logFile, "UTF-8")
    WriteSchedStatus()
    MsgBox(o, APP_NAME " - スケジュール運転", "Iconi 4096")
    ExitApp(0)
}

WriteSchedStatus() {
    global G, STATUSTX, APP_VER
    o := "AutoMeta " APP_VER "  スケジュール運転`n"
    o .= FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss") "`n`n"
    if (G.schedRunning) {
        o .= "■ 実行中: " G.wantSei " " G.wantMei "（" G.schedCurrent "）`n"
        o .= "   状態  : " G.state "`n"
        o .= "   セラピー: " G.cycle " / " CI("TherapyCount") " 回`n"
        if (G.state = "therapy_run")
            o .= "   経過  : " FmtDur(SecSince(G.cycleStartTS)) "`n"
    } else {
        o .= "■ 待機中`n"
    }
    o .= "`n■ 予定`n"
    list := LoadSchedule(&err)
    if (err != "") {
        o .= "  " err "`n"
    } else {
        for p in list {
            mark := (p["key"] = G.schedCurrent) ? "▶" : "  "
            o .= Format("{1} {2} {3}  … {4}  [調査{5} セラピー{6}回]  実行 {7} 回`n"
                , mark, p["sei"], p["mei"], NextDueText(p)
                , p["scan"] ? "有" : "無", p["count"], HistRunCount(p["key"]))
        }
    }
    o .= "`n■ 本日  完了 " G.schedDone " / 要確認 " G.schedCheck
       . " / 失敗 " G.schedFailed " / 見送り " G.schedSkipped "`n"
    o .= "稼働時間: " FmtDur(SecSince(G.schedStartTS)) "`n"
    try FileDelete(STATUSTX)
    try FileAppend(CRLF(o), STATUSTX, "UTF-8")
}

;==============================================================================
;  /schedule  スケジュール運転を始める
;==============================================================================
ModeSchedule() {
    global G, APP_NAME, APP_VER, STOPFILE, SCHEDINI
    LicenseGate()                                  ; 利用の期限（止めるならここで終わる）
    EnsureSingleInstance()
    EnsureTargetForSchedule()                      ; ★落ちていても止めない★
    LoadScreens()
    try FileDelete(STOPFILE)

    if (!Preflight(&msg)) {
        MsgBox(msg, APP_NAME " - 実行できません", "Icon! 4096")
        ExitApp(1)
    }
    list := LoadSchedule(&err)
    if (err != "") {
        MsgBox(err "`n`n" SCHEDINI " を編集してください。", APP_NAME, "Icon! 4096")
        try Run('notepad.exe "' SCHEDINI '"')
        ExitApp(1)
    }

    dlg := Gui("+AlwaysOnTop", APP_NAME " - スケジュール運転" VerTag())
    dlg.MarginX := 16, dlg.MarginY := 12
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "w860", "この予定で自動実行します")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w860 cGray"
        , APP_VER "   1 件ずつ順番に実行します（同時には走りません）。"
        . "止めるときはトレイか Ctrl+Alt+Shift+S。")
    lv := dlg.Add("ListView", "w860 h260 -Multi"
        , ["対象者", "予定", "調査", "セラピー", "実行済", "状態"])
    bad := 0
    for p in list {
        st := ""
        if (!ValidateEntry(p, &vw)) {
            st := "★" vw
            bad++
        } else if (!p["enabled"]) {
            st := "無効"
        } else {
            DueNow(p, &why)
            st := why
        }
        lv.Add(, p["sei"] " " p["mei"], NextDueText(p), p["scan"] ? "有" : "無"
            , p["count"] " 回", HistRunCount(p["key"]) " 回", st)
    }
    lv.ModifyCol(1, 150), lv.ModifyCol(2, 200), lv.ModifyCol(3, 50)
    lv.ModifyCol(4, 80),  lv.ModifyCol(5, 70),  lv.ModifyCol(6, 290)
    dlg.SetFont("s10", "Meiryo UI")
    if (bad > 0) {
        dlg.SetFont("s10 Bold", "Meiryo UI")
        dlg.Add("Text", "w860 cRed", "★ 設定に不備のある予定が " bad " 件あります（その行は実行されません）")
        dlg.SetFont("s10", "Meiryo UI")
    }
    dlg.Add("Text", "w860 cGray"
        , "※ schedule.ini は 1 分ごとに読み直します。運転中に編集しても反映されます。")
    bGo  := dlg.Add("Button", "w270 h40 Default", "この予定で運転を開始")
    bEd  := dlg.Add("Button", "x+15 yp w270 h40", "予定を編集する")
    bNo  := dlg.Add("Button", "x+15 yp w270 h40", "やめる")
    bGo.OnEvent("Click", (*) => (dlg.Destroy(), StartScheduler()))
    bEd.OnEvent("Click", (*) => (dlg.Destroy(), ModeScheduleEditor()))
    bNo.OnEvent("Click", (*) => ExitApp(0))
    dlg.OnEvent("Close", (*) => ExitApp(0))
    dlg.Show()
}

;==============================================================================
;  自動セラピー — いま開いているカードに、セラピーだけを N 回
;==============================================================================
;  目の前の方には、調査は手で行う（ツールを介する必要がない）。
;  ツールに任せたいのは「セラピーを決めた回数くりかえす」ところだけ。
;  ＝ 既存の自動セラピーツール（AutoTherapy v4）と同じ役割。
;
;  ★対象者の検索も選択も行わない★
;    いま画面に開いているカードがそのまま対象。
;    そのかわり、開いているカードの氏名を読んで【必ず画面に見せてから】開始する。
;==============================================================================

; 動作中の版へ「この方にセラピーを N 回してほしい」と頼む
WriteTherapyRequest(count, sei, mei) {
    global REQFILE
    o := "[Therapy]`nCount=" count "`nSei=" sei "`nMei=" mei "`nAt=" A_Now "`n"
    try {
        if FileExist(REQFILE)
            FileDelete(REQFILE)
        FileAppend(CRLF(o), REQFILE, "UTF-8")
    } catch {
        return false
    }
    return true
}

; ★依頼の見張り★
;   SchedTick は 60 秒おきなので、そこで拾うと最大 1 分待たされる。
;   目の前にお客様がいるので待たせたくない（カマヤン指摘 2026-09-15）。
;   ファイルの有無を見るだけの軽い処理を 1 秒ごとに回す。
WatchTherapyRequest() {
    global G, REQFILE
    if (!G.schedOn || G.schedRunning)
        return
    if !FileExist(REQFILE)
        return
    TakeTherapyRequest()
}

; 依頼が来ていたら受け取って始める（スケジューラ側）
TakeTherapyRequest() {
    global G, C, REQFILE, APP_NAME
    if !FileExist(REQFILE)
        return false
    m := IniLoad(REQFILE)
    cnt := ToInt(IniGet(m, "Therapy", "Count", "1"), 1)
    sei := Trim(IniGet(m, "Therapy", "Sei", ""))
    mei := Trim(IniGet(m, "Therapy", "Mei", ""))
    try FileDelete(REQFILE)                         ; 二度実行しないよう先に消す
    ; ★先に占有する★
    ;   このあと氏名の照合で最大 15 秒待つ。その間に SchedTick が
    ;   予定のジョブを始めてしまうと、2 つが同じ画面を取り合う。
    G.schedRunning := true
    if (cnt < 1 || cnt > CI("MaxUnattendedCycles")) {
        Log("ERROR", "自動セラピーの依頼を却下: 回数が範囲外 " cnt)
        G.schedRunning := false
        return false
    }
    ; ★依頼したときのカードと、いま開いているカードが同じか確かめる★
    ;   間に別のカードを開かれていたら、別人に施術してしまう。
    if (sei != "") {
        ok := false
        if (h := FindScreen("S2_Card")) {
            if (ReadPatientSettled(h, &s2, &m2, &w2))
                ok := (Norm(s2) = Norm(sei) && Norm(m2) = Norm(mei))
        }
        if (!ok) {
            Log("ERROR", Format("自動セラピーの依頼を取り消しました："
                . "開いているカードが「{1} {2}」ではありません", sei, mei))
            try TrayTip("自動セラピーを中止しました`n開いているカードが違います", APP_NAME)
            G.schedRunning := false
            return false
        }
    }
    C["RunInvestigation"] := "0"
    C["TherapyCount"]     := cnt
    G.wantSei := sei, G.wantMei := mei
    G.wantMid     := ""                            ; 開いているカードが対象。前の指定は持ち越さない
    G.skipSelect  := true
    G.manualJob   := true
    G.schedCurrent := ""
    Log("INFO", Format("--- 手動の自動セラピー: 「{1} {2}」 セラピー {3} 回 ---", sei, mei, cnt))
    try TrayTip("自動セラピーを開始: " sei " " mei, APP_NAME)
    StartJob()
    return true
}

ModeTherapy() {
    global G, C, APP_NAME, APP_VER, STOPFILE
    LicenseGate()                                  ; 利用の期限（止めるならここで終わる）
    LoadScreens()
    C["RunInvestigation"] := "0"                    ; 調査は行わない

    ; ★スケジュール運転を止めずに、自動セラピーを使えるようにする★
    ;   画面を操作してよいのは常に 1 つだけ。2 つが同時に触ると必ず壊れる。
    ;   そこで、すでに動いている版があるときは【自分では動かさず、その版に頼む】。
    other := AnotherInstanceRunning()
    live  := other ? ReadLive() : Map("Running", "0", "SchedOn", "0", "Patient", ""
                                    , "Cycle", "", "fresh", false)
    ; 頼めるのは「スケジュール運転が、いま待機中」のときだけ。
    ;   live.txt が無い/古いときは様子が分からないので頼まない（安全側）。
    canAsk := (other && live["fresh"] && live["SchedOn"] = "1" && live["Running"] = "0")
    busy   := (other && !canAsk)

    ; ★ここで EnsureTarget() を呼ばない★
    ;   呼ぶと対象ソフトが無いときに画面すら出ずに終わってしまう。
    ;   「何が足りないのか」はダイアログの中で見せ、開始のときに止める。
    who := "", warn := "", sei0 := "", mei0 := ""
    exe := CS("ExeName")
    if (exe = "") {
        warn := "対象ソフトがまだ設定されていません（「設定」→「対象ソフトを設定する」）。"
    } else if (!(G.pid := FindPidByExe(exe))) {
        warn := "対象ソフト「" exe "」が起動していません。起動してから実行してください。"
    } else if (!Preflight(&msg, false)) {
        warn := StrReplace(msg, "`n", " ")
    } else if (h := FindScreen("S2_Card")) {
        if (ReadPatientSettled(h, &sei0, &mei0, &w0))
            who := sei0 " " mei0
        else
            warn := "氏名が読めません: " w0
    } else {
        warn := "カード画面が見つかりません。対象者のカードを開いてから実行してください。"
    }

    dlg := Gui("+AlwaysOnTop", APP_NAME " - 自動セラピー" VerTag())
    dlg.MarginX := 18, dlg.MarginY := 14
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "w560", "セラピーをくりかえします（調査は行いません）")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w560 cGray", APP_VER "   対象ソフト: " CS("ExeName"))
    if (other) {
        dlg.SetFont("s10", "Meiryo UI")
        if (busy) {
            dlg.Add("Text", "w560 cRed"
                , "⚠ ほかの AutoMeta が実行中です"
                . (live["Patient"] = "" ? "" : "（" live["Patient"] "  セラピー " live["Cycle"] "）"))
            dlg.SetFont("s9", "Meiryo UI")
            dlg.Add("Text", "w560 cGray"
                , "　終わるまで開始できません。急ぐ場合は運転パネルの「止める」で中断してください。")
        } else {
            dlg.Add("Text", "w560 cGreen", "◌ スケジュール運転は待機中です")
            dlg.SetFont("s9", "Meiryo UI")
            dlg.Add("Text", "w560 cGray"
                , "　開始すると、待機中のスケジュール運転にそのまま実行してもらいます"
                . "（運転は止まりません）。")
        }
    }
    dlg.Add("Text", "w560 h1 0x10")

    dlg.SetFont("s10", "Meiryo UI")
    dlg.Add("Text", "w560", "いま開いているカード")
    if (who != "") {
        dlg.SetFont("s16 Bold", "Meiryo UI")
        dlg.Add("Text", "xm+12 w540 cNavy", who)
        dlg.SetFont("s9", "Meiryo UI")
        dlg.Add("Text", "xm+12 w540 cGray"
            , "この方に施術します。違う場合は、やめてからソフト側でカードを開き直してください。")
    } else {
        dlg.SetFont("s11 Bold", "Meiryo UI")
        dlg.Add("Text", "xm+12 w540 cRed", "★ 読み取れません")
        dlg.SetFont("s9", "Meiryo UI")
        dlg.Add("Text", "xm+12 w540 cGray", warn)
    }

    dlg.SetFont("s10", "Meiryo UI")
    dlg.Add("Text", "xm w560 h1 0x10")
    dlg.Add("Text", "xm w120", "セラピーの回数")
    cntList := []
    Loop CI("MaxUnattendedCycles")
        cntList.Push(String(A_Index))
    dCnt := dlg.Add("DropDownList", "x+10 yp-4 w80", cntList)
    dCnt.Value := (CI("TherapyCount") >= 1 && CI("TherapyCount") <= cntList.Length)
                  ? CI("TherapyCount") : 1
    dlg.Add("Text", "x+8 yp+4 w40", "回")
    lblEst := dlg.Add("Text", "xm+12 w540 cGray", "")

    dlg.SetFont("s10", "Meiryo UI")
    cDry := dlg.Add("CheckBox", "xm w560 " (CB("DryRun") ? "Checked" : "")
        , "DryRun（画面は追うが、一切クリックしない）")

    dlg.Add("Text", "xm w560 h1 0x10")
    dlg.SetFont("s11 Bold", "Meiryo UI")
    bGo := dlg.Add("Button", "xm w260 h44 Default", "開始する")
    dlg.SetFont("s10", "Meiryo UI")
    bNo := dlg.Add("Button", "x+20 yp w260 h44", "やめる")
    bGo.OnEvent("Click", DoTherapy)
    bNo.OnEvent("Click", (*) => ExitApp(0))
    dlg.OnEvent("Close", (*) => ExitApp(0))
    dCnt.OnEvent("Change", (*) => UpdateEst())
    UpdateEst()
    dlg.Show()
    return

    UpdateEst() {
        n := dCnt.Value
        lblEst.Value := Format("目安 {1}〜{2}（セラピー 1 回 6〜30 分の実測より）"
            , FmtDur(n * 360), FmtDur(n * CI("PlanCycleSec")))
    }

    DoTherapy(*) {
        global G, C, APP_NAME, STOPFILE
        n := dCnt.Value
        ; 開始の直前に、対象ソフトが本当にいるかを確かめる
        if (CS("ExeName") = "" || !(G.pid := FindPidByExe(CS("ExeName")))) {
            MsgBox("対象ソフトが見つからないため、開始できません。`n`n" warn
                , APP_NAME " - 実行できません", "Iconx 4096")
            return
        }
        if (who = "") {
            ans := MsgBox("いま開いているカードの氏名が読めませんでした。`n`n"
                . warn "`n`n"
                . "このまま進めると、【画面に開いている方】にセラピーを "
                . n " 回行います。`n続けますか？", APP_NAME, "YesNo Iconx 4096")
            if (ans != "Yes")
                return
        }
        ; --- すでに動いている版がある場合 ---------------------------------------
        if (AnotherInstanceRunning()) {
            now := ReadLive()
            if (!(now["fresh"] && now["SchedOn"] = "1" && now["Running"] = "0")) {
                MsgBox("ほかの AutoMeta が動いているため、開始できません。`n`n"
                    . "　対象者　: " (now["Patient"] = "" ? "（不明）" : now["Patient"]) "`n"
                    . "　セラピー: " (now["Cycle"] = "" ? "（不明）" : now["Cycle"]) "`n`n"
                    . "画面を 2 つで取り合うと必ず誤動作するため、開始できません。`n"
                    . "終わるのを待つか、運転パネルの「止める」で中断してください。"
                    , APP_NAME " - いまは実行できません", "Iconx 4096")
                return
            }
            if (!WriteTherapyRequest(n, (who = "") ? "" : sei0, (who = "") ? "" : mei0)) {
                MsgBox("依頼を書き込めませんでした。", APP_NAME, "Iconx 4096")
                return
            }
            dlg.Destroy()
            MsgBox("待機中のスケジュール運転に実行を頼みました。`n`n"
                . "　" (who = "" ? "（開いているカード）" : who) "　セラピー " n " 回`n`n"
                . "数秒で始まります。進み具合は運転パネルで見られます。`n"
                . "スケジュール運転はそのまま続きます。"
                , APP_NAME, "Iconi 4096")
            ExitApp(0)
        }
        ; --- 自分で動かす -------------------------------------------------------
        EnsureSingleInstance()
        try FileDelete(STOPFILE)
        C["TherapyCount"] := n
        C["DryRun"]       := cDry.Value ? "1" : "0"
        G.wantSei := (who = "") ? "" : sei0
        G.wantMei := (who = "") ? "" : mei0
        G.skipSelect := true                        ; ★検索も選択もしない★
        dlg.Destroy()
        SetupTray()
        ShowPanel()
        StartJob()
    }
}

;==============================================================================
;  予定の編集画面
;==============================================================================
;  schedule.ini を手で書くと、TherapyCount・Days・Time の打ち間違いに気づけない。
;  氏名だけは G1（照合）が守ってくれるが、回数・曜日・時刻には安全網がない。
;  そこで「選ぶだけで書ける」画面を用意し、保存の前に必ず検証する。
;==============================================================================

; 実測にもとづく所要時間の見積もり
;   調査   : 35〜38 項目 × 8.4 秒 ≒ 5〜7 分（2026-09-14 実測 05:01 / 05:28）
;   セラピー: 1 回 6〜30 分（実測 06:04 / 07:25。30 分を超える例もある）
EstimateText(scan, count) {
    lo := (scan ? 5 : 0) + count * 6
    hi := (scan ? 7 : 0) + count * 30
    if (lo = 0 && hi = 0)
        return "何も行いません"
    return Format("およそ {1}〜{2} 分", lo, hi)
}

; 実行履歴を消す（回数の上限に達した人を、もう一度回せるようにする）
HistReset(key) {
    global STATEINI
    IniSet(STATEINI, "History." key, "LastRunAt", "")
    IniSet(STATEINI, "History." key, "LastResult", "")
    IniSet(STATEINI, "History." key, "RunCount", "0")
}

NewPatientMap() {
    return Map("key", "", "name", "", "enabled", true
             , "sei", "", "mei", "", "mode", "interval", "days", "月,水,金"
             , "order", 0
             , "time", "2100", "timemode", "at"
             , "interval", 3, "scan", true, "count", 1
             , "scantype", CS("ScanTypeName"), "manual", CS("ManualName")
             , "start", FormatTime(A_Now, "yyyyMMdd"), "end", ""
             , "maxruns", 4, "catchup", 120, "note", "")
}

; 重複しない [Patient.◯◯] の名前を作る
MakeSchedKey(sei, mei, list, selfKey := "") {
    base := StrReplace(StrReplace(Trim(sei) Trim(mei), " ", ""), "]", "")
    if (base = "")
        base := "Patient"
    num := 0
    Loop {
        cand := "Patient." base . (num = 0 ? "" : num)
        used := false
        for item in list {
            if (item["key"] = cand && cand != selfKey)
                used := true
        }
        if (!used)
            return cand
        num++
    }
}

;==============================================================================
;  schedule.ini の書き出し
;==============================================================================
SaveSchedule(list, &err) {
    global SCHEDINI
    err := ""
    ; --- 検証（有効な予定だけ厳しく見る）-------------------------------------
    for item in list {
        if (!item["enabled"])
            continue
        if (!ValidateEntry(item, &why)) {
            err := Format("「{1} {2}」の設定が正しくありません。`n`n{3}"
                , item["sei"], item["mei"], why)
            return false
        }
    }
    ; --- 書き出し（元のファイルは .bak に残す）-------------------------------
    if FileExist(SCHEDINI) {
        try FileDelete(SCHEDINI ".bak")
        try FileCopy(SCHEDINI, SCHEDINI ".bak", 1)
    }
    ; 画面に並んでいる順を、そのまま実行の順番として書き出す
    for idx, item in list
        item["order"] := idx
    txt := "; ============================================================="
        . "`n;  AutoMeta  schedule  — 対象者ごとの予定"
        . "`n;  文字コード: UTF-8 (BOM付き) / 改行: CRLF"
        . "`n;"
        . "`n;  ★このファイルは「予定を編集する」画面が書き出しています。"
        . "`n;    手で書き換えても構いませんが、次に画面から保存すると"
        . "`n;    この見出し以外のコメントは失われます。"
        . "`n;    直前の内容は schedule.ini.bak に残しています。"
        . "`n;"
        . "`n;  最終更新: " FormatTime(A_Now, "yyyy-MM-dd HH:mm")
        . "`n; =============================================================`n"
    for item in list {
        txt .= "`n[" item["key"] "]`n"
        txt .= "Order=" item["order"] "`n"
        txt .= "Enabled=" (item["enabled"] ? "1" : "0") "`n"
        txt .= "LastName=" item["sei"] "`n"
        txt .= "FirstName=" item["mei"] "`n"
        txt .= "MiddleName=" (item.Has("middle") ? item["middle"] : "") "`n"
        txt .= "RunInvestigation=" (item["scan"] ? "1" : "0") "`n"
        txt .= "ScanType=" item["scantype"] "`n"
        txt .= "ManualSelect=" item["manual"] "`n"
        txt .= "TherapyCount=" item["count"] "`n"
        txt .= "Mode=" item["mode"] "`n"
        ; 両方書いておく。Mode を切り替えたときに、もう片方の設定を失わないため
        txt .= "Days=" item["days"] "`n"
        txt .= "IntervalDays=" item["interval"] "`n"
        txt .= "Time=" SubStr(item["time"], 1, 2) ":" SubStr(item["time"], 3, 2) "`n"
        txt .= "TimeMode=" item["timemode"] "`n"
        txt .= "StartDate=" FmtYmd(item["start"]) "`n"
        txt .= "EndDate=" FmtYmd(item["end"]) "`n"
        txt .= "MaxRuns=" item["maxruns"] "`n"
        txt .= "CatchUpWindowMin=" item["catchup"] "`n"
        txt .= "Note=" item["note"] "`n"
    }
    try {
        if FileExist(SCHEDINI)
            FileDelete(SCHEDINI)
        FileAppend(CRLF(txt), SCHEDINI, "UTF-8")      ; BOM 付きで書く
    } catch as e {
        err := "schedule.ini に書き込めませんでした: " e.Message
        return false
    }
    return true
}

; 日付の入力欄（クリックするとカレンダーが出る）
;   左のチェックを外すと「指定なし」になる。
;   ymd は "" か YYYYMMDD。
AddDateBox(dlg, opts, ymd) {
    ; ★オプション番号に注意★
    ;     1 = カレンダーのボタンを【上下ボタンに置き換える】← これを指定すると
    ;         クリックしてもカレンダーが出ない（2026-09-15 の取り違え）
    ;     2 = 左にチェックボックスを出す（外すと「指定なし」）
    ;   何も指定しなければ、右の ▼ でカレンダーが開く。
    o := opts . " 2 " . ((StrLen(ymd) = 8) ? "Choose" ymd : "ChooseNone")
    try
        return dlg.Add("DateTime", o, "yyyy-MM-dd")
    catch as e {
        ; ★万一この環境でカレンダー部品が使えなくても、画面が開かなくならないように★
        Log("WARN", "カレンダー部品を作れませんでした（文字入力に切り替えます）: " e.Message)
        return dlg.Add("Edit", opts, FmtYmd(ymd))
    }
}

; 日付の入力欄から YYYYMMDD を取り出す。指定なしなら "" を返す。
DateBoxValue(ctrl) {
    v := ""
    try v := ctrl.Value
    v := "" . v
    if (ctrl.Type = "Edit")                         ; 代替の文字入力だったとき
        return NormDate(v)
    if (StrLen(v) >= 8 && RegExMatch(SubStr(v, 1, 8), "^\d{8}$"))
        return SubStr(v, 1, 8)
    return ""
}

; 一覧の中から名前が一致するものを選ぶ。無ければ先頭。
; 「変更しない」の表示名（空っぽ＝触らない、を表す）
NoChangeLabel() => "（変更しない）"

; 予定に入っている値を、一覧に出す表示名に直す
OptLabelOfValue(v) {
    v := Trim("" . v)
    if (v = "")
        return NoChangeLabel()
    if (v = "なし")
        return NoneSelectLabel()
    return v
}

OptLabelOf(item, key) {
    return OptLabelOfValue(item.Has(key) ? item[key] : "")
}

SelectByName(ddl, names, want) {
    if (!names.Length)
        return
    for i, nm in names {
        if (nm = Trim(want)) {
            ddl.Value := i
            return
        }
    }
    ddl.Value := 1
}

FmtYmd(ymd) {
    if (StrLen(ymd) != 8)
        return ""
    return SubStr(ymd, 1, 4) "-" SubStr(ymd, 5, 2) "-" SubStr(ymd, 7, 2)
}

;==============================================================================
;  一覧画面
;==============================================================================
ModeScheduleEditor() {
    global APP_NAME, APP_VER, SCHEDINI, SCHEDUI

    list := LoadSchedule(&err)                      ; err は「1 件もない」だけなら無視
    SCHEDUI := Map("list", list, "dirty", false)

    dlg := Gui("+Resize", APP_NAME " - 予定の編集" VerTag())
    dlg.MarginX := 16, dlg.MarginY := 12
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "w940", "予定の編集")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w940 h34 cGray"
        , "行をダブルクリックすると編集できます。"
        . "「順番に実行する」方は、この表の上から順に実行されます（▲▼ で入れ替え）。`n"
        . "保存すると schedule.ini に書き出します（直前の内容は schedule.ini.bak に残ります）。")

    dlg.SetFont("s10", "Meiryo UI")
    lv := dlg.Add("ListView", "xm w940 r12 -Multi Grid"
        , ["順", "", "対象者", "やること", "繰り返し", "次に実行される", "回数"])
    lv.OnEvent("DoubleClick", SchedEditOpen)

    dlg.SetFont("s10", "Meiryo UI")
    bNew := dlg.Add("Button", "xm w150 h36", "＋ 追加")
    bEdt := dlg.Add("Button", "x+8 yp w150 h36", "編集")
    bDup := dlg.Add("Button", "x+8 yp w150 h36", "複製")
    bDel := dlg.Add("Button", "x+8 yp w150 h36", "削除")
    bTgl := dlg.Add("Button", "x+8 yp w150 h36", "有効／無効")
    bUp  := dlg.Add("Button", "x+24 yp w80 h36", "▲ 上へ")
    bDn  := dlg.Add("Button", "x+8 yp w80 h36", "▼ 下へ")

    dlg.Add("Text", "xm w940 h1 0x10")
    dlg.SetFont("s11 Bold", "Meiryo UI")
    bRun  := dlg.Add("Button", "xm w360 h46 Default", "▶  この予定で運転を開始する")
    dlg.SetFont("s10", "Meiryo UI")
    bSave := dlg.Add("Button", "x+10 yp w270 h46", "保存して閉じる")
    bCls  := dlg.Add("Button", "x+10 yp w270 h46", "閉じる")

    bNew.OnEvent("Click",  (*) => SchedEditNew())
    bEdt.OnEvent("Click",  (*) => SchedEditOpen())
    bDup.OnEvent("Click",  (*) => SchedEditDup())
    bDel.OnEvent("Click",  (*) => SchedEditDel())
    bTgl.OnEvent("Click",  (*) => SchedEditToggle())
    bUp.OnEvent("Click",   (*) => SchedEditMove(-1))
    bDn.OnEvent("Click",   (*) => SchedEditMove(1))
    bSave.OnEvent("Click", (*) => SchedEditSave(true))
    bRun.OnEvent("Click",  (*) => SchedEditRun())
    bCls.OnEvent("Click",  (*) => SchedEditClose())
    dlg.OnEvent("Close",   (*) => SchedEditClose())

    SCHEDUI["dlg"] := dlg
    SCHEDUI["lv"]  := lv
    SchedEditRefresh()
    dlg.Show()
}

SchedEditRefresh() {
    global SCHEDUI
    lv := SCHEDUI["lv"]
    lv.Delete()
    for item in SCHEDUI["list"] {
        todo := ""
        if (item["scan"])
            todo := "調査"
        if (item["scan"] && item.Has("scantype") && item["scantype"] != "")
            todo .= "（" item["scantype"]
                 . (item.Has("manual") && item["manual"] != "" ? " / " item["manual"] : "") "）"
        if (item["count"] > 0)
            todo .= (todo = "" ? "" : " ＋ ") "セラピー " item["count"] " 回"
        if (todo = "")
            todo := "（なし）"
        todo .= "   " EstimateText(item["scan"], item["count"])

        if (item["mode"] = "weekly")
            rep := "毎週 " DaysLabel(item["days"]) "  " TimeLabel(item)
        else
            rep := item["interval"] " 日おき  " TimeLabel(item)

        runs := HistRunCount(item["key"])
        if (item["maxruns"] > 0)
            cnt := runs " / " item["maxruns"] " 回"
        else
            cnt := runs " 回（上限なし）"

        lv.Add("", A_Index, item["enabled"] ? "✓" : "－"
             , item["sei"] " " item["mei"], todo, rep, NextDueText(item), cnt)
    }
    lv.ModifyCol(1, 34)
    lv.ModifyCol(2, 34)
    lv.ModifyCol(3, 130)
    lv.ModifyCol(4, 236)
    lv.ModifyCol(5, 160)
    lv.ModifyCol(6, 230)
    lv.ModifyCol(7, 110)
    if (SCHEDUI.Has("sel") && SCHEDUI["sel"] >= 1 && SCHEDUI["sel"] <= SCHEDUI["list"].Length)
        lv.Modify(SCHEDUI["sel"], "Select Focus Vis")
}

; 実行の順番を入れ替える（dir = -1 で上へ / +1 で下へ）
SchedEditMove(dir) {
    global SCHEDUI
    row := SCHEDUI["lv"].GetNext()
    if (row < 1) {
        MsgBox("動かしたい行を選んでください。", "予定の編集", "Icon! 4096")
        return
    }
    dst := row + dir
    if (dst < 1 || dst > SCHEDUI["list"].Length)
        return
    tmp := SCHEDUI["list"][row]
    SCHEDUI["list"][row] := SCHEDUI["list"][dst]
    SCHEDUI["list"][dst] := tmp
    SCHEDUI["sel"]   := dst
    SCHEDUI["dirty"] := true
    SchedEditRefresh()
}

FmtHHMM(t) {
    return (StrLen(t) = 4) ? SubStr(t, 1, 2) ":" SubStr(t, 3, 2) : "??:??"
}

DaysLabel(spec) {
    out := ""
    for part in StrSplit(spec, ",") {
        num := DayNameToNum(part)
        if (num > 0)
            out .= (out = "" ? "" : "・") DayNumToName(num)
    }
    return (out = "") ? "？" : out
}

SchedEditNew() {
    global SCHEDUI
    item := NewPatientMap()
    if (!PatientDialog(item, true))
        return
    item["key"] := MakeSchedKey(item["sei"], item["mei"], SCHEDUI["list"])
    SCHEDUI["list"].Push(item)
    SCHEDUI["dirty"] := true
    SchedEditRefresh()
}

SchedEditOpen(args*) {
    global SCHEDUI
    row := SCHEDUI["lv"].GetNext()
    if (row < 1) {
        MsgBox("編集したい行を選んでください。", "予定の編集", "Icon! 4096")
        return
    }
    item := SCHEDUI["list"][row]
    if (!PatientDialog(item, false))
        return
    SCHEDUI["dirty"] := true
    SchedEditRefresh()
}

SchedEditDup() {
    global SCHEDUI
    row := SCHEDUI["lv"].GetNext()
    if (row < 1) {
        MsgBox("複製したい行を選んでください。", "予定の編集", "Icon! 4096")
        return
    }
    src := SCHEDUI["list"][row]
    item := Map()
    for k, v in src
        item[k] := v
    item["sei"] := "", item["mei"] := "", item["enabled"] := false
    if (!PatientDialog(item, true))
        return
    item["key"] := MakeSchedKey(item["sei"], item["mei"], SCHEDUI["list"])
    SCHEDUI["list"].Push(item)
    SCHEDUI["dirty"] := true
    SchedEditRefresh()
}

SchedEditDel() {
    global SCHEDUI
    row := SCHEDUI["lv"].GetNext()
    if (row < 1) {
        MsgBox("削除したい行を選んでください。", "予定の編集", "Icon! 4096")
        return
    }
    item := SCHEDUI["list"][row]
    ans := MsgBox(Format("「{1} {2}」の予定を削除します。よろしいですか？`n`n"
        . "（実行の履歴は残ります。保存するまでファイルは変わりません）"
        , item["sei"], item["mei"]), "予定の編集", "YesNo Icon? 4096")
    if (ans != "Yes")
        return
    SCHEDUI["list"].RemoveAt(row)
    SCHEDUI["dirty"] := true
    SchedEditRefresh()
}

SchedEditToggle() {
    global SCHEDUI
    row := SCHEDUI["lv"].GetNext()
    SCHEDUI["sel"] := row
    if (row < 1) {
        MsgBox("切り替えたい行を選んでください。", "予定の編集", "Icon! 4096")
        return
    }
    SCHEDUI["list"][row]["enabled"] := !SCHEDUI["list"][row]["enabled"]
    SCHEDUI["dirty"] := true
    SchedEditRefresh()
}

SchedEditSave(thenClose := true) {
    global SCHEDUI, APP_NAME
    if (!SaveSchedule(SCHEDUI["list"], &err)) {
        MsgBox(err, APP_NAME " - 保存できません", "Iconx 4096")
        return
    }
    SCHEDUI["dirty"] := false
    Log("INFO", "schedule.ini を保存しました（" SCHEDUI["list"].Length " 件）")
    if (!thenClose) {
        SchedEditRefresh()
        return
    }
    SCHEDUI["dlg"].Destroy()
    ModeMenu()
}

; 変更があれば保存してから運転へ。無ければそのまま運転へ
SchedEditRun() {
    global SCHEDUI, APP_NAME
    if (SCHEDUI["dirty"]) {
        if (!SaveSchedule(SCHEDUI["list"], &err)) {
            MsgBox(err, APP_NAME " - 保存できません", "Iconx 4096")
            return
        }
        SCHEDUI["dirty"] := false
        Log("INFO", "schedule.ini を保存しました（" SCHEDUI["list"].Length " 件）")
    }
    SCHEDUI["dlg"].Destroy()
    ModeSchedule()
}

SchedEditClose() {
    global SCHEDUI
    if (SCHEDUI["dirty"]) {
        ans := MsgBox("保存していない変更があります。破棄して閉じますか？"
            , "予定の編集", "YesNo Icon! 4096")
        if (ans != "Yes")
            return
    }
    SCHEDUI["dlg"].Destroy()
    ModeMenu()
}

;==============================================================================
;  1 人ぶんの編集フォーム
;==============================================================================
;  戻り値: true = OK が押されて item が書き換わった / false = やめた
PatientDialog(item, isNew) {
    global APP_NAME, SCHEDUI
    accepted := false
    finished := false

    dlg := Gui("+AlwaysOnTop", APP_NAME (isNew ? " - 予定を追加" : " - 予定を編集") VerTag())
    dlg.MarginX := 16, dlg.MarginY := 6

    ; ★縦を詰める★
    ;   画面の小さい環境では、下の OK ボタンが画面外に出てしまう（2026-09-15 指摘）。
    ;   説明文は 1 行に収め、関連する入力は同じ行に並べること。
    W := 700

    ; --- 対象者 ---------------------------------------------------------------
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "w" W, "対象者")
    dlg.SetFont("s10", "Meiryo UI")
    dlg.Add("Text", "xm+12 w30", "姓")
    eSei := dlg.Add("Edit", "x+4 yp-4 w100", item["sei"])
    dlg.Add("Text", "x+14 yp+4 w30", "名")
    eMei := dlg.Add("Edit", "x+4 yp-4 w100", item["mei"])
    dlg.Add("Text", "x+14 yp+4 w60", "ミドル")
    eMid := dlg.Add("Edit", "x+4 yp-4 w100", item.Has("middle") ? item["middle"] : "")
    cOn := dlg.Add("Checkbox", "x+24 yp+4 w200" (item["enabled"] ? " Checked" : "")
        , "この予定を有効にする")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "xm+12 w" (W - 12) " cGray"
        , "★検索欄と同じ氏名に（実行前に照合）。ミドルは比較用カードと区別するときだけ／空欄＝ミドル無しのカード")

    ; --- やること -------------------------------------------------------------
    dlg.Add("Text", "xm w" W " h1 0x10")
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "xm w" W, "やること")
    dlg.SetFont("s10", "Meiryo UI")
    cScan := dlg.Add("Checkbox", "xm+12 w150" (item["scan"] ? " Checked" : ""), "調査を行う")
    dlg.Add("Text", "x+20 yp w70", "セラピー")
    cntList := []
    Loop (CI("MaxUnattendedCycles") + 1)
        cntList.Push(String(A_Index - 1))
    dCnt := dlg.Add("DropDownList", "x+4 yp-4 w70", cntList)
    dCnt.Value := item["count"] + 1
    dlg.Add("Text", "x+6 yp+4 w30", "回")

    ; 調査タイプ／マニュアル選択（位置を教えてあれば選べる）
    ; 先頭は必ず「変更しない」。
    ;   マニュアル選択は【設定】ではなく【動作】で、押すと調査項目が選び直される。
    ;   「自動選択」を押したら項目が 1 つに減った（2026-09-16 実機）。
    ;   触らないでおけるようにしておく。
    stNames := OptNames("ScanType")
    mnNames := OptNames("Manual")
    stList  := [NoChangeLabel()]
    for nm in stNames
        stList.Push(nm)
    mnList := [NoChangeLabel(), NoneSelectLabel()]
    for nm in mnNames
        mnList.Push(nm)
    dlg.Add("Text", "xm+12 w70", "調査タイプ")
    dST := dlg.Add("DropDownList", "x+4 yp-4 w150", stList)
    SelectByName(dST, stList, OptLabelOf(item, "scantype"))
    dlg.Add("Text", "x+20 yp+4 w90", "マニュアル選択")
    dMN := dlg.Add("DropDownList", "x+4 yp-4 w170", mnList)
    SelectByName(dMN, mnList, OptLabelOf(item, "manual"))
    dlg.SetFont("s9", "Meiryo UI")
    if (!stNames.Length || !mnNames.Length)
        dlg.Add("Text", "xm+12 w" (W - 12) " cRed"
            , "※ 位置が未登録です（設定 →「調査タイプ／マニュアル選択の位置を教える」）")
    else
        dlg.Add("Text", "xm+12 w" (W - 12) " cGray"
            , "マニュアル選択は【押すと調査項目が選び直される動作】です。"
            . "既定の「どれも選ばない」なら、青いものを押して外します。")
    dlg.SetFont("s10", "Meiryo UI")

    ; --- 繰り返し -------------------------------------------------------------
    dlg.Add("Text", "xm w" W " h1 0x10")
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "xm w" W, "繰り返し")
    dlg.SetFont("s10", "Meiryo UI")
    rWeek := dlg.Add("Radio", "xm+12 w90" (item["mode"] = "weekly" ? " Checked" : ""), "毎週")
    dayBoxes := []
    Loop 7 {
        opt := (A_Index = 1 ? "x+0 yp w48" : "x+2 yp w48")
        dayBoxes.Push(dlg.Add("Checkbox", opt
            . (DaysInclude(item["days"], A_Index) ? " Checked" : ""), DayNumToName(A_Index)))
    }
    rIntv := dlg.Add("Radio", "xm+12 w90" (item["mode"] = "weekly" ? "" : " Checked"), "日数で")
    ivList := []
    Loop 30
        ivList.Push(String(A_Index))
    dIv := dlg.Add("DropDownList", "x+0 yp-4 w70", ivList)
    dIv.Value := (item["interval"] >= 1 && item["interval"] <= 30) ? item["interval"] : 3
    dlg.Add("Text", "x+8 yp+4 w280", "日おき（前回の実行日から数えます）")

    ; --- 実行のしかた ---------------------------------------------------------
    dlg.Add("Text", "xm w" W " h1 0x10")
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "xm w" W, "実行のしかた")
    dlg.SetFont("s10", "Meiryo UI")
    dlg.Add("Text", "xm+12 w40", "時刻")
    hrList := []
    Loop 24
        hrList.Push(Format("{:02}", A_Index - 1))
    dHr := dlg.Add("DropDownList", "x+4 yp-4 w66", hrList)
    dHr.Value := ToInt(SubStr(item["time"], 1, 2), 21) + 1
    dlg.Add("Text", "x+4 yp+4 w12", ":")
    mnList := []
    Loop 12
        mnList.Push(Format("{:02}", (A_Index - 1) * 5))
    curMn := ToInt(SubStr(item["time"], 3, 2), 0)
    if (Mod(curMn, 5) = 0) {
        mnIdx := curMn // 5 + 1
    } else {                                        ; 5 分刻みでない値も失わない
        mnList.Push(Format("{:02}", curMn))
        mnIdx := mnList.Length
    }
    dMn := dlg.Add("DropDownList", "x+2 yp-4 w66", mnList)
    dMn.Value := mnIdx

    isQueue := (item["timemode"] = "queue")
    rAt := dlg.Add("Radio", "x+24 yp+4 w220" (isQueue ? "" : " Checked"), "この時刻ちょうどに")
    rQu := dlg.Add("Radio", "x+0 yp w220" (isQueue ? " Checked" : ""), "以降、空いたら順番に")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "xm+12 w" (W - 12) " cGray"
        , "順番に＝その日のうちに、前の方が終わりしだい続けて実行（時間の上限なし）。"
        . "初回は開始日のうちに実行されます")

    ; --- 期間と回数 -----------------------------------------------------------
    dlg.Add("Text", "xm w" W " h1 0x10")
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "xm w" W, "期間と回数")
    dlg.SetFont("s10", "Meiryo UI")
    dlg.Add("Text", "xm+12 w50", "開始日")
    eSt := AddDateBox(dlg, "x+4 yp-4 w150", item["start"])
    dlg.Add("Text", "x+14 yp+4 w50", "終了日")
    eEn := AddDateBox(dlg, "x+4 yp-4 w150", item["end"])
    dlg.Add("Text", "x+18 yp+4 w40", "上限")
    mrList := ["無制限"]
    Loop 30
        mrList.Push(String(A_Index))
    dMr := dlg.Add("DropDownList", "x+4 yp-4 w86", mrList)
    dMr.Value := (item["maxruns"] >= 1 && item["maxruns"] <= 30) ? item["maxruns"] + 1 : 1
    dlg.Add("Text", "x+6 yp+4 w60", "回で終了")

    dlg.Add("Text", "xm+12 w110", "遅れて起動したとき")
    cuList := ["制限なし", "30 分", "60 分", "120 分", "180 分", "360 分", "720 分"]
    cuVals := [0, 30, 60, 120, 180, 360, 720]
    dCu := dlg.Add("DropDownList", "x+4 yp-4 w100", cuList)
    dCu.Value := 4
    for idx, val in cuVals {
        if (val = item["catchup"])
            dCu.Value := idx
    }
    dlg.Add("Text", "x+6 yp+4 w120", "以内なら実行する")
    dlg.Add("Text", "x+10 yp w40", "メモ")
    eNote := dlg.Add("Edit", "x+4 yp-4 w220", item["note"])

    ; --- このとおりに実行されます ---------------------------------------------
    dlg.Add("Text", "xm w" W " h1 0x10")
    dlg.SetFont("s10 Bold", "Meiryo UI")
    dlg.Add("Text", "xm w" W, "このとおりに実行されます")
    dlg.SetFont("s10", "Meiryo UI")
    tPrev := dlg.Add("Text", "xm w" W " h58 cBlue", "")

    ; --- ボタン（必ず 1 行に収める）-------------------------------------------
    dlg.SetFont("s10", "Meiryo UI")
    bHist := dlg.Add("Button", "xm w200 h40", "この人の実行履歴を消す")
    dlg.SetFont("s11 Bold", "Meiryo UI")
    bOk := dlg.Add("Button", "x+" (W - 200 - 160 - 160 - 20) " yp w160 h40 Default", "OK")
    dlg.SetFont("s10", "Meiryo UI")
    bNg := dlg.Add("Button", "x+20 yp w160 h40", "やめる")

    ; ★ラジオの間にチェックボックスを挟むと Windows のグループが切れる★
    ;   どちらも押せてしまうので、排他は自分で面倒を見る。
    rWeek.OnEvent("Click", (*) => PickMode(true))
    rIntv.OnEvent("Click", (*) => PickMode(false))
    rAt.OnEvent("Click",   (*) => PickTiming(true))
    rQu.OnEvent("Click",   (*) => PickTiming(false))

    ; 入力の種類ごとにイベント名が違う（Edit / DDL は Change、Checkbox は Click）
    for ctrl in [eSei, eMei, eMid, eSt, eEn]
        ctrl.OnEvent("Change", (*) => Preview())
    for ctrl in [dCnt, dST, dMN, dIv, dHr, dMn, dMr, dCu]
        ctrl.OnEvent("Change", (*) => Preview())
    for ctrl in [cOn, cScan]
        ctrl.OnEvent("Click", (*) => Preview())
    for box in dayBoxes
        box.OnEvent("Click", (*) => Preview())

    bHist.OnEvent("Click", (*) => ResetHist())
    bOk.OnEvent("Click",   (*) => Accept())
    bNg.OnEvent("Click",   (*) => Cancel())
    dlg.OnEvent("Close",   (*) => Cancel())
    dlg.OnEvent("Escape",  (*) => Cancel())        ; Esc でやめる

    Preview()
    if (SCHEDUI.Has("dlg"))
        SCHEDUI["dlg"].Opt("+Disabled")            ; 編集中に一覧を触らせない
    ; 画面の上端から出す。小さい画面でも下のボタンが隠れにくいように。
    ;   （それでも入りきらない場合のために、Enter = OK / Esc = やめる が効く）
    dlg.Show("y6")
    ; タスクバーの分を除いた「使える高さ」と比べる（画面の高さそのものではなく）
    wkT := 0, wkB := A_ScreenHeight
    try MonitorGetWorkArea(, , &wkT, , &wkB)
    wh := 0
    try WinGetPos(, , , &wh, "ahk_id " dlg.Hwnd)
    if (wh > wkB - wkT - 6)
        Log("WARN", Format("編集画面の高さ {1}px が使える高さ {2}px に収まりません（拡大 {3}%）"
            . "（Enter で OK、Esc でやめる が使えます）", wh, wkB - wkT, Round(A_ScreenDPI / 96 * 100)))
    while (!finished)
        Sleep(60)
    try dlg.Destroy()                           ; ×で閉じた場合はすでに壊れている
    if (SCHEDUI.Has("dlg")) {
        try SCHEDUI["dlg"].Opt("-Disabled")
        try WinActivate("ahk_id " SCHEDUI["dlg"].Hwnd)
    }
    return accepted

    Cancel() {
        finished := true
    }

    PickMode(weekly) {
        rWeek.Value := weekly ? 1 : 0
        rIntv.Value := weekly ? 0 : 1
        Preview()
    }

    PickTiming(exact) {
        rAt.Value := exact ? 1 : 0
        rQu.Value := exact ? 0 : 1
        Preview()
    }

    ; --- 画面の入力から Map を作る -------------------------------------------
    Collect() {
        out := Map()
        for k, v in item
            out[k] := v
        out["sei"]     := Trim(eSei.Value)
        out["mei"]     := Trim(eMei.Value)
        out["middle"]  := Trim(eMid.Value)
        out["enabled"] := (cOn.Value = 1)
        out["scan"]    := (cScan.Value = 1)
        out["count"]   := dCnt.Value - 1
        out["scantype"] := (dST.Value >= 2) ? stList[dST.Value] : ""
        out["manual"]   := (dMN.Value = 1) ? "" : ((dMN.Value = 2) ? "なし" : mnList[dMN.Value])
        out["mode"]    := (rWeek.Value = 1) ? "weekly" : "interval"
        days := ""
        for idx, box in dayBoxes {
            if (box.Value = 1)
                days .= (days = "" ? "" : ",") DayNumToName(idx)
        }
        out["days"]     := days
        out["interval"] := dIv.Value
        out["time"]     := hrList[dHr.Value] . mnList[dMn.Value]
        out["timemode"] := (rQu.Value = 1) ? "queue" : "at"
        out["start"]    := DateBoxValue(eSt)
        out["end"]      := DateBoxValue(eEn)
        out["maxruns"]  := dMr.Value - 1
        out["catchup"]  := cuVals[dCu.Value]
        out["note"]     := Trim(eNote.Value)
        if (out["key"] = "")
            out["key"] := "Patient.（新規）"
        return out
    }

    ; --- 入力のたびに「結局どうなるか」を見せる ------------------------------
    Preview() {
        cur := Collect()
        lines := ""
        if (cur["start"] != "" && cur["end"] != "" && cur["end"] < cur["start"])
            lines .= "⚠ 終了日が開始日より前になっています`n"
        if (!ValidateEntry(cur, &why)) {
            tPrev.Opt("cRed")
            tPrev.Value := lines "⚠ " why
            tPrev.Redraw()
            return
        }
        tPrev.Opt("cBlue")
        lines .= NextDueText(cur) "`n"
        if (cur["timemode"] = "queue") {
            if (cur["time"] = "0000")
                lines .= "その日のうちに、空いたら実行します（時刻の指定なし）`n"
            else
                lines .= FmtHHMM(cur["time"]) " 以降に、空いたら実行します`n"
        }
        lines .= "1 回の所要 " EstimateText(cur["scan"], cur["count"])
        if (cur["maxruns"] > 0) {
            done := (cur["key"] = "Patient.（新規）") ? 0 : HistRunCount(cur["key"])
            left := Max(0, cur["maxruns"] - done)
            lines .= Format("    残り {1} 回（{2}/{3} 回 済み）", left, done, cur["maxruns"])
            if (cur["mode"] = "interval" && left > 0) {
                base := (cur["start"] != "") ? cur["start"] : FormatTime(A_Now, "yyyyMMdd")
                fin  := DateAdd(base "000000", cur["interval"] * (left - 1), "Days")
                lines .= "`n最後の回は " FormatTime(fin, "M月d日") " ごろの見込みです"
            }
        }
        ; ★「いま保存したらすぐ走る」かどうかを、その場で見せる★
        ;   2026-09-15、開始日=今日・06:00 以降・順番待ち の予定が、
        ;   設定した直後（19 時台）に走って驚かせてしまった。
        ;   仕様どおりだが、事前に分かるようにしておく。
        if (cur["enabled"] && DueNow(cur, &dw)) {
            lines .= "`n★ いまこの時点で条件を満たしています"
                  . "（運転を開始すると、すぐに始まります）"
        }
        tPrev.Value := lines
        tPrev.Redraw()
    }

    ResetHist() {
        if (item["key"] = "") {
            MsgBox("まだ保存していない予定なので、履歴はありません。", APP_NAME, "Iconi 4096")
            return
        }
        ans := MsgBox(Format("「{1} {2}」の実行履歴（{3} 回）を消します。`n`n"
            . "回数の上限に達した方を、もう一度はじめから回したいときに使います。`n"
            . "よろしいですか？", item["sei"], item["mei"], HistRunCount(item["key"]))
            , APP_NAME, "YesNo Icon? 4096")
        if (ans != "Yes")
            return
        HistReset(item["key"])
        Log("INFO", "実行履歴を消しました: " item["key"])
        Preview()
    }

    Accept() {
        cur := Collect()
        if (cur["enabled"] && !ValidateEntry(cur, &why)) {
            MsgBox("この内容では実行できません。`n`n" why
                . "`n`n（直すか、「この予定を有効にする」のチェックを外してください）"
                , APP_NAME, "Iconx 4096")
            return
        }
        if (cur["sei"] = "" || cur["mei"] = "") {
            MsgBox("姓と名の両方を入れてください。", APP_NAME, "Iconx 4096")
            return
        }
        for k, v in cur
            item[k] := v
        accepted := true
        finished := true
    }
}

;==============================================================================
;  確認待ち — 終わったことを見落とさないための控え
;==============================================================================
;  スケジュール運転が 1 人ぶん終わったら、その方へ結果を報告する必要がある
;  （LP の「3 日ごとの定期遠隔調律＆フォロー通知」）。
;
;  トレイ通知は数秒で消えるので、席を外していると気づけない。
;  ★終わったことは、こちらが ✓ を付けて消すまで残す★
;  ファイルに持つので、ツールを再起動しても消えない。
;
;  1 行 = 完了時刻 | 成否 | 姓 | 名 | 内容
;==============================================================================

PendingLoad() {
    global PENDFILE
    out := []
    if !FileExist(PENDFILE)
        return out
    txt := ""
    try txt := FileRead(PENDFILE, "UTF-8")
    txt := StrReplace(txt, Chr(0xFEFF), "")
    for line in StrSplit(txt, "`n", "`r") {
        if (Trim(line) = "")
            continue
        f := StrSplit(line, "|")
        if (f.Length < 5)
            continue
        out.Push(Map("ts", f[1], "ok", f[2] = "1", "sei", f[3], "mei", f[4]
                   , "text", f[5], "raw", line))
    }
    return out
}

PendingSave(list) {
    global PENDFILE
    o := ""
    for it in list
        o .= it["raw"] "`n"
    try {
        if FileExist(PENDFILE)
            FileDelete(PENDFILE)
        if (o != "")
            FileAppend(CRLF(o), PENDFILE, "UTF-8")
    }
}

; ジョブが終わったところで積む（G をまだ初期化する前に呼ぶこと）
PendingAdd(ok) {
    global G, PENDFILE
    if (G.wantSei = "" && G.wantMei = "")
        return
    line := FormatTime(A_Now, "yyyyMMddHHmmss") "|" (ok ? "1" : "0")
          . "|" G.wantSei "|" G.wantMei "|" PendingText()
    try FileAppend(CRLF(line "`n"), PENDFILE, "UTF-8")
}

; 一覧に出す 1 行ぶんの内容
PendingText() {
    global G
    t := ""
    if (CB("RunInvestigation") && G.scanItems > 0)
        t := "調査 " FmtDur(G.scanSec) " / " G.scanItems " 項目"
    if (CI("TherapyCount") > 0)
        t .= (t = "" ? "" : " ＋ ") "セラピー " G.cycle " / " CI("TherapyCount") " 回"
    if (t = "")
        t := "（内容なし）"
    if (G.optWarn != "")
        t .= "　★" G.optWarn
    if (G.needCheck != "")
        t .= "　★要確認: " G.needCheck
    return t "　所要 " FmtDur(SecSince(G.startTS))
}

PendFmtTS(ts) {
    return (StrLen(ts) = 14) ? FormatTime(ts, "M/d HH:mm") : ts
}

;------------------------------------------------------------------------------
;  確認待ちの一覧（運転パネルから開く。運転は止まらない）
;------------------------------------------------------------------------------
ShowPendingDialog(*) {
    global APP_NAME, PENDUI
    if (PENDUI.Has("dlg")) {                       ; すでに開いていれば前面に出すだけ
        try {
            PENDUI["dlg"].Show()
            return
        }
    }
    list := PendingLoad()
    dlg := Gui("+AlwaysOnTop", APP_NAME " - 確認待ち" VerTag())
    dlg.MarginX := 16, dlg.MarginY := 12
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "w720", "確認待ち")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w720 cGray"
        , "終わった方の控えです。内容を確認したら ✓ を付けて、下のボタンで消してください。"
        . "✓ を付けて消すまで、運転パネルに出続けます。")
    dlg.SetFont("s10", "Meiryo UI")
    ; ★Checked を付けると各行にチェックボックスが出る★
    lv := dlg.Add("ListView", "xm w720 r10 Checked Grid", ["", "終了", "対象者", "内容"])
    for it in list {
        lv.Add("", it["ok"] ? "済" : "★失敗", PendFmtTS(it["ts"])
             , it["sei"] " " it["mei"], it["text"])
    }
    lv.ModifyCol(1, 56), lv.ModifyCol(2, 90), lv.ModifyCol(3, 130), lv.ModifyCol(4, 400)

    dlg.SetFont("s10", "Meiryo UI")
    lblCnt := dlg.Add("Text", "xm w720 cGray", "")

    bDone := dlg.Add("Button", "xm w260 h40 Default", "✓ を付けた行を確認済みにする")
    bAll  := dlg.Add("Button", "x+10 yp w200 h40", "すべてに ✓ を付ける")
    bCls  := dlg.Add("Button", "x+10 yp w200 h40", "閉じる")
    bDone.OnEvent("Click", (*) => ClearChecked())
    bAll.OnEvent("Click",  (*) => CheckAll())
    bCls.OnEvent("Click",  (*) => Close())
    lv.OnEvent("ItemCheck", (*) => UpdateCount())
    dlg.OnEvent("Close",  (*) => Close())
    dlg.OnEvent("Escape", (*) => Close())
    PENDUI["dlg"] := dlg
    PENDUI["lv"]  := lv
    UpdateCount()
    dlg.Show()
    return

    ; いま何件あって、何件に ✓ が付いているか
    UpdateCount() {
        total := lv.GetCount()
        done  := 0, row := 0
        Loop {
            row := lv.GetNext(row, "Checked")
            if (!row)
                break
            done++
        }
        if (total = 0)
            lblCnt.Value := "確認待ちはありません。"
        else
            lblCnt.Value := Format("全 {1} 件　／　✓ を付けた行 {2} 件", total, done)
        lblCnt.Redraw()
    }

    CheckAll() {
        Loop lv.GetCount()
            lv.Modify(A_Index, "Check")
        UpdateCount()
    }

    ClearChecked() {
        checked := [], row := 0
        Loop {
            row := lv.GetNext(row, "Checked")
            if (!row)
                break
            checked.Push(row)
        }
        if (checked.Length = 0) {
            MsgBox("確認できた行に ✓ を付けてください。", APP_NAME, "Icon! 4096")
            return
        }
        cur := PendingLoad()
        ; ★後ろの行から消す★ 先頭から消すと、以降の行番号がずれる
        idx := checked.Length
        while (idx >= 1) {
            r := checked[idx]
            if (r <= cur.Length) {
                Log("INFO", "確認済みにしました: " cur[r]["sei"] " " cur[r]["mei"])
                cur.RemoveAt(r)
            }
            lv.Delete(r)
            idx--
        }
        PendingSave(cur)
        RefreshPanelPending(true)
        UpdateCount()
    }

    Close() {
        global PENDUI
        try dlg.Destroy()
        PENDUI.Delete("dlg")
        PENDUI.Delete("lv")
    }
}

; 運転パネルの「確認待ち」行を作る
PendingPanelText() {
    list := PendingLoad()
    if (list.Length = 0)
        return "確認待ちはありません"
    out := "★ 未確認 " list.Length " 件　← クリックで開く"
    n := 0
    for it in list {
        n++
        if (n > 3) {
            out .= "`n　　ほか " (list.Length - 3) " 件"
            break
        }
        out .= "`n　・" it["sei"] " " it["mei"] "　" PendFmtTS(it["ts"])
             . (it["ok"] ? "" : "　★失敗")
    }
    return out
}

RefreshPanelPending(force := false) {
    global G
    static lastTS := ""
    if (G.panelPend = "")
        return
    if (!force && lastTS != "" && SecSince(lastTS) < 3)
        return                                      ; 毎秒ファイルを読まない
    lastTS := A_Now
    t := PendingPanelText()
    G.panelPend.Value := t
    G.panelPend.Opt(InStr(t, "★") ? "cRed" : "cGray")
    G.panelPend.Redraw()
}

;==============================================================================
;  運転パネル — 動いていることが「ひと目で分かる」ようにする
;
;  トレイ常駐だけだと、Windows がトレイアイコンを隠すため
;  動いているのか止まっているのか分からない（カマヤン指摘 2026-09-14）。
;  タスクバーに出る小さな窓を常に表示する。
;==============================================================================

; トレイから呼ばれたとき。最小化しているなら元に戻し、無ければ作る
RestorePanel() {
    global G
    if (G.panel != "") {
        try G.panel.Restore()
        try WinActivate("ahk_id " G.panel.Hwnd)
        return
    }
    ShowPanel()
}

ShowPanel() {
    ; ★ローカル変数に g を使ってはいけない★
    ;   AHK は大文字小文字を区別しないため、g := Gui(...) がグローバルの G（実行時状態）を
    ;   丸ごと上書きしてしまう。2026-09-14 に「Gui に schedOn がありません」で落ちた原因。
    global G, APP_NAME, APP_VER
    if (G.panel != "")
        return
    pnl := Gui("+AlwaysOnTop +Resize", APP_NAME VerTag())
    ; ★タスクバーのボタンを必ず持たせる★（WS_EX_APPWINDOW）
    ;   2026-09-22、×で引っ込めるとタスクバーからも消え、動いているのか
    ;   分からなくなった。この指定があれば、最小化しても必ず残る。
    try pnl.Opt("+E0x40000")
    pnl.MarginX := 14, pnl.MarginY := 10
    pnl.BackColor := "FFFFFF"

    pnl.SetFont("s12 Bold", "Meiryo UI")
    G.panelState := pnl.Add("Text", "w400 cGreen", "● 準備中")

    pnl.SetFont("s10", "Meiryo UI")
    G.panelWho := pnl.Add("Text", "w400", "対象者 : -")
    G.panelJob := pnl.Add("Text", "w400", "")
    pnl.SetFont("s9", "Meiryo UI")
    G.panelSub := pnl.Add("Text", "w400 cGray", "")

    pnl.Add("Text", "w400 h1 0x10")
    pnl.SetFont("s10 Bold", "Meiryo UI")
    G.panelPend := pnl.Add("Text", "w400 h58 cRed +0x100", "")   ; 0x100 = クリックを拾う
    G.panelPend.OnEvent("Click", ShowPendingDialog)
    pnl.Add("Text", "w400 h1 0x10")
    pnl.SetFont("s9", "Meiryo UI")
    ; ★人数が増えても全員読めるように、スクロールできる欄にする★
    ;   （Text だと入りきらない。2026-09-15 指摘）
    G.panelNext := pnl.Add("Edit", "w400 h130 ReadOnly -WantReturn +VScroll cGray", "")

    pnl.SetFont("s10", "Meiryo UI")
    bMenu := pnl.Add("Button", "w94 h34", "メニュー")
    bStop := pnl.Add("Button", "x+8 yp w94 h34", "止める")
    bLog  := pnl.Add("Button", "x+8 yp w94 h34", "ログ")
    bHide := pnl.Add("Button", "x+8 yp w94 h34", "隠す")
    G.panelBtns := [bMenu, bStop, bLog, bHide]
    bMenu.OnEvent("Click", (*) => OpenMenuWindow())
    bStop.OnEvent("Click", (*) => PanelStop())
    bLog.OnEvent("Click", (*) => OpenFile(G.logFile))
    bHide.OnEvent("Click", (*) => pnl.Minimize())
    ; ★×では止めない★
    ;   閉じるボタンで運転ごと終わっていた。誤って押すとスケジュールが機能しない
    ;   （2026-09-17 指摘）。×は「隠す」だけにして、止めるのは
    ;   「止める」ボタンとトレイの終了だけにする。
    pnl.OnEvent("Close", (*) => PanelHide())

    ; 右下に、作業の邪魔にならない位置で出す。フォーカスは奪わない
    x := A_ScreenWidth - 470
    y := A_ScreenHeight - 500
    pnl.OnEvent("Size", PanelResize)               ; 広げたら予定欄も伸びる
    pnl.Show(Format("NoActivate x{1} y{2} w430", x, y))
    G.panel := pnl
    SetTimer(UpdatePanel, 1000)
    UpdatePanel()
}

; 窓を広げたら、予定欄を伸ばしてボタンを下へ送る
;   人数が増えると予定欄を大きくしたくなるため（2026-09-15）
PanelResize(pnl, minMax, w, h) {
    global G
    if (minMax = -1 || G.panel = "" || G.panelNext = "")
        return
    try {
        m := 14, btnH := 34
        G.panelNext.GetPos(, &ny)
        newH := h - ny - btnH - m * 2
        if (newH < 60)
            newH := 60
        G.panelNext.Move(, , w - m * 2, newH)
        by := ny + newH + 10
        bw := (w - m * 2 - 24) // 4
        for idx, b in G.panelBtns
            b.Move(m + (idx - 1) * (bw + 8), by, bw, btnH)
    }
}

PanelStop() {
    global G, APP_NAME
    ; 手動の自動セラピー中は、そのぶんだけ止めて、スケジュール運転は続ける
    if (G.manualJob) {
        Finish(3, "パネルの「止める」が押されました（自動セラピー）")
        return
    }
    if (G.schedOn) {
        if (G.schedRunning) {
            ans := MsgBox("いま実行中のジョブごと、スケジュール運転を終了します。`n`n"
                . "　対象者: " G.wantSei " " G.wantMei "`n`n"
                . "よろしいですか？", APP_NAME, "YesNo Icon! 4096")
            if (ans != "Yes")
                return
        }
        StopScheduler("パネルの「止める」が押されました")
        return
    }
    Finish(3, "パネルの「止める」が押されました")
}

; ×で閉じられたとき。運転は続けたまま、パネルだけ引っ込める
;   ★消さずに最小化する★
;     2026-09-22 指摘。消してしまうとタスクバーからも居なくなり、
;     裏で動いているのかどうかが分からない。最小化なら、
;     タスクバーに残るので「動いている」と一目で分かり、押せば戻る。
PanelHide() {
    global G, APP_NAME
    if (G.panel != "") {
        try G.panel.Minimize()
        try TrayTip((G.schedOn ? "スケジュール運転は続いています" : "実行は続いています") "`n"
            . "タスクバーに残してあります。押すと元に戻ります。", APP_NAME)
        ; ★1 を返して、AHK の既定の動き（窓を隠す）を止める★
        ;   2026-09-22、最小化したそばから AHK が窓を隠していた。
        ;   そのためタスクバーから消え、トレイにしか残らなかった。
        return 1
    }
    ClosePanel()
    return 0
}

ClosePanel() {
    global G
    SetTimer(UpdatePanel, 0)
    if (G.panel != "") {
        try G.panel.Destroy()
        G.panel := ""
        G.panelPend := ""
    }
}

UpdatePanel() {
    global G
    if (G.panel = "")
        return
    ; --- 1 行目: いま何をしているか -------------------------------------------
    if (G.schedOn && !G.schedRunning) {
        G.panelState.Opt("cGray")
        G.panelState.Value := "◌ 待機中（予定の時刻を待っています）"
    } else if (G.state = "therapy_run") {
        G.panelState.Opt("cRed")
        G.panelState.Value := G.manualJob ? "● 自動セラピー実行中（手動）" : "● セラピー実行中"
    } else if (G.state = "scan_running") {
        G.panelState.Opt("cBlue")
        G.panelState.Value := "● 調査中"
    } else if (G.state = "verify") {
        G.panelState.Opt("cBlue")
        G.panelState.Value := "● 氏名を確認中"
    } else if (G.state = "idle" || G.state = "") {
        G.panelState.Opt("cGray")
        G.panelState.Value := "◌ 準備中"
    } else {
        G.panelState.Opt("cBlue")
        G.panelState.Value := "● 動作中（" . StateLabel(G.state) . "）"
    }

    ; --- 2 行目: 対象者 -------------------------------------------------------
    if (G.wantSei = "") {
        G.panelWho.Value := "対象者 : -"
    } else {
        mark := (G.gotSei = "") ? "" : "  ✓ 照合 OK"
        G.panelWho.Value := "対象者 : " . G.wantSei . " " . G.wantMei . mark
    }

    ; --- 3 行目: 進捗 ---------------------------------------------------------
    t := ""
    if (G.schedOn && !G.schedRunning) {
        t := "本日  完了 " . G.schedDone . " / 要確認 " . G.schedCheck
           . " / 失敗 " . G.schedFailed . " / 見送り " . G.schedSkipped
    } else if (CB("RunInvestigation") && G.scanSec = 0 && G.scanItems > 0) {
        t := "調査 " . G.scanItems . " 項目目"
    } else if (CI("TherapyCount") > 0) {
        t := "セラピー " . G.cycle . " / " . CI("TherapyCount") . " 回"
        if (G.state = "therapy_run")
            t .= "    経過 " . FmtDur(SecSince(G.cycleStartTS))
    } else if (G.scanSec > 0) {
        t := "調査 完了 " . FmtDur(G.scanSec) . " / " . G.scanItems . " 項目"
    }
    G.panelJob.Value := t

    ; --- 4 行目: 補足 ---------------------------------------------------------
    sub := ""
    if (G.startTS != "" && !(G.schedOn && !G.schedRunning))
        sub := "経過 " . FmtDur(SecSince(G.startTS))
    if (CB("DryRun"))
        sub .= (sub = "" ? "" : "    ") . "※ DryRun（何も押しません）"
    G.panelSub.Value := sub

    ; --- 確認待ち -------------------------------------------------------------
    RefreshPanelPending()                          ; 中で 3 秒に 1 回だけ読む

    ; --- 予定 -----------------------------------------------------------------
    if (G.schedOn) {
        ; 予定の判定は state.ini を読むので、毎秒はやらない
        if (G.panelNextTS = "" || SecSince(G.panelNextTS) >= 10) {
            G.panelNextTS := A_Now
            G.panelNext.Value := CRLF(NextUpText())
        }
    } else {
        G.panelNext.Value := "1 人だけの実行です（スケジュール運転ではありません）"
    }
    G.panelState.Redraw()
}

; 状態名を日本語に
StateLabel(st) {
    static m := Map(
        "homing","起点へ戻しています", "open_index","患者一覧を開いています",
        "search","検索しています",     "pick_row","カードを開いています",
        "verify","氏名を確認中",       "scan_open","調査を開こうとしています",
        "scan_anamnesis","既往症画面を通過中", "scan_scheme","スキーム画面を待っています",
        "scan_type","調査タイプを設定中", "scan_manual","マニュアル選択を設定中",
        "scan_go","調査を開始しています", "scan_running","調査中",
        "scan_dialog","完了の確認中",   "scan_check","実行を確認中",
        "therapy_ready","セラピーの準備中", "therapy_click","セラピーを開始します",
        "therapy_start","開始を確認中", "therapy_run","セラピー実行中",
        "therapy_rest","次まで待機中",  "cleanup","後始末中")
    return m.Has(st) ? m[st] : st
}

; 次に実行される予定を 1 行で
; パネルに出す予定の一覧。
;   ★有効な予定は全員ぶん出す★
;     以前は先頭 2 件で切っていたため、3 人目を足した方が
;     「追加したのに出てこない」と見えてしまった（2026-09-15 指摘）。
;   併せて「なぜ今ではないのか」を DueNow の理由でそのまま見せる。
NextUpText() {
    global G
    list := LoadSchedule(&err)
    if (err != "")
        return err
    out := "", n := 0
    for p in list {
        if (!p["enabled"])
            continue
        n++
        mark := (G.schedRunning && p["key"] = G.schedCurrent) ? "▶" : "・"
        why  := ""
        if (G.schedRunning && p["key"] = G.schedCurrent)
            why := "実行中"
        else if (DueNow(p, &w2))
            why := "順番待ち"
        else
            why := w2
        out .= (out = "" ? "" : "`n") . mark " " p["sei"] " " p["mei"] "　" why
    }
    return (out = "") ? "有効な予定がありません" : out
}
;==============================================================================
;  /listread  ★氏名照合ゲート（G1）が実装できるかを判定する★
;  読み取り専用。唯一「検索欄への入力テスト」だけは確認を取ってから行い、
;  終わったら必ず入力を消す。
;==============================================================================
ModeListRead() {
    global C, CFG, APP_NAME
    pid := EnsureTarget()
    wins := TargetWindows(pid)
    if (wins.Length = 0) {
        MsgBox("対象ウィンドウが見えません。最小化していないか確認してください。", APP_NAME, "Icon! 4096")
        ExitApp(1)
    }

    out := "=== AutoMeta /listread  読み取り可否レポート ===`n"
    out .= FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss") "`n"
    out .= "対象: " CS("ExeName") " (pid " pid ")  権限: " (A_IsAdmin ? "管理者" : "通常ユーザー") "`n`n"

    foundIndex := 0, foundCard := 0
    verdict := []

    for w in wins {
        rows := DumpCtrls(w["hwnd"])
        cls  := ClassifyScreen(w["hwnd"], rows)
        out .= "── ウィンドウ: 「" w["title"] "」  class=" w["class"] "  判定=" cls["id"]
             . (cls["hit"] = "" ? "" : "（『" cls["hit"] "』を検出）") "`n"
        out .= CtrlsToText(rows)
        out .= "`n"

        if (cls["id"] = "S1_Index" && !foundIndex) {
            foundIndex := w["hwnd"]
            out .= AnalyzeIndex(w["hwnd"], rows, &verdict)
        }
        if (cls["id"] = "S2_Card" && !foundCard) {
            foundCard := w["hwnd"]
            out .= AnalyzeCard(w["hwnd"], rows, &verdict)
        }
    }

    if (!foundIndex)
        verdict.Push("[--] カードインデックス（一覧）が開いていないため未判定です")
    if (!foundCard)
        verdict.Push("[--] カード画面が開いていないため未判定です（★G1 の可否はここで決まります）")

    out .= "`n======================================================================`n"
    out .= "■ 判定`n"
    for v in verdict
        out .= "  " v "`n"
    out .= "`n■ この結果の読み方`n"
    out .= "  ・姓と名が読めた   → G1（氏名照合ゲート）を実装できます。対象者の自動選択に進めます`n"
    out .= "  ・姓と名が読めない → 対象者の自動選択は【行いません】。`n"
    out .= "                       人が対象者を開いてから調査＋セラピーを自動実行する半自動版にします`n"
    out .= "  ・一覧が読めた     → 方式 B（行を読んで選ぶ）が使えます`n"
    out .= "  ・検索欄があった   → 方式 A（氏名で絞り込む）が使えます。これが第 1 候補です`n"

    path := A_ScriptDir "\listread.txt"
    try FileDelete(path)
    FileAppend(CRLF(out), path, "UTF-8")

    msg := "判定結果`n`n"
    for v in verdict
        msg .= "  " v "`n"
    msg .= "`n詳細は listread.txt に出力しました。`n"
    msg .= "★このファイルの中身をそのまま Claude に貼ってください。`n`n"
    msg .= "続けて「検索欄への入力テスト」を行いますか？`n"
    msg .= "（検索欄に文字を入れて絞り込めるかを確かめ、終わったら消します。`n"
    msg .= " 　ソフトのデータは一切変更しません）"

    if (foundIndex && MsgBox(msg, APP_NAME " - 判定", "YesNo Icon? 4096") = "Yes") {
        TestSearchBox(foundIndex)
    } else if (!foundIndex) {
        MsgBox(msg, APP_NAME " - 判定", "Iconi 4096")
    }
    OpenFile(path)
    ExitApp(0)
}

; 一覧画面の分析
AnalyzeIndex(hwnd, rows, &verdict) {
    out := "     ▼ カードインデックス（一覧）の分析`n"
    edits := [], lists := []
    for r in rows {
        cn := r["cnn"]
        if (RegExMatch(cn, "i)edit"))
            edits.Push(r)
        if (RegExMatch(cn, "i)listview|listbox|SysListView|grid|TStringGrid|TListBox|TDBGrid"))
            lists.Push(r)
    }
    if (edits.Length > 0) {
        out .= "       [OK] 入力欄（検索欄の候補）が " edits.Length " 件`n"
        for r in edits
            out .= "            - " . r["cnn"] . Format("  x{1} y{2} w{3} h{4}", r["x"], r["y"], r["w"], r["h"]) . "`n"
        verdict.Push("[OK] 検索欄の候補あり → 方式 A（氏名で絞り込む）が使える可能性が高い")
        IniSet(A_ScriptDir "\config.ini", "Select", "SearchBoxClassNN", edits[1]["cnn"])
    } else {
        out .= "       [NG] 入力欄が 1 つも見つかりません（検索欄は描画かもしれません）`n"
        verdict.Push("[NG] 検索欄がコントロールとして見つからない → 方式 A は不可")
    }

    if (lists.Length > 0) {
        for r in lists {
            out .= "       [??] 一覧の候補: " r["cnn"] "`n"
            content := ""
            try content := ListViewGetContent("", r["cnn"], "ahk_id " hwnd)
            catch                                   ; ListView でなければ例外になる＝読めない
                content := ""
            if (content != "") {
                n := 0
                Loop Parse, content, "`n", "`r" {
                    if (A_LoopField = "")
                        continue
                    n++
                    if (n <= 5)
                        out .= "            " n ": " A_LoopField "`n"
                }
                out .= "       [OK] " n " 行を読み取れました`n"
                verdict.Push("[OK] 一覧の行を読める（" r["cnn"] " / " n " 行）→ 方式 B が使える")
                IniSet(A_ScriptDir "\config.ini", "Select", "ListClassNN", r["cnn"])
            } else {
                out .= "       [NG] " r["cnn"] " の中身は読み取れません（Delphi の独自描画グリッドの可能性）`n"
            }
        }
    } else {
        out .= "       [NG] 一覧に相当するコントロールが見つかりません`n"
        verdict.Push("[NG] 一覧がコントロールとして見つからない → 方式 B は不可。方式 C（座標）＋ G1 で対応")
    }
    return out "`n"
}

; カード画面の分析（★ここが G1 の可否を決める★）
AnalyzeCard(hwnd, rows, &verdict) {
    out := "     ▼ カード画面の分析（★氏名照合ゲート G1 の可否★）`n"
    edits := []
    for r in rows {
        if (RegExMatch(r["cnn"], "i)edit") && r["x"] != "")
            edits.Push(r)
    }
    if (edits.Length = 0) {
        out .= "       [NG] 入力欄が 1 つも見つかりません`n"
        verdict.Push("[NG] ★カード画面の姓名が読めません → 対象者の自動選択は行いません（半自動版へ）")
        return out "`n"
    }
    ; 上から順に並べ替え、左側の列にある上位 2 件を 姓 / 名 の候補とする
    sorted := []
    for r in edits
        sorted.Push(r)
    Loop sorted.Length - 1 {
        i := A_Index
        Loop sorted.Length - i {
            j := A_Index
            if (sorted[j]["y"] > sorted[j + 1]["y"]) {
                tmp := sorted[j], sorted[j] := sorted[j + 1], sorted[j + 1] := tmp
            }
        }
    }
    out .= "       入力欄（上から順）:`n"
    withText := 0
    for r in sorted {
        tx := Trim(r["text"])
        if (tx != "")
            withText++
        out .= Format("            - {1:-16} x{2} y{3}  値=「{4}」`n", r["cnn"], r["x"], r["y"], tx)
    }
    ; 姓・名の欄を選ぶ。DB 連動の入力欄（TDBEdit）を上から 2 件とるのが最も確実。
    ; 実機では TDBEdit3(y20)=姓 / TDBEdit5(y63)=名 だった。
    ; 検索欄は素の TEdit なので、この選び方なら自然に除外できる。
    dbeds := []
    for r in sorted {
        if RegExMatch(r["cnn"], "i)dbedit")
            dbeds.Push(r)
    }
    a := 0, b := 0, how := ""
    if (dbeds.Length >= 2) {
        a := dbeds[1], b := dbeds[2]
        how := "DB 連動の入力欄（TDBEdit）を上から 2 件"
    } else if (withText >= 2) {
        filled := []
        for r in sorted {
            if (Trim(r["text"]) != "")
                filled.Push(r)
        }
        a := filled[1], b := filled[2]
        how := "中身の入っている入力欄を上から 2 件"
    }
    if !IsObject(a) {
        out .= "       [NG] 姓・名にあたる入力欄を特定できません（権限不足かもしれません）`n"
        verdict.Push("[NG] ★姓名を読み取れません → 管理者版で再実行してください。それでも駄目なら半自動版へ")
        return out "`n"
    }
    ta := Trim(a["text"]), tb := Trim(b["text"])
    out .= "       採用基準: " how "`n"
    out .= "       [OK] 姓の欄: " a["cnn"] " =「" ta "」`n"
    out .= "       [OK] 名の欄: " b["cnn"] " =「" tb "」`n"
    IniSet(A_ScriptDir "\config.ini", "Select", "LastNameFieldClassNN", a["cnn"])
    IniSet(A_ScriptDir "\config.ini", "Select", "FirstNameFieldClassNN", b["cnn"])
    ; ★3 つ目の入力欄はミドルネーム★（姓 / 名前 / ミドルネーム の順に並んでいる）
    ;   同姓同名で「ミドルネームだけ違う比較用カード」を見分けるのに使う。
    if (dbeds.Length >= 3) {
        IniSet(A_ScriptDir "\config.ini", "Select", "MiddleNameFieldClassNN", dbeds[3]["cnn"])
        out .= "       [OK] ミドルの欄: " dbeds[3]["cnn"] " =「" Trim(dbeds[3]["text"]) "」`n"
    } else {
        out .= "       [??] ミドルネームの欄は見つかりませんでした`n"
    }
    if (ta = "" || tb = "") {
        out .= "       [??] 欄は特定できましたが中身が空です。対象者のカードを開いた状態で実行してください`n"
        verdict.Push("[??] 姓名の欄は見つかりましたが中身が空でした（カードを開いてから再実行）")
    } else {
        out .= "       ★ この 2 つが画面の 姓 / 名 と一致していれば、G1 を実装できます`n"
        verdict.Push("[OK] ★姓名を読み取れました（" ta " / " tb "）→ G1 実装可能")
    }
    return out "`n"
}

; 検索欄への入力テスト（確認済みのときだけ実行し、必ず元に戻す）
TestSearchBox(hwnd) {
    global C, APP_NAME
    cn := IniGet(IniLoad(A_ScriptDir "\config.ini"), "Select", "SearchBoxClassNN", "")
    if (cn = "") {
        MsgBox("検索欄の候補が記録されていないためテストできません。", APP_NAME, "Icon! 4096")
        return
    }
    word := ""
    ib := InputBox("検索欄に入れて試す文字を入力してください。`n（対象者の姓など。あとで自動的に消します）"
                 , APP_NAME " - 入力テスト", "w480 h160")
    if (ib.Result != "OK" || Trim(ib.Value) = "")
        return
    word := Trim(ib.Value)

    before := SnapText(hwnd)
    ok := false
    try {
        ControlSetText(word, cn, "ahk_id " hwnd)
        ControlFocus(cn, "ahk_id " hwnd)
        ok := true
    }
    if (!ok) {
        MsgBox("検索欄に入力できませんでした（権限不足か、コントロールではない可能性）。", APP_NAME, "Icon! 4096")
        return
    }
    Sleep(1500)
    after := SnapText(hwnd)
    changed := (before != after)

    ; 必ず元に戻す
    try ControlSetText("", cn, "ahk_id " hwnd)
    Sleep(400)

    if (changed) {
        res := "[OK] 入力したら画面の表示が変わりました → 検索欄として使えます"
    } else {
        res := "[??] 入力しても表示が変わりませんでした（Enter が必要／別の欄かもしれません）"
    }
    MsgBox("入力テストの結果`n`n  検索欄: " cn "`n  入力した文字: " word "`n`n  " res "`n`n"
        . "入力は消しました。", APP_NAME, "Iconi 4096")
    try FileAppend(CRLF("`n[検索欄テスト] " cn " に「" word "」を入力 → " res "`n")
                 , A_ScriptDir "\listread.txt", "UTF-8")

    SnapText(h) {
        s := ""
        rows := DumpCtrls(h)
        for r in rows
            s .= r["cnn"] "=" r["text"] "|"
        return s
    }
}

;==============================================================================
;  /pickrow  患者一覧の「先頭行」の位置を実測して記録する
;  ★推測で座標を置かない。v4 の /pickpos と同じ考え方★
;==============================================================================
ModePickRow() {
    global CFG, APP_NAME, G
    pid := EnsureTarget()
    h := 0
    for w in TargetWindows(pid) {
        if (ClassifyScreen(w["hwnd"])["id"] = "S1_Index") {
            h := w["hwnd"]
            break
        }
    }
    if (!h) {
        MsgBox("患者一覧が開いていません。`n`n"
            . "メタアナライザーで「カードを選択します」を押して"
            . "一覧を表示してから、もう一度実行してください。", APP_NAME, "Icon! 4096")
        ; ★案内の途中なら閉じない★ 準備ができたら続けられるように戻す
        if (G.backTo = "wizard") {
            ModeWizard()
            return
        }
        ExitApp(1)
    }
    grid := CS("ListClassNN")
    gr := CtrlRect(h, grid)
    gx := gr["x"], gy := gr["y"], gw := gr["w"], gh := gr["h"]

    dlg := Gui("+AlwaysOnTop", APP_NAME " - 先頭行の位置を教える" VerTag())
    dlg.MarginX := 16, dlg.MarginY := 12
    dlg.SetFont("s11 Bold", "Meiryo UI")
    step := 1, y1 := 0
    ; ★見出しは書き換えられるようにしておく★
    ;   2026-09-22、2 行目を待っているのに見出しが「1 行目」のままで、
    ;   同じ行をもう一度教えてしまう人がいた（他社の PC で発生）。
    lblHead := dlg.Add("Text", "w640", "一覧の【1 行目】の上にマウスを置いて、F1 を押してください")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w640 cGray"
        , "  検索で絞り込んだあと、いちばん上に出る行の位置を記録します。`n"
        . "  クリックはしません。マウスを乗せるだけです。`n"
        . "  ★1 行目のあと、続けて【2 行目】も教えてください（行の間隔を測ります）。`n"
        . "  　2 行目が無いときは Esc でやめれば、1 行目だけ記録されます。")
    dlg.SetFont("s10", "Consolas")
    lbl := dlg.Add("Text", "w640 h90", "")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w640 cGray", "やめるときは Esc。")
    dlg.Show()

    Hotkey("F1", Pick)
    Hotkey("Esc", (*) => QuitRow())
    SetTimer(Watch, 100)
    Watch()
    return

    ; ★やめ方★ 1 行目だけ記録済みなら、設定画面へ戻る（落とさない）
    QuitRow() {
        SetTimer(Watch, 0)
        try Hotkey("F1", "Off")
        try Hotkey("Esc", "Off")
        try dlg.Destroy()
        if (step = 2) {
            MsgBox("1 行目だけ記録しました。`n`n"
                . "★行の間隔は記録していません★`n"
                . "このままだと、狙いのカードが 2 行目以降にあるとき"
                . "「別のカードが開いています」で中止します。`n`n"
                . "比較用カード（ミドルネーム違い）をお使いなら、"
                . "もう一度この画面を開いて 2 行目まで教えてください。"
                , APP_NAME, "Icon! 4096")
            ModeMore()
            return
        }
        ExitApp(0)
    }

    Watch() {
        if (!WinExist("ahk_id " dlg.Hwnd)) {   ; 閉じたあとは書き換えない
            SetTimer(Watch, 0)
            return
        }
        MouseGetPos(&mx, &my)
        WinGetPos(&wx, &wy, , , "ahk_id " h)
        rx := mx - wx, ry := my - wy
        inGrid := (gw > 0 && rx >= gx && ry >= gy && rx <= gx + gw && ry <= gy + gh)
        lbl.Value := Format("ウィンドウ内 : x{1}  y{2}`n"
                          . "グリッド     : {3} (x{4} y{5} w{6} h{7})`n"
                          . "グリッド内   : x{8}  y{9}`n"
                          . "判定         : {10}"
            , rx, ry, grid = "" ? "（未設定）" : grid, gx, gy, gw, gh
            , rx - gx, ry - gy, inGrid ? "★グリッドの中です★" : "グリッドの外です")
    }

    Pick(*) {
        MouseGetPos(&mx, &my)
        WinGetPos(&wx, &wy, , , "ahk_id " h)
        rx := mx - wx, ry := my - wy
        if (gw > 0 && (rx < gx || ry < gy || rx > gx + gw || ry > gy + gh)) {
            MsgBox(Format("いま指している場所はグリッドの外です。`n"
                . "一覧の {1} 行目の上に合わせてから F1 を押してください。", step)
                , APP_NAME, "Icon! 4096")
            return
        }
        if (step = 1) {
            ; ★モデルごとの節に書く★ 18D は [Select]、別モデルは [Select.<モデル>]
            ;   2026-09-22、読む側だけモデル対応していて、書く側が共通だった。
            ;   モデルを戻したときに、前の実測値が生きているようにする。
            IniSet(CFG, ModelSec("Select"), "ListFirstRowX", rx)
            IniSet(CFG, ModelSec("Select"), "ListFirstRowY", ry)
            y1 := ry, step := 2
            dlg.Title := APP_NAME . " - 2 行目の位置を教える" . VerTag()
            lblHead.Value := "★いま【2 行目】を待っています★　"
                . "2 行目の上にマウスを置いて、F1 を押してください"
            MsgBox(Format("1 行目を記録しました（x{1} y{2}）。`n`n"
                . "続けて【2 行目】の上にマウスを置いて F1 を押してください。`n"
                . "行の間隔が分かると、狙いのカードが 2 行目以降にあるときも選べます。`n`n"
                . "2 行目が無いときは Esc でやめてください（1 行目だけ記録されます）。"
                , rx, ry), APP_NAME, "Iconi 4096")
            return
        }
        ; ★2 行目★ 差が行の間隔になる
        pitch := ry - y1
        if (pitch <= 0) {
            MsgBox("2 行目は 1 行目より下を指してください。", APP_NAME, "Icon! 4096")
            return
        }
        IniSet(CFG, ModelSec("Select"), "ListRowPitchY", pitch)
        ; ★見張りとキーを外してから閉じる★
        ;   外さないと、消えた文字欄を書き換えようとして落ちる（2026-09-22）。
        SetTimer(Watch, 0)
        try Hotkey("F1", "Off")
        try Hotkey("Esc", "Off")
        MsgBox(Format("記録しました。`n`n  ListFirstRowY = {1}`n  ListRowPitchY = {2}`n`n"
            . "1 行目を開いて氏名が違えば、{2}px ずつ下の行を試します。"
            , y1, pitch), APP_NAME, "Iconi 4096")
        ; ★保存したら閉じずに設定画面へ戻る★
        ;   続けて別の設定をしたいのに、毎回ソフトが消えていた（2026-09-22 指摘）。
        try dlg.Destroy()
        BackToSettings()
        return
    }
}

;==============================================================================
;  /inspect  いま開いている対象ソフトの全画面・全コントロールを列挙
;==============================================================================
ModeInspect() {
    global C, APP_NAME
    pid := EnsureTarget()
    out := "=== AutoMeta /inspect  画面とコントロールの一覧 ===`n"
    out .= FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss") "`n"
    out .= "対象: " CS("ExeName") " (pid " pid ")  権限: " (A_IsAdmin ? "管理者" : "通常ユーザー") "`n`n"
    wins := TargetWindows(pid)
    for w in wins {
        rows := DumpCtrls(w["hwnd"])
        cls  := ClassifyScreen(w["hwnd"], rows)
        out .= "── ウィンドウ: 「" w["title"] "」`n"
        out .= "     ahk_class : " w["class"] "`n"
        out .= "     判定      : " . cls["id"] . (cls["hit"] = "" ? "" : "（『" . cls["hit"] . "』を検出）") . "`n"
        out .= "     hwnd      : " w["hwnd"] "`n"
        out .= CtrlsToText(rows)
        out .= "`n"
    }
    if (wins.Length = 0)
        out .= "（可視ウィンドウがありません）`n"
    path := A_ScriptDir "\inspect.txt"
    try FileDelete(path)
    FileAppend(CRLF(out), path, "UTF-8")
    MsgBox("ウィンドウ " wins.Length " 件を inspect.txt に出力しました。", APP_NAME, "Iconi 4096")
    OpenFile(path)
    ExitApp(0)
}

;==============================================================================
;  /watchall  対象プロセスの変化を監視する（AutoTherapy v4 と同じ道具）
;==============================================================================
ModeWatchAll() {
    global APP_NAME
    pid := EnsureTarget()
    buf := "=== AutoMeta /watchall  変化の監視 " FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss") " ===`r`n`r`n"
    prev := ""

    dlg := Gui("+AlwaysOnTop", APP_NAME " - 変化の監視" VerTag())
    dlg.MarginX := 14, dlg.MarginY := 10
    dlg.SetFont("s10", "Meiryo UI")
    dlg.Add("Text", "w900", "対象プロセスのウィンドウを 1 秒ごとに調べ、変化したときだけ記録します。")
    dlg.Add("Text", "w900 cGray", "終わったら × で閉じると watchall.txt に保存されます。")
    dlg.SetFont("s9", "Consolas")
    ed := dlg.Add("Edit", "w900 h420 ReadOnly -Wrap +VScroll")
    dlg.OnEvent("Close", (*) => Done())
    dlg.Show()
    SetTimer(WatchTick, 1000)
    WatchTick()
    return

    WatchTick() {
        snap := ""
        for w in TargetWindows(pid)
            snap .= "  「" w["title"] "」 [" w["class"] "]`r`n"
        if (snap != prev) {
            buf .= FormatTime(A_Now, "HH:mm:ss") "  ★変化★`r`n" snap "`r`n"
            prev := snap
            ed.Value := buf
            try SendMessage(0x0115, 7, 0, ed)
            Save()
        }
    }
    Save() {
        path := A_ScriptDir "\watchall.txt"
        try FileDelete(path)
        try FileAppend(CRLF(buf), path, "UTF-8")
    }
    Done(*) {
        SetTimer(WatchTick, 0)
        Save()
        OpenFile(A_ScriptDir "\watchall.txt")
        ExitApp(0)
    }
}

;==============================================================================
;  /doctor  自己診断
;==============================================================================
ModeDoctor() {
    global C, CFG, SCRINI, APP_NAME, APP_VER, APP_BUILD
    out := "=== AutoMeta 自己診断 ===`n"
    out .= FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss") "`n`n"
    out .= "バージョン   : " APP_VER "  (build " APP_BUILD ")`n"
    out .= "AHK          : " A_AhkVersion "  " (A_Is64bitOS ? "(64bit OS)" : "") "`n"
    out .= "権限         : " (A_IsAdmin ? "管理者" : "通常ユーザー") "`n"
    out .= "フォルダ     : " A_ScriptDir "`n`n"

    exe := CS("ExeName")
    out .= "対象ソフト   : " (exe = "" ? "（未設定 → 1_SETUP.bat を実行）" : exe) "`n"
    if (exe != "") {
        pid := FindPidByExe(exe)
        out .= "起動状態     : " (pid ? "起動中 (pid " pid ")" : "★見つかりません★") "`n"
        if (pid) {
            out .= "`n見えている画面:`n"
            for w in TargetWindows(pid) {
                cls := ClassifyScreen(w["hwnd"])
                out .= Format("  {1:-16} class={2:-22} title=「{3}」`n", cls["id"], w["class"], w["title"])
            }
        }
    }
    out .= "`n--- config.ini ---`n" SafeRead(CFG)
    out .= "`n--- screens.ini ---`n" SafeRead(SCRINI)
    out .= "`n--- 生成済みファイル ---`n"
    for f in ["trace.txt", "listread.txt", "inspect.txt", "watchall.txt"] {
        p := A_ScriptDir "\" f
        when := "（未作成）"
        if FileExist(p)
            when := FormatTime(FileGetTime(p, "M"), "yyyy-MM-dd HH:mm") . " に更新"
        out .= Format("  {1:-16} {2}`n", f, when)
    }
    path := A_ScriptDir "\doctor.txt"
    try FileDelete(path)
    FileAppend(CRLF(out), path, "UTF-8")
    MsgBox("doctor.txt に出力しました。`n中身をそのまま Claude に貼れば原因を切り分けられます。", APP_NAME, "Iconi 4096")
    OpenFile(path)
    ExitApp(0)
}

SafeRead(p) {
    if !FileExist(p)
        return "（ありません）`n"
    try return FileRead(p, "UTF-8") "`n"
    return "（読めません）`n"
}

;==============================================================================
;  /code  利用者コードを入れる（オンラインの利用確認）
;==============================================================================
;   ★画面を出すのはここだけ★ 以降は起動時に黙って確認する。
;   無人で夜間に動くツールなので、毎回ログインを求める形にはしない。
;==============================================================================
;  ショートカット（デスクトップ ／ スタートメニュー）
;==============================================================================
; ★タスクバーへのピン留めは、Windows 10 以降プログラムから行えない★
;   仕様で塞がれているので、最後の 1 手順（右クリック）だけ利用者に案内する。
;   自動セラピー（AutoTherapy）と同じ作法に合わせた。
CreateDesktopShortcut(&msg) {
    global APP_NAME
    icon := FileExist(A_ScriptDir . "\AutoMeta.ico") ? A_ScriptDir . "\AutoMeta.ico" : A_AhkPath
    made := [], failed := []
    for target in [A_Desktop . "\AutoMeta.lnk", A_Programs . "\AutoMeta.lnk"] {
        try {
            FileCreateShortcut(A_AhkPath, target, A_ScriptDir
                , Chr(34) . A_ScriptFullPath . Chr(34) . " /menu"
                , "AutoMeta メタアナライザー自動操作", icon, , 1)
            made.Push(target)
        } catch as e {
            failed.Push(target . " : " . e.Message)
        }
    }
    if (made.Length = 0) {
        msg := "ショートカットを作れませんでした。`n" . (failed.Length ? failed[1] : "")
        return false
    }
    msg := "ショートカットを作りました。`n`n"
         . "　・デスクトップ`n"
         . "　・スタートメニュー（スタートボタンから「AutoMeta」で検索できます）`n`n"
         . "―――――――――――――――――――――――`n"
         . "【タスクバーに入れたい場合】`n"
         . "Windows の仕様でプログラムからは登録できないため、`n"
         . "お手数ですが次の操作をお願いします（1 回だけ）。`n`n"
         . "　1. デスクトップの「AutoMeta」を右クリック`n"
         . "　2. 「タスクバーにピン留めする」を選ぶ`n"
         . "　　（Windows 11 では「その他のオプションを表示」の中にあります）"
    if (failed.Length > 0)
        msg .= "`n`n※ 一部作れませんでした: " . failed[1]
    return true
}

; 「設定」から押されたとき（画面は閉じない）
ShortcutNow() {
    global APP_NAME
    msg := ""
    ok := CreateDesktopShortcut(&msg)
    Log(ok ? "INFO" : "WARN", "ショートカット作成: " . (ok ? "成功" : "失敗"))
    MsgBox(msg, APP_NAME, ok ? "Iconi 4096" : "Icon! 4096")
}

;==============================================================================
;  /model  対象ソフトのモデルを選ぶ
;==============================================================================
;   選択中の項目の色がモデルで違うため、どちらかを記録しておく。
;==============================================================================
;  /schemename  スキームの名前を変える
;==============================================================================
;   ソフト側で利用者がスキームに名前を付けられるため、こちらも合わせられるようにする。
;   ★モデルごとに保存する★ 18D と別モデルで名前が違ってよい。
;   ★予定の記載も追従させる★ 名前だけ変えると、予定が指す先を見失う。
ModeSchemeNames() {
    global CFG, SCHEDINI, APP_NAME
    m   := IniLoad(CFG)
    sec := ModelSecRead(m, "Manual")
    dlg := Gui("+AlwaysOnTop", APP_NAME . " - スキームの名前" . VerTag())
    dlg.MarginX := 16, dlg.MarginY := 12
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "w560", "マニュアル選択の名前を、お使いのソフトに合わせます")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w560 h46 cGray"
        , "ソフト側で付けた名前に合わせておくと、予定を組むときに迷いません。`n"
        . "押す位置は変わりません。名前だけを付け替えます。`n"
        . "保存先: [" . sec . "]（いまのモデル）")
    dlg.SetFont("s10", "Meiryo UI")
    olds := [], eds := []
    Loop 5 {
        cur := Trim(IniGet(m, sec, "Name" A_Index, "スキーム " A_Index))
        olds.Push(cur)
        dlg.Add("Text", "xm w110 h30 +0x200", A_Index . " 番目")
        eds.Push(dlg.Add("Edit", "x+8 yp w440", cur))
    }
    bOk := dlg.Add("Button", "xm w270 h38 Default", "保存する")
    bNo := dlg.Add("Button", "x+20 yp w270 h38", "やめる")
    bNo.OnEvent("Click", (*) => ExitApp(0))
    dlg.OnEvent("Close", (*) => ExitApp(0))
    bOk.OnEvent("Click", (*) => Save())
    dlg.Show()
    return

    Save() {
        changed := 0, fixed := 0
        Loop 5 {
            nw := Trim(eds[A_Index].Value)
            od := olds[A_Index]
            if (nw = "" || nw = od)
                continue
            IniSet(CFG, sec, "Name" A_Index, nw)
            changed++
            ; 予定が古い名前を指していたら、新しい名前に直す
            sm := IniLoad(SCHEDINI)
            for key, vals in sm {
                if (SubStr(key, 1, 8) != "Patient.")
                    continue
                if (Trim(IniGet(sm, key, "ManualSelect", "")) = od) {
                    IniSet(SCHEDINI, key, "ManualSelect", nw)
                    fixed++
                }
            }
            Log("INFO", Format("スキーム名を変更: 「{1}」→「{2}」（予定 {3} 件を追従）", od, nw, fixed))
        }
        msg := "変更はありませんでした。"
        if (changed > 0)
            msg := Format("{1} 件の名前を変えました。`n予定側も {2} 件を合わせています。", changed, fixed)
        MsgBox(msg, APP_NAME, "Iconi 4096")
        try dlg.Destroy()
        BackToSettings()
        return
    }
}

ModeModel() {
    global CFG, C, APP_NAME
    now := Trim(CS("ModelName"))
    dlg := Gui("+AlwaysOnTop", APP_NAME . " - モデルの選択" . VerTag())
    dlg.MarginX := 16, dlg.MarginY := 12
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "w560", "お使いのソフトのモデルを選んでください")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w560 h52 cGray"
        , "マニュアル選択などで「選ばれているか」を色で見分けています。`n"
        . "モデルによって選択中の色が違うため、ここで切り替えます。`n"
        . "うまく判定されないときは、もう一方を試してください。")
    dlg.SetFont("s11", "Meiryo UI")
    r1 := dlg.Add("Radio", "xm w560 h30" . (now = "MetaAnalyzer" ? "" : " Checked")
        , "18D-NLS（選択中は淡い青）")
    r2 := dlg.Add("Radio", "xm w560 h30" . (now = "MetaAnalyzer" ? " Checked" : "")
        , "Meta Analyzer（選択中は淡いクリーム）")
    dlg.SetFont("s10", "Meiryo UI")
    bOk := dlg.Add("Button", "xm w270 h38 Default", "保存する")
    bNo := dlg.Add("Button", "x+20 yp w270 h38", "やめる")
    bNo.OnEvent("Click", (*) => ExitApp(0))
    dlg.OnEvent("Close", (*) => ExitApp(0))
    bOk.OnEvent("Click", (*) => Save())
    dlg.Show()
    return

    Save() {
        name := r2.Value ? "MetaAnalyzer" : "18D"
        C["ModelName"] := name
        IniSet(CFG, "Model", "ModelName", name)
        Log("INFO", "モデルを記録しました: " . name)
        MsgBox("モデルを「" . name . "」にしました。", APP_NAME, "Iconi 4096")
        dlg.Destroy()
        ModeMore()
    }
}

ModeCode() {
    global C, CFG, APP_NAME
    dlg := Gui("+AlwaysOnTop", APP_NAME . " - 利用者コード" . VerTag())
    dlg.MarginX := 16, dlg.MarginY := 12
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "w620", "お渡しした利用者コードを入れてください")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w620 h58 cGray"
        , "一度入れれば、あとは自動で確認します。ふだんは何も表示されません。`n"
        . "インターネットにつながらない日が続いても、14 日間はそのまま動きます。`n"
        . "コードが分からないときは、お渡しした案内をご確認ください。")
    dlg.SetFont("s12", "Consolas")
    edt := dlg.Add("Edit", "xm w620", Trim(CS("UserCode")))
    dlg.SetFont("s10 Bold", "Meiryo UI")
    lbl := dlg.Add("Text", "xm w620 h50 cNavy", "")
    dlg.SetFont("s10", "Meiryo UI")
    bOk  := dlg.Add("Button", "xm w300 h38 Default", "確認して保存")
    bDel := dlg.Add("Button", "x+20 yp w140 h38", "登録を解除")
    bNo  := dlg.Add("Button", "x+20 yp w140 h38", "閉じる")
    bOk.OnEvent("Click", (*) => Check())
    bDel.OnEvent("Click", (*) => Clear())
    bNo.OnEvent("Click", (*) => ExitApp(0))
    dlg.OnEvent("Close", (*) => ExitApp(0))
    dlg.Show()
    return

    Check() {
        global C, CFG, APP_NAME
        code := Trim(edt.Value)
        if (code = "") {
            lbl.Value := "コードが空です"
            return
        }
        lbl.Value := "確認しています…"
        why := ""
        C["UserCode"] := code
        if (PassRenew(code, &why)) {
            IniSet(CFG, "License", "UserCode", code)
            p   := PassCheck()
            lic := p["ok"] ? p["lic"] : Map("name", "", "why", "")
            MsgBox("確認できました。`n`n"
                . "　利用者: " . lic["name"] . "`n"
                . "　" . lic["why"] . "`n`n"
                . "これ以降は自動で確認します。画面は出ません。`n`n"
                . "【お願い】2 週間に 1 度は、インターネットにつないだ状態で`n"
                . "このソフトを開いてください。それだけで確認が済みます。"
                , APP_NAME, "Iconi 4096")
            ; ★ここで終わらせない★ 登録のあとは、そのまま使い始められるように
            ;   メニューへ進む（2026-09-19 指摘）。
            dlg.Destroy()
            ModeMenu()
            return
        }
        lbl.Value := "確認できませんでした: " . why
    }

    ; ★入れたものは外せるようにする★
    ;   コードを入れると config.ini に残り、画面からは消せなかった。
    ;   試すたびに手で設定を触ることになる（2026-09-19 指摘）。
    Clear() {
        global C, CFG, PASSFILE, APP_NAME
        C["UserCode"] := ""
        IniSet(CFG, "License", "UserCode", "")
        try FileDelete(PASSFILE)
        Log("INFO", "利用者コードの登録を解除しました")
        MsgBox("登録を解除しました。`n`n"
            . "このままでは調査・セラピーは実行できません。`n"
            . "もう一度使うときは、同じ画面でコードを入れ直してください。"
            , APP_NAME, "Iconi 4096")
        dlg.Destroy()
        ModeMenu()
        return
    }
}

;==============================================================================
;  /menu  調査メニュー
;==============================================================================
ModeMenu() {
    global APP_NAME, APP_VER, C
    ; ★二重に開かれたら、先に開いている方を使ってもらう★
    if (h := MenuWindowHwnd()) {
        try WinActivate("ahk_id " h)
        ExitApp(0)
    }
    exe := CS("ExeName")
    ; ★メニュー窓だけの目印を付ける★
    ;   運転パネルも「AutoMeta v2.5.2」と同じ形のタイトルで、
    ;   タイトルだけでは見分けがつかなかった（2026-09-18）。
    dlg := Gui("+AlwaysOnTop", APP_NAME " - メニュー" VerTag())
    dlg.MarginX := 20, dlg.MarginY := 16
    dlg.SetFont("s12 Bold", "Meiryo UI")
    dlg.Add("Text", "w560", "AutoMeta")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w560 cGray", "メタアナライザー自動操作   " APP_VER)
    dlg.SetFont("s10", "Meiryo UI")
    dlg.Add("Text", "w560 " (exe = "" ? "cRed" : "cGreen")
        , (exe = "" ? "★対象ソフトが未設定です" : "対象ソフト: " exe))

    ; ★設定が足りないことを、メニューの一番上で知らせる★
    ;   2026-09-22、新しい PC で「何をすればよいか」が分からなかった。
    ;   設定の奥に入らないと気づけないのでは遅い。
    wizLeft := 0, wizNext := ""
    for st in SetupSteps() {
        if (st["d"] || !st["must"])
            continue
        wizLeft++
        if (wizNext = "")
            wizNext := st["t"]
    }
    if (wizLeft > 0) {
        dlg.SetFont("s11 Bold", "Meiryo UI")
        dlg.Add("Text", "w560 cRed"
            , Format("★この PC は、まだ設定が {1} 件のこっています★", wizLeft))
        dlg.SetFont("s9", "Meiryo UI")
        dlg.Add("Text", "w560 cGray", "　つぎ: " wizNext "　／　終わるまで運転できません")
        dlg.SetFont("s11 Bold", "Meiryo UI")
        bWiz := dlg.Add("Button", "w560 h44", "🔧　はじめての設定をする（順番に案内します）")
        bWiz.OnEvent("Click", (*) => Go("wizard"))
        dlg.SetFont("s10", "Meiryo UI")
    }

    dlg.Add("Text", "w560 h1 0x10")

    dlg.SetFont("s13 Bold", "Meiryo UI")
    bSch := dlg.Add("Button", "w560 h62 Default", "⏰　スケジュール")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w560 cGray"
        , "　予定を決めて、その予定どおりに自動で回します。ふだんの運用はこちら。")

    dlg.SetFont("s13 Bold", "Meiryo UI")
    bOne := dlg.Add("Button", "w560 h62", "👤　1 人だけ、いますぐ実行する")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w560 cGray"
        , "　検索して対象者を選び、調査 ＋ セラピーを 1 回だけ回します（予定には入れません）。")

    dlg.SetFont("s13 Bold", "Meiryo UI")
    bThe := dlg.Add("Button", "w560 h62", "▶　自動セラピー")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w560 cGray"
        , "　いま開いているカードに、セラピーだけをくりかえします（調査は行いません）。")

    dlg.Add("Text", "w560 h1 0x10")
    dlg.SetFont("s10", "Meiryo UI")
    bMore := dlg.Add("Button", "w270 h38", "⚙  設定")
    bEnd  := dlg.Add("Button", "x+20 yp w270 h38", "閉じる")

    bSch.OnEvent("Click",  (*) => Go("schededit"))
    bOne.OnEvent("Click",  (*) => Go("run"))
    bThe.OnEvent("Click",  (*) => Go("therapy"))
    bMore.OnEvent("Click", (*) => Go("more"))
    bEnd.OnEvent("Click",  (*) => ExitApp(0))
    dlg.OnEvent("Close",   (*) => ExitApp(0))
    dlg.Show()
    return

    Go(mode) {
        global G, APP_NAME
        dlg.Destroy()
        G.mode := mode
        ; ★メニューから始めた実行は、終わってもソフトを閉じない★
        ;   2026-09-22、1 人だけ実行が終わるとソフトごと消えていた。
        G.fromMenu := true
        switch mode {
            case "run":       ModeRun()
            case "wizard":    ModeWizard()
            case "schedule":  ModeSchedule()
            case "schededit": ModeScheduleEditor()
            case "therapy":   ModeTherapy()
            case "more":      ModeMore()
            case "code":      ModeCode()
            case "setup":     ModeSetup()
            case "trace":     ModeTrace()
            case "listread":  ModeListRead()
            case "pickrow":   ModePickRow()
            case "inspect":   ModeInspect()
            case "watchall":  ModeWatchAll()
            case "doctor":    ModeDoctor()
            default:
                ; ★ここに落ちると、窓が 1 つも無くなって黙って終了してしまう★
                ;   2026-09-15 に「設定」「自動セラピー」で画面が消えたのがこれ。
                MsgBox("行き先「" mode "」が実装されていません。`n"
                    . "メニューに戻ります。", APP_NAME, "Iconx 4096")
                Log("ERROR", "未実装の行き先: " mode)
                ModeMenu()
        }
    }
}

;==============================================================================
;  調査タイプ／マニュアル選択の位置を教える
;==============================================================================
;  スキーム画面の「調査タイプ」「マニュアル選択」は【描画されたボタン】で、
;  開くポップアップ（TPanel3 / TPanel1）の中の項目も描画。
;  文字がひとつも読めないので、座標で押すしかない（2026-09-15 のトレースで判明）。
;
;  ★クリックさせない★
;    項目をクリックするとポップアップが閉じ、ソフトが 14 秒ほど作り直しを始める。
;    マウスを乗せて F1 を押すだけにすれば、開いたまま全項目を記録できる。
;==============================================================================

; 調査タイプ／マニュアル選択の記録は、config.ini の [ScanType] / [Manual] にある。
;   C（設定の一覧）は DEFAULTS のキーしか持たず、しかも節をまたぐと名前がぶつかるので、
;   ここだけは節を指定して読む。
; 指定した位置にいちばん近い TImageButton を探す。
;   描画ボタンの位置を「絶対座標」で覚えると、ウィンドウの大きさが変わった瞬間に
;   全部ずれる（2026-09-15 に実際に起きた）。近くの本物のボタンからの差で覚える。
; コントロールの位置を安全に取る。
;   ★ControlGetPos は失敗すると、出力の変数を「未代入」に戻す★
;     あらかじめ px := 0 と入れておいても消えるので、IsSet で確かめる必要がある。
;     （2026-09-15、マウスを AutoMeta の窓に移した瞬間に落ちた）
CtrlRect(hwnd, cnn) {
    ng := Map("ok", false, "x", 0, "y", 0, "w", 0, "h", 0)
    if (cnn = "" || !hwnd)
        return ng
    x := "", y := "", w := "", h := ""
    try ControlGetPos(&x, &y, &w, &h, cnn, "ahk_id " hwnd)
    if (!IsSet(x) || !IsSet(y) || !IsSet(w) || !IsSet(h))
        return ng
    if (x = "" || y = "" || w = "" || h = "")
        return ng
    return Map("ok", true, "x", x, "y", y, "w", w, "h", h)
}

NearestButton(hwnd, rx, ry) {
    best := Map("cnn", "", "dx", 0, "dy", 0, "dist", 999999)
    list := []
    try list := WinGetControls("ahk_id " hwnd)
    for cnn in list {
        if (SubStr(cnn, 1, 12) != "TImageButton")
            continue
        r := CtrlRect(hwnd, cnn)
        if (!r["ok"] || r["w"] <= 0)
            continue
        mx := r["x"] + r["w"] // 2, my := r["y"] + r["h"] // 2
        d := Sqrt((rx - mx) ** 2 + (ry - my) ** 2)
        if (d < best["dist"])
            best := Map("cnn", cnn, "dx", rx - r["x"], "dy", ry - r["y"], "dist", Round(d))
    }
    return best
}

; スキーム画面の「調査タイプ」「マニュアル選択」は描画ボタンで、位置を直接は読めない。
;   実測（2026-09-16 /inspect）: ボタンは 44px おきの行で並んでいる。
;     右列  カードインデックス y23 ／ 調査 y110 ／ 現在の分析 y154 ／【マニュアル選択 y198】
;     左列  インタラクティブ既往症 y110 ／ アイコン y154 ／【調査タイプ y198】
;     一覧  TPanel3 x706 y265（左列の下）／ TPanel1 x1080 y240（右列の下）
;   ★本物のコントロールから毎回計算する★
;     座標を覚えないので、窓の大きさが変わっても、記録がずれていても狂わない。
;     （2026-09-16、覚えた座標が空白を指していて 3 件連続で失敗した）
SchemeDrawnButton(hwnd, grp) {
    ng   := Map("ok", false, "x", 0, "y", 0)
    left := FindCtrlByText(hwnd, CS("AnchorLeftText"))     ; インタラクティブ既往症
    top  := FindCtrlByText(hwnd, CS("AnchorRightText"))    ; 調査
    mid  := FindCtrlByText(hwnd, CS("SchemeRowRefText"))   ; 現在の分析
    if (!left.Has("x") || !top.Has("x") || !mid.Has("x"))
        return ng
    gap := mid["y"] - top["y"]                             ; 行の間隔（実測 44）
    if (gap <= 0 || gap > 200)
        gap := 44
    row3 := mid["y"] + gap                                 ; 3 行目の上端
    if (grp = "ScanType")
        return Map("ok", true, "x", left["x"] + left["w"] // 2, "y", row3 + left["h"] // 2)
    return Map("ok", true, "x", mid["x"] + mid["w"] // 2, "y", row3 + mid["h"] // 2)
}

; 選択されている（青い）かどうかを色で見分ける。
;   実測（2026-09-16 の録画より）
;     通常     #DBDBDB  青み B-R =  0
;     カーソル #DDEFF9  青み B-R = +28
;     選択中   #C0DDF6  青み B-R = +54
; ★モデルごとの「選択中の色」★
;   18D-NLS は淡い青、Meta Analyzer は淡いクリーム。
;   「青みが +20 以上なら選択中」という以前の決め方では、クリームを拾えない
;   （黄みは青みがマイナスになる）。2026-09-21 に別モデルの録画で判明。
; 実行ファイル名からモデルを見分ける（初期設定で自動記録する）
;   18D-NLS.exe        → 18D
;   META ANALYZER.exe  → MetaAnalyzer
GuessModel(exe) {
    e := StrUpper(Trim(exe))
    if (InStr(e, "META") && InStr(e, "ANALYZER"))
        return "MetaAnalyzer"
    if (InStr(e, "18D"))
        return "18D"
    return ""                                       ; 分からなければ変えない
}

ModelProfile() {
    static P := Map(
        "18D",          Map("sel", 0xC0DDF6, "normal", 0xDBDBDB),
        "MetaAnalyzer", Map("sel", 0xEEEFE4, "normal", 0xD1D1D1))
    n := Trim(CS("ModelName"))
    base := P.Has(n) ? P[n] : P["18D"]
    ; 設定で上書きされていればそちらを優先する（現場で微調整できるように）
    sel := Trim(CS("SelectedColor")), nor := Trim(CS("NormalColor"))
    return Map("sel",    (sel != "") ? Integer("0x" . StrReplace(sel, "#", "")) : base["sel"]
             , "normal", (nor != "") ? Integer("0x" . StrReplace(nor, "#", "")) : base["normal"])
}

; 2 つの色の隔たり（大きいほど違う色）
ColorDist(a, b) {
    dr := Abs(((a >> 16) & 0xFF) - ((b >> 16) & 0xFF))
    dg := Abs(((a >> 8)  & 0xFF) - ((b >> 8)  & 0xFF))
    db := Abs((a & 0xFF) - (b & 0xFF))
    return dr + dg + db
}

; 選択中の色に近いか（モデルの既定色と見比べる）
IsHighlighted(col) {
    if (col < 0)
        return false
    p := ModelProfile()
    return (ColorDist(col, p["sel"]) < ColorDist(col, p["normal"]))
}

; 項目の行を横に走査して、青い点が何点あるかを数える。
;   ★1 点だけ読むと文字の上に乗る★
;   2026-09-17、自動選択が青く光っているのに #4C555C（B-R+16）と読み、
;   「選ばれていない」と判定して外せなかった。読んでいたのは文字の色だった。
;   行の背景は文字の左右にも広がっているので、横に並べて読めば必ず当たる。
;   一覧の外は読まない（外は別の色で、いくらでも青がありうる）。
ItemHighlight(hwnd, cnn, dx, dy) {
    ng := Map("ok", false, "hit", 0, "max", 0, "col", -1)
    r := CtrlRect(hwnd, cnn)
    if (!r["ok"] || r["w"] <= 0 || r["h"] <= 0)
        return ng
    cx := "", cy := ""
    try WinGetClientPos(&cx, &cy, , , "ahk_id " hwnd)
    if (!IsSet(cx) || !IsSet(cy) || cx = "" || cy = "")
        return ng
    hit := 0, best := 0, bestCol := -1, read := 0
    for oy in [-5, 0, 5] {
        py := dy + oy
        if (py < 2 || py > r["h"] - 3)
            continue
        ox := -75
        while (ox <= 150) {
            px := dx + ox
            ox += 15
            if (px < 2 || px > r["w"] - 3)
                continue
            col := -1
            try col := PixelGetColor(cx + r["x"] + px, cy + r["y"] + py)
            if (col < 0)
                continue
            read++
            blue := (col & 0xFF) - ((col >> 16) & 0xFF)
            if (bestCol < 0 || blue > best) {
                best := blue
                bestCol := col
            }
            if (IsHighlighted(col))
                hit++
        }
    }
    if (read = 0)
        return ng
    return Map("ok", true, "hit", hit, "max", best, "col", bestCol)
}

; ★カーソルを当てても色が変わらない＝すでに選ばれている★
;   Meta Analyzer では、選択済みのボタンだけカーソルに反応しない（2026-09-21 指摘）。
;   色の値そのものはモデルや環境で変わるが、「反応するかどうか」は変わらない。
;   戻り値: true = 変わらなかった（選択済み）
ItemUnchangedOnHover(hwnd, panel, dx, dy) {
    return ItemHoverProbe(hwnd, panel, dx, dy)["un"]
}

; ★実測した色をそのまま返す★
;   2026-09-22、別モデルで「外したのに選択済みのまま」と読み違えた。
;   反応あり／なしだけでは原因が追えないので、色と差をログに残せるようにする。
ItemHoverProbe(hwnd, panel, dx, dy) {
    ng := Map("ok", false, "un", false, "c1", -1, "c2", -1, "d", -1)
    r := CtrlRect(hwnd, panel)
    if (!r["ok"])
        return ng
    WinGetPos(&wx, &wy, , , "ahk_id " hwnd)
    px := wx + r["x"] + dx, py := wy + r["y"] + dy
    away := Map("x", wx + r["x"] - 20, "y", wy + r["y"] - 20)
    MouseGetPos(&ox, &oy)
    c1 := -1, c2 := -1
    try {
        MouseMove(away["x"], away["y"], 0)
        Sleep(150)
        c1 := PixelGetColor(px, py)
        MouseMove(px, py, 0)
        Sleep(200)
        c2 := PixelGetColor(px, py)
        MouseMove(away["x"], away["y"], 0)
        Sleep(80)
    } catch as e {
        Log("WARN", "色の確認でつまずきました: " . e.Message)
    }
    try MouseMove(ox, oy, 0)
    if (c1 < 0 || c2 < 0)
        return ng
    d := ColorDist(c1, c2)
    lim := CI("HoverDiffMin")
    if (lim <= 0)
        lim := 12
    ; 差が小さい＝カーソルに反応しなかった＝選択済み
    return Map("ok", true, "un", (d < lim), "c1", c1, "c2", c2, "d", d)
}

; ★記録はモデルごとに分ける★
;   18D で覚えた位置を、別モデルの記録で上書きしないため（2026-09-22 指摘）。
;   18D … これまでどおり [Manual] / [ScanType]（既存の設定をそのまま使える）
;   ほか … [Manual.MetaAnalyzer] のようにモデル名を付けた節
ModelSec(grp) {
    n := Trim(CS("ModelName"))
    if (n = "" || n = "18D")
        return grp
    return grp . "." . n
}

; 読むときは、モデル専用の節があればそちら。無ければ従来の節。
ModelSecRead(m, grp) {
    sec := ModelSec(grp)
    if (sec != grp && Trim(IniGet(m, sec, "Panel", "")) != "")
        return sec
    return grp
}

; 記録した項目のうち、いま選ばれているものは何番目か。0 = どれも選ばれていない
HighlightedOptIndex(hwnd, grp) {
    global CFG
    m := IniLoad(CFG)
    grp := ModelSecRead(m, grp)
    panel := Trim(IniGet(m, grp, "Panel", ""))
    if (panel = "")
        return 0
    n := ToInt(IniGet(m, grp, "Count", "0"), 0)
    ; ★カーソルを当てた状態を拾わない★
    ;   マウスが項目の上にあると、その項目だけ色が変わる（別モデルで確認）。
    ;   読む前に一覧の外へ退避させれば、見分ける状態が 2 つに減る。
    rw := CtrlRect(hwnd, panel)
    if (rw["ok"]) {
        WinGetPos(&wx, &wy, , , "ahk_id " hwnd)
        try MouseMove(wx + rw["x"] - 20, wy + rw["y"] - 20, 0)
        Sleep(120)
    }
    found := 0, note := ""
    Loop n {
        dx := ToInt(IniGet(m, grp, "DX" A_Index, "0"), 0)
        dy := ToInt(IniGet(m, grp, "DY" A_Index, "0"), 0)
        if (CB("HoverTest")) {
            ; カーソルに反応しない項目＝選択済み
            pb := ItemHoverProbe(hwnd, panel, dx, dy)
            un := pb["un"]
            det := "(色を読めず)"
            if (pb["ok"])
                det := Format("(#{:06X}→#{:06X} 差{:d})", pb["c1"], pb["c2"], pb["d"])
            note .= (note = "" ? "" : " / ") Trim(IniGet(m, grp, "Name" A_Index, A_Index))
                 . (un ? "=反応なし（選択済み）" : "=反応あり") . det
            if (found = 0 && un)
                found := A_Index
        } else {
            hh := ItemHighlight(hwnd, panel, dx, dy)
            lbl := (!hh["ok"]) ? "=読めず" : Format("=#{:06X}(青{:d}点/最大{:+d})", hh["col"], hh["hit"], hh["max"])
            note .= (note = "" ? "" : " / ") Trim(IniGet(m, grp, "Name" A_Index, A_Index)) lbl
            if (found = 0 && hh["ok"] && hh["hit"] >= CI("HighlightHitMin"))
                found := A_Index
        }
    }
    ; ★色の実測をログに残す★ 誤判定したときに、あとから原因が分かるように
    Log("DEBUG", grp " の色: " note)
    return found
}

OptNameAt(grp, idx) {
    global CFG
    m := IniLoad(CFG)
    return Trim(IniGet(m, ModelSecRead(m, grp), "Name" idx, ""))
}

NoneSelectLabel() => "（どれも選ばない）"

; コントロールの左上を基準にした位置を、いまのウィンドウの座標に直す
SpotFromAnchor(hwnd, cnn, dx, dy) {
    r := CtrlRect(hwnd, cnn)
    if (!r["ok"] || r["w"] <= 0)
        return Map("ok", false, "x", 0, "y", 0)
    return Map("ok", true, "x", r["x"] + dx, "y", r["y"] + dy)
}

OptNames(grp) {
    global CFG
    m := IniLoad(CFG)
    grp := ModelSecRead(m, grp)
    out := []
    n := ToInt(IniGet(m, grp, "Count", "0"), 0)
    Loop n {
        nm := Trim(IniGet(m, grp, "Name" A_Index, ""))
        if (nm != "")
            out.Push(nm)
    }
    return out
}

; 名前 → 何番目か（0 = 見つからない）
OptIndex(grp, name) {
    for i, nm in OptNames(grp) {
        if (nm = Trim(name))
            return i
    }
    return 0
}

; grp の設定をまとめて返す（BtnX/BtnY/Panel と、指定した番号の X/Y）
OptSpot(grp, idx) {
    global CFG
    m := IniLoad(CFG)
    grp := ModelSecRead(m, grp)
    return Map("btnAnchor", Trim(IniGet(m, grp, "BtnAnchor", ""))
             , "btnDX", ToInt(IniGet(m, grp, "BtnDX", "0"), 0)
             , "btnDY", ToInt(IniGet(m, grp, "BtnDY", "0"), 0)
             , "panel", Trim(IniGet(m, grp, "Panel", ""))
             , "dx",    ToInt(IniGet(m, grp, "DX" idx, "0"), 0)
             , "dy",    ToInt(IniGet(m, grp, "DY" idx, "0"), 0))
}

TeachScanSteps() {
    ; ★ボタンの位置は覚えない★
    ;   「調査タイプ」「マニュアル選択」は本物のコントロールから計算できる
    ;   （SchemeDrawnButton）。覚えるのは一覧の中の項目だけ。
    out := []
    for nm in ["エクスプレス", "標準", "詳細", "科学"]
        out.Push(Map("grp", "ScanType", "kind", "item", "label", nm))
    ; ★一覧には他に「設定」「選択を解除」「トップに選択しました」もあるが、記録しない★
    ;   「選択を解除」は測定項目のチェックを全部外すボタン（2026-09-17 利用者の指摘）。
    ;   記録すると選択肢に出てしまい、誤って押せてしまうため、載せない。
    for nm in ["スキーム 1", "スキーム 2", "スキーム 3", "スキーム 4", "スキーム 5"
             , "自動選択", "リンクされた臓器", "すべて"]
        out.Push(Map("grp", "Manual", "kind", "item", "label", nm))
    return out
}

; 画面のタイトルに付ける版の文字（例: "  v2.1.1"）
;   ★どの画面からでも版を確かめられるように★
;   2026-09-17、別 PC の版を確かめたくても記録画面に表示がなく、
;   閉じると記録が消えるためログを開いてもらうしかなかった。
VerTag() {
    global APP_VER
    return "  v" StrSplit(APP_VER, " ")[1]
}

ModeTeachScan() {
    global CFG, APP_NAME, APP_VER, G
    pid := EnsureTarget()
    LoadScreens()
    hw := FindScreen("S3_Scheme")
    if (!hw) {
        MsgBox("スキーム画面（調査のスキーム）が開いていません。`n`n"
            . "対象者のカードを開いて「調査」を押し、スキーム画面を出してから"
            . "もう一度実行してください。`n"
            . "※ 調査は開始しないでください。", APP_NAME, "Icon! 4096")
        ; ★案内の途中なら閉じない★ 準備ができたら続けられるように戻す
        if (G.backTo = "wizard") {
            ModeWizard()
            return
        }
        ExitApp(1)
    }

    steps := TeachScanSteps()
    idx   := 1
    got   := Map()
    grabLeft := 0                                  ; "grp|label" → Map("x","y","panel")

    dlg := Gui("+AlwaysOnTop", APP_NAME " - 調査タイプ／マニュアル選択を教える" VerTag())
    dlg.MarginX := 16, dlg.MarginY := 12
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "w660", "位置を教えてください（クリックはしません）")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w660 h64 cGray"
        , "項目の上にマウスを乗せて F1 を押すだけです。クリックすると"
        . "ポップアップが閉じてしまうので、押さないでください。`n"
        . "ボタン（調査タイプ／マニュアル選択）だけは、記録したあとクリックして開きます。`n"
        . "位置は「近くのボタンからの差」で覚えるので、窓の大きさが変わっても狂いません。`n"
        . "F2 = 1 つ戻る　／　行をダブルクリック = その項目だけ取り直す")

    dlg.SetFont("s13 Bold", "Meiryo UI")
    lblNext := dlg.Add("Text", "xm w660 cNavy", "")
    dlg.SetFont("s10", "Meiryo UI")
    lblHow  := dlg.Add("Text", "xm w660 h44", "")
    dlg.SetFont("s10", "Consolas")
    lblPos  := dlg.Add("Text", "xm w660 h52", "")

    dlg.SetFont("s10", "Meiryo UI")
    ; ★一覧の高さは画面に合わせて決める★
    ;   行数を 12 行で固定していたため、拡大表示のある環境で画面からはみ出し、
    ;   下にある「保存して終わる」が押せなくなった（2026-09-17、別の PC）。
    wkT := 0, wkB := A_ScreenHeight
    try MonitorGetWorkArea(, , &wkT, , &wkB)
    availH := (IsSet(wkT) && IsSet(wkB) && wkB > wkT) ? (wkB - wkT) : A_ScreenHeight
    ; ★画面の実ピクセルと、GUI の指定値は単位が違う★
    ;   拡大表示（125% など）では h300 と書いても実際には 375px 描かれる。
    ;   作業領域は実ピクセルで返ってくるので、同じ単位に直してから引く。
    ;   2026-09-17、1920×1080 の別 PC で「直したのにまだ切れる」と指摘を受けた点。
    scale := (A_ScreenDPI > 0) ? (A_ScreenDPI / 96) : 1
    availH := Floor(availH / scale)
    lvH := availH - 520                            ; 一覧以外に要る高さ
    if (lvH < 110)
        lvH := 110
    if (lvH > 300)
        lvH := 300
    lv := dlg.Add("ListView", "xm w660 h" lvH " -Multi Grid", ["#", "区分", "項目", "位置"])
    for st in steps
        lv.Add("", A_Index, (st["grp"] = "ScanType" ? "調査タイプ" : "マニュアル選択")
             , st["label"], "")
    lv.ModifyCol(1, 34), lv.ModifyCol(2, 100), lv.ModifyCol(3, 170), lv.ModifyCol(4, 330)
    lv.OnEvent("DoubleClick", (*) => JumpTo())     ; 行をダブルクリックで、そこからやり直す

    dlg.SetFont("s10", "Meiryo UI")
    lblKey := dlg.Add("Text", "xm w660 cGray", "F1 を待っています（まだ一度も受け取っていません）")
    bGrab := dlg.Add("Button", "xm w660 h34", "F1 が効かないとき → 3 秒後に記録する")
    bTest := dlg.Add("Button", "xm w660 h34", "★ 記録した位置を試す（ここで確かめてから保存してください）")
    bSave := dlg.Add("Button", "xm w320 h38 Default", "保存して終わる")
    bQuit := dlg.Add("Button", "x+16 yp w320 h38", "やめる")
    bGrab.OnEvent("Click", (*) => StartGrab())
    bTest.OnEvent("Click", (*) => TestSpots())
    bSave.OnEvent("Click", (*) => SaveAll())
    bQuit.OnEvent("Click", (*) => ExitApp(0))
    dlg.OnEvent("Close", (*) => ExitApp(0))
    ; ★画面の一番上に出す★ 下に置くほど、ボタンがはみ出しやすくなる
    dlg.Show("y" wkT)

    ; F1 が別のところに取られることがあるので、F9 でも受け付ける。
    ; * を付けて、修飾キーが押されていても反応するようにする。
    Hotkey("*F1", (*) => Pick())
    Hotkey("*F9", (*) => Pick())
    Hotkey("*F2", (*) => Undo())
    ; ★Esc では終了しない★
    ;   ソフト側の一覧を閉じようとして Esc を押すことがある。
    ;   そこで記録画面ごと消えると、それまでの記録が失われる。
    Hotkey("Esc", (*) => AskQuit())
    SetTimer(Watch, 200)
    ShowNext()
    Watch()
    return

    AskQuit() {
        ans := MsgBox("記録をやめますか？`n`n"
            . "（ソフトの一覧を閉じたいだけなら「いいえ」を選んでください）"
            , APP_NAME, "YesNo Icon? 4096")
        if (ans = "Yes")
            ExitApp(0)
    }

    ShowNext() {
        if (idx > steps.Length) {
            lblNext.Value := "★ 全部そろいました。「保存して終わる」を押してください"
            lblHow.Value  := ""
            return
        }
        st := steps[idx]
        grpName := (st["grp"] = "ScanType") ? "調査タイプ" : "マニュアル選択"
        lblNext.Value := Format("{1} / {2}　つぎ: {3}　の　{4}"
            , idx, steps.Length, grpName, st["label"])
        firstItem := (st["kind"] = "item")
                  && (idx = 1 || steps[idx - 1]["grp"] != st["grp"]
                     || steps[idx - 1]["kind"] = "btn")
        if (st["kind"] = "btn") {
            lblHow.Value := "まだ押さないでください。" grpName
                . " のボタンの上に【マウスを乗せるだけ】で F1。"
        } else if (firstItem) {
            lblHow.Value := grpName " のボタンを【クリックして】一覧を開いてください。`n"
                . "開いたら「" st["label"] "」の上に【マウスを乗せるだけ】で F1。"
                . "（項目はクリックしないでください）"
        } else {
            lblHow.Value := "続けて「" st["label"] "」の上に【マウスを乗せるだけ】で F1。"
        }
    }

    Watch() {
        ; ★画面が消えていたら、何もせずに見張りを止める★
        ;   閉じたあとに書き換えようとすると落ちる（2026-09-22）。
        if (!WinExist("ahk_id " dlg.Hwnd)) {
            SetTimer(Watch, 0)
            return
        }
        mx := 0, my := 0, uw := 0, ctrl := ""
        MouseGetPos(&mx, &my, &uw, &ctrl)
        wx := 0, wy := 0, ww := 0, wh := 0
        try WinGetPos(&wx, &wy, &ww, &wh, "ahk_id " hw)
        ucls := ""
        try ucls := WinGetClass("ahk_id " uw)
        same := (uw = hw)
        rx := mx - wx, ry := my - wy
        ; どこを基準に覚えることになるか、その場で見せる
        base := ""
        if (!same) {
            base := "（スキーム画面の外です）"
        } else if (ctrl != "") {
            pr := CtrlRect(hw, ctrl)
            if (pr["ok"])
                base := Format("{1} から +{2},{3}", ctrl, rx - pr["x"], ry - pr["y"])
            else
                base := ctrl "（位置が取れません）"
        } else if (same) {
            nb := NearestButton(hw, rx, ry)
            if (nb["cnn"] = "")
                base := "（基準が見つかりません）"
            else
                base := Format("{1} から +{2},{3}", nb["cnn"], nb["dx"], nb["dy"])
        }
        ; カーソル下の色。「選ばれている（青）」と「選ばれていない（灰）」を
        ; 見分けられるか確かめるために出す。
        col := ""
        try col := Format("0x{:06X}", PixelGetColor(mx, my))
        lblPos.Value := Format("スキーム画面 : x{1} y{2} ({3}×{4})　ウィンドウ内: x{5} y{6}　{7}`n"
                             . "いまの場所   : {8}　窓: {9}　色: {10}`n"
                             . "覚え方       : {11}"
            , wx, wy, ww, wh, rx, ry
            , same ? "" : "★スキーム画面の上ではありません★"
            , (ctrl = "") ? "（コントロールなし＝描画部分）" : ctrl
            , ucls = "" ? "?" : ucls, col = "" ? "?" : col, base)
    }

    ; ★記録した位置が本当に当たるかを、その場で確かめる★
    ;   2026-09-16、ずれた位置を記録したまま運転し、3 件続けて失敗して
    ;   その晩の運転が止まった。30 分のジョブを回さずに確かめられるようにする。
    TestSpots() {
        out := ""
        for grp in ["ScanType", "Manual"] {
            jp    := (grp = "ScanType") ? "調査タイプ" : "マニュアル選択"
            sp := SchemeDrawnButton(hw, grp)
            if (!sp["ok"]) {
                out .= jp "：位置を計算できません"
                     . "（インタラクティブ既往症／調査／現在の分析 が読めません）`n`n"
                continue
            }
            ; この区分で記録済みの項目から、一覧（パネル）の名前を拾う
            panel := ""
            for st in steps {
                k := st["grp"] "|" st["label"]
                if (st["grp"] = grp && st["kind"] = "item" && got.Has(k)) {
                    panel := got[k]["panel"]
                    break
                }
            }
            try ControlClick(Format("x{1} y{2}", sp["x"], sp["y"]), "ahk_id " hw
                , , "Left", 1, "NA")
            ; ★開くまで待つ★
            ;   1.5 秒しか待たずに判定していたため、位置が正しくても
            ;   「開きません」と出ていた（2026-09-17、別の PC でのセットアップ）。
            ;   このソフトは一覧が出るまで 6 秒以上かかることがある。
            vis := false
            waited := 0
            while (waited < 10000) {
                if (panel != "") {
                    try vis := ControlGetVisible(panel, "ahk_id " hw)
                    if (vis)
                        break
                }
                Sleep(500)
                waited += 500
            }
            out .= Format("{1}`n　押した位置 : x{2} y{3}（本物のボタンから計算）`n"
                        . "　一覧 {4} : {5}`n`n"
                , jp, sp["x"], sp["y"]
                , panel = "" ? "（未記録）" : panel
                , (panel = "") ? "確かめられません" : (vis ? "★開きました" : "開きません（10 秒待っても出ませんでした）"))
            if (vis) {                              ; 開いたら、もう一度押して閉じる
                try ControlClick(Format("x{1} y{2}", sp["x"], sp["y"]), "ahk_id " hw
                    , , "Left", 1, "NA")
                Sleep(800)
            }
        }
        MsgBox(out "両方とも「★開きました」になっていれば大丈夫です。"
            , APP_NAME " - 試した結果", "Iconi 4096")
    }

    ; 押したボタンから 3 秒後に記録する。F1 が届かない環境のための逃げ道。
    StartGrab() {
        grabLeft := 3
        lblKey.Value := "3 秒後に、いまマウスがある場所を記録します…"
        SetTimer(GrabTick, 1000)
    }

    GrabTick() {
        grabLeft--
        if (grabLeft > 0) {
            lblKey.Value := grabLeft " 秒後に記録します… 記録したい場所にマウスを置いてください"
            return
        }
        SetTimer(GrabTick, 0)
        Pick()
    }

    Pick() {
        ; ★最初にここを更新する★
        ;   これが動かなければ「F1 が届いていない」、
        ;   動くのに記録されなければ「届いたが弾かれた」と切り分けられる。
        lblKey.Value := "受け取りました: " FormatTime(A_Now, "HH:mm:ss")
        if (idx > steps.Length)
            return
        mx := 0, my := 0, ctrl := ""
        MouseGetPos(&mx, &my, , &ctrl)
        wx := 0, wy := 0, ww := 0, wh := 0
        try WinGetPos(&wx, &wy, &ww, &wh, "ahk_id " hw)
        rx := mx - wx, ry := my - wy
        st := steps[idx]
        ; ★スキーム画面の外を指していたら受け付けない★
        ;   2026-09-15、マニュアル選択のボタンが y=-31 で記録された。
        ;   ウィンドウの外（上）を指したまま F1 を押したため。
        if (rx < 0 || ry < 0 || (ww > 0 && rx > ww) || (wh > 0 && ry > wh)) {
            ; ★止めない。数字を見せて判断してもらう★
            ;   こちらの座標の取り方が違っている可能性もあるので、
            ;   「外だから受け付けない」と決めつけない（2026-09-15）
            uw2 := 0
            MouseGetPos(, , &uw2)
            ucls2 := ""
            try ucls2 := WinGetClass("ahk_id " uw2)
            ans := MsgBox(Format("記録しようとしている位置が、スキーム画面の範囲から外れています。`n`n"
                . "　ウィンドウ内 : x{1} y{2}`n"
                . "　画面の大きさ : {3} × {4}`n"
                . "　カーソルの下 : {5}`n`n"
                . "指している場所が正しければ、このまま記録して構いません。`n"
                . "記録しますか？", rx, ry, ww, wh, ucls2 = "" ? "?" : ucls2)
                , APP_NAME, "YesNo Icon! 4096")
            if (ans != "Yes")
                return
        }
        ; 項目はポップアップ（TPanel…）の上にあるはず
        if (st["kind"] = "item" && ctrl = "") {
            ans := MsgBox("いま指している場所に、ポップアップがありません。`n`n"
                . "先に " (st["grp"] = "ScanType" ? "「調査タイプ」" : "「マニュアル選択」")
                . " を押して一覧を開いてから、項目の上で F1 を押してください。`n`n"
                . "それでもこの位置で記録しますか？", APP_NAME, "YesNo Icon! 4096")
            if (ans != "Yes")
                return
        }
        ; ★絶対座標では覚えない★ 近くの本物のボタン／ポップアップからの差で覚える
        pr := (ctrl = "") ? Map("ok", false) : CtrlRect(hw, ctrl)
        if (st["kind"] = "item" && ctrl != "" && pr["ok"]) {
            got[st["grp"] "|" st["label"]] := Map("anchor", ctrl
                , "dx", rx - pr["x"], "dy", ry - pr["y"], "panel", ctrl)
            lv.Modify(idx, "Col4", Format("{1} から +{2},{3}　→ いま x{4} y{5}", ctrl
                , rx - pr["x"], ry - pr["y"], rx, ry))
        } else {
            nb := NearestButton(hw, rx, ry)
            if (nb["cnn"] = "") {
                MsgBox("近くに基準にできるボタンが見つかりませんでした。`n"
                    . "スキーム画面の上で操作しているか確かめてください。", APP_NAME, "Iconx 4096")
                return
            }
            got[st["grp"] "|" st["label"]] := Map("anchor", nb["cnn"]
                , "dx", nb["dx"], "dy", nb["dy"], "panel", "")
            lv.Modify(idx, "Col4", Format("{1} から +{2},{3}　→ いま x{4} y{5}"
                , nb["cnn"], nb["dx"], nb["dy"], rx, ry))
        }
        lv.Modify(idx, "Select Focus")
        idx++
        ShowNext()
    }

    ; 一覧の行をダブルクリックしたら、その項目から記録し直す
    JumpTo() {
        row := lv.GetNext()
        if (row < 1)
            return
        idx := row
        ShowNext()
    }

    Undo() {
        if (idx <= 1)
            return
        idx--
        st := steps[idx]
        got.Delete(st["grp"] "|" st["label"])
        lv.Modify(idx, "Col4", "")
        ShowNext()
    }

    SaveAll() {
        ; ★「まだ何番目か」ではなく、実際に記録できていない数を数える★
        ;   行をダブルクリックして 1 つだけ取り直したときに、
        ;   そのあとの項目まで「空」と誤解しないため。
        miss := 0
        for st in steps {
            if (!got.Has(st["grp"] "|" st["label"]))
                miss++
        }
        if (miss > 0) {
            ans := MsgBox("まだ " miss " 件が空です。`n"
                . "空のままの項目は、予定の編集画面に出てきません。`n`n"
                . "このまま保存しますか？", APP_NAME, "YesNo Icon? 4096")
            if (ans != "Yes")
                return
        }
        for grp in ["ScanType", "Manual"] {
            head := [], items := [], n := 0, panel := ""
            for st in steps {
                if (st["grp"] != grp)
                    continue
                key := grp "|" st["label"]
                if (!got.Has(key))
                    continue
                g := got[key]
                if (st["kind"] = "btn") {
                    head.Push(["BtnAnchor", g["anchor"]])
                    head.Push(["BtnDX", g["dx"]])
                    head.Push(["BtnDY", g["dy"]])
                    continue
                }
                n++
                items.Push(["Name" n, st["label"]])
                items.Push(["DX" n, g["dx"]])
                items.Push(["DY" n, g["dy"]])
                if (panel = "" && g["panel"] != "")
                    panel := g["panel"]             ; ポップアップの正体（TPanel3 など）
            }
            ; ★何も記録していない区分は触らない★
            ;   節ごと書き換えるので、空で書くと前回の記録が消えてしまう
            if (!head.Length && !items.Length)
                continue
            pairs := []
            for pr in head
                pairs.Push(pr)
            if (panel != "")
                pairs.Push(["Panel", panel])
            pairs.Push(["Count", n])
            for pr in items
                pairs.Push(pr)
            IniSetSection(CFG, ModelSec(grp), pairs)   ; モデルごとに分けて保存
        }
        Log("INFO", "調査タイプ／マニュアル選択の位置を保存しました")
        MsgBox("config.ini に保存しました。`n`n"
            . "予定の編集画面の「やること」に、選べるようになります。`n"
            . "既定は 調査タイプ＝詳細 / マニュアル選択＝自動選択 です。"
            , APP_NAME, "Iconi 4096")
        ; ★保存したら閉じずに設定画面へ戻る★
        ;   続けて別の設定をしたいのに、毎回ソフトが消えていた（2026-09-22 指摘）。
        CloseTeach()
        BackToSettings()
        return
    }

    ; ★画面を閉じる前に、見張りとキーを必ず外す★
    ;   2026-09-22、閉じたあとも 0.2 秒ごとの見張りが動き続け、
    ;   消えたはずの文字欄を書き換えようとして
    ;   「Error: The control is destroyed.」が出た。
    CloseTeach() {
        SetTimer(Watch, 0)
        SetTimer(GrabTick, 0)
        try Hotkey("*F1", "Off")
        try Hotkey("*F9", "Off")
        try Hotkey("*F2", "Off")
        try Hotkey("Esc", "Off")
        try dlg.Destroy()
    }
}

;==============================================================================
;  設定 — 初期設定と診断（ふだんは使わないもの）
;==============================================================================
; 調査履歴の件数が出ている場所を覚える。
;   ここが空だと G2 の裏取りができず、「調査できたか」を画面の見た目だけで
;   判断することになる（毎回 WARN が出ていた）。判定する側の仕組みは既にある。
ModeTeachCount() {
    global CFG, APP_NAME
    EnsureTarget()
    picked := ""
    dlg := Gui("+AlwaysOnTop", APP_NAME " - 調査履歴の件数の場所を教える" VerTag())
    dlg.MarginX := 16, dlg.MarginY := 12
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "w660", "調査履歴の件数が出ているところを教えてください")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w660 h78 cGray"
        , "対象者のカードを開くと、これまでの調査の履歴が出ます。"
        . "その【件数】が表示されている場所にマウスを乗せて F1 を押してください。`n"
        . "ここを覚えると、調査の前後で件数が増えたかどうかを見て"
        . "【本当に調査できたか】を確かめられるようになります。`n"
        . "分からなければ「やめる」で閉じて構いません。"
        . "その場合はこれまでどおり、画面の見た目だけで判断します。")
    dlg.SetFont("s10", "Consolas")
    lblNow := dlg.Add("Text", "xm w660 h52", "")
    dlg.SetFont("s10 Bold", "Meiryo UI")
    lblGot := dlg.Add("Text", "xm w660 h52 cNavy", "まだ受け取っていません")
    dlg.SetFont("s10", "Meiryo UI")
    bSave := dlg.Add("Button", "xm w320 h38 Default", "保存して終わる")
    bQuit := dlg.Add("Button", "x+16 yp w320 h38", "やめる")
    bSave.OnEvent("Click", (*) => SaveIt())
    bQuit.OnEvent("Click", (*) => ExitApp(0))
    dlg.OnEvent("Close", (*) => ExitApp(0))
    dlg.Show()
    Hotkey("*F1", (*) => PickIt())
    Hotkey("*F9", (*) => PickIt())
    SetTimer(WatchIt, 200)
    WatchIt()
    return

    WatchIt() {
        if (!WinExist("ahk_id " dlg.Hwnd)) {   ; 閉じたあとは書き換えない
            SetTimer(WatchIt, 0)
            return
        }
        uw := 0, uc := ""
        MouseGetPos(, , &uw, &uc)
        t := ""
        if (uc != "" && uw)
            try t := Trim(ControlGetText(uc, "ahk_id " uw))
        lblNow.Value := "いまの場所 : " (uc = "" ? "（コントロールがありません）" : uc)
                      . "`n読める文字 : " (t = "" ? "（空）" : SubStr(t, 1, 60))
                      . "`n件数として読む値 : " (ParseCount(t) = "" ? "（数字なし）" : ParseCount(t))
    }
    PickIt() {
        global G
        uw := 0, uc := ""
        MouseGetPos(, , &uw, &uc)
        if (uc = "") {
            MsgBox("その場所にはコントロールがありません。`n`n"
                . "件数の数字が出ているところに、まっすぐ乗せてみてください。"
                , APP_NAME, "Icon! 4096")
            return
        }
        ; ★対象ソフトの上を指しているか確かめる★
        ;   これが無いと、この記録画面そのものを指したまま F1 を押せてしまい、
        ;   まったく別のコントロール名が記録される（2026-09-17 の見直しで発見）。
        upid := 0
        try upid := WinGetPID("ahk_id " uw)
        if (!upid || upid != G.pid) {
            wexe := ""
            try wexe := WinGetProcessName("ahk_id " uw)
            MsgBox("いま指しているのは対象ソフトではありません。`n`n"
                . "　指している窓 : " (wexe = "" ? "（不明）" : wexe) "`n"
                . "　対象ソフト   : " CS("ExeName") "`n`n"
                . "対象ソフトのカード画面で、履歴の件数の上に乗せてから F1 を押してください。"
                , APP_NAME, "Icon! 4096")
            return
        }
        t := ""
        try t := Trim(ControlGetText(uc, "ahk_id " uw))
        picked := uc
        lblGot.Value := "受け取りました : " uc
                      . "`n読めた文字 : " (t = "" ? "（空）" : SubStr(t, 1, 60))
                      . "`n件数として読む値 : " (ParseCount(t) = "" ? "★数字なし★" : ParseCount(t))
    }
    SaveIt() {
        global CFG, APP_NAME
        if (picked = "") {
            MsgBox("まだ受け取っていません。件数の上で F1 を押してください。"
                , APP_NAME, "Icon! 4096")
            return
        }
        IniSet(CFG, ModelSec("Ctrl"), "RecordCountClassNN", picked)
        MsgBox("config.ini に記録しました。`n`n  RecordCountClassNN = " picked "`n`n"
            . "これから調査のたびに、履歴の件数が増えたかを確かめます。"
            . "増えていなければ完了とは判断しません。", APP_NAME, "Iconi 4096")
        ; ★保存したら閉じずに設定画面へ戻る★
        ;   続けて別の設定をしたいのに、毎回ソフトが消えていた（2026-09-22 指摘）。
        ;   見張りとキーを外してから閉じる（外し忘れると消えた文字欄を
        ;   書き換えようとして落ちる）。
        SetTimer(WatchIt, 0)
        try Hotkey("*F1", "Off")
        try Hotkey("*F9", "Off")
        try dlg.Destroy()
        BackToSettings()
        return
    }
}

; ★いま行の間隔が登録されているか、ボタンの字で見えるようにする★
;   2026-09-22、「設定したのに未登録と言われる」ことがあった。
;   設定ファイルを開かなくても確かめられるようにする。
; 「はじめての設定」ボタンの字。残りの件数が見えるようにする
SetupWizLabel() {
    left := 0
    for st in SetupSteps() {
        if (!st["d"] && st["must"])
            left++
    }
    if (left = 0)
        return "はじめての設定（順番に案内します）　― 必要な設定は済んでいます"
    return "★はじめての設定（順番に案内します）　残り " . left . " 件★"
}

RowPitchLabel() {
    p := CI("ListRowPitchY")
    return "一覧の先頭行を教える（行の間隔: "
         . (p > 0 ? p . "px" : "★未登録★") . "）"
}

; ★設定を保存したあとに戻る先★
;   「はじめての設定」から入ったときは、そちらへ戻して続きを促す。
BackToSettings() {
    global G
    if (G.backTo = "wizard") {
        ModeWizard()
        return
    }
    ModeMore()
}

; モデル別の節を優先して読む（設定ファイルを開き直して、その場の値を見る）
CfgRead(m, sec, key, dflt := "") {
    mdl := Trim(CS("ModelName"))
    if (mdl != "" && mdl != "18D") {
        v := Trim(IniGet(m, sec . "." . mdl, key, ""))
        if (v != "")
            return v
    }
    return Trim(IniGet(m, sec, key, dflt))
}

; ★この PC で済ませるべきことの一覧★
;   2026-09-22、他社の PC に配って分かったこと。
;   設定はボタンが並んでいるだけで、どれが必須でどこまで済んだのかが分からなかった。
SetupSteps() {
    global CFG
    m := IniLoad(CFG)
    exe := Trim(IniGet(m, "Target", "ExeName", ""))
    mdl := Trim(IniGet(m, "Model", "ModelName", ""))
    rowX := ToInt(CfgRead(m, "Select", "ListFirstRowX", "0"), 0)
    rowY := ToInt(CfgRead(m, "Select", "ListFirstRowY", "0"), 0)
    pitch := ToInt(CfgRead(m, "Select", "ListRowPitchY", "0"), 0)
    manN := ToInt(IniGet(m, ModelSecRead(m, "Manual"), "Count", "0"), 0)
    scanN := ToInt(IniGet(m, ModelSecRead(m, "ScanType"), "Count", "0"), 0)
    cnt := CfgRead(m, "Ctrl", "RecordCountClassNN", "")
    code := Trim(IniGet(m, "License", "UserCode", ""))
    rowVal := ""
    if (rowX > 0 && rowY > 0) {
        rowVal := "x" . rowX . " y" . rowY
        rowVal .= (pitch > 0) ? ("／間隔 " . pitch . "px") : "／★間隔が未登録★"
    }
    posVal := ""
    if (manN > 0 || scanN > 0)
        posVal := "調査タイプ " . scanN . " 件／マニュアル選択 " . manN . " 件"
    exeVal := ""
    if (exe != "")
        exeVal := exe . ((mdl = "") ? "" : ("（" . mdl . "）"))
    st := []
    st.Push(Map("mode", "setup", "must", true
        , "t", "対象ソフトを選ぶ"
        , "d", exe != "", "v", exeVal))
    st.Push(Map("mode", "pickrow", "must", true
        , "t", "一覧の 1 行目と 2 行目を教える"
        , "d", (rowX > 0 && rowY > 0)
        , "v", rowVal))
    st.Push(Map("mode", "teachscan", "must", true
        , "t", "調査タイプ／マニュアル選択の位置を教える"
        , "d", (manN > 0 || scanN > 0), "v", posVal))
    st.Push(Map("mode", "teachcount", "must", false
        , "t", "調査履歴の件数の場所を教える"
        , "d", cnt != "", "v", cnt))
    st.Push(Map("mode", "code", "must", false
        , "t", "利用者コードを入れる"
        , "d", code != "", "v", code))
    return st
}

; ★はじめての設定★ 必要なことを、順番に案内する
ModeWizard() {
    global APP_NAME, G
    G.backTo := "wizard"
    steps := SetupSteps()
    left := 0, nextMode := "", nextName := ""
    for st in steps {
        if (st["d"])
            continue
        if (st["must"])
            left++
        if (nextMode = "")
            nextMode := st["mode"], nextName := st["t"]
    }
    dlg := Gui("+AlwaysOnTop", APP_NAME " - はじめての設定" VerTag())
    dlg.MarginX := 20, dlg.MarginY := 12
    dlg.SetFont("s12 Bold", "Meiryo UI")
    dlg.Add("Text", "w640", "この PC で済ませることを、上から順に進めてください")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w640 cGray"
        , "★の 3 つは、終わらないと運転できません。"
        . "下の 2 つは、あとからでも構いません。`n"
        . "測った値はこの PC にだけ残ります。ほかの PC の値は使えません。")
    dlg.Add("Text", "w640 h1 0x10")

    dlg.SetFont("s10", "Meiryo UI")
    for st in steps {
        mark := st["d"] ? "済" : (st["must"] ? "★まだ" : "任意")
        cap := Format("{1}　{2}", mark, st["t"])
        b := dlg.Add("Button", "xm w640 h36", cap)
        b.OnEvent("Click", MakeGo(st["mode"]))
        dlg.SetFont("s9", "Meiryo UI")
        dlg.Add("Text", "xm+24 w600 " (st["d"] ? "cGreen" : "cGray")
            , st["v"] = "" ? "（まだ記録がありません）" : st["v"])
        dlg.SetFont("s10", "Meiryo UI")
    }

    dlg.Add("Text", "xm w640 h1 0x10")
    dlg.SetFont("s10 Bold", "Meiryo UI")
    if (left = 0) {
        dlg.Add("Text", "w640 cGreen", "★必要な設定はそろっています★　運転できます")
    } else {
        dlg.Add("Text", "w640 cRed", Format("あと {1} 件（次: {2}）", left, nextName))
    }
    dlg.SetFont("s10", "Meiryo UI")
    if (nextMode != "") {
        bNext := dlg.Add("Button", "xm w400 h38 Default", "次へ　→　" nextName)
        bNext.OnEvent("Click", MakeGo(nextMode))
        bBack := dlg.Add("Button", "x+16 yp w224 h38", "設定にもどる")
    } else {
        bBack := dlg.Add("Button", "xm w640 h38 Default", "設定にもどる")
    }
    bBack.OnEvent("Click", (*) => Leave())
    dlg.OnEvent("Close", (*) => Leave())
    dlg.Show()
    return

    ; ★ボタンごとに別の行き先を覚えさせる★
    ;   繰り返しの中で直接 (*) => Go(st["mode"]) と書くと、
    ;   すべてのボタンが最後の 1 つを指してしまう。
    MakeGo(md) {
        return (*) => Go(md)
    }

    Go(md) {
        global G
        dlg.Destroy()
        G.mode := md
        switch md {
            case "setup":      ModeSetup()
            case "pickrow":    ModePickRow()
            case "teachscan":  ModeTeachScan()
            case "teachcount": ModeTeachCount()
            case "code":       ModeCode()
            default:           ModeMore()
        }
    }

    Leave() {
        global G
        G.backTo := "more"
        dlg.Destroy()
        ModeMore()
    }
}

ModeMore() {
    global APP_NAME, APP_VER
    dlg := Gui("+AlwaysOnTop", APP_NAME " - 設定" VerTag())
    dlg.MarginX := 20, dlg.MarginY := 10
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "w620", "設定")
    dlg.SetFont("s9", "Meiryo UI")
    mdlNow := Trim(CS("ModelName"))
    exeNow := Trim(CS("ExeName"))
    dlg.Add("Text", "w620 cGray", "ふだんの運用では使いません。" APP_VER)
    dlg.Add("Text", "w620 cNavy"
        , "対象ソフト: " (exeNow = "" ? "（未設定）" : exeNow)
        . "　／　モデル: " (mdlNow = "" ? "（未設定）" : mdlNow))
    ; ★どの場所のツールを動かしているか出す★
    ;   2026-09-22、zip を配り直すうちに同じ PC に 2 つ置かれ、
    ;   「設定したのに反映されない」ことがあり得る。設定ファイルは
    ;   ツールと同じ場所にあるので、ここが違えば別物を動かしている。
    dlg.Add("Text", "w620 cGray", "いまの場所: " A_ScriptDir)

    dlg.Add("Text", "w620 h1 0x10")
    dlg.SetFont("s10 Bold", "Meiryo UI")
    dlg.Add("Text", "w620 cNavy", "最初に 1 回だけ")
    dlg.SetFont("s10", "Meiryo UI")
    ; ★新しい PC はここから★ 必要なことを順番に案内する（2026-09-22 指摘）
    bWiz  := dlg.Add("Button", "w620 h36", SetupWizLabel())
    ; ★2 列に詰める★ 1 列だと画面の高さに収まらず、下が切れる（2026-09-21 指摘）
    b0    := dlg.Add("Button", "w300 h34", "対象ソフトを設定する")
    bRow  := dlg.Add("Button", "x+20 yp w300 h34", RowPitchLabel())
    bTS   := dlg.Add("Button", "xm w300 h34", "調査タイプ／マニュアル選択の位置")
    bRC   := dlg.Add("Button", "x+20 yp w300 h34", "調査履歴の件数の場所")
    bSN   := dlg.Add("Button", "xm w620 h34", "スキームの名前を変える（マニュアル選択の 1〜5 番目）")
    bCode := dlg.Add("Button", "xm w300 h34", "利用者コードを入れる")
    bSC   := dlg.Add("Button", "x+20 yp w300 h34", "ショートカットを作る")
    bVT   := dlg.Add("Button", "xm w300 h34", "利用の確認の自己診断（公開鍵）")
    bUp   := dlg.Add("Button", "x+20 yp w300 h34", "新しい版があるか調べて更新する")
    bSU   := dlg.Add("Button", "xm w620 h34", StartupLabel())
    bWD   := dlg.Add("Button", "xm w620 h34", WatchdogLabel())

    ; 「1 人だけ、いますぐ実行する」はメニュー側へ移した（2026-09-21）

    dlg.Add("Text", "xm w620 h1 0x10")
    dlg.SetFont("s10 Bold", "Meiryo UI")
    dlg.Add("Text", "w620 cNavy", "調整・診断（ソフトは操作しません。読み取るだけです）")
    dlg.SetFont("s10", "Meiryo UI")
    b1 := dlg.Add("Button", "w300 h34", "操作を記録する")
    b2 := dlg.Add("Button", "x+20 yp w300 h34", "読み取り可否を調べる")
    b3 := dlg.Add("Button", "xm w300 h34", "画面とボタンを一覧する")
    b4 := dlg.Add("Button", "x+20 yp w300 h34", "変化を監視する")
    b5 := dlg.Add("Button", "xm w620 h34", "調子が悪いときの診断")

    dlg.Add("Text", "xm w620 h1 0x10")
    dlg.SetFont("s10", "Meiryo UI")
    bBack := dlg.Add("Button", "w620 h34 Default", "← 戻る")

    bWiz.OnEvent("Click", (*) => Jump("wizard"))
    b0.OnEvent("Click",   (*) => Jump("setup"))
    bRow.OnEvent("Click", (*) => Jump("pickrow"))
    bTS.OnEvent("Click",  (*) => Jump("teachscan"))
    bRC.OnEvent("Click",  (*) => Jump("teachcount"))
    bSN.OnEvent("Click",  (*) => Jump("schemename"))
    bCode.OnEvent("Click",(*) => Jump("code"))
    bSC.OnEvent("Click",  (*) => ShortcutNow())
    bVT.OnEvent("Click",  (*) => Jump("verifytest"))
    bUp.OnEvent("Click",  (*) => Jump("update"))
    bSU.OnEvent("Click",  (*) => StartupClicked())
    bWD.OnEvent("Click",  (*) => WatchdogClicked())
    b1.OnEvent("Click",   (*) => Jump("trace"))
    b2.OnEvent("Click",   (*) => Jump("listread"))
    b3.OnEvent("Click",   (*) => Jump("inspect"))
    b4.OnEvent("Click",   (*) => Jump("watchall"))
    b5.OnEvent("Click",   (*) => Jump("doctor"))
    bBack.OnEvent("Click",(*) => Jump("menu"))
    dlg.OnEvent("Close",  (*) => Jump("menu"))
    dlg.Show()
    return

    StartupClicked() {
        ToggleStartup()
        bSU.Text := StartupLabel()                 ; 押したあとの表示を合わせる
    }

    WatchdogClicked() {
        ToggleWatchdog()
        bWD.Text := WatchdogLabel()
    }

    Jump(mode) {
        global G, APP_NAME
        dlg.Destroy()
        G.mode := mode
        switch mode {
            case "menu":     ModeMenu()
            case "run":      ModeRun()
            case "setup":    ModeSetup()
            case "pickrow":  ModePickRow()
            case "teachscan": ModeTeachScan()
            case "teachcount": ModeTeachCount()
            case "wizard":   ModeWizard()
            case "code":     ModeCode()
            case "verifytest": ModeVerifyTest()
            case "update":     ModeUpdate()
            case "model":      ModeModel()
            case "schemename": ModeSchemeNames()
            case "trace":    ModeTrace()
            case "listread": ModeListRead()
            case "inspect":  ModeInspect()
            case "watchall": ModeWatchAll()
            case "doctor":   ModeDoctor()
            default:
                MsgBox("行き先「" mode "」が実装されていません。", APP_NAME, "Iconx 4096")
                Log("ERROR", "未実装の行き先: " mode)
                ModeMenu()
        }
    }
}

;==============================================================================
;  ユーティリティ
;==============================================================================
; Windows のメモ帳で崩れないよう、書き出す文字列の改行を CRLF に揃える
CRLF(txt) {
    txt := StrReplace(txt, "`r`n", "`n")
    return StrReplace(txt, "`n", "`r`n")
}

FmtDur(sec) {
    sec := Max(0, Integer(sec))
    if (sec >= 3600)
        return Format("{1:02}:{2:02}:{3:02}", sec // 3600, Mod(sec // 60, 60), Mod(sec, 60))
    return Format("{1:02}:{2:02}", sec // 60, Mod(sec, 60))
}

OpenFile(p) {
    try Run('notepad.exe "' p '"')
}
