﻿#Requires AutoHotkey v2.0
#SingleInstance Off          ; 多重起動は自前で検出する（Force は実行中の処理を殺すため禁止）
Persistent()
SetWorkingDir A_ScriptDir
DetectHiddenWindows false
SetTitleMatchMode 2
; ★座標の基準を画面にそろえる★
;   AHK v2 の既定は Client（＝アクティブウィンドウ基準）。
;   記録画面を操作しているときは AutoMeta の窓が前面なので、
;   MouseGetPos が「メタアナライザーではなく AutoMeta の窓」を基準に返してしまい、
;   覚えた座標が見当違いになる（2026-09-16、x1095 y67 など）。
CoordMode "Mouse", "Screen"
CoordMode "Pixel", "Screen"
ListLines false
#Warn VarUnset, Off

;==============================================================================
;  AutoMeta.ahk  --  メタアナライザー自動操作ツール
;  Phase 0 : 実機調査ツール（★このフェーズではソフトを操作しません★）
;  仕様書: 仕様書.md
;
;  目的は 3 つだけ。
;    1) 各画面のウィンドウクラスを確定し screens.ini を作る      → /trace
;    2) 「自然終了」の見分け方を実測で確定する                   → /trace
;    3) 氏名照合ゲート（G1）が実装可能かを判定する               → /listread
;
;  ★安全★ Phase 0 は【読み取り専用】です。
;    唯一の例外は /listread の「検索欄への入力テスト」で、
;    実行前に必ず確認ダイアログを出し、終了時に入力を消します。
;
;  使い方:
;    2_START.bat         調査メニューを開く
;    /setup              対象ソフト（プロセス）を特定して config に記録
;    /trace              人が手で 1 周操作する間、画面遷移とクリックを記録
;    /listread           一覧・検索欄・姓名欄が読めるかを判定（G1 の可否）
;    /inspect            今開いている全画面のコントロールを列挙
;    /watchall           対象プロセスの変化を監視
;    /doctor             自己診断レポート
;==============================================================================

; 専用アイコン（タスクバーとトレイで見分けるため）
if FileExist(A_ScriptDir "\AutoMeta.ico") {
    try TraySetIcon(A_ScriptDir "\AutoMeta.ico")
}

APP_NAME  := "AutoMeta"
APP_VER   := "3.10.50 (本番と開発版を同じ本体に。事前のお知らせは本番で切り替えてオフ)"
APP_BUILD := "2026-11-07 12:28"      ; 配布時に自動で書き換わる（版の識別用）
; ★どちらの版か★ 配布時に自動で書き換わる。空＝本番、"開発版"＝作業中の版。
;   置き場のフォルダ名が同じ「最新版」でも、窓の名前で見分けられるようにする
;   （2026-09-22、開発版と本番を別の場所へ配り分けたため）。
APP_CHANNEL := ""

; ★まだ利用者へ出していない機能★（2026-11-07）
;   本番と開発版は、同じ本体を配る（違うのは上の刻印だけ）。出す準備ができていない機能は、
;   ここに false で書き、本番では FeatureOn() が false を返す。開発版（カマヤンの PC）では常にオン。
;   本番へ出すと決めたら、true に変えて開発版で配り、PC で動かしてから _promote.py で公開する。
;   以前は本番へ一部の関数だけを手で移していて、移し漏れで本番 3.10.46 が起動しなかった。
FEATURES := Map(
    "prenotice", false     ; 顧客への事前のお知らせ（F-9）。同意説明の雛形・説明書・LINE 残り通数での停止の準備中
)

; ---- ファイルパス ----------------------------------------------------------
CFG      := A_ScriptDir "\config.ini"
SCRINI   := A_ScriptDir "\screens.ini"
SCHEDINI := A_ScriptDir "\schedule.ini"
; ★ログは、同期の対象の外に書く★（3.10.24）
;   このフォルダは OneDrive・Google ドライブの同期の対象で、2 つの同期がログを取り合い、書き込みが弾かれたり
;   同期が止まったりした（10-08・10-12 のログが更新されなかった）。書くのは PC の中の別の場所にして、
;   LOGCOPY（従来の場所）へ、LogCopyOut が 1 時間に 1 回と終了時にコピーする。
LOGCOPY  := A_ScriptDir "\logs"
LOGDIR   := (EnvGet("LOCALAPPDATA") != "") ? EnvGet("LOCALAPPDATA") "\AutoMeta\logs" : A_ScriptDir "\logs"
STATEINI := A_ScriptDir "\state.ini"
STATUSTX := A_ScriptDir "\status.txt"
STOPFILE := A_ScriptDir "\STOP"
LIVEFILE := A_ScriptDir "\live.txt"              ; 動作中の版が「いま何をしているか」を書く
REQFILE  := A_ScriptDir "\request_therapy.ini"   ; 動作中の版へ「自動セラピーをして」と頼む
LICFILE  := A_ScriptDir "\license.key"           ; 利用の期限（配布物には含めない）

; ★鍵は必ず要る（配布版の前提）★
;   以前は config.ini の LicenseRequired で切り替えていた。しかしその config.ini は
;   利用者が編集できるため 0 に戻せば鍵を無視でき、さらに配布するひな型には
;   [License] 節が無く、既定の 0 ＝ 素通りだった（2026-09-19 指摘）。
;   切り替えを設定から外し、ここに固定する。開発機にも鍵を置いて運用する。
LICENSE_REQUIRED := true

PASSFILE := A_ScriptDir "\pass.key"             ; 通行証（オンライン確認の結果。手書き換えは通らない）
; 利用確認の窓口（第 2 段階）。ここを見て「使ってよいか・いつまでか」を受け取る。
;   返事には署名が付いていて、通行証を手で書き換えても通らない。
;   つながらないときは、通行証の期限までそのまま動く（セラピーの予定を止めないため）。
LICENSE_URL := "https://script.google.com/macros/s/AKfycbxZPxudZIvhuJ4_AFQRhVXHZ3koyI36nO7gDK3isP_8Ybv4aMk1TUpnI4nILSEr-jQ3/exec"
PENDFILE := A_ScriptDir "\pending.txt"           ; 確認待ち（✓ を付けて消去するまで残る）
REMOTEFILE := A_ScriptDir "\REMOTE_STOP"
SHOTDIR  := A_ScriptDir "\screenshots"

; ---- 設定の既定値 [セクション, キー, 既定値] --------------------------------
DEFAULTS := [
    ["Target","ExeName",          ""],
    ["Target","ExePath",          ""],               ; 落ちていたときに起動し直すため
    ["Target","LaunchWaitSec",    "120"],            ; 起動してから現れるまで待つ上限
    ["Target","AppSettleSec",     "180"],            ; 再起動のあと、画面が整うまで次の予定を始めない
    ["Target","FreshAppSec",      "900"],            ; 起動してからこの秒数以内のソフトは「起動直後」（一覧が開くのを長めに待つ）
    ["Target","TitleHint",        ""],
    ["Trace", "TickMs",           "1000"],
    ["Trace", "StallSec",         "10"],
    ["Trace", "MaxTrackedCtrls",  "60"],
    ["Trace", "MaxTextLen",       "60"],
    ["Output","LogRetentionDays", "30"],
    ["Output","DryRun",           "0"],
    ["Output","DryHopSec",        "3"],
    ["Output","LogLevel",         "INFO"],

    ; --- 画面のコントロール（実機 2026-09-13 で確定）-------------------------
    ["Ctrl","SelectCardClassNN",   "TImageButton6"],  ; カード画面「カードを選択します」
    ["Ctrl","SelectCardText",      "カードを選択します"],
    ["Ctrl","CardScanClassNN",     "TImageButton12"], ; カード画面「調査」
    ["Ctrl","CardScanText",        "調査"],
    ["Ctrl","AnamnesisNextClassNN","TImageButton1"],  ; 既往症「進む」
    ["Ctrl","AnamnesisNextText",   "進む"],
    ["Ctrl","SchemeScanClassNN",   "TImageButton4"],  ; スキーム「調査」
    ["Ctrl","SchemeScanText",      "調査"],
    ["Ctrl","SchemeBackClassNN",   "TImageButton3"],  ; スキーム「カードインデックス」
    ["Ctrl","SchemeBackText",      "カードインデックス"],
    ["Ctrl","DialogOkClassNN",     "TImageButton1"],  ; 完了ダイアログ「はい」
    ["Ctrl","LoginText",          "ログイン"],      ; 起動直後のメニュー画面を通る
    ; ★どの画面からでもカード選択へ戻るため★（2026-09-29 指摘）
    ;   解析やエタロンの画面には「カードインデックス」が無く、「終了」で 1 つ戻る。
    ["Ctrl","ExitText",           "終了"],          ; 1 つ前の画面へ戻るボタン
    ["Ctrl","ExitMaxPress",       "6"],             ; 何回まで戻ってよいか
    ["Ctrl","DialogOkText",        "はい"],
    ["Ctrl","RecordCountClassNN",  ""],               ; 調査履歴の件数（読めれば G2 に使う）
    ["Ctrl","AnchorLeftText",      "インタラクティブ既往症"],
    ["Ctrl","AnchorRightText",     "調査"],
    ["Ctrl","SchemeRowRefText",   "現在の分析"],
    ["Model","ModelName",         "18D"],           ; 18D / MetaAnalyzer
    ["Model","SelectedColor",     ""],              ; 空ならモデルの既定値を使う
    ["Model","NormalColor",       ""],
    ["Model","HoverTest",         "0"],            ; 1 = カーソルを当てて色が変わるかで判定
    ["Ctrl","HighlightBlueMin",   "20"],            ; （旧方式。いまは使わない）
    ["Ctrl","HighlightHitMin",    "3"],
    ["Ctrl","HighlightStrongMin", "20"],            ; 一覧のなかで「選ばれている」と読むのに要る青い点の数（3.10.29）
    ["Wait","SchemeOpenRetrySec", "20"],             ; 一覧が開かないときに押し直す間隔
    ["Wait","SchemeSettleSec",    "6"],
    ["Ctrl","TherapyClickX",       ""],               ; アンカーが使えないときの予備
    ["Ctrl","TherapyClickY",       ""],
    ["Ctrl","IndicatorClass",      "TFormDiagn"],     ; セラピー実行中の指標（v4 と同じ）
    ["Ctrl","SchemeBusyTitleHint", "共振周波数を決定"], ; 調査中の Polling のウィンドウ名

    ; --- 顧客の選択 ---------------------------------------------------------
    ["Select","SearchBoxClassNN",       ""],
    ["Select","ListClassNN",            ""],
    ["Select","LastNameFieldClassNN",   ""],
    ["Select","MiddleNameFieldClassNN", ""],          ; 同姓同名の別カードを見分けるため
    ["Select","FirstNameFieldClassNN",  ""],
    ["Select","ListFirstRowX",          "0"],
    ["Select","ListFirstRowY",          "0"],
    ["Select","ListRowPitchY",          "0"],        ; 行の間隔（0 なら次の行を試さない）
    ["Select","ListMaxRows",            "5"],        ; 何行目まで試すか
    ["Select","NameSeparator",          " "],
    ["Select","VerifyPatientName",      "1"],
    ["Select","SettleChecks",           "3"],
    ; カーソルに反応したとみなす色の差（別モデルで調整できるように）
    ["Select","HoverDiffMin",           "12"],
    ["Select","SettleIntervalMs",       "300"],
    ["Select","SettleTimeoutSec",       "15"],

    ; --- 実行内容 -------------------------------------------------------------
    ["Run","LastName",            ""],
    ["Run","FirstName",           ""],
    ["Run","MiddleName",          ""],
    ; --- 利用の期限（第 1 段階：通信なし。鍵ファイルを手で配る）---
    ;   ★既定は 0（警告するだけで止めない）★
    ;   1 にすると、鍵が無い・期限切れのときに実行系を止める。
    ;   配布を始めるときに 1 にする。最初から 1 にすると、
    ;   鍵を配り忘れた瞬間に自分の運用まで止まる。
    ["License","LicenseGraceDays", "7"],             ; 期限後この日数は動く（毎回警告）
    ; ★2 週間前から予告する★（2026-09-23 指摘）
    ;   30 日前からだと、まだ先の話なので読み流される。
    ;   14 日なら「そろそろ連絡しよう」と思える距離。
    ;   config.ini で人ごとに変えられる。
    ["License","LicenseWarnDays",  "14"],            ; この日数前から予告する
    ["Run","RunInvestigation",    "1"],
    ["Run","TherapyCount",        "3"],
    ["Run","ScanTypeName",        "詳細"],
    ["Run","ManualName",          "なし"],
    ; ★調査の項目数の下限★（2026-09-28 指摘）
    ;   以前は「その人の前回の半分」を下限に引き上げていたが、
    ;   ふだん多い方が少なめに終わっただけで運転が止まっていた。
    ;   固定の下限だけで見る。前回の数は参考として知らせるだけにする。
    ["Run","MinScanItems",        "10"],
    ["Run","JobRetryMax",         "1"],             ; 調査が空振りしたときのやり直し回数
    ["Run","PollIntervalMs",      "3000"],
    ["Run","StableChecks",        "5"],
    ["Run","RestBetweenSec",      "0"],
    ["Run","VerifyTimeoutSec",    "30"],

    ; --- 待ち時間 -------------------------------------------------------------
    ["Wait","HomingTimeoutSec",       "120"],
    ["Wait","TransitionTimeoutSec",   "120"],
    ["Wait","AnamnesisTimeoutSec",    "60"],
    ["Wait","SchemeListWaitSec",      "90"],
    ["Wait","ScanStartTimeoutSec",    "90"],
    ["Wait","ScanOpenTimeoutSec",     "300"],
    ["Wait","ScanOpenRetrySec",       "75"],
    ["Wait","ScanStallTimeoutSec",    "300"],
    ["Wait","DialogWaitSec",          "60"],
    ["Wait","DialogGraceSec",         "8"],
    ["Wait","TherapyStartTimeoutSec", "90"],
    ["Wait","TherapyMaxSec",          "5400"],

    ; --- 安全装置 -------------------------------------------------------------
    ["Safety","BaseClicks",           "16"],
    ["Safety","MaxSameClick",         "5"],
    ["Safety","RetryGapSec",          "10"],
    ["Safety","MaxClicksExtra",       "3"],
    ["Safety","MinClickGapSec",       "2"],
    ["Safety","MaxRuntimeSec",        "28800"],
    ["Safety","MaxUnattendedCycles",  "10"],
    ; ★セラピー 1 回の下限は 90 秒★（2026-09-23 カマヤン指示）
    ;   調査の項目数が少ない方は 2 分半で終わることが実機で確認された。
    ;   180 秒だと正常なセラピーまで「短すぎる」と中止していた。
    ["Safety","ExpectedCycleMinSec",  "90"],
    ["Safety","ExpectedCycleMaxSec",  "5400"],
    ["Safety","PlanCycleSec",        "1800"],
    ["Safety","CycleTolerancePct",    "40"],
    ["Safety","AbortOnAnomaly",       "1"],
    ["Safety","MaxConsecutiveFailures","3"],

    ["License","UserCode",            ""],             ; 利用者コード（オンライン確認に使う）

    ; ★既定で取得先が入っている★ 新しい PC に配った直後でも更新できるようにする
    ;   （公開リポジトリの URL。秘密は含まない／2026-09-22）
    ["Update","UpdateUrl",            ""],             ; 版番号だけを書いた小さなテキストの URL（空なら埋め込みを使う）
    ["Update","UpdateZipUrl",         ""],             ; 配布 zip の URL（空なら埋め込みを使う）

    ; ★通知（V3）★ 既定は OFF。意図して入にしたときだけ送る
    ["Notify","NotifyEnabled",     "0"],            ; 通知そのものの入切
    ["Notify","NameStyle",         "family"],       ; 宛名 none/family/full
    ; ★送信しない時間帯 1 つだけ★ ためた分は「明けたとき」に送る。
    ;   送信時刻を別に持たせると、時間帯の外を指せてしまう（2026-09-30 に整理）。
    ["Notify","QuietFrom",         "2100"],         ; 送信しない時間帯のはじまり
    ["Notify","QuietTo",           "0800"],         ; 送信しない時間帯の終わり（＝ためた分を送る時刻）
    ["Notify","MorningTime",       "0800"],         ; 3.6.4 以前の名前。QuietTo へ引き継ぐためだけに残す
    ; 顧客の登録（QR を 1 回読むだけで済ませるための仕組み）
    ["Notify","LiffId",            ""],             ; このセラピストの LIFF ID
    ["Notify","ShopName",          ""],             ; 登録用のページに出す名前（屋号）
    ["Notify","LineOaId",          ""],             ; LINE 公式アカウントの ID（@から始まる）
    ["Notify","RegisterPage",      "https://therapyreport.jp/"],
    ["Notify","RegisterApi",       "https://script.google.com/macros/s/AKfycbxZy7hP0-oSJED1hWNhRV4mW8aW4byQm06rG85oHjFaoRmJkMLoc8QnylGddz_5m5ED/exec"],
    ["Notify","MailFrom",          ""],             ; 差出人（自分の Gmail）
    ["Notify","MailAdmin",         ""],             ; 異常の知らせ先（空なら差出人）
    ["Notify","NotifyAdminOnDone", "0"],            ; 完了も管理者に知らせるか
    ["Notify","PreNotifyEnabled",  "0"],            ; 事前のお知らせを使うか（F-9）
    ["Notify","PreNotifyLeadMin",  "30"],           ; 予告を、送信しない時間帯の何分前に送るか
    ["Notify","LineAdminId",       ""],             ; 管理者の LINE ユーザー ID
    ["Scheduler","SchedulerTickSec",  "60"],
    ["Scheduler","MaxJobsPerDay",     "8"],
    ["Scheduler","StartLateHours",    "10"],              ; 順番待ちの予定を、予定の時刻から何時間まで開始してよいか
    ["Scheduler","StartIdleMin",      "10"],             ; PC の操作がない状態が何分続いたら予定を開始するか（0＝待たない）
    ["Scheduler","RestBetweenJobsSec","60"],
    ["Scheduler","ResumeMaxTries",    "2"],              ; 中断した予定の続きを試す回数の上限
    ["Scheduler","ResumeMaxHours",    "6"],              ; 中断から、これを過ぎたら続きはやらない（人に返す）
    ; ★稼働の記録・ログの送信★ LogShare は本人がオンにしたときだけ送る。既定はオフ
    ["Telemetry","LogShare",       "0"],            ; 1 = 動作ログを、顧客の氏名を置き換えて開発者へ送る
    ["Telemetry","TeleHbSec",      "600"],          ; 稼働の記録を送る間隔（秒）
    ["Debug","ForcePlan",          ""],               ; ★試験用★ general と書くと、一般として動かす（制限が効くかの確認用）
    ["Debug","ForceMax",           "5"]               ; 試験用に一般として動かすときの上限
]

; ---- 画面の見分け方 ---------------------------------------------------------
;  2026-09-09 の実機 /trace で、対象ソフト（18D-NLS.exe）の全画面クラスが確定した。
;  推測に頼らず、まずこの表で判定する。表にないクラスだけ署名テキストで推測する。
SCREEN_CLASSES := Map(
    "TFormMenu",          "S0_Menu",        ; メインメニュー（ログイン/設定/終了）常時開いている
    "TFormPacients",      "S1_Index",       ; 患者一覧（「カードを選択します」で開く）
    "TFormCartateca",     "S2_Card",        ; カード画面（title は「カードインデックス」）
    "TpfFormEasyPolling", "S2b_Anamnesis",  ; インタラクティブ既往症（「調査」の直後に出る）
    "TpfFormPolling",     "S3_Scheme",      ; 調査のスキーム
    "TFormHardest",       "S4_ScanItem",    ; 項目ごとのスキャン画面（title に臓器名）
    "TFormDiagn",         "S5_Indicator",   ; 指標窓（title は数字。進捗の鼓動）
    "TMessageForm",       "Dialog")         ; 完了ダイアログ（「はい」1 個・title は DlgInformation）

;  未知のクラス用のフォールバック。上から順に照合し、最初に当たったものを採る。
SCREEN_SIGS := [
    ["Dialog",      ["DlgInformation"]],
    ["P1_Progress", ["心身スクリーニング"]],
    ["S4_ScanItem", ["ポーズ", "再開する", "再開"]],
    ["S3_Scheme",   ["インタラクティブ既往症", "マニュアル選択", "調査タイプ"]],
    ["S2_Card",     ["新カード", "カードを選択します", "ビュー結果", "比較分析"]],
    ["S1_Index",    ["検索"]]
]

; ---- 対象ソフトの候補（/setup の自動検出用）---------------------------------
KNOWN_EXES := ["META ANALYZER.exe", "METAANALYZER.exe", "18D-NLS.exe", "18DNLS.exe", "MetaAnalyzer.exe"]

; ---- グローバル -------------------------------------------------------------
;  ※ AutoTherapy v4 と同じ流儀。使う関数の側で必ず `global` を宣言すること。
C := Map()          ; 設定
G := {              ; 実行時状態
    mode:    "menu",
    pid:     0,
    logFile: "",
    badArgs: "",       ; 知らない指定（/xxx）。起動ログに残すだけ
    fromMenu: false,   ; メニューから始めた実行か（終わったらメニューへ戻す）
    backTo:   "more",  ; 設定を保存したあとに戻る先（more＝設定／wizard＝初期設定）
    ; --- ジョブ用（ここは ResetJobState() が毎回すべて初期化する）--- ★JOBSTATE-BEGIN★
    state:   "idle",   stateTS: "",  startTS: "",  stopping: false,
    wantSei: "",       wantMei: "",  wantMid: "",  gotSei: "",   gotMei: "",   gotMid: "",
    searched: false,   rowClicked: false,   rowTry: 1,   lastCard: "",   rowExtra: 0,
    jobRetry: 0,       ; カード選択からやり直した回数
    homeExit: 0,       ; 起点へ戻るために「終了」を押した回数
    openMiss: 0,       ; 一覧を開けなかった回数
    clicks:  0,        lastClickTS: "",
    repeat:  0,        lastTarget: "",   lastTargetState: "", stateClickTS: "",
    cycle:   0,        cycleStartTS: "", durations: [], stable: 0,
    maxGap:  0,        therapySeenTS: "", runLogTS: "",
    scanBefore: "",    scanStartTS: "",  scanProgressTS: "",
    scanItems: 0,      scanSec: 0,       lastScanItem: "", dialogSeen: false,
    needCheck: "",     logLost: 0,
    optStep: 0, optTS: "", optTries: 0, optBusy: false, optWarn: "",
    optOff: 0, optLast: 0, optNoBtn: 0, optAlt: "",
    statusTS: "",
    ; ★JOBSTATE-END★
    ; --- スケジューラ用 ---
    schedOn: false,     schedRunning: false, schedCurrent: "",
    schedDueTs: "",     schedSlotTs: "",     preDone: false,
    schedDone: 0,       schedFailed: 0,      schedSkipped: 0,     schedCheck: 0,
    schedDay: "",
    logBuf: [],         logLate: 0,          ; ログに書き足せていない行（ジョブをまたいで持つ）
    resumeQuiet: false,                          ; 見張り（/resume）で、記録を 1 時間に 1 回に絞る間は true
    freshApp: false,
    appLaunchTS: "",    appWarnTS: "",
    appUpTS: "",        appSettleLogTS: "",
    resumeRun: false,   resumeNote: "",
    appAlive: true,     appDownTS: "",   appTryTS: "",
    schedFailStreak: 0, schedStartTS: "", lastJobEnd: "", pcBusy: false,
    skipSelect: false, manualJob: false,
    useOpenCard: false,   ; 1 人だけ実行で「いま開いているカード」を使う
    notifierIdle: "",     ; 送信係が「送るものが無い」と気づいた時刻
    ; --- 運転パネル用 ---
    panel: "",         panelState: "", panelWho: "", panelJob: "",
    panelSub: "",      panelNext: "",  panelNextTS: "", panelPend: "", panelBtns: []
}

; 確認待ちの一覧画面の作業用
PENDUI := Map()

; 予定の編集画面の作業用（一覧・編集中かどうか）
;   ★EDIT という名前は使えない★
;     AHK v2 には組み込み関数 Edit() があり、大文字小文字を区別しないため
;     EDIT := Map() が "This Func cannot be used as an output variable" で落ちる。
;     変数名は必ず AHK の組み込み関数・変数と衝突しないものにすること。
SCHEDUI := Map()
REGUI   := Map()        ; 開いている予定の編集画面（登録を受け取ったら、その場で欄に入れる）

Main()

;==============================================================================
;  エントリポイント
;==============================================================================
; ★無人で動いているとき、予期しないエラーで窓を出して止まらない★（3.10.36）
;   AutoHotkey は、予期しないエラーが起きると「Error: …」の窓を出し、押されるまでそのスレッドを止める。
;   夜の運転中に出ると、朝まで（あるいは何日も）止まったままになる（2026-10-22 の 43 時間の停止は、これの疑い。
;   2026-11-01 には通知の送信待ちの確認で実際に出た）。
;   無人のとき（運転中・見張り・送信係）は、ログに残して窓は出さず、運転の続きを動かし直す。
;   10 分のあいだに 4 回続いたら、そのジョブは中止する（同じエラーを延々と繰り返さない）。
;   人が操作しているとき（メニューなど）は、いつもどおり窓で知らせる。
UnhandledError(e, mode) {
    global G
    static errs := []
    unattended := false
    try unattended := (G.schedOn || G.mode = "resume" || G.mode = "notifier")
    if (!unattended)
        return 0
    try Log("ERROR", Format("予期しないエラー（窓は出さずに続けます）: {1}／行 {2}／{3}", e.Message, e.Line, e.What))
    keep := []
    for t in errs {
        if (DateDiff(A_Now, t, "Seconds") < 600)
            keep.Push(t)
    }
    keep.Push(A_Now)
    errs := keep
    try {
        if (G.schedOn) {
            if (G.schedRunning && errs.Length >= 4) {
                errs := []
                Abort("予期しないエラーが 10 分のあいだに 4 回続きました。最後: " . e.Message)
            } else {
                if (G.schedRunning)
                    SetTimer(Tick, -2000)              ; 止まったジョブの続きを、動かし直す
                SetTimer(SchedTick, -5000)
            }
        }
    }
    return 1
}

Main() {
    global C, G, LOGDIR, LOGCOPY, APP_VER, APP_BUILD, CFG, SCHEDINI, APP_NAME
    if !DirExist(LOGDIR)
        DirCreate(LOGDIR)
    G.logFile := LOGDIR "\" FormatTime(A_Now, "yyyy-MM-dd") ".log"
    OnError(UnhandledError)
    ; 置き場所を移した最初の日：従来の場所に今日のログがあれば、そのコピーから続ける（書き出しで上書きして短くしない）
    if (LOGDIR != LOGCOPY && !FileExist(G.logFile) && FileExist(LOGCOPY "\" FormatTime(A_Now, "yyyy-MM-dd") ".log"))
        try FileCopy(LOGCOPY "\" FormatTime(A_Now, "yyyy-MM-dd") ".log", G.logFile)
    OnExit(LogExitFlush)                           ; 終わるとき、書き足せていない行を書く
    RotateLogs()

    ParseArgs()
    ; ★利用者の設定を、更新で消さないための仕組み★
    ;   配布 zip には config.default.ini / schedule.default.ini だけを入れる。
    ;   実際に使う config.ini / schedule.ini は、無いときだけここで作る。
    ;   （以前は zip に本体名で入れていたため、上書き解凍で予定が消えていた）
    EnsureUserFile(CFG,      A_ScriptDir "\config.default.ini")
    EnsureUserFile(SCHEDINI, A_ScriptDir "\schedule.default.ini")
    LoadConfig()
    MigrateConfig()                                ; 古い既定値の手当て
    ; ログ送信の専用窓。利用確認や更新の窓を経由せず、運転には触れない。
    if (G.mode = "logreport") {
        ModeLogReport()
        return
    }
    ; ★見張りは 5 分ごとに走る★
    ;   毎回ログへ書くと 1 日 288 行になり、本体の書き込みと取り合って
    ;   【別の行】が消える（2026-10-05、1 回の運転で 46 行を取りこぼした）。
    ;   動いている証拠は別のファイルに残し、ログは 1 時間に 1 回だけにする。
    if (G.mode = "resume") {
        prevSeen := WatchSeenAt()
        WatchSeenWrite()
        hourLine := (prevSeen = "" || SubStr(prevSeen, 1, 10) != FormatTime(A_Now, "yyyyMMddHH"))
        if (hourLine) {
            Log("INFO", "起動 mode=resume ver=" APP_VER " build=" APP_BUILD "（5 分ごと／記録は 1 時間に 1 回）")
            LogCopyOut()                           ; ログを従来の場所（同期される側）へ写す
        }
        ; ★「利用の期限」「すでに動いています」も、同じく 1 時間に 1 回に絞る★（2026-10-13）
        ;   これまで起動の 1 行だけを絞っていて、残りの 2〜3 行は 5 分ごとに書いていた
        ;   （1 日 約 580 行。ほとんど「何もせず終わります」）。ログへの書き込みの取り合いも増やしていた。
        G.resumeQuiet := !hourLine
    } else {
        Log("INFO", "起動 mode=" G.mode " ver=" APP_VER " build=" APP_BUILD)
    }
    if (G.badArgs != "")
        Log("WARN", "知らない指定がありました: " G.badArgs "（メニューを開きました）")
    ; --- 利用の期限を見る（既定では止めない。記録だけ残す）---
    PassAutoRenew()                                ; 通行証を静かに取り直す（画面は出ない）
    TelemetryTick()                                ; 稼働の記録（見張りの回だけ。運転とは別のプロセス）
    lic := LicenseCheck()
    planLog := ""
    try planLog := PlanLabel()
    ; 見張りで、問題がなければ（state が ok）、絞っている間は書かない。問題があるときは必ず書く。
    if (!G.resumeQuiet || lic["state"] != "ok")
        Log("INFO", Format("利用の期限: {1}{2}{3}{4}", lic["state"]
            , lic["name"] = "" ? "" : "／" lic["name"]
            , lic["why"] = "" ? "" : "／" lic["why"]
            , planLog = "" ? "" : "／区分 " . planLog))
    ; ★ここでは止めない★ 実行系の入口（LicenseGate）で判定する。
    ;   起動時の mode で止めると、メニュー経由の実行を取りこぼす。

    ; ★知らせるのは、人がメニューを開いたときだけ★
    ;   夜間に無人で動いているなら、登録はすでに済んでいる（2026-09-19 指摘）。
    ;   ただし実行の入口（/run /schedule /therapy）で窓を出すと、
    ;   押されるまで運転が始まらない。夜に始めて離席したら朝まで動かない。
    ;   実行系の可否は LicenseGate が判断するので、ここでは黙る。
    if ((G.mode = "menu" || G.mode = "more" || G.mode = "code") && LicenseNudge()) {
        ModeCode()                                 ; 「いま入れる」を選んだ
        return
    }

    ; ★新しい版のお知らせも、人が開いたときだけ★
    if (G.mode = "menu" || G.mode = "more" || G.mode = "code") {
        if (nv := UpdateCheck()) {
            msg := "新しい版 " . nv . " が出ています。`n`n"
                 . "いまお使いの版: " . VerNumOnly(APP_VER) . "`n`n"
            if (UpdateUrlOf("zip") = "") {
                MsgBox(msg . "更新方法は、お渡しした案内をご確認ください。"
                    , APP_NAME . " - 新しい版のお知らせ", "Iconi 4096")
            } else if (MsgBox(msg . "いま更新しますか？（設定や予定はそのまま残ります）"
                    , APP_NAME . " - 新しい版のお知らせ", "YesNo Iconi 4096") = "Yes") {
                ModeUpdate()
                return
            }
        }
    }

    switch G.mode {
        case "run":      ModeRun()
        case "schedule": ModeSchedule()
        case "schededit": ModeScheduleEditor()
        case "therapy":   ModeTherapy()
        case "teachscan": ModeTeachScan()
        case "teachcount": ModeTeachCount()
        case "code":      ModeCode()
        case "verifytest": ModeVerifyTest()
        case "update":     ModeUpdate()
        case "model":      ModeModel()
        case "schemename": ModeSchemeNames()
        case "notify":    ModeNotify()
        case "notifier":  ModeNotifier()
        case "secretcheck": ModeSecretCheck()
        case "mail":      ModeMail()
        case "line":      ModeLine()
        case "register":  ModeRegister()
        case "diag":      ModeDiag()
        case "wizard":    ModeWizard()
        case "resume":    ModeResume()
        case "more":      ModeMore()
        case "dryrun":   (C["DryRun"] := "1", ModeRun())
        case "setup":    ModeSetup()
        case "trace":    ModeTrace()
        case "listread": ModeListRead()
        case "pickrow":  ModePickRow()
        case "inspect":  ModeInspect()
        case "watchall": ModeWatchAll()
        case "doctor":   ModeDoctor()
        default:         ModeMenu()
    }
}

;==============================================================================
;  INI（UTF-8）の読み書き
;  ※ Windows 標準の IniRead/IniWrite は BOM 無しファイルを ANSI として扱うため、
;     UTF-8 の設定ファイルでは日本語が壊れる。そのため自前で実装している。
;     （AutoTherapy v4 と同一実装）
;==============================================================================
IniLoad(file) {
    m := Map()
    if !FileExist(file)
        return m
    txt := ""
    try txt := FileRead(file, "UTF-8")
    catch
        return m
    txt := StrReplace(txt, Chr(0xFEFF), "")      ; BOM を除去
    sec := "Default"
    Loop Parse, txt, "`n", "`r" {
        line := Trim(A_LoopField)
        if (line = "" || SubStr(line, 1, 1) = ";" || SubStr(line, 1, 1) = "#")
            continue
        if (SubStr(line, 1, 1) = "[") {
            sec := Trim(line, "[] `t")
            continue
        }
        pos := InStr(line, "=")
        if (pos < 2)
            continue
        if !m.Has(sec)
            m[sec] := Map()
        m[sec][Trim(SubStr(line, 1, pos - 1))] := StripInlineComment(SubStr(line, pos + 1))
    }
    return m
}

; 値のうしろに書かれたコメント（" ;" 以降）を取り除く。
;   INI では「TherapyCount=0   ; セラピーなし」のように書くのが自然で、README でもそう例示している。
;   ※ 直前が空白の ";" だけを対象にする（値そのものに ";" を含む場合を壊さないため）
StripInlineComment(v) {
    v := "" . v
    pos := RegExMatch(v, "[ \t];")
    if (pos > 0)
        v := SubStr(v, 1, pos - 1)
    return Trim(v)
}

; 落ちない整数変換。数字として読めなければ既定値を返す。
;   ★Integer() は数字でない文字列を渡すと例外で落ちる。設定ファイル由来の値には必ずこちらを使う
ToInt(v, def := 0) {
    t := StripInlineComment(v)
    if RegExMatch(t, "^-?\d+$")
        return Integer(t)
    return def
}

; 利用者用のファイルが無ければ、ひな型から作る。あれば触らない。
EnsureUserFile(target, sample) {
    if FileExist(target)
        return
    if !FileExist(sample)
        return
    try FileCopy(sample, target, 0)
}

IniGet(m, section, key, default := "") {
    if (m.Has(section) && m[section].Has(key) && m[section][key] != "")
        return m[section][key]
    return default
}

; 節をまるごと入れ替える。
;   キーを 1 つずつ書くと、古いキーが残り、書くたびに行が増えていく。
;   座標表のように「その節の内容がまとまって決まる」ものはこちらを使う。
;   ※ その節に書かれたコメントは消えます（機械が書く節だけに使うこと）
IniSetSection(file, section, pairs) {
    txt := ""
    if FileExist(file) {
        try txt := FileRead(file, "UTF-8")
    }
    txt := StrReplace(txt, Chr(0xFEFF), "")
    out := [], inSec := false, wrote := false
    Loop Parse, txt, "`n", "`r" {
        line := A_LoopField
        t := Trim(line)
        if (SubStr(t, 1, 1) = "[") {
            if (inSec && !wrote) {
                for pr in pairs
                    out.Push(pr[1] "=" pr[2])
                out.Push("")                       ; 次の節との間を空ける
                wrote := true
            }
            inSec := (Trim(t, "[] `t") = section)
            out.Push(line)
            continue
        }
        if (inSec)
            continue                               ; 古い中身は捨てる
        out.Push(line)
    }
    if (inSec && !wrote) {
        for pr in pairs
            out.Push(pr[1] "=" pr[2])
        wrote := true
    }
    if (!wrote) {
        out.Push("")
        out.Push("[" section "]")
        for pr in pairs
            out.Push(pr[1] "=" pr[2])
    }
    body := ""
    for line in out
        body .= line "`n"
    IniWriteBody(file, body)
}

; ★同じ節の複数項目を、1 回の書き直しで保存する★
;   IniSet は 1 項目ごとに「削除してから書き直す」。5 項目なら 5 回。
;   state.ini は実行履歴も持つので、書き直しの回数はそのまま危険の量になる
;   （その瞬間に落ちるとファイルごと失われる）。まとめれば 1 回で済む。
; ★書き戻しは、別名に書いてから置き換える★
;   「消してから書く」と、その一瞬だけファイルが無くなる。
;   顧客の登録を入れてから、見回りが 20〜60 秒ごとに
;   複数のプロセスから読み書きするようになり、ちょうど当たると
;   ・読む側は空に見える
;   ・書く側は例外で止まり、画面が閉じないまま残る（2026-10-03）
;   取れなければ少し待って数回やり直す。それでも駄目なら元のファイルは壊さない。
IniWriteBody(file, body) {
    tmp := file . ".tmp"
    Loop 5 {
        try {
            try FileDelete(tmp)
            FileAppend(CRLF(body), tmp, "UTF-8")
            FileMove(tmp, file, true)              ; 置き換えは一度に
            return true
        }
        Sleep(80)
    }
    try FileDelete(tmp)
    Log("WARN", "書き込めませんでした（ほかが開いている可能性）: " . file)
    return false
}

IniSetMany(file, section, pairs) {
    txt := ""
    if FileExist(file) {
        try txt := FileRead(file, "UTF-8")
    }
    txt := StrReplace(txt, Chr(0xFEFF), "")
    left := Map()
    for k, v in pairs
        left[k] := v
    out := [], inSec := false, secSeen := false
    Loop Parse, txt, "`n", "`r" {
        line := A_LoopField
        t := Trim(line)
        if (SubStr(t, 1, 1) = "[") {
            if (inSec) {                          ; 節の終わりで、残りを書き足す
                for k, v in left
                    out.Push(k "=" v)
                left := Map()
            }
            inSec := (Trim(t, "[] `t") = section)
            if inSec
                secSeen := true
        } else if (inSec) {
            pos := InStr(t, "=")
            if (pos > 1) {
                k := Trim(SubStr(t, 1, pos - 1))
                if (left.Has(k)) {
                    out.Push(k "=" left[k])
                    left.Delete(k)
                    continue
                }
            }
        }
        out.Push(line)
    }
    if (left.Count > 0) {
        if (!secSeen) {
            out.Push("")
            out.Push("[" section "]")
        }
        for k, v in left
            out.Push(k "=" v)
    }
    body := ""
    for line in out
        body .= line "`r`n"
    IniWriteBody(file, body)
}

IniSet(file, section, key, value) {
    txt := ""
    if FileExist(file) {
        try txt := FileRead(file, "UTF-8")
    }
    txt := StrReplace(txt, Chr(0xFEFF), "")
    out := [], inSec := false, done := false, secSeen := false
    Loop Parse, txt, "`n", "`r" {
        line := A_LoopField
        t := Trim(line)
        if (SubStr(t, 1, 1) = "[") {
            if (inSec && !done) {                 ; セクション末尾に追記
                out.Push(key "=" value)
                done := true
            }
            inSec := (Trim(t, "[] `t") = section)
            if inSec
                secSeen := true
        } else if (inSec && !done) {
            pos := InStr(t, "=")
            if (pos > 1 && Trim(SubStr(t, 1, pos - 1)) = key) {
                out.Push(key "=" value)
                done := true
                continue
            }
        }
        out.Push(line)
    }
    if !done {
        if !secSeen {
            out.Push("")
            out.Push("[" section "]")
        }
        out.Push(key "=" value)
    }
    body := ""
    for line in out
        body .= line "`r`n"
    IniWriteBody(file, body)                      ; BOM 付き UTF-8 / CRLF で書き戻す
}

;==============================================================================
;  引数解析 / 設定
;==============================================================================
ParseArgs() {
    global G
    static modeMap := Map("/setup",    "setup",    "/trace",   "trace"
                        , "/listread", "listread", "/inspect", "inspect"
                        , "/watchall", "watchall", "/doctor",  "doctor"
                        , "/menu",     "menu",     "/run",     "run"
                        , "/dryrun",   "dryrun",   "/pickrow", "pickrow"
                        , "/schedule", "schedule"
                        , "/schededit", "schededit"
                        , "/therapy",   "therapy"
                        , "/teachscan", "teachscan"
                        , "/teachcount", "teachcount"
                        , "/more",      "more"
                        , "/resume",    "resume"
                        , "/code",      "code"
                        , "/verifytest", "verifytest"
                        , "/update",    "update"
                        , "/model",     "model"
                        , "/schemename", "schemename"
                        , "/wizard",    "wizard"
                        , "/notify",    "notify"
                        , "/notifier",  "notifier"
                        , "/secretcheck", "secretcheck"
                        , "/mail",      "mail"
                        , "/line",      "line"
                        , "/register",  "register"
                        , "/logreport", "logreport"
                        , "/diag",      "diag")
    ; ★知らない指定を、黙ってメニューにしない★
    ;   /resume が対応表に無く、見張り（5 分ごと）とスタートアップ登録が
    ;   「復帰」ではなく「メニューを開く」を実行していた。最小化した窓が
    ;   勝手に戻るうえ、落ちた運転を一度も拾えていなかった（2026-09-19 指摘）。
    G.badArgs := ""
    for a in A_Args {
        low := StrLower(Trim(a))
        if modeMap.Has(low) {
            G.mode := modeMap[low]
            continue
        }
        if (SubStr(low, 1, 1) = "/")
            G.badArgs .= (G.badArgs = "" ? "" : " ") . low
    }
}

; ★古い既定値のまま残っている設定を、1 回だけ現行の基準に合わせる★
;   config.ini は端末ごとに残るので、既定値を変えただけでは
;   配布済みの PC に届かない（2026-09-23）。
MigrateConfig() {
    global C, CFG
    if (Trim(IniRead(CFG, "Safety", "MinCycle90", "")) != "")
        return                                 ; もう済んでいる
    cur := ToInt(IniRead(CFG, "Safety", "ExpectedCycleMinSec", ""), 0)
    if (cur = 180) {                           ; 昔の既定値だけを直す
        IniSet(CFG, "Safety", "ExpectedCycleMinSec", 90)
        C["ExpectedCycleMinSec"] := 90
        Log("INFO", "セラピー 1 回の下限を 180 秒から 90 秒に変更しました（基準の見直し）")
    }
    IniSet(CFG, "Safety", "MinCycle90", 1)     ; 二度目は走らせない
}

LoadConfig() {
    global C, CFG, DEFAULTS
    m := IniLoad(CFG)
    for row in DEFAULTS
        C[row[2]] := IniGet(m, row[1], row[2], row[3])
    ; ★モデル専用の値があれば、そちらで上書きする★
    ;   例: [Ctrl.MetaAnalyzer] ListFirstRowY=...  座標や部品名はモデルで違う。
    mdl := Trim(C.Has("ModelName") ? C["ModelName"] : "")
    if (mdl != "" && mdl != "18D") {
        for row in DEFAULTS {
            v := IniGet(m, row[1] . "." . mdl, row[2], "")
            if (Trim(v) != "")
                C[row[2]] := v
        }
    }
}

CI(k) {
    global C
    return ToInt(C.Has(k) ? C[k] : "", 0)
}
CS(k) {
    global C
    return C.Has(k) ? "" . C[k] : ""
}
CB(k) {
    global C
    v := StripInlineComment(C.Has(k) ? C[k] : "")
    return (v = "1" || v = 1 || v = true)
}
SecSince(ts) => (ts = "") ? 0 : DateDiff(A_Now, ts, "Seconds")
FmtTS(ts) => (ts = "") ? "-" : FormatTime(ts, "yyyy-MM-dd HH:mm:ss")

;==============================================================================
;  共通ヘルパ
;==============================================================================
; 全角英数・記号を半角へ。前後空白と & を除去（AutoTherapy v4 と同一）
Norm(s) {
    s := StrReplace(s, "&", "")
    s := Trim(s, " `t`r`n")
    out := ""
    Loop Parse, s {
        c := Ord(A_LoopField)
        out .= (c >= 0xFF01 && c <= 0xFF5E) ? Chr(c - 0xFEE0) : (c = 0x3000 ? " " : A_LoopField)
    }
    return Trim(out)
}

MyPid() => DllCall("GetCurrentProcessId", "uint")

; いま別の AutoMeta（実行系）が動いているか。動いていれば true
AnotherInstanceRunning() {
    ; 0x100000 = SYNCHRONIZE。開けたら存在する
    h := DllCall("OpenMutexW", "UInt", 0x100000, "Int", 0, "Str", "AutoMeta_Job_Singleton", "Ptr")
    if (h) {
        DllCall("CloseHandle", "Ptr", h)
        return true
    }
    return false
}

; いまジョブが動いているか（スケジュール運転でも、単独実行でも）
;   ★スケジュール運転中は schedRunning だけが根拠★
;     G.state はジョブが終わっても "cleanup" のまま残るため、
;     これを見ていると「待機中なのに実行中」と名乗ってしまう。
;     2026-09-15、待機中なのに自動セラピーを断られた原因。
JobInProgress() {
    global G
    if (G.schedOn)
        return G.schedRunning
    return (G.state != "" && G.state != "idle" && !G.stopping)
}

; 動作中の版が、自分の状況を書き出す。別プロセスから読むためのもの。
WriteLive() {
    global G, LIVEFILE, APP_VER
    o := "Pid=" MyPid() "`n"
      . "Ver=" APP_VER "`n"
      . "SchedOn=" (G.schedOn ? 1 : 0) "`n"
      . "Running=" (JobInProgress() ? 1 : 0) "`n"
      . "Manual=" (G.manualJob ? 1 : 0) "`n"
      . "Patient=" G.wantSei " " G.wantMei "`n"
      . "State=" G.state "`n"
      . "Cycle=" G.cycle "/" CI("TherapyCount") "`n"
      . "Key=" G.schedCurrent "`n"
      . "JobStart=" G.startTS "`n"
      . "JobMin=" EstimateMaxMin(CB("RunInvestigation"), CI("TherapyCount")) "`n"
      . "SchedRun=" (G.schedRunning ? 1 : 0) "`n"
      . "SchedStart=" G.schedStartTS "`n"
      . "SchedDone=" G.schedDone "`n"
      . "At=" A_Now "`n"
    try FileDelete(LIVEFILE)
    try FileAppend(CRLF(o), LIVEFILE, "UTF-8")
}

; live.txt を読む。書かれてから 5 分以上たっていたら、当てにしない。
ReadLive() {
    global LIVEFILE
    out := Map("SchedOn", "0", "Running", "0", "Manual", "0"
             , "Patient", "", "State", "", "Cycle", "", "fresh", false)
    if !FileExist(LIVEFILE)
        return out
    txt := ""
    try txt := FileRead(LIVEFILE, "UTF-8")
    txt := StrReplace(txt, Chr(0xFEFF), "")
    for line in StrSplit(txt, "`n", "`r") {
        pos := InStr(line, "=")
        if (pos > 1)
            out[Trim(SubStr(line, 1, pos - 1))] := Trim(SubStr(line, pos + 1))
    }
    if (out.Has("At") && RegExMatch(out["At"], "^\d{14}$"))
        out["fresh"] := (DateDiff(A_Now, out["At"], "Seconds") < 300)
    return out
}

; =============================================================================
;  利用の期限（ライセンス）— 第 1 段階
;   ★通信しない★ 鍵ファイルを読んで、期限と署名を見るだけ。
;   ★完全な錠前ではない★ AHK は中身が読めるので、本気の回避は防げない。
;     止められるのは「うっかりの又貸し」「期限切れの継続利用」まで（利用者に説明済み）。
;   鍵の発行は手元の _make_license.py で行う。配布物に発行機能は入れない。
; =============================================================================
; ★合言葉は廃止した（2026-09-21）★
;   ソースを一時的に公開してしまい、値が露出した。公開鍵方式へ移行し、
;   この値では何も偽造できないようにした。復活させないこと。

; 文字列の SHA-256（16 進）。Windows の暗号 API を使う
Sha256Hex(str) {
    static PROV_RSA_AES := 24, CALG_SHA_256 := 0x0000800c
    static CRYPT_VERIFYCONTEXT := 0xF0000000, HP_HASHVAL := 0x0002
    hProv := 0, hHash := 0
    if (!DllCall("advapi32\CryptAcquireContextW", "Ptr*", &hProv, "Ptr", 0, "Ptr", 0
                , "UInt", PROV_RSA_AES, "UInt", CRYPT_VERIFYCONTEXT))
        return ""
    out := ""
    if (DllCall("advapi32\CryptCreateHash", "Ptr", hProv, "UInt", CALG_SHA_256
               , "Ptr", 0, "UInt", 0, "Ptr*", &hHash)) {
        n := StrPut(str, "UTF-8") - 1
        buf := Buffer(n + 1, 0)
        StrPut(str, buf, "UTF-8")
        DllCall("advapi32\CryptHashData", "Ptr", hHash, "Ptr", buf, "UInt", n, "UInt", 0)
        size := 32
        hash := Buffer(size, 0)
        if (DllCall("advapi32\CryptGetHashParam", "Ptr", hHash, "UInt", HP_HASHVAL
                   , "Ptr", hash, "UInt*", &size, "UInt", 0)) {
            Loop size
                out .= Format("{:02x}", NumGet(hash, A_Index - 1, "UChar"))
        }
        DllCall("advapi32\CryptDestroyHash", "Ptr", hHash)
    }
    DllCall("advapi32\CryptReleaseContext", "Ptr", hProv, "UInt", 0)
    return out
}

; 鍵ファイルを読んで状態を返す。
;   state: none（未登録）/ broken（壊れている）/ forged（署名が合わない）
;          / wrongpc（別の PC 用）/ expired（期限切れ）/ grace（猶予中）
;          / soon（まもなく期限）/ ok
; ---- 通行証（オンライン確認）----------------------------------------------
; URL に載せられる形に直す（PC 名に日本語が入っても壊れないよう UTF-8 で）
UriEncode(s) {
    if (s = "")
        return ""
    n := StrPut(s, "UTF-8") - 1
    buf := Buffer(n + 1, 0)
    StrPut(s, buf, "UTF-8")
    out := ""
    Loop n {
        c  := NumGet(buf, A_Index - 1, "UChar")
        ch := Chr(c)
        if ((c >= 48 && c <= 57) || (c >= 65 && c <= 90) || (c >= 97 && c <= 122)
            || ch = "-" || ch = "_" || ch = "." || ch = "~")
            out .= ch
        else
            out .= "%" . Format("{:02X}", c)
    }
    return out
}

; 返事から 1 項目だけ取り出す（本格的な JSON 解析は要らない）
JStr(body, key) {
    if RegExMatch(body, '"' . key . '"\s*:\s*"([^"]*)"', &m)
        return m[1]
    return ""
}
JBool(body, key) {
    if RegExMatch(body, '"' . key . '"\s*:\s*(true|false)', &m)
        return (m[1] = "true")
    return false
}

; ---- 機器の識別値 ---------------------------------------------------------------
;   ★PC 名ではなく「機器そのもの」を見分ける★（PC 名を変えても同じ PC と分かるように）
;   Windows の MachineGuid に、このソフト専用の文字を足して SHA-256 にする。
;   生の値は送らない。取れない PC では PC 名から作る（窓口は「届かないときは PC 名で見る」）。
DeviceId() {
    static cached := ""
    if (cached != "")
        return cached
    guid := ""
    try guid := RegRead("HKLM\SOFTWARE\Microsoft\Cryptography", "MachineGuid")
    guid := Trim(guid)
    if (guid != "")
        cached := Sha256Hex("AutoMeta|device|" . guid)
    else
        cached := Sha256Hex("AutoMeta|name|" . StrLower(A_ComputerName))
    return cached
}

; 署名する本文（新しい通行証）。★窓口（Judge.js の sign3Body_）と同じ並び・同じ区切り★
;   name|expires|until|pc|dev|plan|maxTargets|upgradeUrl|mail|line
;   どの項目にも「|」を含めない（含んでいたら呼ぶ側が弾く）。
Sign3Message(nm, exp, unt, pc, dev, pl, mx, uu, ml, lineV) {
    return nm . "|" . exp . "|" . unt . "|" . pc . "|" . dev . "|" . pl . "|" . mx . "|" . uu
         . "|" . ml . "|" . lineV
}

; 区切りの「|」が混ざっていないか（混ざると、別の区切りで読ませて区分を書き換えられる）
HasPipe(arr) {
    for v in arr {
        if (InStr(v, "|"))
            return true
    }
    return false
}

; 区分の既定値＝制限なし。★通行証が無い・古い形のときは、今までどおり動かす★
; スタンダードプランの顧客数の上限の既定（窓口の値が届かないときに使う。商品設計：5 件）
StdLimitDefault() => 5

PlanInfoDefault() {
    return Map("plan", "business", "max", 0, "known", false, "grace", false, "lapsed", false
             , "left", 0, "upgradeUrl", "", "mail", "", "line", "", "was", "")
}

YmdDash(t) => SubStr(t, 1, 4) . "-" . SubStr(t, 5, 2) . "-" . SubStr(t, 7, 2)

; 手元の通行証を確かめる。通信はしない。
;   戻り値に "info"（区分・上限・案内先）を足した。通行証が読めたときだけ中身が入る。
;   ★区分を知りたいときは PlanKind() / PlanInfo() を使う（ここの文字を直接比べない）★
PassCheck() {
    global PASSFILE
    ng := Map("ok", false, "lic", "", "gone", false, "notice", "", "info", "")
    if (!FileExist(PASSFILE))
        return ng
    m   := IniLoad(PASSFILE)
    nm  := Trim(IniGet(m, "Pass", "Name", ""))
    exp := Trim(IniGet(m, "Pass", "Expires", ""))
    unt := Trim(IniGet(m, "Pass", "Until", ""))
    pc  := Trim(IniGet(m, "Pass", "Pc", ""))
    sig  := Trim(IniGet(m, "Pass", "Sign", ""))
    sig2 := Trim(IniGet(m, "Pass", "Sign2", ""))
    sig3 := Trim(IniGet(m, "Pass", "Sign3", ""))
    if (nm = "" || exp = "" || unt = "" || (sig2 = "" && sig3 = ""))
        return ng
    info := PlanInfoDefault()
    if (sig3 != "") {
        ; ---- 新しい通行証（区分つき）。機器ID で同じ PC かを見る -------------------------
        dev := StrLower(Trim(IniGet(m, "Pass", "Dev", "")))
        pl  := Trim(IniGet(m, "Pass", "Plan", ""))
        mx  := Trim(IniGet(m, "Pass", "MaxTargets", ""))
        uu  := Trim(IniGet(m, "Pass", "UpgradeUrl", ""))
        ml  := Trim(IniGet(m, "Pass", "Mail", ""))
        lineV := Trim(IniGet(m, "Pass", "Line", ""))
        if (HasPipe([nm, exp, unt, pc, dev, pl, mx, uu, ml, lineV]))
            return Map("ok", false, "lic", "", "gone", false, "notice", "broken", "info", "")
        if (!RsaVerify(Sha256Hex(Sign3Message(nm, exp, unt, pc, dev, pl, mx, uu, ml, lineV)), sig3))
            return Map("ok", false, "lic", "", "gone", false, "notice", "broken", "info", "")
        if (pl != "general" && pl != "business")
            return Map("ok", false, "lic", "", "gone", false, "notice", "broken", "info", "")
        if (dev != StrLower(DeviceId()))
            return Map("ok", false, "lic", "", "gone", false, "notice", "wrongpc", "info", "")
        info["plan"]  := pl
        info["max"]   := (pl = "general") ? ToInt(mx, StdLimitDefault()) : 0
        if (pl = "general" && info["max"] < 1)
            info["max"] := StdLimitDefault()
        info["known"] := true
        info["upgradeUrl"] := uu, info["mail"] := ml, info["line"] := lineV
        info["was"]   := Trim(IniGet(m, "Pass", "Was", ""))
    } else {
        ; ---- 旧い通行証（PC 名で見る）。従来どおり。区分は持たない＝制限なし ----------
        ;   ★新しい通行証の方を優先する★ 公開鍵で確かめる。
        if (!RsaVerify(Sha256Hex(nm . "|" . exp . "|" . unt . "|" . pc), sig2))
            return Map("ok", false, "lic", "", "gone", false, "notice", "broken", "info", "")
        if (pc != "" && StrLower(pc) != StrLower(A_ComputerName))
            return Map("ok", false, "lic", "", "gone", false, "notice", "wrongpc", "info", "")
    }
    u := StrReplace(unt, "-", ""), e := StrReplace(exp, "-", "")
    if (StrLen(u) != 8 || StrLen(e) != 8)
        return ng
    today  := FormatTime(A_Now, "yyyyMMdd")
    notice := Trim(IniGet(m, "Pass", "Notice", ""))
    ; ★停止の知らせは、通行証が長くても 14 日で止める★
    ;   一般・永久の通行証は 10 年ある。知らせを受けたあとも 10 年動いてしまわないように。
    endU := u
    if (notice != "") {
        nAt := Trim(IniGet(m, "Pass", "NoticeAt", ""))
        if (StrLen(nAt) >= 8) {
            capDay := FormatTime(DateAdd(SubStr(nAt, 1, 8) . "000000", 14, "Days"), "yyyyMMdd")
            if (capDay < endU)
                endU := capDay
        }
    }
    if (endU < today) {
        if (notice != "")
            ; ★終わった理由も返す★ 文面を理由別に出し分けるため（2026-09-19 点検）。
            return Map("ok", false, "lic", "", "gone", true, "notice", notice, "info", info)
        ; ★停止の知らせを受けていなければ、止めずに一般として動かす★（2026-10-07 決定）
        ;   ネットにつながらない事業者の PC が、2 週間で道具ごと止まらないように。
        ;   署名が正しいことが条件（ここまで来ているので確認済み）。
        info["plan"]   := "general"
        info["max"]    := StdLimitDefault()
        info["known"]  := true
        info["lapsed"] := true
        return Map("ok", true, "lic", Map("state", "offline", "name", nm, "expires", exp, "days", 0
            , "why", Format("確認できないまま通行証の期限（{1}）を過ぎました。"
                          . "つながるまで、スタンダードプラン（顧客 {2} 人まで・通知なし）として動作します", unt, info["max"]))
            , "gone", false, "notice", "", "info", info)
    }
    left := DateDiff(endU . "000000", today . "000000", "Days")
    info["left"] := left
    if (notice != "") {
        ; 終わりが決まっている。だが期限までは今までどおり動かす。
        return Map("ok", true, "lic", Map("state", "ending", "name", nm
            , "expires", exp, "days", left
            , "why", Format("{1} まで使えます（あと {2} 日）／理由: {3}"
                   , YmdDash(endU), left, Trim(IniGet(m, "Pass", "NoticeWhy", notice))))
            , "gone", false, "notice", "", "info", info)
    }
    ; ★つながらない日が続いていることを、黙って進行させない★
    ;   確認できないまま残り日数が減り、ある朝いきなり止まるのが最悪（2026-09-19 指摘）。
    chk := Trim(IniGet(m, "Pass", "Checked", ""))
    if ((chk = "" || DateDiff(A_Now, chk, "Hours") >= 26) && left <= 7) {
        return Map("ok", true, "lic", Map("state", "offline", "name", nm
            , "expires", exp, "days", left
            , "why", Format("ネットにつながらず確認できていません。{1} まで（あと {2} 日）は動きます"
                   , unt, left))
            , "gone", false, "notice", "", "info", info)
    }
    days := DateDiff(e . "000000", today . "000000", "Days")
    lic  := Map("state", "ok", "name", nm, "expires", exp, "why", "", "days", days)
    if (info["known"] && info["plan"] = "general") {
        ; ★一般には、期限も残り日数も出さない★（「ご利用中」とだけ出す）
        lic["why"] := (info["was"] = "business")
            ? "プロプランの期限が切れたため、スタンダードプランで動作しています" : "ご利用中（スタンダードプラン）"
    } else if (info["known"] && days < 0) {
        ; ★事業者の猶予中★ 期限は過ぎているが、通行証は猶予の終わりまで。
        info["grace"] := true
        lic["state"]  := "grace"
        lic["why"]    := Format("プロプランの期限（{1}）を過ぎています。あと {2} 日で、スタンダードプラン（顧客 {3} 人まで・通知なし）になります"
                              , exp, left, StdLimitDefault())
    } else if (SubStr(e, 1, 4) >= 2090) {
        lic["why"] := "ご利用中（期限なし）"
    } else {
        lic["why"] := Format("期限 {1} まであと {2} 日（通行証は {3} まで）", exp, days, unt)
        if (days <= CI("LicenseWarnDays")) {
            lic["state"] := "soon"
            if (info["known"] && info["plan"] = "business")
                lic["why"] .= "。期限後はスタンダードプラン（顧客 " . StdLimitDefault() . " 人まで・通知なし）になります"
        }
    }
    return Map("ok", true, "lic", lic, "gone", false, "notice", "", "info", info)
}

; ---- 区分（一般／事業者）-----------------------------------------------------------
;   ★判断のたびに通行証を読む★ 起動時にメモリへ写した値は、更新のあと古くなる。
;   ★区分の文字（"general" など）は、ここと PassCheck・PassRenew だけで扱う★
;   ほかの場所は PlanKind() / TargetLimit() を呼ぶ（_check.py が見張る）。
PlanInfo() {
    ; ★試験用：一般として動かす★ 制限が効くかを、実機で確かめるための指定。
    ;   「制限する」方向にしか働かない（一般にしかならない）ので、上限を外す抜け道にはならない。
    ;   メニューに「（試験用の設定）」と出るので、消し忘れに気づける。
    if (Trim(CS("ForcePlan")) = "general") {
        fi := PlanInfoDefault()
        fi["plan"]   := "general"
        fi["max"]    := ToInt(CS("ForceMax"), StdLimitDefault())
        if (fi["max"] < 1)
            fi["max"] := StdLimitDefault()
        fi["known"]  := true
        fi["forced"] := true
        return fi
    }
    p := PassCheck()
    if (IsObject(p["info"]))
        return p["info"]
    return PlanInfoDefault()
}

; "general" か "business"。通行証が無い・古い形のとき、鍵ファイル運用のときは "business"（制限なし）
PlanKind() => PlanInfo()["plan"]

; 一般か（区分の文字を、呼ぶ側で直接比べないための入口）
IsGeneralPlan() => (PlanKind() = "general")

; 一般のときだけ顧客の上限を返す。0 は上限なし（事業者）。読めなければ 10。
TargetLimit() {
    info := PlanInfo()
    if (info["plan"] != "general")
        return 0
    return (info["max"] >= 1) ? info["max"] : 10
}

; 顧客を 1 人と数える印。姓・名・ミドルネームが同じ行は同じ顧客。氏名が空なら ""。
;   ★同じ方の予定を 2 つ作っても 2 人にならない★
CustKey(p) {
    if (Trim(p["sei"]) = "" && Trim(p["mei"]) = "")
        return ""
    mid := p.Has("middle") ? p["middle"] : ""
    return StrLower(Trim(p["sei"]) . "|" . Trim(p["mei"]) . "|" . Trim(mid))
}

; 予定の一覧（配列）に含まれる顧客の数（有効・無効とも）
TargetCountOf(list) {
    seen := Map()
    for p in list {
        k := CustKey(p)
        if (k != "")
            seen[k] := true
    }
    return seen.Count
}

; 保存してある予定（schedule.ini）の顧客の数
TargetCount() {
    err := ""
    return TargetCountOf(LoadSchedule(&err))
}

; ============================================================================
;  スタンダードプランの顧客数の上限（3.10.2。既定は 5 件・PC 1 台ごと。窓口の値を使う）
; ============================================================================
;   ★本体の制限は「案内」★ ソースのまま配っているので、書き換えれば外せる。
;   人数と版は窓口へ送られ、シートで把握できる。防壁は窓口と規約。
;   数えるのは登録している顧客（無効も数える）。使わない方は削除して、上限以内に収めてもらう。

; お問い合わせ先。窓口の返事を使い、届かないときのために同じ既定値を本体にも持つ。
SupportInfo() {
    info := PlanInfo()
    url  := Trim(info["upgradeUrl"]), mail := Trim(info["mail"]), lineU := Trim(info["line"])
    if (lineU = "")
        lineU := "https://lin.ee/zxr0ojt"
    if (mail = "")
        mail := "support@therapyreport.jp"
    if (url = "")
        url := lineU                                ; 案内先が未設定のあいだは、問い合わせ先を使う
    return Map("url", url, "mail", mail, "line", lineU)
}

GuideOpen() {
    global APP_NAME
    u := SupportInfo()["url"]
    try {
        Run(u)
    } catch {
        MsgBox("案内を開けませんでした。`n`n次のところへお問い合わせください。`n`n　" . u
            , APP_NAME, "Icon! 4096")
    }
}

; 保存する顧客数 newCount が、一般の上限を超えて「増やす」保存か。
;   ★人数が減る保存・変わらない保存は通す★ 超えたまま整理していく途中を止めない。
LimitBlocks(newCount) {
    limit := TargetLimit()
    if (limit <= 0)
        return false                                ; 事業者は上限なし
    if (newCount <= limit)
        return false
    return (newCount > TargetCount())               ; 保存済みの人数より増えるときだけ止める
}

; 上限の案内。開くかを聞く。
LimitBox(n, atAdd := false) {
    global APP_NAME
    lim := TargetLimit()
    ; 「追加」を押した時点の案内には、同じ顧客の予定を増やす道（複製）を添える
    hint := atAdd ? "同じ顧客の予定を増やすときは、その行を選んで「複製」を押してください。`n`n" : ""
    r := MsgBox(Format("スタンダードプランは、顧客 {1} 人までです。（現在の登録：{2} 人）`n`n"
        . "{3} 人以上のご利用には、プロプランへの登録が必要です。`n"
        . "プロプランへ登録しない場合は、使わない方の予定を削除してください。`n`n"
        . "{4}"
        . "お返事には、数営業日いただきます。`n`n"
        . "プロプランのご案内を開きますか？", lim, n, lim + 1, hint)
        , APP_NAME . " - スタンダードプランの上限", "YesNo Icon! 4096")
    if (r = "Yes")
        GuideOpen()
}

; 保存してよいか。上限を超える「増やす保存」は通さず、案内を出す。
SchedSaveAllowed(list) {
    n := TargetCountOf(list)
    if (!LimitBlocks(n))
        return true
    LimitBox(n)
    return false
}

; 「追加」を押した時点で、新しい顧客を足せない状態か。足せないなら案内を出して true。
;   入力のあとで断ると、打ち込んだ内容が無駄になる（2026-10-10 指摘）。
SchedAddAtLimit(list) {
    limit := TargetLimit()
    if (limit <= 0)
        return false
    n := TargetCountOf(list)
    if (n < limit)
        return false
    LimitBox(n, true)
    return true
}

; 追加した顧客が、上限を超えるか。超えるなら案内を出して true（呼ぶ側は取りやめる）。
SchedAddBlocked(list, item) {
    cand := list.Clone()
    cand.Push(item)
    n := TargetCountOf(cand)
    if (!LimitBlocks(n))
        return false
    LimitBox(n)
    return true
}

; メニューに出す 1 行。上限を超えているときだけ。
PlanOverText() {
    lim := TargetLimit()
    if (lim <= 0)
        return ""
    n := TargetCount()
    if (n <= lim)
        return ""
    return Format("顧客が {1} 人です。スタンダードプランは {2} 人までのため、{3} 人目以降は実行されません", n, lim, lim + 1)
}

; 確認待ちに 1 行足す（運転中の顧客が決まっていない場面でも使える形）
PendingAddRaw(ok, sei, mei, text) {
    global PENDFILE
    line := FormatTime(A_Now, "yyyyMMddHHmmss") . "|" . (ok ? "1" : "0") . "|" . sei . "|" . mei . "|" . text
    try FileAppend(CRLF(line . "`n"), PENDFILE, "UTF-8")
}

; ★運転では、並び順の後ろから外す★（運転は止めない）
;   上限を超えて登録されたままのとき、予定の並び順で数えて上限までの顧客を対象にする。
;   超えた顧客は実行しない。確認待ちに「上限のため未実行」を、1 日 1 回だけ残す。
;   schedule.ini を手で書き換えて増やしても、ここで同じ数に収まる。
SchedLimitFilter(list) {
    global STATEINI
    limit := TargetLimit()
    if (limit <= 0)
        return list
    seen := Map()
    out  := []
    today := FormatTime(A_Now, "yyyyMMdd")
    for p in list {
        k := CustKey(p)
        if (k != "" && !seen.Has(k)) {
            if (seen.Count >= limit) {
                if (IniGet(IniLoad(STATEINI), "LimitNotice", p["key"], "") != today) {
                    IniSet(STATEINI, "LimitNotice", p["key"], today)
                    PendingAddRaw(false, p["sei"], p["mei"]
                        , "★上限のため未実行（スタンダードプランは顧客 " . limit . " 人まで）　プロプランへの登録で解除できます")
                    Log("WARN", Format("上限のため実行しません: {1}（スタンダードプランは顧客 {2} 人まで）", p["key"], limit))
                }
                continue
            }
            seen[k] := true
        }
        out.Push(p)
    }
    return out
}

; メニュー・設定に出す 1 行。区分の情報が無い通行証では空（何も出さない）
PlanLabel() {
    info := PlanInfo()
    if (!info["known"])
        return ""
    if (info["plan"] = "business") {
        if (info["grace"])
            return Format("プロプラン（あと {1} 日でスタンダードプラン）", info["left"])
        return "プロプラン"
    }
    cnt := 0
    try cnt := TargetCount()
    head := info["lapsed"] ? "スタンダードプラン（確認できないため）" : "スタンダードプラン"
    if (info.Has("forced") && info["forced"])
        head := "スタンダードプラン（試験用の設定）"
    return Format("{1}　顧客 {2}／{3} 人", head, cnt, info["max"])
}

; 窓口に問い合わせて通行証を取り直す。つながらなければ false（黙って戻る）。
PassRenew(code, &why) {
    global LICENSE_URL, PASSFILE, APP_VER
    why := ""
    code := Trim(code)
    if (code = "") {
        why := "利用者コードが登録されていません"
        return false
    }
    ; ★機器の識別値・版・登録人数を送る★（氏名・宛先は送らない）
    ;   人数と版は窓口が記録するだけ。判定には使わない（本体が偽れるため）。
    dev  := DeviceId()
    nTgt := ""
    try nTgt := TargetCount()
    url  := LICENSE_URL . "?code=" . UriEncode(code) . "&pc=" . UriEncode(A_ComputerName)
          . "&dev=" . dev . "&v=" . UriEncode(VerNumOnly(APP_VER)) . "&n=" . nTgt
    body := ""
    try {
        http := ComObject("WinHttp.WinHttpRequest.5.1")
        http.SetTimeouts(3000, 5000, 5000, 8000)   ; 起動を待たせない（最長 8 秒）
        http.Open("GET", url, false)
        http.Send()
        body := http.ResponseText
    } catch as e {
        why := "つながりません（" . e.Message . "）"
        return false
    }
    if (!JBool(body, "ok")) {
        st  := JStr(body, "state")
        why := JStr(body, "why")
        if (why = "")
            why := "確認できませんでした"
        Log("WARN", "利用確認の返事: " . st . "／" . why)
        ; ★通行証は捨てない★
        ;   捨てるとその瞬間から実行できなくなる＝予告なしに止まる。
        ;   無人で夜通し動かす道具では、それが最も避けたいこと（2026-09-19 指摘）。
        ;   代わりに「終わりの予告」を書き、通行証の期限（最大 14 日）までは
        ;   動かし続けながら、起動のたびに残り日数を知らせる。
        if (st = "stopped" || st = "expired" || st = "unknown" || st = "wrongpc") {
            if (FileExist(PASSFILE)) {
                IniSet(PASSFILE, "Pass", "Notice",    st)
                IniSet(PASSFILE, "Pass", "NoticeWhy", why)
                IniSet(PASSFILE, "Pass", "NoticeAt",  FormatTime(A_Now, "yyyyMMddHHmmss"))
            }
        }
        return false
    }
    nm  := JStr(body, "name"), exp := JStr(body, "expires")
    unt := JStr(body, "until"), pc  := JStr(body, "pc")
    sig  := JStr(body, "sign")
    sig2 := JStr(body, "sign2")
    sig3 := JStr(body, "sign3")
    out := "; AutoMeta 通行証（自動で作られます。書き換えないでください）`r`n[Pass]`r`n"
         . "Code=" . code . "`r`nName=" . nm . "`r`nExpires=" . exp
         . "`r`nUntil=" . unt . "`r`nPc=" . pc
    if (sig3 != "") {
        ; ---- 新しい返事（区分つき）--------------------------------------------------
        plan := JStr(body, "plan"), mx := JStr(body, "maxTargets"), uu := JStr(body, "upgradeUrl")
        ml   := JStr(body, "mail"), lineV := JStr(body, "line"), was := JStr(body, "was")
        ; ★区切りの「|」が混ざった返事は受け付けない★ 別の区切りで読ませる細工を防ぐ
        if (HasPipe([nm, exp, unt, pc, plan, mx, uu, ml, lineV])) {
            why := "返事の形が不正です"
            return false
        }
        if (plan != "general" && plan != "business") {
            why := "返事の区分が読み取れません"
            return false
        }
        if (!RsaVerify(Sha256Hex(Sign3Message(nm, exp, unt, pc, dev, plan, mx, uu, ml, lineV)), sig3)) {
            why := "返事の署名が合いません"
            return false
        }
        out .= "`r`nDev=" . dev . "`r`nPlan=" . plan . "`r`nMaxTargets=" . mx
             . "`r`nUpgradeUrl=" . uu . "`r`nMail=" . ml . "`r`nLine=" . lineV
             . "`r`nWas=" . was . "`r`nSign3=" . sig3
    } else {
        ; ---- 旧い返事（旧版許可の行だけに返る）。従来どおり ------------------------------
        if (sig2 = "" || !RsaVerify(Sha256Hex(nm . "|" . exp . "|" . unt . "|" . pc), sig2)) {
            why := "返事の署名が合いません"
            return false
        }
        out .= "`r`nSign=" . sig . "`r`nSign2=" . sig2
    }
    out .= "`r`nChecked=" . FormatTime(A_Now, "yyyyMMddHHmmss") . "`r`n"
    ; ★別名に書いて置き換える★ 消してから書くと、その一瞬、通行証が無いように見える。
    ;   見張り（5 分おき）や画面と重なると「利用者コードが未登録」と判断されて止まる。
    if (!IniWriteBody(PASSFILE, out)) {
        why := "通行証を書き込めませんでした"
        return false
    }
    Log("INFO", Format("利用確認 OK（公開鍵で確認）: {1}／期限 {2}／通行証は {3} まで{4}", nm, exp, unt
        , sig3 != "" ? ("／区分 " . plan) : ""))
    return true
}

; 起動時に静かに取り直す。★画面は出さない★（無人で動くため）
PassAutoRenew() {
    global PASSFILE, STATEINI, G
    code := Trim(CS("UserCode"))
    if (code = "")
        return                                      ; コード運用をしていない（鍵ファイル運用）
    need := true
    p := PassCheck()
    if (p["ok"]) {
        m   := IniLoad(PASSFILE)
        unt := StrReplace(Trim(IniGet(m, "Pass", "Until", "")), "-", "")
        chk := Trim(IniGet(m, "Pass", "Checked", ""))
        ; ★予告を早く出すことを優先する★
        ;   人が起動したときは毎回確かめる（その場で残り日数を知らせたい）。
        ;   見張り（5 分おき）で毎回つなぐのは無駄なので、無人は 1 日 1 回。
        ;   人が開いたとき: 10 分以内に確かめていれば省く（続けて開いても遅くならない）
        ;   無人（見張り）: 1 日 1 回
        span := (G.mode = "resume") ? 86400 : 600
        need := (chk = "" || DateDiff(A_Now, chk, "Seconds") >= span)
    }
    if (!need)
        return
    ; ★つながらなかったあとは、10 分あける★（3.10.28。本番 2.34.1 と同じ）
    ;   通行証が有効なあいだ、メニューを開くたびに通信を試して、そのたびに最長 約 12 秒、画面が出るまで待たされた
    ;   （2026-10-16、本番の利用者のログで、1 分のあいだに 5 回）。通行証の期限までは動くので、急いで取り直す必要はない。
    if (p["ok"]) {
        tried := Trim(IniGet(IniLoad(STATEINI), "License", "PassTried", ""))
        if (StrLen(tried) = 14 && DateDiff(A_Now, tried, "Seconds") < 600)
            return
    }
    why := ""
    if (!PassRenew(code, &why)) {
        IniSet(STATEINI, "License", "PassTried", FormatTime(A_Now, "yyyyMMddHHmmss"))
        Log("WARN", "いまは利用確認ができません（" . why . "）。通行証の期限までは動きます")
    }
}

; --- 公開鍵で署名を確かめる（RSA-SHA256 / PKCS#1 v1.5）----------------------
;   ★ツールには公開鍵しか置かない★
;     合言葉を共有する方式は、配布物を読まれた時点で偽造できてしまう。
;     公開鍵なら、読まれても偽造できない（署名には手元の秘密鍵が要る）。
;   当面は旧方式（Sign）も受け付ける。新方式が実機で通ってから旧方式を外す。
LicensePubModulus()  => "df278720e2426124c4bcf011a1736a6cc29b4be65553de7f1f82c21ad1a5563e8fe8172dd26be31e5607d1608c32872114111ecc9b382d52e4c273c3d18252a14863ceef700ac76ea185228b2fea7b586d46fb20c040707e3a990ac046c27c499480cd9a0674263aab40e4ebae0005fb9dd9513ff05952584f0f25eabc9216b62ab352412af6690d506c6d42f3aa89917961b456a89680ac9adc76857f3fb099c9cbf066d5e483d6663c9f42042f6b2d28c2ec6022bf1487689cc213bb1cdefb0282f292007765877e54d1791d6268682ae445991895537639c19504d61a10030c231132cae789c8621199a8e2c0a6a0fcf5cfbef273c3b4203a19760c584c8f"
LicensePubExponent() => "010001"

; 16 進の文字列を、そのままのバイト列にする
HexToBuf(hex) {
    hex := Trim(hex)
    n   := StrLen(hex) // 2
    buf := Buffer(n, 0)
    Loop n
        NumPut("UChar", Integer("0x" . SubStr(hex, (A_Index - 1) * 2 + 1, 2)), buf, A_Index - 1)
    return buf
}

; 文字列の SHA-256 を 32 バイトの生データで返す（Sha256Hex の兄弟）
Sha256Buf(str) {
    static PROV_RSA_AES := 24, CALG_SHA_256 := 0x0000800c
    static CRYPT_VERIFYCONTEXT := 0xF0000000, HP_HASHVAL := 0x0002
    out := Buffer(32, 0)
    hProv := 0, hHash := 0
    if (!DllCall("advapi32\CryptAcquireContextW", "Ptr*", &hProv, "Ptr", 0, "Ptr", 0
                , "UInt", PROV_RSA_AES, "UInt", CRYPT_VERIFYCONTEXT))
        return out
    if (DllCall("advapi32\CryptCreateHash", "Ptr", hProv, "UInt", CALG_SHA_256
               , "Ptr", 0, "UInt", 0, "Ptr*", &hHash)) {
        n := StrPut(str, "UTF-8") - 1
        buf := Buffer(n + 1, 0)
        StrPut(str, buf, "UTF-8")
        DllCall("advapi32\CryptHashData", "Ptr", hHash, "Ptr", buf, "UInt", n, "UInt", 0)
        size := 32
        DllCall("advapi32\CryptGetHashParam", "Ptr", hHash, "UInt", HP_HASHVAL
               , "Ptr", out, "UInt*", &size, "UInt", 0)
        DllCall("advapi32\CryptDestroyHash", "Ptr", hHash)
    }
    DllCall("advapi32\CryptReleaseContext", "Ptr", hProv, "UInt", 0)
    return out
}

; 署名が正しいか（本文・16 進の署名）。Windows の BCrypt を使う。
RsaVerify(msg, sigHex) {
    static BCRYPT_PAD_PKCS1 := 2
    if (Trim(sigHex) = "")
        return false
    hAlg := 0, hKey := 0
    if (DllCall("bcrypt\BCryptOpenAlgorithmProvider", "Ptr*", &hAlg, "Str", "RSA"
               , "Ptr", 0, "UInt", 0) != 0)
        return false
    ; ★組み込み関数と同じ名前を変数に使わない★
    ;   mod / exp は AHK の組み込み（Mod() / Exp()）と衝突する。
    ;   過去に ci / cs で同じ失敗をしている（静的チェックが検出）。
    modBuf := HexToBuf(LicensePubModulus())
    expBuf := HexToBuf(LicensePubExponent())
    cb   := 24 + expBuf.Size + modBuf.Size
    blob := Buffer(cb, 0)
    NumPut("UInt", 0x31415352, blob, 0)         ; RSA1
    NumPut("UInt", modBuf.Size * 8, blob, 4)    ; 鍵のビット長
    NumPut("UInt", expBuf.Size, blob, 8)
    NumPut("UInt", modBuf.Size, blob, 12)
    Loop expBuf.Size
        NumPut("UChar", NumGet(expBuf, A_Index - 1, "UChar"), blob, 24 + A_Index - 1)
    Loop modBuf.Size
        NumPut("UChar", NumGet(modBuf, A_Index - 1, "UChar"), blob, 24 + expBuf.Size + A_Index - 1)
    ok := false
    if (DllCall("bcrypt\BCryptImportKeyPair", "Ptr", hAlg, "Ptr", 0, "Str", "RSAPUBLICBLOB"
               , "Ptr*", &hKey, "Ptr", blob, "UInt", cb, "UInt", 0) = 0) {
        hash := Sha256Buf(msg)
        sg   := HexToBuf(sigHex)
        alg  := Buffer(64, 0)
        StrPut("SHA256", alg, "UTF-16")
        pad  := Buffer(A_PtrSize, 0)
        NumPut("Ptr", alg.Ptr, pad, 0)
        ok := (DllCall("bcrypt\BCryptVerifySignature", "Ptr", hKey, "Ptr", pad
                     , "Ptr", hash, "UInt", 32, "Ptr", sg, "UInt", sg.Size
                     , "UInt", BCRYPT_PAD_PKCS1) = 0)
        DllCall("bcrypt\BCryptDestroyKey", "Ptr", hKey)
    }
    DllCall("bcrypt\BCryptCloseAlgorithmProvider", "Ptr", hAlg, "UInt", 0)
    return ok
}

; 公開鍵の仕組みが、この PC で正しく動くかを確かめる（実機での安全確認用）
ModeVerifyTest() {
    global APP_NAME
    msg := "TEST|動作確認用|2027-03-31|2026-10-03|LAPTOP-VVFENRIS"
    sig := "67003c6f56cccf7a823b0d4245d83d4da47dcdeea2c2fa6fc6e828a0c27481ecac0ff6b4131ffd1dad4111841e5796dc589528740721741b97df1d007d8c4074025d9ccd8d2dd9946f2037f37c5d5bd7652496bc113761c255919712c4fd527df66aa6566407a2dcac2a12f2ae65d1d4461f1d496fd1131d9da6105616481a0a23c18a98cb4ee2cb99c407d6f5197fbb380781dda90c789ade3c3c840c4a0560fbe29aa233d8b9d3717a9127079ce2c40b5e9007fa42927ce8706e07c1caf779fbe5143613556d7123489d836562504cf095cd0e0753876b08174f9040b885ccd0d6dcca65d2922974ad7b9cf2d22001456dce4ae2e830dcfda412968a13941c"
    good := RsaVerify(msg, sig)
    bad  := RsaVerify(msg . "x", sig)          ; 本文を変えたら false になるはず
    ; ---- 新しい通行証（区分つき）の自己診断（3.10.0）-----------------------------------
    ;   本体が本文を組み立てる関数（Sign3Message）と、この PC の署名検証の両方を通す。
    ;   項目は架空・日付は過去・機器ID は存在しない値。実際の通行証としては使えない。
    ;   署名は、手元の秘密鍵で作ったもの（窓口の本番には触れていない）。
    v3sig := "14f23d36e430d309ba379a0fcdf2023c23b7035a591772853b22edccd9ea4cb0c7909d3c0aa3a77f5fc42b3d25a7eadfee2c987bc7c44443b277e39041c854dcb0131cb409aecfb3914693f11368b716bdfca0ffc6b39b556c74e1224365ff8e329694340b149c8677fe6a75a2aff97b1683bf2e71a1b05f99a49033199a3a8c6b0273d3981aa228a3bf4d38f35f32719251cc8fc8923407e62ab41f2652051d601592491eee522805c26772ad1acfa1a018403aa6026e32a64ea60bc6ad119b230aa56234b433b76bd3e4542453e7fc5f10b60ce5c97330ec16acad788ed9c4da252651727bfad4b72ac6f909c9a933756a181c28d41367987dfd4bb3f2b543"
    v3msg := Sign3Message("自己診断", "2000-01-01", "2000-01-01", "TESTPC", "0123456789abcdef"
        , "general", "10", "https://example.invalid/upgrade", "support@example.invalid"
        , "https://lin.ee/example")
    v3bad := Sign3Message("自己診断", "2000-01-01", "2000-01-01", "TESTPC", "0123456789abcdef"
        , "business", "10", "https://example.invalid/upgrade", "support@example.invalid"
        , "https://lin.ee/example")
    good3 := RsaVerify(Sha256Hex(v3msg), v3sig)
    bad3  := RsaVerify(Sha256Hex(v3bad), v3sig)   ; 区分を書き換えたら false になるはず
    guidOk := false
    try guidOk := (Trim(RegRead("HKLM\SOFTWARE\Microsoft\Cryptography", "MachineGuid")) != "")
    okAll := (good && !bad && good3 && !bad3)
    Log(okAll ? "INFO" : "ERROR", "公開鍵の自己診断: 正しい署名=" . (good ? "OK" : "NG")
        . " ／ 改ざんを弾く=" . (bad ? "NG" : "OK")
        . " ／ 区分つき署名=" . (good3 ? "OK" : "NG") . " ／ 区分の書き換えを弾く=" . (bad3 ? "NG" : "OK")
        . " ／ 機器ID=" . SubStr(DeviceId(), 1, 8) . (guidOk ? "（機器の識別値）" : "（PC 名から作成）"))
    ; ★三項演算子を行で割らない★ 行頭の : はラベルと紛らわしく、起動不能になる。
    ;   先に変数へ入れてから組み立てる（今夜 3 度目の同じ間違い）。
    tail := "この PC では動きませんでした。いまの方式のままにします。"
    if (okAll)
        tail := "この PC では公開鍵方式が使えます。"
    MsgBox("公開鍵のしくみの自己診断`n`n"
        . "　正しい署名を受け入れる : " . (good ? "OK" : "★NG★") . "`n"
        . "　書き換えを弾く     : " . (bad ? "★NG★" : "OK") . "`n"
        . "　区分つきの署名を受け入れる : " . (good3 ? "OK" : "★NG★") . "`n"
        . "　区分の書き換えを弾く : " . (bad3 ? "★NG★" : "OK") . "`n"
        . "　この PC の機器ID : " . SubStr(DeviceId(), 1, 8) . "…" . (guidOk ? "" : "（PC 名から作成）") . "`n`n"
        . tail
        , APP_NAME . " - 自己診断", okAll ? "Iconi 4096" : "Iconx 4096")
    ReopenAndExit(okAll ? 0 : 1)              ; 診断のあとも閉じずに戻る
}

LicenseCheck() {
    global LICFILE
    out := Map("state", "none", "name", "", "expires", "", "days", 0, "why", "")
    ; ★通行証（オンライン確認）が生きていれば、そちらを使う★
    ;   鍵ファイルしか無い人は、これまでどおり鍵ファイルで動く。
    p := PassCheck()
    if (p["ok"])
        return p["lic"]
    ; 通行証が壊れている／別 PC のものだったときは、「未登録」ではなくそう言う
    if (!p["gone"] && p["notice"] != "" && !FileExist(LICFILE)) {
        out["state"] := (p["notice"] = "wrongpc") ? "wrongpc" : "broken"
        ; ★三項演算子を行で割らない★ 行頭の : はラベルと紛らわしく、起動不能になる
        if (p["notice"] = "wrongpc")
            out["why"] := "この利用者コードは別のパソコンに登録されています"
        else
            out["why"] := "利用の情報を読み取れません（登録し直してください）"
        return out
    }
    if (p["gone"] && !FileExist(LICFILE)) {
        n := p["notice"]
        if (n = "stopped" || n = "unknown") {
            out["state"] := "stoppedover"
            out["why"]   := "ご利用の停止により、使用できなくなりました"
        } else if (n = "expired") {
            out["state"] := "planover"
            out["why"]   := "有効期限が切れています"
        } else if (n = "wrongpc") {
            out["state"] := "wrongpc"
            out["why"]   := "この利用者コードは別のパソコンに登録されています"
        } else {
            out["state"] := "passexpired"
            out["why"]   := "確認できない日が続き、期限が切れました"
        }
        return out
    }
    if (!FileExist(LICFILE)) {
        out["why"] := "利用者コードが登録されていません"
        return out
    }
    m := IniLoad(LICFILE)
    nm  := Trim(IniGet(m, "License", "Name", ""))
    exp := Trim(IniGet(m, "License", "Expires", ""))
    mac := Trim(IniGet(m, "License", "Machine", ""))
    sig  := Trim(IniGet(m, "License", "Sign", ""))
    sig2 := Trim(IniGet(m, "License", "Sign2", ""))
    out["name"] := nm, out["expires"] := exp
    if (nm = "" || exp = "" || sig2 = "") {
        out["state"] := "broken", out["why"] := "利用の情報が足りません"
        return out
    }
    if (sig2 = "" || !RsaVerify(Sha256Hex(nm . "|" . exp . "|" . mac), sig2)) {
        out["state"] := "forged", out["why"] := "利用の情報の署名が合いません（書き換えられています）"
        return out
    }
    if (mac != "" && StrLower(mac) != StrLower(A_ComputerName)) {
        out["state"] := "wrongpc"
        out["why"] := Format("この鍵は別の PC 用です（鍵: {1} ／ この PC: {2}）", mac, A_ComputerName)
        return out
    }
    ymd := StrReplace(exp, "-", "")
    if (StrLen(ymd) != 8) {
        out["state"] := "broken", out["why"] := "期限の書き方が不正です: " exp
        return out
    }
    today := FormatTime(A_Now, "yyyyMMdd")
    out["days"] := DateDiff(ymd . "000000", today . "000000", "Days")
    if (out["days"] < 0) {
        out["state"] := (Abs(out["days"]) <= CI("LicenseGraceDays")) ? "grace" : "expired"
        out["why"] := Format("期限 {1} を {2} 日過ぎています", exp, Abs(out["days"]))
        return out
    }
    out["state"] := (out["days"] <= CI("LicenseWarnDays")) ? "soon" : "ok"
    out["why"] := Format("期限 {1} まであと {2} 日", exp, out["days"])
    return out
}

; ★事業者の期限の予告を、自分宛の通知（メール／LINE）でも送る★（3.10.3）
;   一般になると通知は使えなくなる。送れるのは事業者のうちだけなので、ここで送る。
;   7 日前・前日・当日の 3 回だけ。同じ期限の同じ段階は 1 回しか送らない。
ExpiryNoticeMaybe() {
    global STATEINI
    static lastTry := ""
    if (lastTry != "" && SecSince(lastTry) < 1800)
        return
    lastTry := A_Now
    if (!NotifyNewOk())
        return
    p := PassCheck()
    if (!p["ok"] || !IsObject(p["lic"]) || !IsObject(p["info"]))
        return
    info := p["info"]
    lic  := p["lic"]
    if (!info["known"])
        return                                     ; 事業者かどうかは NotifyNewOk で確認済み
    if (lic["state"] != "ok" && lic["state"] != "soon")
        return
    if (!lic.Has("expires") || SubStr(StrReplace(lic["expires"], "-", ""), 1, 4) >= 2090)
        return                                     ; 期限なし
    days := lic["days"]
    level := ""
    if (days = 0)
        level := "0"
    else if (days = 1)
        level := "1"
    else if (days >= 2 && days <= 7)
        level := "7"
    if (level = "")
        return
    mark := lic["expires"] . "|" . level
    if (Trim(IniGet(IniLoad(STATEINI), "ExpiryNotice", "Last", "")) = mark)
        return
    when := (level = "0") ? "本日" : ((level = "1") ? "明日" : "あと " . days . " 日")
    ok := NotifyAdmin("AutoMeta プロプランの期限の予告（" . when . "）"
        , "プロプランのご利用期限は " . lic["expires"] . " です（" . when . "）。`n"
        . "期限後はスタンダードプラン（顧客 " . StdLimitDefault() . " 人まで・通知なし）になります。`n"
        . "続けてプロプランでお使いになる場合は、お早めにご連絡ください。`n"
        . "──────────`n"
        . "この PC 　" . A_ComputerName, false)
    if (ok) {
        IniSet(STATEINI, "ExpiryNotice", "Last", mark)
        Log("INFO", "プロプランの期限の予告を送りました: " . mark)
    }
}

; 実行系に入る直前の関門。止めるときはここで終わる。
;   ★起動時の mode だけで見てはいけない★
;   メニューから「調査」「スケジュール運転」へ入ると、同じプロセスのまま
;   モードが変わるため、起動時の判定では素通りする（2026-09-18 に気づいた）。
;   だから実行系の入口すべてで、ここを通す。
; ★人が見ているときだけ知らせる★
;   起動のたびに窓を出すと、無人で動く夜間に「誰も押せない窓」が残る。
;   見張り・スタートアップで一度やった失敗（2026-09-18）。
;   そこで、人がメニューを開いたときにだけ呼ぶ。
;   戻り値 true = 「いまコードを入れる」を選んだ。
; --- 新しい版のお知らせ（第 1 段階：知らせるだけ）----------------------------
;   UpdateUrl には「版番号だけを書いた小さなテキスト」の URL を入れる。
;     例: https://raw.githubusercontent.com/<所有者>/<リポジトリ>/main/version.txt
;   ★取りに行くのは、人がメニューを開いたときだけ★
;     無人の運転中に通信や入れ替えを起こさない。夜中に中身が変わる方が危険。
;   ★つながらなくても何もしない★ 確認の失敗を運転に波及させない。
; ★取得先はツールに埋め込んでおく★
;   2026-09-22、他社の PC へ zip で配ったところ、config.ini に取得先が無く
;   「更新の取得先が設定されていません」で止まった。
;   設定ファイルに書いてあればそれを使い、空なら埋め込みの公開 URL を使う。
UpdateUrlOf(which) {
    v := Trim(CS(which = "zip" ? "UpdateZipUrl" : "UpdateUrl"))
    if (v != "")
        return v
    base := "https://raw.githubusercontent.com/kyhfe013/autometa-updates/main/"
    return base . (which = "zip" ? "AutoMeta.zip" : "version.txt")
}

UpdateCheck() {
    global APP_VER
    url := UpdateUrlOf("ver")
    if (url = "")
        return ""                                   ; 使わない設定
    body := ""
    try {
        http := ComObject("WinHttp.WinHttpRequest.5.1")
        http.SetTimeouts(3000, 5000, 5000, 8000)
        http.Open("GET", url, false)
        http.Send()
        body := http.ResponseText
    } catch as e {
        Log("INFO", "新しい版の確認はできませんでした（" . e.Message . "）")
        return ""
    }
    ver := ""
    Loop Parse, body, "`n", "`r" {
        t := Trim(A_LoopField)
        if (t != "" && SubStr(t, 1, 1) != ";") {
            ver := t
            break
        }
    }
    if (ver = "" || !VerNewer(ver, APP_VER))
        return ""
    Log("INFO", "新しい版があります: " . ver . "（いまは " . VerNumOnly(APP_VER) . "）")
    return ver
}

; 「2.13.0 (説明)」から「2.13.0」だけ取り出す
VerNumOnly(v) {
    v := Trim(v)
    if (p := InStr(v, " "))
        v := SubStr(v, 1, p - 1)
    return v
}

; a が b より新しいか（数字を . で区切って比べる）
VerNewer(a, b) {
    aa := StrSplit(VerNumOnly(a), "."), bb := StrSplit(VerNumOnly(b), ".")
    Loop 4 {
        x := (aa.Length >= A_Index) ? ToInt(aa[A_Index], 0) : 0
        y := (bb.Length >= A_Index) ? ToInt(bb[A_Index], 0) : 0
        if (x != y)
            return (x > y)
    }
    return false
}

; --- 新しい版に入れ替える（第 2 段階）--------------------------------------
;   ★人が選んだときだけ★ 無人の運転中には絶対に動かさない。
;   ★利用者のものには触らない★ 設定・予定・履歴・鍵・通行証は zip に入っていない。
;   ★失敗したら古いまま★ 取得や展開が途中で終わったら、何も置き換えずに戻る。
ModeUpdate() {
    global APP_NAME, APP_VER
    zipUrl := UpdateUrlOf("zip")
    if (zipUrl = "") {
        MsgBox("更新の取得先が設定されていません。`n`n設定ファイルの UpdateZipUrl をご確認ください。", APP_NAME, "Icon! 4096")
        ReopenAndExit(1)
    }
    nv := UpdateCheck()
    if (nv = "") {
        MsgBox("お使いの版が最新です（" . VerNumOnly(APP_VER) . "）。", APP_NAME, "Iconi 4096")
        ReopenAndExit(0)
    }
    r := MsgBox("新しい版 " . nv . " に更新します。`n`n"
        . "　いまの版: " . VerNumOnly(APP_VER) . "`n`n"
        . "設定・予定・実行履歴・鍵は、そのまま残ります。`n"
        . "更新後、自動で再起動します。よろしいですか？"
        , APP_NAME . " - 更新", "YesNo Iconi 4096")
    if (r != "Yes")
        ReopenAndExit(0)

    tmp := A_Temp . "\AutoMeta_update"
    zip := tmp . "\new.zip"
    try DirDelete(tmp, true)
    try DirCreate(tmp)
    Log("INFO", "更新: 取得を開始します " . zipUrl)
    ok := false
    try {
        Download(zipUrl, zip)
        ok := FileExist(zip) ? true : false
    } catch as e {
        Log("WARN", "更新: 取得に失敗しました（" . e.Message . "）")
    }
    if (!ok || FileGetSize(zip) < 10000) {
        MsgBox("新しい版を取りに行けませんでした。`n`n"
            . "いまの版のまま、これまでどおりお使いいただけます。`n"
            . "インターネットにつながっているかご確認ください。"
            , APP_NAME . " - 更新", "Iconx 4096")
        ReopenAndExit(1)
    }
    ; Windows 10 以降に標準で入っている tar で展開する
    rc := 1
    try rc := RunWait(A_ComSpec . " /c tar -xf " . Chr(34) . zip . Chr(34)
        . " -C " . Chr(34) . tmp . Chr(34), , "Hide")
    src := tmp . "\AutoMeta\system"
    if (rc != 0 || !FileExist(src . "\AutoMeta.ahk")) {
        Log("WARN", "更新: 展開に失敗しました（戻り値 " . rc . "）")
        MsgBox("新しい版を取り出せませんでした。`n`n"
            . "いまの版のまま、これまでどおりお使いいただけます。"
            , APP_NAME . " - 更新", "Iconx 4096")
        ReopenAndExit(1)
    }
    ; ★上書きするのは zip に入っているものだけ★
    ;   設定・予定・履歴・鍵・通行証・ログは zip に無いので、触れようがない。
    n := 0
    Loop Files, src . "\*.*" {
        try {
            FileCopy(A_LoopFileFullPath, A_ScriptDir . "\" . A_LoopFileName, true)
            n++
        } catch as e {
            ; ★動作中の実行ファイルは掴まれていて置き換えられない★
            ;   AutoHotkey64.exe はまず変わらないので、失敗しても騒がない。
            if (A_LoopFileName = "AutoHotkey64.exe")
                Log("INFO", "更新: AutoHotkey64.exe は使用中のため、そのままにします")
            else
                Log("WARN", "更新: " . A_LoopFileName . " を置き換えられません（" . e.Message . "）")
        }
    }
    up := tmp . "\AutoMeta"
    Loop Files, up . "\*.bat" {
        try FileCopy(A_LoopFileFullPath, A_ScriptDir . "\..\" . A_LoopFileName, true)
    }
    Log("INFO", Format("更新: {1} 個のファイルを入れ替えました（{2} へ）", n, nv))
    try DirDelete(tmp, true)
    MsgBox("更新しました（" . nv . "）。`n`n再起動します。", APP_NAME . " - 更新", "Iconi 4096")
    try Run(Chr(34) . A_AhkPath . Chr(34) . " " . Chr(34) . A_ScriptFullPath . Chr(34) . " /menu"
          , A_ScriptDir)
    ExitApp(0)                                 ; ここは上で開き直しているので、そのまま終わる
}

LicenseNudge() {
    global APP_NAME, G
    lic := LicenseCheck()
    st  := lic["state"]
    if (st = "ok")
        return false
    if (st = "ending") {
        MsgBox("まもなく利用できなくなります。`n`n　" . lic["why"] . "`n`n"
            . "上の日付までは、これまでどおり動きます。`n"
            . "続けてお使いになる場合は、ご連絡ください。"
            , APP_NAME . " - 利用の期限", "Icon! 4096")
        return false
    }
    if (st = "offline") {
        MsgBox("インターネットにつないでください。`n`n　" . lic["why"] . "`n`n"
            . "このソフトは 2 週間に 1 度、インターネットで利用の確認をします。`n"
            . "つながった状態でこのソフトを開けば、それだけで確認は完了します。`n"
            . "（ほかの操作は不要です）"
            , APP_NAME . " - インターネットにつないでください", "Icon! 4096")
        return false
    }
    if (st = "soon" || st = "grace") {
        MsgBox("利用の期限が近づいています。`n`n　" . lic["why"] . "`n`n"
            . "更新のご連絡をお願いします。"
            , APP_NAME . " - 利用の期限", "Iconi 4096")
        return false
    }
    if (st = "none")
        msg := "まだ利用者コードが登録されていません。"
    else if (st = "expired")
        msg := "利用の期限が切れています。（" . lic["why"] . "）"
    else if (st = "passexpired")
        msg := "確認できない日が続き、期限が切れました。"
    else if (st = "stoppedover")
        msg := "ご利用が停止されています。"
    else if (st = "planover")
        msg := "利用の期限が切れています。"
    else if (st = "wrongpc")
        msg := "この利用者コードは別のパソコン用です。"
    else
        msg := "利用の確認ができません。（" . lic["why"] . "）"
    r := MsgBox(msg . "`n`n"
        . "このままでは調査・セラピーを実行できません。`n"
        . "（設定や診断は、これまでどおりお使いになれます）`n`n"
        . "いま利用者コードを登録しますか？"
        , APP_NAME . " - 利用の確認", "YesNo Icon! 4096")
    return (r = "Yes")
}

LicenseGate() {
    global APP_NAME, G, STATEINI
    lic := LicenseCheck()
    if (!LicenseBlocks(lic))
        return true
    ; ★同じ警告を 5 分おきに積まない★
    ;   見張りは 1 日 288 回来る。実行できない状態が続くとログが埋まる（2026-09-20 指摘）。
    ;   無人の入口では、同じ理由につき 1 日 1 回だけ残す。
    if (G.mode = "resume") {
        mark := FormatTime(A_Now, "yyyyMMdd") . "|" . lic["state"]
        if (Trim(IniGet(IniLoad(STATEINI), "License", "LastBlockLog", "")) != mark) {
            IniSet(STATEINI, "License", "LastBlockLog", mark)
            Log("WARN", "利用の期限により実行を止めました: " lic["why"] "（以後この記録は 1 日 1 回）")
        }
    } else
        Log("WARN", "利用の期限により実行を止めました: " lic["why"])
    ; ★無人の入口では窓を出さない★
    ;   /resume は見張りが 5 分ごとに呼ぶ。ここで窓を出すと、夜のあいだに
    ;   誰も押せない窓が積み上がる。起動時にすでに知らせた場合も同じ。
    if (G.mode = "resume")
        ExitApp(1)
    ; ★状態ごとに、やることを書き分ける★
    ;   「期限を確認できない」と言いながら期限は分かっている、
    ;   鍵はあるのに「置いてください」と案内する、といった食い違いを無くす。
    ;   お客様に出す文面なので、次にすることが一読で分かるようにする。
    st := lic["state"]
    if (st = "expired") {
        head := "利用の期限が切れています。"
        tell := "継続してお使いになる場合は、ご連絡をお願いします。"
    } else if (st = "forged") {
        head := "利用の情報が書き換えられています。"
        tell := "メニューの「設定 → 利用者コードを登録」から、`n"
             . "コードを入力し直してください。"
    } else if (st = "wrongpc") {
        head := "この利用者コードは別のパソコン用です。"
        tell := "このパソコンでお使いになる場合は、ご連絡をお願いします。"
    } else if (st = "stoppedover") {
        head := "ご利用が停止されています。"
        tell := "継続してお使いになる場合は、ご連絡をお願いします。"
    } else if (st = "planover") {
        head := "利用の期限が切れています。"
        tell := "継続してお使いになる場合は、ご連絡をお願いします。"
    } else if (st = "passexpired") {
        head := "インターネットにつながないまま 2 週間が過ぎました。"
        tell := "インターネットにつないで、このソフトをもう一度開いてください。`n"
             . "それだけで元どおり使えるようになります（ほかの操作は不要です）。"
    } else if (st = "broken") {
        head := "利用の情報を読み取れません。"
        tell := "メニューの「設定 → 利用者コードを登録」から、`n"
             . "コードを入力し直してください。"
    } else {
        head := "まだ利用者コードが登録されていません。"
        tell := "メニューの「設定 → 利用者コードを登録」からご登録ください。"
    }
    MsgBox(head "`n`n"
        . "　" lic["why"] "`n`n"
        . tell "`n`n"
        . "設定と診断の画面は、このままお使いいただけます。"
        , APP_NAME " - 利用の期限", "Iconx 4096")
    ExitApp(1)
}

; 実行してよいか。★設定では緩められない★（LICENSE_REQUIRED はソース側の固定値）
LicenseBlocks(lic) {
    global LICENSE_REQUIRED
    if (!LICENSE_REQUIRED)
        return false
    return (lic["state"] = "none" || lic["state"] = "broken" || lic["state"] = "forged"
         || lic["state"] = "wrongpc" || lic["state"] = "expired"
         || lic["state"] = "passexpired" || lic["state"] = "stoppedover"
         || lic["state"] = "planover")
}

; =============================================================================
;  落ちたあとの復帰（H-1）
;   ★中断したジョブは再開しない★
;     途中まで進んだセラピーを再開すると、二重にセラピーを行うことになる。
;     どこまで終わったかは画面からは分からないので、【確認待ち】に残して人に返す。
;   再開するのは「スケジュール運転そのもの」だけ。予定の時刻が来れば普通に走る。
; =============================================================================
ResumeCheck() {
    global STATEINI, PENDFILE
    m := IniLoad(STATEINI)
    if (Trim(IniGet(m, "Scheduler", "Running", "0")) != "1")
        return false                               ; 前回はきちんと終わっている
    startedAt := Trim(IniGet(m, "Scheduler", "StartedAt", ""))
    Log("WARN", Format("前回のスケジュール運転が終了していません（開始 {1}）。落ちたものとみなします"
        , startedAt = "" ? "不明" : startedAt))
    who   := Trim(IniGet(m, "Job", "Patient", ""))
    jstat := Trim(IniGet(m, "Job", "State", ""))
    if (who != "" && jstat != "" && jstat != "idle") {
        done  := Trim(IniGet(m, "Job", "TherapyDone", "0"))
        total := Trim(IniGet(m, "Job", "TherapyTotal", "0"))
        nm := StrSplit(who, " ")
        line := FormatTime(A_Now, "yyyyMMddHHmmss") "|0|"
              . (nm.Length >= 1 ? nm[1] : "") "|" (nm.Length >= 2 ? nm[2] : "") "|"
              . Format("★途中で止まりました（{1} の段階／セラピー {2} / {3} 回）"
                     . "　ソフト側の履歴で、どこまで行われたか確認してください", jstat, done, total)
        try FileAppend(CRLF(line "`n"), PENDFILE, "UTF-8")
        Log("WARN", Format("中断したジョブを確認待ちに残しました: {1}（{2}）", who, jstat))
        IniSet(STATEINI, "Job", "State", "idle")   ; 同じ通知を繰り返さない
    }
    return true
}

; PC 起動時に自動で立ち上げる（H-2）
;   ★登録するのは /resume★
;     /schedule で登録すると、意図的に止めた翌日に勝手に走り出してしまう。
;     /resume なら「前回落ちていたときだけ拾う」という意図どおりになる。
StartupRegPath() => "HKCU\Software\Microsoft\Windows\CurrentVersion\Run"

StartupIsOn() {
    v := ""
    try v := RegRead(StartupRegPath(), "AutoMeta")
    return (Trim(v) != "")
}

StartupLabel() {
    if (StartupIsOn())
        return "PC 起動時の自動起動：登録済み（押すと解除）"
    return "PC 起動時に自動で起動する（現在は未登録）"
}

ToggleStartup() {
    global APP_NAME
    if (StartupIsOn()) {
        try RegDelete(StartupRegPath(), "AutoMeta")
        Log("INFO", "スタートアップ登録を解除しました")
        MsgBox("PC 起動時の自動起動を【解除】しました。", APP_NAME, "Iconi 4096")
        return
    }
    cmd := Chr(34) A_AhkPath Chr(34) " " Chr(34) A_ScriptFullPath Chr(34) " /resume"
    try {
        RegWrite(cmd, "REG_SZ", StartupRegPath(), "AutoMeta")
    } catch as e {
        Log("WARN", "スタートアップに登録できません: " e.Message)
        MsgBox("登録できませんでした。`n`n" e.Message, APP_NAME, "Iconx 4096")
        return
    }
    Log("INFO", "スタートアップに登録しました: " cmd)
    MsgBox("PC 起動時に自動で起動するようにしました。`n`n"
        . "※ 起動しても、運転を再開するのは【前回が異常終了したとき】だけです。`n"
        . "　 正常に停止していた場合は、何もせずに終了します。"
        , APP_NAME, "Iconi 4096")
}

; 見張り（H-3）
;   ★新しい仕組みは作らない★
;     /resume は「動いていれば何もせず終了、落ちていれば拾う」。
;     これを数分おきに走らせれば、それがそのまま見張りになる。
;   PC が動いたままツールだけが落ちた場合を拾う（再起動を待たずに済む）。
WatchTaskName() => "AutoMeta_Watch"

WatchdogIsOn() {
    q := Chr(34)
    cmd := A_ComSpec . " /c schtasks /query /tn " . q . WatchTaskName() . q . " >nul 2>&1"
    rc := 1
    try rc := RunWait(cmd, , "Hide")
    return (rc = 0)
}

WatchdogLabel() {
    if (!WatchdogIsOn())
        return "異常終了時に自動で再起動（5 分ごとに確認・現在は未設定）"
    if (!WatchTaskPathOk())
        return "異常終了時に自動で再起動：★登録が古い場所のままです★（押すと登録し直し）"
    seen := WatchSeenAt()
    if (seen = "")
        return "異常終了時に自動で再起動：監視中（まだ動いた記録がありません）"
    if (DateDiff(A_Now, seen, "Minutes") > 20)
        return "異常終了時に自動で再起動：★" . FormatTime(seen, "M/d H:mm")
             . " から動いていません★（押すと登録し直し）"
    return "異常終了時に自動で再起動：監視中（最終確認 " . FormatTime(seen, "H:mm") . "）"
}

; 登録はされているが、働いていない状態か
WatchdogStale() {
    if (!WatchTaskPathOk())
        return true
    seen := WatchSeenAt()
    return (seen != "" && DateDiff(A_Now, seen, "Minutes") > 20)
}

; 見張りのタスクが AutoHotkey を直接呼ぶ形で登録できているか
;   /tr の引用符は環境で崩れることがあるので、登録したら中身を読んで確かめる。
; ★見張りが最後に動いた時刻★
;   「登録されているか」だけでは、働いているか分からない。
;   2026-10-04、登録は残ったままパスが古くなり、2 日間まったく動いていなかった。
WatchSeenPath() => NotifyDir() . "\watch_seen.txt"

WatchSeenWrite() {
    try FileDelete(WatchSeenPath())
    try FileAppend(FormatTime(A_Now, "yyyyMMddHHmmss"), WatchSeenPath(), "UTF-8")
}

WatchSeenAt() {
    t := ""
    try t := Trim(FileRead(WatchSeenPath(), "UTF-8"))
    return (StrLen(t) = 14) ? t : ""
}

; 登録されている見張りタスクの中身を読む
WatchTaskBody() {
    q   := Chr(34)
    tmp := A_Temp . "\automata_watch_task.txt"
    try FileDelete(tmp)
    try RunWait(A_ComSpec . " /c schtasks /query /tn " . q . WatchTaskName() . q
        . " /fo LIST /v > " . q . tmp . q . " 2>&1", , "Hide")
    body := ""
    try body := FileRead(tmp, "CP0")            ; schtasks の出力は既定の文字コード
    try FileDelete(tmp)
    return body
}

WatchTaskRunsAhk() => InStr(WatchTaskBody(), "AutoHotkey") > 0

; ★いまの置き場所を指しているか★
;   フォルダを動かすと、登録は残ったままパスだけ古くなる。
;   schtasks は 5 分ごとに起動を試み、毎回「ファイルが見つかりません」で
;   失敗し続けるが、画面には「監視中」と出たままだった（2026-10-04 実機）。
WatchTaskPathOk() {
    body := WatchTaskBody()
    if (body = "")
        return true                                ; 読めないときは責めない
    return InStr(body, A_ScriptFullPath) > 0
}

; バッテリーで止まらないようにする（ノート PC では既定で動かない）
WatchTaskAllowBattery() {
    q := Chr(34)
    ps := "powershell -NoProfile -Command " . q
        . "$s=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries;"
        . "Set-ScheduledTask -TaskName '" . WatchTaskName() . "' -Settings $s" . q
    try RunWait(A_ComSpec . " /c " . ps . " >nul 2>&1", , "Hide")
}

ToggleWatchdog() {
    global APP_NAME
    if (WatchdogIsOn()) {
        q := Chr(34)
        ; ★古い場所を指しているなら、1 回で入れ直す★
        ;   「解除 → もう一度押して登録」では、解除したまま忘れやすい（2026-10-04）。
        stale := WatchdogStale()
        cmd := A_ComSpec . " /c schtasks /delete /f /tn " . q . WatchTaskName() . q . " >nul 2>&1"
        try RunWait(cmd, , "Hide")
        if (!stale) {
            Log("INFO", "監視を解除しました")
            MsgBox("監視を【解除】しました。", APP_NAME, "Iconi 4096")
            return
        }
        Log("INFO", "監視が働いていないため、登録し直します")
        ; 下へ進んで、いまの場所で登録する
    }
    ; ★黒い窓を出さない★
    ;   以前は _watch.cmd（バッチ）を登録していたため、5 分ごとに cmd.exe の窓が
    ;   画面の中央に一瞬だけ出ていた（2026-09-19 指摘。1 日 241 回）。
    ;   AutoHotkey64.exe を直接登録すれば、窓は出ない。
    q   := Chr(34)
    esc := "\" . q                                ; /tr の中で使う引用符
    tr  := esc . A_AhkPath . esc . " " . esc . A_ScriptFullPath . esc . " /resume"
    mk  := A_ComSpec . " /c schtasks /create /f /tn " . q . WatchTaskName() . q
         . " /sc minute /mo 5 /tr " . q . tr . q . " >nul 2>&1"
    rc  := 1
    how := "直接起動／黒い窓は出ません"
    try rc := RunWait(mk, , "Hide")
    ; 登録できても、引用符が崩れて中身が壊れていることがある。読んで確かめる。
    if (rc = 0 && !WatchTaskRunsAhk())
        rc := 1

    if (rc != 0) {
        ; ★通らない環境では、これまでどおり .cmd を経由する★
        ;   窓は一瞬出るが、見張りが働かないよりはよい。
        Log("WARN", "直接登録できなかったので _watch.cmd を使います")
        how := "_watch.cmd 経由／黒い窓が一瞬出ます"
        cmdFile := A_ScriptDir . "\_watch.cmd"
        body := "@echo off`r`nstart " . q . q . " " . q . A_AhkPath . q . " "
              . q . A_ScriptFullPath . q . " /resume`r`n"
        try {
            if FileExist(cmdFile)
                FileDelete(cmdFile)
            FileAppend(body, cmdFile, "CP0")       ; cmd.exe が読める文字コードで書く
        } catch as e {
            MsgBox("監視用のファイルを作成できませんでした。`n`n" . e.Message, APP_NAME, "Iconx 4096")
            return
        }
        mk := A_ComSpec . " /c schtasks /create /f /tn " . q . WatchTaskName() . q
            . " /sc minute /mo 5 /tr " . q . cmdFile . q . " >nul 2>&1"
        rc := 1
        try rc := RunWait(mk, , "Hide")
    }
    if (rc != 0) {
        Log("WARN", "監視を設定できませんでした（schtasks の戻り値 " . rc . "）")
        MsgBox("監視を設定できませんでした（戻り値 " . rc . "）。`n`n"
            . "Windows のタスクスケジューラが使えない環境かもしれません。"
            , APP_NAME, "Iconx 4096")
        return
    }
    ; ★どちらの方式で登録したかを残す★
    ;   あとからログだけで判断できるようにする（2026-09-19 指摘）。
    WatchTaskAllowBattery()                        ; ノート PC でも動くようにする
    Log("INFO", "監視を設定しました（5 分ごとに /resume ／ " . how . "）")
    MsgBox("5 分ごとに状態を確認し、異常終了していれば再起動します。`n`n"
        . "※ 動いているときは何もしません。`n"
        . "※ 正常に停止した場合は、自動で再開することはありません。`n"
        . "※ 画面には何も表示されません。`n`n"
        . "★フォルダを動かしたら、登録し直してください★`n"
        . "　場所が変わると、この見張りは何も言わずに働かなくなります。`n"
        . "　設定の画面に「★登録が古い場所のままです★」と出ます。"
        , APP_NAME, "Iconi 4096")
}

; スタートアップから呼ばれる入口。前回落ちていたときだけ運転を再開する
ModeResume() {
    global APP_NAME
    ; ★見るのではなく、その場で鍵を取る★
    ;   「見てから取る」だと、2 つがほぼ同時に立ち上がったとき両方とも通過し、
    ;   対象ソフトを二重に起動したり、ダイアログを残したりする（2026-09-18 指摘）。
    ;   取れなければ黙って終わる。窓は出さない。
    EnsureSingleInstance(true)
    if (!ResumeCheck()) {
        if (!G.resumeQuiet)                        ; 見張りが絞っている間は、記録しない
            Log("INFO", "前回はきちんと終わっているので、何もしません")
        try SchedStoppedNote()
        ExitApp(0)
    }
    Log("INFO", "=== 落ちた前回の運転を引き継ぎます ===")
    try TrayTip("前回の運転を引き継ぎました`n中断したぶんは確認待ちに残しています", APP_NAME)
    ModeSchedule()
}

; ★G5★ 二重起動の禁止
;   2026-09-14 の実機で、スケジューラを 2 つ起動してしまい、
;   2 つの状態機械が同じ画面を取り合って誤動作した。仕様書に書いてあったのに未実装だった。
;   名前付きミューテックスで、実行系のモードは 1 つだけに制限する。
EnsureSingleInstance(quiet := false) {
    global APP_NAME, G
    static hMutex := 0
    ; ★このプロセスがすでに鍵を持っているなら、何もしない★
    ;   /resume が先に取り、そのあと ModeSchedule がもう一度呼ぶため。
    ;   同じ名前で作り直すと「すでに存在」と判定され、自分自身を締め出してしまう。
    if (hMutex)
        return true
    hMutex := DllCall("CreateMutexW", "Ptr", 0, "Int", 1, "Str", "AutoMeta_Job_Singleton", "Ptr")
    if (A_LastError = 183) {                        ; ERROR_ALREADY_EXISTS
        hMutex := 0
        ; ★無人の入口では窓を出さない★
        ;   見張り（5 分ごと）や自動起動で負けた側がダイアログを出すと、
        ;   深夜に誰も押せない窓が残り続ける（2026-09-18 指摘）。
        if (quiet) {
            if (!G.resumeQuiet)                    ; 見張りが絞っている間は、記録しない
                Log("INFO", "すでに動いています。何もせず終わります")
            ExitApp(0)
        }
        MsgBox("AutoMeta はすでに実行中です。`n`n"
            . "二重に起動すると、2 つが同じ画面を操作し誤動作します。`n`n"
            . "・セラピーだけなら、スケジュール運転を止めずに実行できます`n"
            . "　→ メニューの「▶ 自動セラピー」`n`n"
            . "・それ以外は、先に動いているものを終了してください`n"
            . "　→ 運転パネルの「止める」、または system\stop_all.bat"
            , APP_NAME, "Icon! 4096")
        ExitApp(1)
    }
}

; 対象プロセスの可視ウィンドウを z オーダー順（手前が先）で返す
TargetWindows(pid) {
    list := []
    try list := WinGetList("ahk_pid " pid)
    catch
        return []
    out := []
    for h in list {
        cls := "", ttl := ""
        try {
            cls := WinGetClass("ahk_id " h)
            ttl := WinGetTitle("ahk_id " h)
        } catch
            continue
        if (cls = "")
            continue
        ; ★ここでサイズを見て弾いてはいけない（v0.2.0 の重大なバグ）★
        ;   対象ソフトの指標ウィンドウ TFormDiagn は進行状況の更新のたびに作り直され、
        ;   その一瞬だけサイズが 0 になる（AutoTherapy v4 仕様書 §17.3）。
        ;   v0.2.0 はこれを「閉じた」と記録してしまい、実際には連続していたセラピーを
        ;   「4〜39 秒の途切れがある」と誤って報告した。AutoTherapy v4 の
        ;   IsTherapyRunning() はサイズを一切見ておらず、そちらが正しい。
        ;   サイズは情報として持つだけにして、窓の有無の判定には使わない。
        ww := 0, wh := 0
        try WinGetPos(, , &ww, &wh, "ahk_id " h)
        ; ★失敗すると未設定に戻る★ 使う前に必ず確かめる（2026-09-22）
        if (!IsSet(ww))
            ww := 0
        if (!IsSet(wh))
            wh := 0
        out.Push(Map("hwnd", h, "class", cls, "title", ttl, "w", ww, "h", wh))
    }
    return out
}

; ウィンドウのコントロールを [ClassNN, テキスト, 位置, 状態] で列挙する
DumpCtrls(hwnd) {
    rows := []
    ctrls := []
    try ctrls := WinGetControls("ahk_id " hwnd)
    catch
        return rows
    for cn in ctrls {
        tx := "", en := "?", vi := "?"
        try tx := ControlGetText(cn, "ahk_id " hwnd)
        try en := ControlGetEnabled(cn, "ahk_id " hwnd) ? "有効" : "無効"
        try vi := ControlGetVisible(cn, "ahk_id " hwnd) ? "表示" : "非表示"
        r := CtrlRect(hwnd, cn)
        rows.Push(Map("cnn", cn, "text", tx, "en", en, "vi", vi
                    , "x", r["ok"] ? r["x"] : "", "y", r["ok"] ? r["y"] : ""
                    , "w", r["ok"] ? r["w"] : "", "h", r["ok"] ? r["h"] : ""))
    }
    return rows
}

CtrlsToText(rows, indent := "       ") {
    out := ""
    withText := 0
    for r in rows {
        pos := (r["x"] = "") ? "" : Format("x{1} y{2} w{3} h{4}", r["x"], r["y"], r["w"], r["h"])
        tx  := StrReplace(StrReplace(r["text"], "`r", " "), "`n", " ")
        if (tx != "")
            withText++
        out .= Format("{1}- {2:-24} [{3}/{4}] {5:-26} : {6}`n"
             , indent, r["cnn"], r["vi"], r["en"], pos, (tx = "" ? "（テキストなし）" : tx))
    }
    out .= indent "（コントロール " rows.Length " 件 / テキストあり " withText " 件）`n"
    if (rows.Length > 0 && withText = 0)
        out .= indent "★テキストが 1 件も取れていません → 権限不足の可能性が高い（管理者版で再実行）`n"
    return out
}

; 画面を判定する。戻り値 Map("id", ..., "hit", 当たった署名テキスト)
ClassifyScreen(hwnd, rows := 0) {
    global SCREEN_CLASSES, SCREEN_SIGS
    ; まず実機で確定したクラス表を引く（推測より確実）
    cls := ""
    try cls := WinGetClass("ahk_id " hwnd)
    if (cls != "" && SCREEN_CLASSES.Has(cls))
        return Map("id", SCREEN_CLASSES[cls], "hit", "クラス既知")
    ; 表にないクラスだけ、署名テキストで推測する
    if !IsObject(rows)
        rows := DumpCtrls(hwnd)
    texts := []
    for r in rows {
        t := Norm(r["text"])
        if (t != "")
            texts.Push(t)
    }
    ttl := ""
    try ttl := Norm(WinGetTitle("ahk_id " hwnd))
    if (ttl != "")
        texts.Push(ttl)
    for sig in SCREEN_SIGS {
        id := sig[1]
        for want in sig[2] {
            w := Norm(want)
            for t in texts {
                if (t = w || InStr(t, w))
                    return Map("id", id, "hit", want)
            }
        }
    }
    return Map("id", "UNKNOWN", "hit", "")
}

; クリック位置を人間に読める形で説明する。
; 対象ソフトはボタンの一部が「描画」でコントロールが無いため、
; 「どのコントロールの何 px 右か」で表現できないと記録が読めない。
DescribeClick(hwnd, cx, cy, ctrlNN) {
    if (ctrlNN != "") {
        tx := ""
        try tx := Norm(ControlGetText(ctrlNN, "ahk_id " hwnd))
        return ctrlNN . (tx = "" ? "（テキストなし）" : "「" . tx . "」")
    }
    ; コントロールが取れない＝描画されたボタン。同じ行の左右のコントロールで位置を説明する
    rows := DumpCtrls(hwnd)
    bestLd := -1, bestLt := "", bestRd := -1, bestRt := ""
    for r in rows {
        if (r["x"] = "" || Norm(r["text"]) = "")
            continue
        rowTop := r["y"], rowBot := r["y"] + r["h"]
        if (cy < rowTop - 8 || cy > rowBot + 8)      ; 同じ行にないものは無視
            continue
        if (r["x"] + r["w"] <= cx) {
            d := cx - (r["x"] + r["w"])
            if (bestLd < 0 || d < bestLd) {
                bestLd := d, bestLt := Norm(r["text"])
            }
        }
        if (r["x"] >= cx) {
            d := r["x"] - cx
            if (bestRd < 0 || d < bestRd) {
                bestRd := d, bestRt := Norm(r["text"])
            }
        }
    }
    desc := "（コントロールなし＝描画ボタン）"
    if (bestLd >= 0)
        desc .= " 「" bestLt "」の右 " bestLd "px"
    if (bestRd >= 0)
        desc .= " / 「" bestRt "」の左 " bestRd "px"
    return desc
}

;==============================================================================
;  ログ
;==============================================================================
; ★日をまたいだら、その日のファイルへ移る★
;   ログの名前は起動時に 1 度だけ決めていた。そのため 2026-09-18 23:08 に始めた
;   運転は、翌朝 02:57 の完了まで全部 9/18 のファイルに書かれ、朝ログを見るのに
;   前日ぶんが要った（2026-09-19 指摘）。両方に継ぎ目を残し、追えるようにする。
LogRollover() {
    global G, LOGDIR
    want := LOGDIR . "\" . FormatTime(A_Now, "yyyy-MM-dd") . ".log"
    if (G.logFile = "" || want = G.logFile)
        return
    prev  := G.logFile
    stamp := FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss")
    ; ★前日のファイルには書かない★（3.10.24）日付をまたぐ瞬間に前日のファイルへ 1 行足すと、すでに同期に掴まれた
    ;   前日のファイルを再び更新することになり、同期が止まる原因になる。継ぎ目は新しい日のほうにだけ残す。
    G.logFile := want
    try FileAppend(CRLF(stamp . " [INFO] 前日から続いている運転です（前半は " . prev . "）`r`n"), want, "UTF-8")
}

Log(level, msg) {
    global G
    LogRollover()
    line := FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss") " [" level "] " msg "`r`n"
    ; ★書けなかったら、やり直す★
    ;   ログを開いたまま見ていると書き込みが弾かれ、その行が黙って消えていた。
    ;   2026-09-17、これで 3 回も原因調査を遠回りした。
    ;   完全な記録は諦めてよいが、★欠けたことが分からない★のが問題。
    ; 取り合いが増えたので、やり直す回数と待ちを増やした（2026-10-05）
    ; ★それでも書けなかった行は、捨てずに持っておく★（2026-10-13）
    ;   同期（OneDrive・Google ドライブ）や他のソフトにファイルを掴まれると、1 ジョブで 17〜50 行が消えていた。
    ;   持っておいて、次に書けたとき・運転の見回りのとき・終わるときに、順番どおり書き足す。
    if (G.logBuf.Length > 0)
        LogFlush()
    Loop 6 {
        try {
            FileAppend(CRLF(line), G.logFile, "UTF-8")
            return
        }
        Sleep(40 + A_Index * 30)                   ; 70, 100, 130, 160, 190, 220 ミリ秒
    }
    if (G.logBuf.Length < 400) {                   ; 持てるのは 400 行まで（プロセスの重さを守る）
        G.logBuf.Push(Map("file", G.logFile, "line", line))
        G.logLate += 1
    } else {
        G.logLost += 1                             ; 本当に失った行だけを数える
    }
}

; 書き足せていない行を、古い順に書く。書けなかったものは残す（次の機会に）。
LogFlush() {
    global G
    if (G.logBuf.Length = 0)
        return
    keep := []
    for e in G.logBuf {
        if (keep.Length > 0) {                     ; 前の行が書けなかったなら、順番を守って待つ
            keep.Push(e)
            continue
        }
        ok := false
        try {
            FileAppend(CRLF(e["line"]), e["file"], "UTF-8")
            ok := true
        }
        if (!ok)
            keep.Push(e)
    }
    G.logBuf := keep
}

LogExitFlush(*) {
    LogFlush()
    LogCopyOut()
    return 0
}

; ログを従来の場所（LOGCOPY＝同期される側）へ写す。直近 2 日ぶんだけ、中身が違うものだけ。
;   別名に写してから置き換える（置き換える一瞬、読む側に空のファイルが見えないように）。
;   同期に掴まれていて置き換えられなくても、ログ本体は無事なので何もしない（次の機会にまた写す）。
LogCopyOut() {
    global LOGDIR, LOGCOPY
    if (LOGDIR = LOGCOPY)
        return
    try {
        if !DirExist(LOGCOPY)
            DirCreate(LOGCOPY)
        Loop Files, LOGDIR "\*.log" {
            if (DateDiff(A_Now, A_LoopFileTimeModified, "Days") > 1)
                continue
            dest := LOGCOPY "\" A_LoopFileName
            if (FileExist(dest) && FileGetSize(dest) = A_LoopFileSize)
                continue
            tmp := dest ".tmp"
            FileCopy(A_LoopFileFullPath, tmp, 1)
            FileMove(tmp, dest, 1)
        }
    }
}

RotateLogs() {
    global LOGDIR, LOGCOPY, C
    days := 30
    for dir in [LOGDIR, LOGCOPY] {
        Loop Files, dir "\*.log" {
            if (DateDiff(A_Now, A_LoopFileTimeModified, "Days") > days)
                try FileDelete(A_LoopFileFullPath)
        }
    }
}

;==============================================================================
;  対象プロセスの特定
;==============================================================================
; ★対象ソフトが落ちていたら、起動して待つ★
;   2026-09-17 の要望。本体が落ちると、以後の予定がすべて空振りになる。
;   ★待つあいだ止まらないこと★
;     ここで Sleep して待つと、待っている間パネルも「止める」も効かなくなる。
;     そこで「起動を頼んで、いったん戻る」。次の巡回でまた見に来る。
;   立ち上がらなければ false を返す。呼び側は予定を始めない（次の機会に回す）。
EnsureTargetRunning(&why) {
    global G
    why := ""
    exe := CS("ExeName")
    if (exe = "") {
        why := "対象ソフトが設定されていません（設定 →「測定値を設定し直す」で、対象ソフトを選んでください）"
        return false
    }
    if (G.pid := FindPidByExe(exe)) {
        G.appLaunchTS := ""
        return true
    }
    if (G.appLaunchTS != "") {                     ; すでに起動を頼んである
        if (SecSince(G.appLaunchTS) < CI("LaunchWaitSec")) {
            why := "対象ソフトの起動を待っています"
            return false
        }
        why := Format("対象ソフトを起動しましたが、{1} 秒たっても現れませんでした"
            , CI("LaunchWaitSec"))
        G.appLaunchTS := ""
        return false
    }
    path := CS("ExePath")
    if (path = "" || !FileExist(path)) {
        why := "対象ソフト「" exe "」が起動しておらず、場所も分かりません"
             . "（設定 →「測定値を設定し直す」で、対象ソフトを選び直してください）"
        return false
    }
    ; ★自分のフォルダを作業フォルダにして起動する★
    ;   2026-09-18、場所だけ指定して起動したところ、メタアナライザー側が
    ;   「EStringListError / List index out of bounds (0)」で落ちた。
    ;   Delphi のソフトは自分のフォルダを基準に設定を読むため、
    ;   別の場所から起動されるとリストが空のまま進んでしまう。
    ;   手で起動したときは作業フォルダが自分のフォルダになるので表面化しない。
    dir := ""
    SplitPath(path, , &dir)
    Log("INFO", Format("対象ソフトが見つからないので起動します: {1}（作業フォルダ {2}）"
        , path, dir = "" ? "（不明）" : dir))
    try {
        Run(Chr(34) path Chr(34), dir)
    } catch as e {
        why := "対象ソフトを起動できませんでした: " e.Message
        return false
    }
    G.appLaunchTS := A_Now
    G.appUpTS     := A_Now                         ; ★整うまで次の予定を始めない★ その起点
    why := "対象ソフトを起動しました。表示されるまで待ちます"
    return false
}

; config に ExeName があればそれを使う。無ければ /setup へ誘導する。
EnsureTarget() {
    global C, G, APP_NAME
    exe := CS("ExeName")
    if (exe != "") {
        pid := FindPidByExe(exe)
        if (pid) {
            G.pid := pid
            return pid
        }
        MsgBox("config.ini に記録された対象ソフト「" exe "」が起動していません。`n`n"
            . "対象ソフトを起動してから、もう一度実行してください。`n"
            . "別のソフトを対象にしたい場合は、設定 →「測定値を設定し直す」で、対象ソフトを選び直してください。"
            , APP_NAME, "Icon! 4096")
        ReopenAndExit(1)
    }
    MsgBox("対象ソフトがまだ設定されていません。`n`n"
        . "先に、設定 →「測定値を設定し直す」で対象ソフトを選んでください（または 1_SETUP.bat）。"
        , APP_NAME, "Icon! 4096")
    ReopenAndExit(1)
}

; スケジュール運転の入口用。★対象ソフトが落ちていても止めない★
;   2026-09-18、夜中に PC が再起動して /resume で立ち上がっても、
;   その瞬間にメタアナライザーが落ちていれば EnsureTarget() がここで終了させ、
;   H-1〜H-3 の復帰が丸ごと無駄になることが分かった。
;   起動を頼んだうえで、見つからなくても運転だけは始める。
;   予定の直前に SchedTick がもう一度確かめる（そこで駄目なら見送り、警告は 10 分に 1 回）。
;   ※ 対面で使う「1 人だけ実行」「自動セラピー」は、人が見ているので従来どおり止める。
EnsureTargetForSchedule() {
    global G, APP_NAME
    exe := CS("ExeName")
    if (exe = "") {
        MsgBox("対象ソフトがまだ設定されていません。`n`n"
            . "先に、設定 →「測定値を設定し直す」で対象ソフトを選んでください（または 1_SETUP.bat）。"
            , APP_NAME, "Icon! 4096")
        ReopenAndExit(1)
    }
    if (G.pid := FindPidByExe(exe))
        return true
    why := ""
    EnsureTargetRunning(&why)                      ; 起動を頼む（待たずに戻る作り）
    Log("WARN", Format("対象ソフト「{1}」が起動していません（{2}）。"
        . "運転は開始します。予定の直前にもう一度確認します", exe, why))
    return true
}

; プロセスが起動してからの秒数。分からないときは -1。
;   ★人が起こしたソフトも、自分で起こしたソフトも、同じ物差しで測れる★
;   Windows が記録している作成時刻（Win32_Process の CreationDate）を使う。
ProcessAgeSec(pid) {
    if (!pid)
        return -1
    try {
        wmi := ComObjGet("winmgmts:")
        for p in wmi.ExecQuery("Select CreationDate from Win32_Process where ProcessId=" . pid) {
            cd := SubStr(p.CreationDate, 1, 14)         ; yyyyMMddHHmmss（この PC の時刻）
            if (RegExMatch(cd, "^\d{14}$"))
                return Max(0, DateDiff(A_Now, cd, "Seconds"))
        }
    }
    return -1
}

FindPidByExe(exe) {
    for h in WinGetList() {
        try {
            if (StrLower(WinGetProcessName("ahk_id " h)) = StrLower(exe))
                return WinGetPID("ahk_id " h)
        }
    }
    return 0
}

; 可視ウィンドウを持つプロセスを列挙する（自分自身と明らかな常駐物は除く）
ListCandidateProcesses() {
    static skip := Map("explorer.exe",1, "ApplicationFrameHost.exe",1, "SystemSettings.exe",1
                     , "TextInputHost.exe",1, "ShellExperienceHost.exe",1, "SearchHost.exe",1
                     , "StartMenuExperienceHost.exe",1, "AutoHotkey64.exe",1, "AutoHotkey32.exe",1)
    mine := MyPid()
    agg := Map()
    for h in WinGetList() {
        ttl := "", exe := "", pid := 0
        try {
            ttl := WinGetTitle("ahk_id " h)
            exe := WinGetProcessName("ahk_id " h)
            pid := WinGetPID("ahk_id " h)
        } catch
            continue
        if (ttl = "" || pid = mine || skip.Has(exe))
            continue
        if !agg.Has(exe)
            agg[exe] := Map("exe", exe, "pid", pid, "n", 0, "sample", ttl)
        agg[exe]["n"]++
    }
    out := []
    for k, v in agg
        out.Push(v)
    return out
}

;==============================================================================
;  /setup  対象ソフトを特定して config.ini に記録する
;==============================================================================
ModeSetup() {
    global CFG, APP_NAME, KNOWN_EXES
    cands := ListCandidateProcesses()
    if (cands.Length = 0) {
        MsgBox("ウィンドウを持つソフトが見つかりませんでした。`n対象ソフトを起動してから実行してください。"
            , APP_NAME, "Icon! 4096")
        ReopenAndExit(1)
    }
    ; 既知の名前があれば先頭へ並べ替える
    known := [], other := []
    for c in cands {
        isKnown := false
        for k in KNOWN_EXES {
            if (StrLower(c["exe"]) = StrLower(k))
                isKnown := true
        }
        (isKnown ? known : other).Push(c)
    }
    ordered := []
    for c in known
        ordered.Push(c)
    for c in other
        ordered.Push(c)

    dlg := Gui("+AlwaysOnTop", APP_NAME " - 対象ソフトの設定" VerTag())
    dlg.MarginX := 14, dlg.MarginY := 12
    dlg.SetFont("s10", "Meiryo UI")
    dlg.Add("Text", "w760", "調査の対象にするソフトを選んでください。")
    dlg.Add("Text", "w760 cGray"
        , "通常は一番上（META ANALYZER.exe / 18D-NLS.exe）です。"
        . "これは記録するだけで、ソフトを操作することはありません。")
    lv := dlg.Add("ListView", "w760 h280 -Multi", ["実行ファイル", "ウィンドウ数", "ウィンドウ名の例"])
    for c in ordered
        lv.Add(, c["exe"], c["n"], c["sample"])
    lv.ModifyCol(1, 260), lv.ModifyCol(2, 90), lv.ModifyCol(3, 390)
    if (ordered.Length > 0)
        lv.Modify(1, "Select Focus")
    if (known.Length > 0)
        dlg.Add("Text", "w760 cGreen", "★ 1 行目は既知の対象ソフトです。通常はこれが正しい対象です。")
    btn := dlg.Add("Button", "w200 h36 Default", "この設定を保存")
    btn.OnEvent("Click", DoSave)
    dlg.OnEvent("Close", (*) => ReopenAndExit(0))
    dlg.Show()
    return

    DoSave(*) {
        ; ★C（設定の入れ物）も宣言する★
        ;   抜けていたため、モデルを記録する行で「値が入っていません」になった
        ;   （2026-09-22、利用者の画面でエラー）。
        global CFG, APP_NAME, C
        r := lv.GetNext(0, "F")
        if (!r) {
            MsgBox("行を選んでください。", APP_NAME, "Icon! 4096")
            return
        }
        exe := lv.GetText(r, 1)
        IniSet(CFG, "Target", "ExeName", exe)
        ; ★モデルも一緒に記録する★
        ;   選択中の色がモデルで違うため（18D は青、Meta Analyzer はクリーム）。
        mdl := GuessModel(exe)
        if (mdl != "") {
            IniSet(CFG, "Model", "ModelName", mdl)
            C["ModelName"] := mdl
            ; Meta Analyzer は「カーソルに反応しない＝選択済み」で見分ける
            ht := (mdl = "MetaAnalyzer") ? "1" : "0"
            IniSet(CFG, "Model", "HoverTest", ht)
            C["HoverTest"] := ht
            Log("INFO", "モデルを自動で記録しました: " . mdl)
        }
        ; ★場所も控える★ 落ちていたときに起動し直せるようにする（2026-09-17）
        pth := ""
        try pth := ProcessGetPath(ordered[r]["pid"])
        if (pth != "")
            IniSet(CFG, "Target", "ExePath", pth)
        if (mdl = "") {
            ; 名前から判別できなかったときだけ、手で選んでもらう
            MsgBox("config.ini に記録しました。`n`n  対象ソフト: " exe "`n`n"
                . "モデルを自動で判別できませんでした。`n"
                . "次の画面で選んでください。", APP_NAME, "Icon! 4096")
            ModeModel()
            return
        }
        MsgBox("config.ini に記録しました。`n`n  対象ソフト: " exe "`n"
            . ("  モデル　　: " . mdl . "`n")
            . (pth = "" ? "  場所: （取得できませんでした）`n" : "  場所: " pth "`n") "`n"
            . "次は 設定 →「お問い合わせ・診断」→「操作を記録」を実行してください。", APP_NAME, "Iconi 4096")
        ; ★続けてショートカットを作れるようにする★
        ;   次回からアイコンを押すだけで開ける（2026-09-19 指摘）。
        if (MsgBox("続けて、ショートカットを作りますか？`n`n"
            . "デスクトップとスタートメニューの両方に作ります。`n"
            . "次回からアイコンをダブルクリックするだけで使えます。"
            , APP_NAME, "YesNo Iconi 4096") = "Yes") {
            m2 := ""
            ok := CreateDesktopShortcut(&m2)
            MsgBox(m2, APP_NAME, ok ? "Iconi 4096" : "Icon! 4096")
        }
        ; ★保存したら閉じずに設定画面へ戻る★
        ;   続けて別の設定をしたいのに、毎回ソフトが消えていた（2026-09-22 指摘）。
        try dlg.Destroy()
        BackToSettings()
        return
    }
}
;==============================================================================
;  /trace  ★Phase 0 の主役★
;  人が手で 1 周操作する間、対象ソフトの様子を記録する。
;
;  ★v0.2 で作り直した理由（v0.1 の重大な欠陥）★
;    v0.1 は「見えているウィンドウの顔ぶれが変わったら画面が変わった」と判定し、
;    その "今の画面" のコントロールだけを見ていた。
;    ところが実機では TFormHardest / TFormDiagn が調査のあとも閉じずに残り、
;    セラピー中も顔ぶれが変わらなかったため、17 分間まったく記録できなかった。
;    「ポーズ→再開する」も 1 件も取れなかった。
;
;  v0.2 は 3 つの信号を独立に追う。どれか 1 つでも動けば記録できる。
;    (1) 窓の開閉         … どの画面がいつ開いて、いつ閉じたか
;    (2) 窓のタイトル      … TFormHardest は臓器名、TFormDiagn は数字（＝進捗の鼓動）
;    (3) 全窓のボタン文字  … ★「ポーズ」→「再開する」はここで捕まえる★
;==============================================================================
ModeTrace() {
    global C, G, SCRINI, APP_NAME, APP_VER
    pid := EnsureTarget()
    tickMs   := Max(250, CI("TickMs"))
    maxCtrls := CI("MaxTrackedCtrls")
    maxLen   := CI("MaxTextLen")
    stallSec := Max(5, CI("StallSec"))

    buf := "=== AutoMeta /trace  操作記録 ===`r`n"
         . "日時      : " FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss") "`r`n"
         . "バージョン: " APP_VER "`r`n"
         . "対象      : " CS("ExeName") " (pid " pid ")`r`n"
         . "権限      : " (A_IsAdmin ? "管理者" : "通常ユーザー") "`r`n`r`n"
         . "凡例`r`n"
         . "  [窓+]    画面が開いた          [窓-]  画面が閉じた（開いていた時間つき）`r`n"
         . "  [窓名]   タイトルが変わった    [変化] ボタンなどの文字が変わった ★本命★`r`n"
         . "  [鼓動停止] 数字タイトルが止まった（＝処理が終わった可能性）`r`n"
         . "  [クリック] 人が押した`r`n"
         . "----------------------------------------------------------------------`r`n"

    seenClasses := Map()      ; クラス → コントロール一覧を出したか
    screenMap   := Map()      ; 画面 ID → クラス
    episodes    := []         ; 閉じた窓の滞在記録
    openWins    := Map()      ; hwnd → Map("at","cls","id","title")
    titles      := Map()      ; hwnd → Map("t","at","stalled","beats")
    texts       := Map()      ; "hwnd|ClassNN" → 直前のテキスト
    prevSig     := ""
    lastClick   := Map("desc", "（記録なし）", "screen", "", "at", "")
    warnedGone  := false
    lastSave    := 0
    startTick   := A_TickCount

    dlg := Gui("+Resize", APP_NAME " - /trace 操作記録 v0.2" VerTag())
    dlg.MarginX := 14, dlg.MarginY := 10
    dlg.SetFont("s10", "Meiryo UI")
    dlg.Add("Text", "w1000"
        , "対象ソフトを【手で】通常どおり操作してください。ツールは見て記録するだけで、一切操作しません。")
    dlg.SetFont("s10 Bold", "Meiryo UI")
    dlg.Add("Text", "w1000 cRed"
        , "★今回ほしいのは「終わり方」です。調査を 1 回、セラピーを 1 回、どちらも最後まで自然に終わらせてください。")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w1000 cGray"
        , "  途中で「ポーズ」を押さないでください。押すと、自然に終わったのか人が止めたのか区別できなくなります。`n"
        . "  カード選択の手順は前回の記録で判明しているため、再登録は不要です。")
    dlg.SetFont("s10", "Meiryo UI")
    stat := dlg.Add("Text", "w1000 cBlue", "監視中の画面: -")
    dlg.SetFont("s9", "Consolas")
    ed := dlg.Add("Edit", "w1000 h400 ReadOnly -Wrap +VScroll")
    dlg.SetFont("s10", "Meiryo UI")
    btn := dlg.Add("Button", "w260 h36 Default", "記録を終了して保存")
    btn.OnEvent("Click", (*) => FinishTrace())
    dlg.OnEvent("Close", (*) => FinishTrace())
    dlg.Show()

    Hotkey("~LButton", OnClick)          ; ~ 付きなのでクリックはそのまま対象に届く
    SetTimer(TraceTick, tickMs)
    TraceTick()
    return

    ; -- 1 tick ---------------------------------------------------------------
    TraceTick() {
        wins := TargetWindows(pid)
        if (wins.Length = 0) {
            if (!warnedGone) {                      ; 毎 tick 出すと記録が埋まるので 1 回だけ
                warnedGone := true
                Emit("[警告] 対象ウィンドウが 1 つも見えません（最小化していませんか）")
            }
            return
        }
        warnedGone := false

        sig := ""
        for w in wins
            sig .= w["hwnd"] "|"
        if (sig != prevSig) {
            OnWindowSetChanged(wins)
            prevSig := sig
        }
        ; ★ v0.1 の失敗はここ。"今の画面" だけでなく【全部の窓】を見る
        for w in wins {
            TrackTitle(w)
            TrackTexts(w)
        }
        names := ""
        for w in wins
            names .= (names = "" ? "" : " / ") ClassifyScreen(w["hwnd"])["id"]
        stat.Value := "監視中の画面: " names
    }

    ; -- 窓が開いた／閉じた ----------------------------------------------------
    OnWindowSetChanged(wins) {
        now := Map()
        for w in wins
            now[w["hwnd"]] := w

        for h, w in now {
            if openWins.Has(h)
                continue
            id := ClassifyScreen(h)["id"]
            openWins[h] := Map("at", A_TickCount, "cls", w["class"], "id", id, "title", w["title"])
            Emit(Format("[窓+] {1} ({2})  title=「{3}」", id, w["class"], w["title"]))
            if (lastClick["at"] != "")
                Emit("        直前の操作: " lastClick["desc"])
            if (id != "UNKNOWN")
                screenMap[id] := w["class"]
            if !seenClasses.Has(w["class"]) {
                seenClasses[w["class"]] := true
                Emit("        --- " w["class"] " のコントロール一覧 ---")
                Emit(RTrim(CtrlsToText(DumpCtrls(h), "        "), "`n"))
            }
        }
        for h, rec in openWins.Clone() {
            if now.Has(h)
                continue
            sec := Round((A_TickCount - rec["at"]) / 1000, 1)
            Emit(Format("[窓-] {1} ({2}) が閉じました（開いていた時間 {3} 秒）", rec["id"], rec["cls"], sec))
            episodes.Push(Map("id", rec["id"], "class", rec["cls"], "sec", sec
                            , "enteredBy", lastClick["desc"]))
            openWins.Delete(h)
            if titles.Has(h)
                titles.Delete(h)
            for k in texts.Clone() {              ; 閉じた窓の記憶を捨てる（hwnd 再利用への備え）
                if (SubStr(k, 1, StrLen(h) + 1) = h "|")
                    texts.Delete(k)
            }
        }
    }

    ; -- タイトルの変化（TFormHardest は臓器名、TFormDiagn は数字＝鼓動）-------
    TrackTitle(w) {
        h := w["hwnd"], t := w["title"]
        if !titles.Has(h) {
            titles[h] := Map("t", t, "at", A_TickCount, "stalled", false, "beats", 0)
            return
        }
        rec := titles[h]
        if (rec["t"] = t) {
            ; 数字タイトルが動いていたのに止まった＝処理が終わった可能性
            if (!rec["stalled"] && rec["beats"] >= 3 && (A_TickCount - rec["at"]) > stallSec * 1000) {
                rec["stalled"] := true
                Emit(Format("[鼓動停止] {1} のタイトルが {2} 秒変化していません（title=「{3}」／それまで {4} 回変化）"
                          . "  ★処理が終わった可能性", w["class"], stallSec, t, rec["beats"]))
            }
            return
        }
        if (rec["stalled"]) {
            rec["stalled"] := false
            Emit(Format("[鼓動再開] {1} のタイトルがまた動き始めました", w["class"]))
        }
        if (IsBeat(rec["t"]) && IsBeat(t)) {
            rec["beats"] := rec["beats"] + 1       ; 数字→数字は鼓動。1 行ずつは記録しない
        } else {
            Emit(Format("[窓名] {1}: 「{2}」→「{3}」", w["class"], rec["t"], t))
        }
        rec["t"] := t, rec["at"] := A_TickCount
    }

    ; -- ボタンなどの文字の変化（★「ポーズ」→「再開する」はここ★）------------
    TrackTexts(w) {
        h := w["hwnd"]
        ctrls := []
        try ctrls := WinGetControls("ahk_id " h)
        catch
            return
        if (ctrls.Length > maxCtrls)               ; 大量コントロールの窓は追わない
            return
        for cn in ctrls {
            tx := ""
            try tx := ControlGetText(cn, "ahk_id " h)
            catch
                continue
            if (StrLen(tx) > maxLen)
                continue
            key := h "|" cn
            if !texts.Has(key) {
                texts[key] := tx
                continue
            }
            if (texts[key] != tx) {
                Emit(Format("[変化] {1} / {2}: 「{3}」→「{4}」", w["class"], cn, texts[key], tx))
                texts[key] := tx
            }
        }
    }

    ; -- 人がクリックした ------------------------------------------------------
    OnClick(*) {
        MouseGetPos(&mx, &my, &winId, &ctrlNN)
        if (!winId)
            return
        wpid := 0
        try wpid := WinGetPID("ahk_id " winId)
        if (wpid != pid)                            ; 対象ソフト以外のクリックは無視
            return
        rx := mx, ry := my
        try {
            WinGetPos(&wx, &wy, , , "ahk_id " winId)
            rx := mx - wx, ry := my - wy
        }
        scr := ClassifyScreen(winId)["id"]
        desc := DescribeClick(winId, rx, ry, ctrlNN)
        lastClick := Map("desc", desc, "screen", scr, "at", A_Now)
        Emit(Format("[クリック] {1} 上の {2}  （ウィンドウ内 x{3} y{4}）", scr, desc, rx, ry))
    }

    IsBeat(t) => RegExMatch(Trim(t), "^\d{1,5}$") > 0

    ; -- 出力 ------------------------------------------------------------------
    Emit(line) {
        buf .= FormatTime(A_Now, "HH:mm:ss") "  " line "`r`n"
        ed.Value := buf
        try SendMessage(0x0115, 7, 0, ed)          ; 末尾へスクロール
        if (A_TickCount - lastSave > 2000) {       ; 落ちても失われないよう随時保存
            SaveTrace()
            lastSave := A_TickCount
        }
    }

    SaveTrace() {
        path := A_ScriptDir "\trace.txt"
        try FileDelete(path)
        try FileAppend(CRLF(buf . ReportTail()), path, "UTF-8")
    }

    ; -- 末尾のまとめ ----------------------------------------------------------
    ReportTail() {
        out := "`r`n----------------------------------------------------------------------`r`n"
        out .= "■ 画面 ID ↔ ウィンドウクラス`r`n"
        if (screenMap.Count = 0) {
            out .= "  （まだ判定できていません）`r`n"
        } else {
            for id, cls in screenMap
                out .= Format("  {1:-16} = {2}`r`n", id, cls)
        }
        out .= "`r`n■ 閉じた窓と、開いていた時間`r`n"
        if (episodes.Length = 0) {
            out .= "  （まだありません）`r`n"
        } else {
            for e in episodes
                out .= Format("  {1:-16} {2:-22} {3:8} 秒   ← {4}`r`n"
                     , e["id"], e["class"], e["sec"], e["enteredBy"])
        }
        out .= "`r`n■ いま開いたままの窓`r`n"
        for h, rec in openWins
            out .= Format("  {1:-16} {2:-22} {3:8} 秒（継続中）`r`n"
                 , rec["id"], rec["cls"], Round((A_TickCount - rec["at"]) / 1000, 1))
        out .= "`r`n■ 見てほしいところ`r`n"
        out .= "  1) [変化] の行に「ポーズ」→「再開する」があるか`r`n"
        out .= "     それが【クリックの直後ではなく】処理の終わり際に出ていれば、自然終了の合図として使える`r`n"
        out .= "  2) [鼓動停止] が調査の終わり・セラピーの終わりに出ているか`r`n"
        out .= "  3) 調査のあと TFormHardest / TFormDiagn が [窓-] で閉じるか、開いたまま残るか`r`n"
        return out
    }

    ; -- 終了して screens.ini を書く -------------------------------------------
    FinishTrace() {
        global APP_NAME
        SetTimer(TraceTick, 0)
        try Hotkey("~LButton", "Off")
        for h, rec in openWins {
            episodes.Push(Map("id", rec["id"], "class", rec["cls"]
                            , "sec", Round((A_TickCount - rec["at"]) / 1000, 1)
                            , "enteredBy", "（最後まで開いたまま）"))
        }
        SaveTrace()
        WriteScreensIni()
        total := Round((A_TickCount - startTick) / 1000)
        MsgBox("記録を終了しました（" FmtDur(total) "）。`n`n"
            . "  trace.txt    … 操作の記録（★これを Claude に貼ってください）`n"
            . "  screens.ini  … 画面 ID ↔ クラスの対応表（自動生成）`n`n"
            . "画面が " screenMap.Count " 種類 特定できました。"
            , APP_NAME, "Iconi 4096")
        OpenFile(A_ScriptDir "\trace.txt")
        ReopenAndExit(0)
    }

    WriteScreensIni() {
        global SCRINI
        body := "; =============================================================`r`n"
             .  ";  AutoMeta  screens.ini`r`n"
             .  ";  /trace が自動生成しました（" FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss") "）`r`n"
             .  ";  ★内容を目視で確認してから使ってください★`r`n"
             .  "; =============================================================`r`n`r`n"
             .  "[Screens]`r`n"
        for id in ["S0_Menu", "S1_Index", "S2_Card", "S2b_Anamnesis", "S3_Scheme"
                 , "S4_ScanItem", "S5_Indicator", "P1_Progress"]
            body .= id "=" (screenMap.Has(id) ? screenMap[id] : "") "`r`n"
        body .= "`r`n[Timing]`r`n; 実測値（秒）。同じ画面が複数回開いた場合は最長のものを採用`r`n"
        best := Map()
        for e in episodes {
            if (!best.Has(e["id"]) || e["sec"] > best[e["id"]])
                best[e["id"]] := e["sec"]
        }
        for id, sec in best
            body .= id "MaxSec=" sec "`r`n"
        try FileDelete(SCRINI)
        try FileAppend(CRLF(body), SCRINI, "UTF-8")
    }
}

;==============================================================================
;  Phase 1: Navigator — 画面の特定・待機・クリック
;  ★このフェーズから対象ソフトを実際に操作する。安全装置は §12 を参照★
;==============================================================================

; screens.ini（/trace が生成）を読み、画面 ID → クラスの対応を C に載せる。
; ファイルが無ければ SCREEN_CLASSES の既定値をそのまま使う。
LoadScreens() {
    global SCRINI, SCREEN_CLASSES
    m := IniLoad(SCRINI)
    if (!m.Has("Screens"))
        return
    for id, cls in m["Screens"] {
        if (Trim(cls) = "")
            continue
        SCREEN_CLASSES[Trim(cls)] := id          ; クラス → ID の向きで持つ
    }
}

; 指定した画面 ID のウィンドウを返す（無ければ 0）。手前にあるものを優先。
FindScreen(id) {
    global G
    for w in TargetWindows(G.pid) {
        if (ClassifyScreen(w["hwnd"])["id"] = id)
            return w["hwnd"]
    }
    return 0
}

; 今開いている画面 ID の一覧（重複あり）
ScreenList() {
    global G
    out := []
    for w in TargetWindows(G.pid)
        out.Push(ClassifyScreen(w["hwnd"])["id"])
    return out
}

HasScreen(id) => FindScreen(id) != 0

ScreenNames() {
    s := ""
    for id in ScreenList()
        s .= (s = "" ? "" : " / ") id
    return (s = "" ? "（なし）" : s)
}

;==============================================================================
;  クリック — 押す直前に必ず再確認する（安全装置 S4）
;==============================================================================

; コントロールをクリックする。wantText を渡すとキャプションを照合してから押す。
;   ★空文字は「読めなかった」であって「一致した」ではない。押さずに false を返す。
;     （アプリがビジーな瞬間は ControlGetText が空を返す — 仕様書 §5.3-2）
ClickCtrl(hwnd, cnn, wantText := "") {
    global G
    if (!hwnd || cnn = "")
        return false
    try {
        if (!ControlGetVisible(cnn, "ahk_id " hwnd))
            return false
        if (!ControlGetEnabled(cnn, "ahk_id " hwnd))
            return false
    } catch {
        return false
    }
    if (wantText != "") {
        got := ""
        try got := Norm(ControlGetText(cnn, "ahk_id " hwnd))
        if (got = "") {
            Log("DEBUG", "キャプションが読めないため見送り: " cnn "（アプリがビジー）")
            return false
        }
        if (got != Norm(wantText)) {
            ; ★番号がずれていても、キャプションで探し直す★
            ;   コントロール名（TImageButton4 など）は PC ごとに違う。
            ;   ひな型はこちらの環境の実測値なので、別の PC では必ずずれる。
            ;   2026-09-17、別 PC で TImageButton4 が「カードインデックス」だったため
            ;   調査を開始できず、47 回警告を出し続けて失敗した。
            rec := FindCtrlByText(hwnd, wantText)
            alt := rec.Has("cnn") ? rec["cnn"] : ""
            ; ★乗り換える前に、そちらが押せる状態かを確かめる★
            ;   もとのコントロールで済ませていた確認を、探し直した先でもやり直す。
            ok2 := false
            if (alt != "" && alt != cnn)
                try ok2 := ControlGetVisible(alt, "ahk_id " hwnd) && ControlGetEnabled(alt, "ahk_id " hwnd)
            if (ok2) {
                Log("INFO", Format("{1} は「{2}」でした。「{3}」は {4} にあるので、そちらを押します"
                    , cnn, got, wantText, alt))
                cnn := alt
            } else {
                Log("WARN", Format("キャプション不一致のため押しません: {1} 期待「{2}」実際「{3}」"
                    . "（同じ文字のボタンが見つかりません）", cnn, wantText, got))
                return false
            }
        }
    }
    if (!CountClick("ctrl:" cnn))
        return false
    if (CB("DryRun")) {
        Log("INFO", "[DryRun] 押したつもり: " cnn (wantText = "" ? "" : "「" wantText "」"))
        return true
    }
    try ControlClick(cnn, "ahk_id " hwnd, , "Left", 1, "NA")
    Log("INFO", "クリック: " cnn (wantText = "" ? "" : "「" wantText "」"))
    return true
}

; ウィンドウ内の座標をクリックする（描画ボタン用）
; ★コントロールを名指しして、その中の座標を押す★
;   ウィンドウ座標で押すと、重なっているどのコントロールが受け取るかが不確実。
;   マニュアル選択の一覧（TPanel1 x1080-1394 y240-738）は、
;   項目リスト（TCheckListBox1 x693-1411 y251-1002）と重なっている。
;   2026-09-16、「自動選択」を押したつもりが選ばれず、調査項目が 1 つに減っていた
;   （項目リストのチェックを触ってしまったと考えると辻褄が合う）。
ClickCtrlAt(hwnd, cnn, dx, dy, why := "") {
    if (!hwnd || cnn = "")
        return false
    if (!CountClick(Format("ctrl:{1}@{2},{3}", cnn, dx, dy)))
        return false
    if (CB("DryRun")) {
        Log("INFO", Format("[DryRun] 押したつもり: {1} の中 x{2} y{3} {4}", cnn, dx, dy, why))
        return true
    }
    try ControlClick(cnn, "ahk_id " hwnd, , "Left", 1, "NA X" dx " Y" dy)
    Log("INFO", Format("クリック: {1} の中 x{2} y{3} {4}", cnn, dx, dy, why))
    return true
}

ClickAt(hwnd, x, y, why := "") {
    if (!hwnd)
        return false
    if (!CountClick(Format("pos:{1},{2}", x, y)))
        return false
    if (CB("DryRun")) {
        Log("INFO", Format("[DryRun] 押したつもり: x{1} y{2} {3}", x, y, why))
        return true
    }
    try ControlClick(Format("x{1} y{2}", x, y), "ahk_id " hwnd, , "Left", 1, "NA")
    Log("INFO", Format("クリック: x{1} y{2} {3}", x, y, why))
    return true
}

; ★本物のダブルクリック★
;   ControlClick(..., 2, ...) は「押す・離す」を 2 回送るだけで、
;   Windows がダブルクリックと見なす WM_LBUTTONDBLCLK を送らない。
;   Delphi のグリッドはこれを見ているため、回数指定では行が開かない
;   （カマヤン指摘 2026-09-14）。そこでメッセージを直接組み立てて送る。
DoubleClickCtrl(hwnd, cnn, wx, wy, why := "") {
    static WM_LBUTTONDOWN := 0x201, WM_LBUTTONUP := 0x202, WM_LBUTTONDBLCLK := 0x203
    static MK_LBUTTON := 0x0001
    if (!hwnd || cnn = "")
        return false
    ; 渡ってくる座標はウィンドウ内。コントロール内の座標へ直す
    r := CtrlRect(hwnd, cnn)
    if (!r["ok"])
        return false
    px := r["x"], py := r["y"], pw := r["w"], ph := r["h"]
    rx := wx - px, ry := wy - py
    if (rx < 0 || ry < 0 || rx > pw || ry > ph) {
        Log("WARN", Format("行の座標がグリッドの外です（グリッド x{1} y{2} w{3} h{4} / 指定 x{5} y{6}）"
            , px, py, pw, ph, wx, wy))
        return false
    }
    lp := ((ry & 0xFFFF) << 16) | (rx & 0xFFFF)
    try {
        PostMessage(WM_LBUTTONDOWN,   MK_LBUTTON, lp, cnn, "ahk_id " hwnd)
        PostMessage(WM_LBUTTONUP,     0,          lp, cnn, "ahk_id " hwnd)
        PostMessage(WM_LBUTTONDBLCLK, MK_LBUTTON, lp, cnn, "ahk_id " hwnd)
        PostMessage(WM_LBUTTONUP,     0,          lp, cnn, "ahk_id " hwnd)
    } catch as e {
        Log("WARN", "ダブルクリックを送れませんでした: " e.Message)
        return false
    }
    Log("INFO", Format("ダブルクリック: {1} の x{2} y{3}（ウィンドウ内 x{4} y{5}）{6}"
        , cnn, rx, ry, wx, wy, why))
    return true
}

; 「自動セラピー」の位置を毎回計算する（v4 と同一。端末差・解像度差に追従）
;   [インタラクティブ既往症]  ←この間の中央→  [調査]
AutoTherapyPoint(hwnd, &cx, &cy, &how) {
    cx := 0, cy := 0, how := ""
    lrec := FindCtrlByText(hwnd, CS("AnchorLeftText"))
    rrec := FindCtrlByText(hwnd, CS("AnchorRightText"))
    if (lrec.Count > 0 && rrec.Count > 0) {
        sameRow := (Abs(lrec["y"] - rrec["y"]) <= 12)
        gapL := lrec["x"] + lrec["w"]
        gapR := rrec["x"]
        if (sameRow && (gapR - gapL) >= 40) {
            cx := (gapL + gapR) // 2
            cy := lrec["y"] + lrec["h"] // 2
            how := Format("アンカー計算（隙間 {1}px）", gapR - gapL)
            return true
        }
    }
    if (CS("TherapyClickX") != "" && CS("TherapyClickY") != "") {
        cx := CI("TherapyClickX"), cy := CI("TherapyClickY")
        how := "config の固定座標"
        return true
    }
    return false
}

; テキストが一致するコントロールの位置を返す（v4 と同一）
FindCtrlByText(hwnd, text) {
    rec := Map()
    want := Norm(text)
    if (want = "" || !hwnd)
        return rec
    ctrls := []
    try ctrls := WinGetControls("ahk_id " hwnd)
    catch
        return rec
    for cn in ctrls {
        t := ""
        try t := Norm(ControlGetText(cn, "ahk_id " hwnd))
        if (t != "" && t = want) {
            r := CtrlRect(hwnd, cn)
            if (r["ok"])
                rec := Map("cnn", cn, "x", r["x"], "y", r["y"], "w", r["w"], "h", r["h"])
            return rec
        }
    }
    return rec
}

;==============================================================================
;  安全装置 S1 / S2 — サーキットブレーカーと最小クリック間隔
;==============================================================================
CountClick(what) {
    global G
    ; --- S2: 最小クリック間隔（先に見る）--------------------------------------
    ;   ★見送りは「押していない」ので、繰り返しには数えない★
    ;     2026-09-14 の実機で、見送りまで数えたため実際は 2 回しか押していないのに
    ;     「4 回続けて押そうとしました」と誤検知して止まった。
    gap := CI("MinClickGapSec")
    if (gap > 0 && G.lastClickTS != "" && SecSince(G.lastClickTS) < gap) {
        Log("DEBUG", Format("最小クリック間隔 {1} 秒に満たないため見送り（前回から {2} 秒）"
            , gap, SecSince(G.lastClickTS)))
        return false
    }
    ; --- S1a: 同じ状態で同じものを【実際に】何度も押していないか ---------------
    if (what = G.lastTarget && G.state = G.lastTargetState) {
        G.repeat++
    } else {
        G.repeat := 1
        G.lastTarget := what
        G.lastTargetState := G.state
    }
    if (G.repeat > CI("MaxSameClick")) {
        Abort(Format("同じものを {1} 回押しましたが、画面が変わりません。`n`n"
            . "  状態  : {2}`n  対象  : {3}`n`n"
            . "ソフトが応答していないか、押す場所が違っている可能性があります。"
            . "暴走を防ぐため停止しました。", G.repeat, G.state, what))
        return false
    }
    ; --- S1b: 総クリック数の上限 ---------------------------------------------
    if (G.clicks >= MaxClicksTotal()) {
        Abort(Format("総クリック数が上限 {1} に達しました（直近: {2} / 状態: {3}）。`n"
            . "暴走を防ぐため停止します。", MaxClicksTotal(), what, G.state))
        return false
    }
    G.clicks++
    G.lastClickTS := A_Now
    return true
}

; ★押したあとは、間を置いてから押し直す★
;   これまでは毎 tick（1 秒ごと）に押そうとしていたため、
;   画面の切り替わりが少し遅いだけで「何度も押している」ことになっていた。
;   一度押したら RetryGapSec 秒は待ち、画面が変わるのを見守る。
TryClick(hwnd, cnn, text := "") {
    global G
    if (!hwnd || cnn = "")
        return false
    if (G.stateClickTS != "" && SecSince(G.stateClickTS) < CI("RetryGapSec"))
        return false                                ; まだ待つ
    if (ClickCtrl(hwnd, cnn, text)) {
        G.stateClickTS := A_Now
        return true
    }
    return false                                    ; 押せなかった（ビジー等）ので次の tick で再挑戦
}

; 正常な 1 実行に必要なクリックの実数（実測で 11 回）に、
; セラピー 1 回あたりの再ナビゲーション分とリトライの余裕を足す。
;   ★以前は 8 + N + 3 としていたが、正常動作ですら足りず誤停止していた（2026-09-14 修正）
MaxClicksTotal() {
    global G
    ; ★やり直した回数ぶん、上限を足す★
    ;   やり直しでクリックが増えるのは当然なので、安全装置に引っかけない。
    return CI("BaseClicks") + CI("TherapyCount") * 2 + CI("MaxClicksExtra")
         + G.jobRetry * 12
}

;==============================================================================
;  ★G1★ 氏名照合ゲート — 本ツールで最も重要な安全装置
;
;  カード画面は項目ごとに順に書き換わり、一瞬だけ前の顧客のデータが混ざる
;  （実測・仕様書 §7.2）。値が安定するまで読まないこと。
;==============================================================================

; 姓名を「同じ値が SettleChecks 回続いたら確定」で読む。
; 確定できなければ false。
ReadPatientSettled(hwnd, &sei, &mei, &why) {
    sei := "", mei := "", why := ""
    cnSei := CS("LastNameFieldClassNN")
    cnMei := CS("FirstNameFieldClassNN")
    if (cnSei = "" || cnMei = "") {
        why := "config.ini に姓名の欄が設定されていません（/listread を実行してください）"
        return false
    }
    need  := Max(2, CI("SettleChecks"))
    wait  := Max(100, CI("SettleIntervalMs"))
    limit := Max(3, CI("SettleTimeoutSec"))
    started := A_Now
    lastS := "", lastM := "", same := 0
    Loop {
        if (SecSince(started) > limit) {
            why := Format("姓名が {1} 秒たっても安定しません（最後に読めた値: 「{2}」「{3}」）"
                , limit, lastS, lastM)
            return false
        }
        s := "", m := ""
        try s := Trim(ControlGetText(cnSei, "ahk_id " hwnd))
        try m := Trim(ControlGetText(cnMei, "ahk_id " hwnd))
        if (s != "" && m != "" && s = lastS && m = lastM) {
            same++
            if (same >= need) {
                sei := s, mei := m
                return true
            }
        } else {
            same := 1
        }
        lastS := s, lastM := m
        Sleep(wait)
    }
}

; カード画面から、ミドルネームの欄を推定する
;   姓 / 名前 / ミドルネーム の順に並んでいるので、DB 連動の入力欄の 3 番目。
;   「読み取り可否を調べる」とまったく同じ選び方。
;   ★設定が空のときだけ使い、選んだ結果は config.ini に記録する★
;   2026-09-18、欄が未登録というだけで実行できず、利用者を行き止まりにしていた。
;   カード画面は目の前に開いているのだから、その場で見つければよい。
GuessMiddleField(hwnd) {
    rows := []
    for r in DumpCtrls(hwnd) {
        if (!RegExMatch(r["cnn"], "i)dbedit") || r["y"] = "")
            continue
        rows.Push(r)
    }
    Loop Max(0, rows.Length - 1) {                 ; y の小さい順（画面の上から）
        i := A_Index
        Loop rows.Length - i {
            j := A_Index
            if (rows[j]["y"] > rows[j + 1]["y"]) {
                tmp := rows[j], rows[j] := rows[j + 1], rows[j + 1] := tmp
            }
        }
    }
    return (rows.Length >= 3) ? rows[3]["cnn"] : ""
}

; カード画面のミドルネームを読む（設定していなければ空文字）
;   ★同姓同名の別カードを見分けるために要る★
;   2026-09-18、ビフォーアフター比較用に「ミドルネームだけ違う同一人物のカード」を
;   作って使っている運用があると判明した。姓名だけでは区別できない。
ReadMiddleName(hwnd) {
    return ReadMiddleSettled(hwnd)["text"]
}

; ミドルネームを「同じ値が続いたら確定」で読む。
;   ★姓名と同じ待ち方をする★
;   2026-09-18、姓名だけ待ってミドルは 1 回読むだけだったため、
;   カード画面が書き換わる途中の【空】を読み、空欄指定と一致して素通りした。
;   ok=false は「一度も読めなかった」。空だったのか読めなかったのかを区別する。
ReadMiddleSettled(hwnd) {
    cn := CS("MiddleNameFieldClassNN")
    if (cn = "")
        return Map("ok", false, "text", "", "why", "ミドルネームの欄が設定されていません")
    need  := Max(2, CI("SettleChecks"))
    wait  := Max(100, CI("SettleIntervalMs"))
    limit := Max(3, CI("SettleTimeoutSec"))
    started := A_Now
    last := "", same := 0, got := false
    Loop {
        t := "", read := false
        try {
            t := Trim(ControlGetText(cn, "ahk_id " hwnd))
            read := true
        }
        if (read)
            got := true
        if (read && t = last) {
            same++
            if (same >= need)
                return Map("ok", true, "text", t, "why", "")
        } else {
            same := 1
        }
        last := t
        if (SecSince(started) > limit)
            return Map("ok", got, "text", last
                     , "why", got ? "" : "ミドルネームの欄を読めませんでした")
        Sleep(wait)
    }
}

; 予定の氏名と完全一致するか。しなければジョブを中止する（リトライしない）。
VerifyPatient(hwnd) {
    ; C は、ミドルネーム欄を自動で見つけたときに記録するために使う
    global G, C, CFG
    if (!CB("VerifyPatientName")) {
        Abort("VerifyPatientName=0 は許可されていません。氏名照合を省略しての実行はできません。")
        return false
    }
    if (!ReadPatientSettled(hwnd, &sei, &mei, &why)) {
        Abort("★氏名を読み取れませんでした。安全のため中止します。`n" why)
        return false
    }
    okS := (Norm(sei) = Norm(G.wantSei))
    okM := (Norm(mei) = Norm(G.wantMei))
    if (okS && okM) {
        ; ★ミドルネームまで見る★
        ;   同姓同名で、ミドルネームだけ違うカードが並んでいることがある
        ;   （ビフォーアフター比較用）。一覧は先頭行を開くので、
        ;   姓名だけでは【別のカードを開いたまま素通り】してしまう。
        cnMid := CS("MiddleNameFieldClassNN")
        ; ★空欄指定のときも欄を探す★
        ;   「欄が未登録 かつ 空欄指定」だと、以前は照合を丸ごと飛ばしていた。
        ;   空欄は「ミドルの無いカードを対象にする」という指定なので、
        ;   一番守るべき場面で無検査になっていた（2026-09-18）。
        if (cnMid = "") {
            ; ★その場で見つけて覚える★ 欄が未登録というだけで止めない
            cnMid := GuessMiddleField(hwnd)
            if (cnMid != "") {
                IniSet(CFG, ModelSec("Select"), "MiddleNameFieldClassNN", cnMid)
                C["MiddleNameFieldClassNN"] := cnMid
                Log("INFO", Format("ミドルネームの欄を見つけて記録しました: {1}（読めた値「{2}」）"
                    , cnMid, ReadMiddleName(hwnd)))
            }
        }
        if (cnMid = "") {
            if (Trim(G.wantMid) != "") {
                SaveShot("g1_no_middle_field")
                Abort(Format("予定でミドルネーム「{1}」を指定していますが、"
                    . "【ツール側の設定】で、画面のどの欄がミドルネームかを特定できませんでした。`n`n"
                    . "※ カードの内容の問題ではありません。ツールが欄の場所を知らないという意味です。`n`n"
                    . "カード画面を開いた状態で「設定 →『読み取り可否を確認』」を"
                    . "実行してください。", G.wantMid))
                return false
            }
        } else {
            mr  := ReadMiddleSettled(hwnd)
            mid := mr["text"]
            if (!mr["ok"]) {
                ; ★読めていないなら合格にしない★ 空欄と区別がつかないため
                SaveShot("g1_middle_unread")
                Abort(Format("ミドルネームを読み取れませんでした（{1}）。`n`n"
                    . "同姓同名の別カードと区別できないため中止しました。", mr["why"]))
                return false
            }
            if (Norm(mid) != Norm(G.wantMid)) {
                ; ★同じカードが開いたら、行の間隔が足りていない★
                ;   2026-09-18、カードは 2 枚しか無いのに 3 行目まで試していた。
                ;   1 行目の下寄りと 2 行目の上寄りを指して教えると、
                ;   差が実際の行の高さより小さく記録されるため起きる。
                ;   同じ位置を踏み続けないよう、そのぶん余計に進める。
                ; ★行番号を飛ばしてはいけない★
                ;   2026-09-18、ここで rowTry を足したうえに通常の加算も走り、
                ;   2 行目の次が 4 行目になって【正解の 3 行目を読み飛ばし】、
                ;   別人のカードに到達した（照合が止めたので実害はなし）。
                ;   行番号はそのまま 1 つずつ進め、位置だけを半行ぶん下へずらす。
                card := Norm(sei) . "|" . Norm(mei) . "|" . Norm(mid)
                if (card = G.lastCard) {
                    G.rowExtra += Max(8, CI("ListRowPitchY") // 2)
                    Log("WARN", Format("同じカードがまた開きました。行の間隔（{1}px）が"
                        . "実際の行の高さより小さいようです。次回から {2}px 下げて補正します"
                        , CI("ListRowPitchY"), G.rowExtra))
                }
                G.lastCard := card
                ; ★次の行を試せるなら、中止せずに戻る★
                ;   一覧は常に上から開くので、狙いのカードが 2 行目以降にある。
                if (CI("ListRowPitchY") > 0 && G.rowTry < CI("ListMaxRows")) {
                    G.rowTry++
                    G.rowClicked := false
                    ; ★検索をやり直す★
                    ;   2026-09-18、2 行目以降は検索を素通りしていた（利用者の指摘）。
                    ;   一覧に戻ると絞り込みが解除されている可能性があり、
                    ;   その場合【絞り込まれていない一覧】の行を開いてしまう。
                    ;   実際に別人（同姓の方）のカードに到達した。
                    G.searched := false
                    Log("INFO", Format("ミドルが違うので次の行を試します（{1} 行目へ／"
                        . "この行は「{2}」）", G.rowTry, mid = "" ? "なし" : mid))
                    SetState("open_index", "別の行を開きます")
                    Arm(800)
                    return false
                }
                SaveShot("g1_middle_mismatch")
                ; ★次の行を試せなかった理由を、そのまま伝える★
                ;   2026-09-22、行の間隔が未登録のまま、1 行目だけ見て中止していた。
                ;   「取り違えた」とだけ出ても、次に何をすればよいか分からない。
                hint := ""
                if (CI("ListRowPitchY") <= 0) {
                    hint := "`n`n【次にすること】`n"
                        . "　一覧の【行の間隔】が登録されていないため、1 行目しか見ていません。`n"
                        . "　設定 →「測定値を設定し直す」→「一覧の 1 行目と 2 行目を登録」で、1 行目に続けて"
                        . "【2 行目】も登録してください。`n"
                        . "　そうすると、2 行目以降にある本来のカードを自動で探します。"
                } else if (G.rowTry >= CI("ListMaxRows")) {
                    hint := Format("`n`n{1} 行目まで試しましたが、見つかりませんでした。"
                        . "`n検索で絞り込めているか確かめてください。", CI("ListMaxRows"))
                }
                Abort(Format("★★ 別のカードが開いています（ミドルネーム違い）★★`n`n"
                    . "  予定: 「{1} {2}」ミドル「{3}」`n"
                    . "  実際: 「{4} {5}」ミドル「{6}」`n`n"
                    . "セラピーは一切行わずに中止しました。`n"
                    . "ビフォーアフター比較用のカードと取り違えている可能性があります。{7}"
                    , G.wantSei, G.wantMei, G.wantMid = "" ? "（なし）" : G.wantMid
                    , sei, mei, mid = "" ? "（なし）" : mid, hint))
                return false
            }
            G.gotMid := mid
        }
        Log("INFO", Format("★G1 照合 OK: 「{1} {2}」{3}", sei, mei
            , G.gotMid = "" ? "" : "ミドル「" G.gotMid "」"))
        G.gotSei := sei, G.gotMei := mei
        try PreNoticeAtStart()                     ; ★動き始めてから送る★ 失敗しても運転は止めない
        return true
    }
    SaveShot("g1_mismatch")
    Abort(Format("★★ 別人のカードが開いています ★★`n`n"
        . "  予定: 「{1} {2}」`n  実際: 「{3} {4}」`n`n"
        . "セラピーは一切行わずに中止しました。`n"
        . "同姓の方がいる場合は、schedule の氏名が正確か確認してください。"
        , G.wantSei, G.wantMei, sei, mei))
    return false
}

;==============================================================================
;  ホーミング — 想定外の場所からでも安全な起点へ戻す（G4）
;  ★原則: 閉じる／戻る方向にしか操作しない。分からない画面では絶対に押さない★
;==============================================================================
HomeStep() {
    global G
    ; セラピー中なら絶対に割り込まない（G8）
    if (HasScreen("S4_ScanItem") || HasScreen("S5_Indicator")) {
        Log("INFO", "実行中の画面があります。完了を待ちます（割り込みません）")
        return "wait"
    }
    if (h := FindScreen("P1_Progress"))
        return "wait"                              ; 進捗ダイアログは消えるのを待つ
    if (h := FindScreen("Dialog")) {
        TryClick(h, CS("DialogOkClassNN"), CS("DialogOkText"))
        return "wait"
    }
    if (h := FindScreen("S1_Index"))
        return "done"                              ; ここが起点
    if (h := FindScreen("S2b_Anamnesis")) {
        TryClick(h, CS("AnamnesisNextClassNN"), CS("AnamnesisNextText"))
        return "wait"
    }
    if (h := FindScreen("S3_Scheme")) {
        ; ★部品の番号はモデルごとに違う★
        ;   TImageButton3 は 18D での番号。別モデルでは空振りして起点に戻れない
        ;   （2026-09-22 指摘）。まず文字で探し、見つからなければ番号で押す。
        rec := FindCtrlByText(h, CS("SchemeBackText"))
        if (rec.Has("cnn"))
            TryClick(h, rec["cnn"], CS("SchemeBackText"))
        else
            TryClick(h, CS("SchemeBackClassNN"), CS("SchemeBackText"))
        return "wait"
    }
    if (h := FindScreen("S2_Card"))
        return "done"                              ; カード画面も起点として使える
    if (h := FindScreen("S0_Menu")) {
        ; ★ログイン画面は押して通る★
        ;   2026-09-18 までは「ログインは自動化しない」と決めていた。
        ;   パスワードが要る前提だったが、実機では【ボタンを 1 回押すだけ】で、
        ;   認証情報は一切扱わないと分かった（利用者に確認済み）。
        ;   H-4 でソフトを自動起動する以上、ここを通れないと無人運転が成立しない。
        ;   ★ボタンは文字で探す★ TImageButton23 のような番号は PC ごとに変わる。
        rec := FindCtrlByText(h, CS("LoginText"))
        if (rec.Has("cnn")) {
            TryClick(h, rec["cnn"], CS("LoginText"))
            return "wait"
        }
        Abort(Format("メニュー画面に「{1}」のボタンが見つかりません。`n"
            . "手でログインしてから、もう一度実行してください。", CS("LoginText")))
        return "abort"
    }
    ; ★最後の手立て 1★
    ;   画面の種類が分からなくても、「カードインデックス」ボタンがあれば
    ;   それを押せば起点へ戻れる。諦める前に一度だけ試す。
    for hw in TargetWindows(G.pid) {
        rec := FindCtrlByText(hw, CS("SchemeBackText"))
        if (rec.Has("cnn")) {
            Log("INFO", "見覚えのない画面ですが「" . CS("SchemeBackText") . "」があるので押します")
            TryClick(hw, rec["cnn"], CS("SchemeBackText"))
            return "wait"
        }
    }
    ; ★最後の手立て 2★ ログインのボタンがあれば、それを押して次へ進む
    ;   起動直後のメニューがメニューとして判定できなかったときの保険。
    for hw in TargetWindows(G.pid) {
        rec := FindCtrlByText(hw, CS("LoginText"))
        if (rec.Has("cnn")) {
            Log("INFO", "「" . CS("LoginText") . "」があるので押します")
            TryClick(hw, rec["cnn"], CS("LoginText"))
            return "wait"
        }
    }
    ; ★最後の手立て 3★「終了」で 1 つ前の画面へ戻る
    ;   解析・エタロン・比較分析などには「カードインデックス」が無い。
    ;   これらは「終了」を押すと 1 つ前へ戻るので、順に戻していけば
    ;   いつかカード画面か一覧に着く（2026-09-29 指摘）。
    ;   ★起動直後のメニューでは押さない★ そこで押すとソフトが終了する。
    ;     ログインのボタンがある窓は、上の手立て 2 で先に拾っている。
    for hw in TargetWindows(G.pid) {
        if (FindCtrlByText(hw, CS("LoginText")).Has("cnn"))
            continue                               ; メニュー画面なので触らない
        rec := FindCtrlByText(hw, CS("ExitText"))
        if (!rec.Has("cnn"))
            continue
        if (G.homeExit >= CI("ExitMaxPress")) {
            SaveShot("home_exit_limit")
            Abort(Format("「{1}」を {2} 回押しましたが、カード選択にたどり着けませんでした。`n"
                . "いまの画面: {3}", CS("ExitText"), G.homeExit, ScreenNames()))
            return "abort"
        }
        G.homeExit++
        Log("INFO", Format("「{1}」を押して 1 つ前の画面へ戻ります（{2} 回目／いまの画面: {3}）"
            , CS("ExitText"), G.homeExit, ScreenNames()))
        TryClick(hw, rec["cnn"], CS("ExitText"))
        return "wait"
    }
    SaveShot("unknown_screen")
    Abort("想定していない画面です: " ScreenNames()
        . "`n`n何も押さずに中止しました。screenshots フォルダに画面を保存しています。")
    return "abort"
}


;==============================================================================
;  Phase 1: ジョブの状態機械
;  1 ジョブ ＝ 1 人に対する「調査 1 回 ＋ セラピー N 回」
;
;  状態遷移（仕様書 §6）
;    homing → select → verify(G1) → scan → therapy × N → cleanup → done
;  どの状態からでも、停止指示・異常があれば abort へ抜ける。
;==============================================================================

; ★ジョブ用の状態を、毎回すべて初期化する★
;   2026-09-15、スケジュール運転の 2 件目が失敗した。
;   G.searched / G.rowClicked が前のジョブの true のままだったため、
;   検索も行のクリックもせず、60 秒待って中止していた。
;   要約に前の人の「調査 37 項目」が出ていたのも同じ原因。
;   ★ここでは wantSei / wantMei / skipSelect / manualJob は触らない★
;     （呼ぶ側が「誰に何をするか」として先に決めているため）
ResetJobState() {
    global G
    G.state := "idle", G.stateTS := "", G.startTS := "", G.stopping := false
    G.gotSei := "", G.gotMei := "", G.gotMid := ""
    G.searched := false, G.rowClicked := false, G.rowTry := 1, G.lastCard := ""
    G.rowExtra := 0, G.jobRetry := 0, G.homeExit := 0, G.openMiss := 0
    G.clicks := 0, G.lastClickTS := ""
    G.repeat := 0, G.lastTarget := "", G.lastTargetState := "", G.stateClickTS := ""
    G.cycle := 0, G.cycleStartTS := "", G.durations := [], G.stable := 0
    G.maxGap := 0, G.therapySeenTS := "", G.runLogTS := ""
    G.scanBefore := "", G.scanStartTS := "", G.scanProgressTS := ""
    G.scanItems := 0, G.scanSec := 0, G.lastScanItem := "", G.dialogSeen := false
    G.needCheck := ""
    G.logLost   := 0
    G.optStep := 0, G.optTS := "", G.optTries := 0, G.optBusy := false, G.optWarn := ""
    G.optOff := 0, G.optLast := 0, G.optNoBtn := 0, G.optAlt := ""
    G.statusTS := ""
}

StartJob() {
    global G
    ResetJobState()
    ; 自動セラピーでは顧客の検索・選択を行わない（いま開いているカードが対象）
    ; ★どこから始めるか★
    ;   自動セラピー   … いま開いているカード。検索も選択もしない
    ;   開いているカード … 探しに行かず、その場で氏名を照合してから調査へ
    ;   ふだん         … 起点に戻って、検索して選ぶ
    startState := "homing"
    if (G.skipSelect)
        startState := "therapy_ready"
    else if (G.useOpenCard)
        startState := "verify"
    G.state      := startState
    G.stateTS    := A_Now
    G.startTS    := A_Now
    SaveState()                                    ; 開始した時点で誰のジョブかを残す
    ; ★起動直後のソフトは、一覧が開くのに時間がかかる★ 押し直しの回数と、画面に入ってからの待ちを増やす
    age := ProcessAgeSec(G.pid ? G.pid : FindPidByExe(CS("ExeName")))
    G.freshApp := (age >= 0 && age < CI("FreshAppSec"))
    if (G.freshApp)
        Log("INFO", Format("対象ソフトは起動して {1} 秒です（起動直後のため、一覧が開くのを長めに待ちます）", age))
    Log("INFO", Format("=== ジョブ開始 対象=「{1} {2}」 調査={3} セラピー={4}回 DryRun={5} ==="
        , G.wantSei, G.wantMei, CB("RunInvestigation") ? "する" : "しない"
        , CI("TherapyCount"), CB("DryRun") ? 1 : 0))
    WriteStatus(true)
    WriteLive()
    Arm(500)
}

SetState(state, note := "") {
    global G
    if (G.state = state)
        return
    Log("INFO", Format("状態: {1} → {2}{3}", G.state, state, note = "" ? "" : "（" note "）"))
    G.state        := state
    G.stateTS      := A_Now
    G.stable       := 0
    G.repeat       := 0
    G.stateClickTS := ""
    G.optStep      := 0
    G.optTries     := 0
    G.optBusy      := false
    G.optOff       := 0
    G.optLast      := 0
    G.optNoBtn     := 0
    G.optAlt       := ""
    ; ★いま誰を、どこまで進めたかを残す★
    ;   以前は「セラピー中」と「終了時」にしか書いていなかったため、
    ;   調査中に落ちると【前のジョブの人】が確認待ちに載った（2026-09-21 発見）。
    ;   状態が変わるときだけなので、書き込みは 1 ジョブあたり十数回に収まる。
    SaveState()
    WriteStatus(true)
}

Arm(ms) => SetTimer(Tick, -Abs(ms))

StateSec() {
    global G
    return SecSince(G.stateTS)
}

; 状態ごとの制限時間を超えたら中止する（G3）
StateTimedOut(sec, what) {
    if (StateSec() <= sec)
        return false
    Abort(Format("{1} が {2} 秒たっても進みませんでした。`n現在の画面: {3}"
        , what, sec, ScreenNames()))
    return true
}

;==============================================================================
;  1 tick
;==============================================================================
Tick() {
    global G
    if (G.stopping)
        return
    if (CheckStopFiles())
        return
    ; S3: 実行時間の上限
    if (SecSince(G.startTS) > CI("MaxRuntimeSec")) {
        Abort(Format("実行時間が上限 {1} を超えました。", FmtDur(CI("MaxRuntimeSec"))))
        return
    }
    if (!ProcessAlive()) {
        Abort("対象ソフトのウィンドウが見えなくなりました（終了・最小化していませんか）。")
        return
    }
    WriteStatus()

    ; --- DryRun は画面が動かないので、各状態を一巡したら次へ送る ---------------
    ;   ★氏名照合(verify)だけは本当に読ませる。ここを飛ばすと確認の意味がない
    static dryNext := Map(
        "homing",        "open_index",
        "open_index",    "search",
        "search",        "pick_row",
        "pick_row",      "verify",
        "scan_open",     "scan_anamnesis",
        "scan_anamnesis","scan_scheme",
        "scan_scheme",   "scan_type",
        "scan_type",     "scan_manual",
        "scan_manual",   "scan_go",
        "scan_go",       "scan_running",
        "scan_running",  "scan_dialog",
        "scan_dialog",   "scan_check",
        "scan_check",    "therapy_ready",
        "therapy_ready", "therapy_click",
        "therapy_click", "therapy_start")
    if (CB("DryRun") && dryNext.Has(G.state) && StateSec() >= CI("DryHopSec")) {
        SetState(dryNext[G.state], "DryRun のため次へ")
        Arm(300)
        return
    }

    switch G.state {
        case "homing":        TickHoming()
        case "open_index":    TickOpenIndex()
        case "search":        TickSearch()
        case "pick_row":      TickPickRow()
        case "verify":        TickVerify()
        case "scan_open":     TickScanOpen()
        case "scan_anamnesis":TickScanAnamnesis()
        case "scan_scheme":   TickScanScheme()
        case "scan_type":     TickScanOption("ScanType")
        case "scan_manual":   TickScanOption("Manual")
        case "scan_go":       TickScanGo()
        case "scan_running":  TickScanRunning()
        case "scan_dialog":   TickScanDialog()
        case "scan_check":    TickScanCheck()
        case "therapy_ready": TickTherapyReady()
        case "therapy_click": TickTherapyClick()
        case "therapy_start": TickTherapyStart()
        case "therapy_run":   TickTherapyRun()
        case "therapy_rest":  TickTherapyRest()
        case "cleanup":       TickCleanup()
        default:              Arm(1000)
    }
}

ProcessAlive() {
    global G
    return TargetWindows(G.pid).Length > 0
}

;==============================================================================
;  顧客を選ぶ
;==============================================================================
TickHoming() {
    if (StateTimedOut(CI("HomingTimeoutSec"), "起点の画面へ戻る処理"))
        return
    r := HomeStep()
    if (r = "abort")
        return
    if (r = "wait") {
        Arm(2000)
        return
    }
    SetState("open_index")
    Arm(300)
}

; カード画面から「カードを選択します」で患者一覧を開く
TickOpenIndex() {
    global G
    if (HasScreen("S1_Index")) {
        SetState("search")
        Arm(300)
        return
    }
    if (StateTimedOut(CI("TransitionTimeoutSec"), "患者一覧を開く処理"))
        return
    if (h := FindScreen("S2_Card")) {
        if (TryClick(h, CS("SelectCardClassNN"), CS("SelectCardText"))) {
            G.openMiss := 0
            Arm(1000)
            return
        }
        ; ★押せない状態が続くなら、カード画面ではない★
        ;   2026-09-29、解析の画面をカード画面と取り違え、
        ;   「カードを選択します」の代わりに「テスト」を見つけて 15 秒空回りした。
        ;   粘らずに起点へ戻り、「終了」で画面を戻していく。
        G.openMiss++
        if (G.openMiss >= 8) {
            Log("WARN", "「" . CS("SelectCardText") . "」を押せない状態が続きます。"
                . "起点へ戻ります")
            G.openMiss := 0
            SetState("homing", "一覧を開けないため")
            Arm(800)
            return
        }
    }
    Arm(1000)
}

; 検索欄に「姓␣名」を入れて Enter（仕様書 §7.1 で実証）
; 検索欄に入れる文字を組み立てる。
;   ★ミドルの指定があれば足す★
;   2026-09-18 に実機で確認: 「姓 名 ミドル」で検索すると
;   ミドルありのカードだけが 1 件に絞られる。
;   ※ 空欄指定（ミドルの無いカードを狙う）は検索では表現できない。
;     そちらは開いて照合し、違えば次の行へ進む方式が要る（未実装）。
SearchKey() {
    global G
    key := G.wantSei . NameSep() . G.wantMei
    if (Trim(G.wantMid) != "")
        key .= NameSep() . Trim(G.wantMid)
    return key
}

TickSearch() {
    global G
    h := FindScreen("S1_Index")
    if (!h) {
        if (CB("DryRun") && !G.searched) {
            G.searched := true
            Log("INFO", "[DryRun] 検索欄に入れるつもり: 「" SearchKey() "」")
        }
        if (StateTimedOut(CI("TransitionTimeoutSec"), "患者一覧の表示"))
            return
        Arm(500)
        return
    }
    if (G.searched) {
        SetState("pick_row")
        Arm(1200)                                   ; 絞り込みの反映を待つ
        return
    }
    cn := CS("SearchBoxClassNN")
    if (cn = "") {
        Abort("検索欄が config.ini に設定されていません（/listread を実行してください）。")
        return
    }
    key := SearchKey()
    if (CB("DryRun")) {
        Log("INFO", "[DryRun] 検索欄に入れたつもり: 「" key "」")
    } else {
        try {
            ControlSetText(key, cn, "ahk_id " h)
            ControlFocus(cn, "ahk_id " h)
            Sleep(200)
            ControlSend("{Enter}", cn, "ahk_id " h)
        } catch as e {
            Abort("検索欄に入力できませんでした: " e.Message)
            return
        }
    }
    Log("INFO", "検索: 「" key "」＋ Enter")
    G.searched := true
    Arm(1200)
}

; 姓と名のあいだの区切り。
;   INI のパーサは値を Trim するため、半角スペースをそのまま書いても消えてしまう。
;   そこでキーワードで指定する（既定は半角スペース = 実機で 1 件に絞れることを実証済み）。
NameSep() {
    v := CS("NameSeparator")
    if (v = "" || v = "space" || v = "sp")
        return " "
    if (v = "none" || v = "-")
        return ""
    if (v = "fullwidth" || v = "zen")
        return Chr(0x3000)
    return v
}

; 絞り込んだ先頭行を開く。1 件に絞れている保証はないので G1 が最終防壁。
TickPickRow() {
    global G
    h := FindScreen("S1_Index")
    if (!h) {
        if (HasScreen("S2_Card")) {                 ; もう開いた
            SetState("verify")
            Arm(500)
            return
        }
        if (StateTimedOut(CI("TransitionTimeoutSec"), "患者一覧の表示"))
            return
        Arm(500)
        return
    }
    if (StateTimedOut(CI("TransitionTimeoutSec"), "顧客の行を開く処理"))
        return
    if (!G.rowClicked) {
        x := CI("ListFirstRowX"), y := CI("ListFirstRowY")
        ; ★2 行目以降は、行の間隔ぶん下を開く★
        ;   ミドル無しのカードを狙うとき、検索では絞れないので
        ;   開いて照合し、違えば次の行を試す（2026-09-18）。
        if (G.rowTry > 1)
            y += CI("ListRowPitchY") * (G.rowTry - 1)
        y += G.rowExtra                            ; 同じ行を踏んだぶんの補正
        if (x <= 0 || y <= 0) {
            Abort("一覧の【先頭行の位置】がまだ登録されていません。`n`n"
                . "設定 →「測定値を設定し直す」→「一覧の 1 行目と 2 行目を登録」で、1 行目（と 2 行目）を"
                . "登録してください。`n"
                . "この PC の画面に合わせて実測する必要があります"
                . "（ListFirstRowX / ListFirstRowY）。")
            return
        }
        if (!CountClick(Format("row:{1},{2}", x, y)))
            return
        if (CB("DryRun")) {
            Log("INFO", Format("[DryRun] 先頭行をダブルクリックしたつもり（x{1} y{2}）", x, y))
        } else if (!DoubleClickCtrl(h, CS("ListClassNN"), x, y, G.rowTry " 行目")) {
            Abort("一覧の先頭行を開けませんでした。`n"
                . "座標がずれている可能性があります。メニューの「一覧の先頭行を登録」で"
                . "実際の位置を記録してください。")
            return
        }
        G.rowClicked := true
    }
    Arm(1000)
}

;==============================================================================
;  ★G1★ 氏名照合
;==============================================================================
TickVerify() {
    global G
    h := FindScreen("S2_Card")
    if (!h) {
        if (StateTimedOut(CI("TransitionTimeoutSec"), "カード画面の表示"))
            return
        Arm(500)
        return
    }
    if (!VerifyPatient(h))
        return                                      ; 中で Abort 済み
    ; 調査前の履歴件数を控える（G2 の裏取り用）
    G.scanBefore := ReadRecordCount(h)
    if (G.scanBefore != "")
        Log("INFO", "調査前の履歴件数: " G.scanBefore)
    if (!CB("RunInvestigation")) {
        SetState("therapy_ready", "調査は行わない設定")
        Arm(500)
        return
    }
    SetState("scan_open")
    Arm(500)
}

; 「1/16020」のような表示から、総件数だけを取り出す。
;   ★左の数字は行カーソルの位置★
;     選択が動いただけで文字列が変わるため、そのまま比べると
;     調査していないのに「増えた」と誤判定する（2026-09-19 に画面で確認）。
;   区切りが無ければ、数字だけを拾う。
ParseCount(t) {
    t := Trim(t)
    if (t = "")
        return ""
    if (p := InStr(t, "/", , -1))
        t := SubStr(t, p + 1)
    out := ""
    Loop Parse, t
        if (A_LoopField >= "0" && A_LoopField <= "9")
            out .= A_LoopField
    return out
}

; カード画面の調査履歴の総件数（読めなければ空文字）
ReadRecordCount(hwnd) {
    cn := CS("RecordCountClassNN")
    if (cn = "")
        return ""
    t := ""
    try t := Trim(ControlGetText(cn, "ahk_id " hwnd))
    return ParseCount(t)
}

;==============================================================================
;  調査
;==============================================================================
TickScanOpen() {
    global G
    if (HasScreen("S2b_Anamnesis")) {
        SetState("scan_anamnesis")
        Arm(500)
        return
    }
    if (HasScreen("S3_Scheme")) {
        SetState("scan_scheme", "既往症画面を経由しませんでした")
        Arm(500)
        return
    }
    ; ★ここは時間がかかる★
    ;   2026-09-16、押してから画面が出るまで 60 秒を超えた（直後には出ていた）。
    ;   調査タイプによっては一覧の作り直しに時間がかかるため、長めに待つ。
    if (StateTimedOut(CI("ScanOpenTimeoutSec"), "「調査」を押して次の画面へ進む処理"))
        return
    ; ★押し直しは十分に間を置く★
    ;   同じときに 4 回押していた。処理中に押し足しても早くはならず、
    ;   むしろ二重に開くおそれがある。
    if (G.stateClickTS != "" && SecSince(G.stateClickTS) < CI("ScanOpenRetrySec")) {
        Arm(2000)
        return
    }
    if (h := FindScreen("S2_Card"))
        TryClick(h, CS("CardScanClassNN"), CS("CardScanText"))
    Arm(1000)
}

; 既往症画面は「進む」で通過するだけ（2026-09-13 合意）
;
;  ★スキーム画面は既往症画面と【同時に】現れる★
;    2026-09-13 のトレースで、19:57:25 に TpfFormPolling と TpfFormEasyPolling が
;    同じ秒に出ている。したがって「スキーム画面があるか」で次へ進む判定をしてはいけない。
;    そうすると「進む」を一度も押さないまま scan_go へ行き、
;    裏に隠れたスキーム画面の「調査」を押し続けて止まる（2026-09-14 の失敗）。
;
;    抜ける条件は【既往症画面が閉じたこと】。トレースでも「進む」の 6.0 秒後に閉じている。
TickScanAnamnesis() {
    h := FindScreen("S2b_Anamnesis")
    if (!h) {                                   ; 閉じた＝通過できた
        if (HasScreen("S3_Scheme")) {
            SetState("scan_scheme")
            Arm(500)
            return
        }
        if (StateTimedOut(CI("TransitionTimeoutSec"), "スキーム画面の表示"))
            return
        Arm(500)
        return
    }
    if (StateTimedOut(CI("AnamnesisTimeoutSec"), "既往症画面の通過"))
        return
    TryClick(h, CS("AnamnesisNextClassNN"), CS("AnamnesisNextText"))
    Arm(1000)
}

; スキーム画面のリスト読み込みを待ってから「調査」を押す
TickScanScheme() {
    global G
    ; 既往症画面が手前に残っているうちは、裏のスキーム画面を触っても何も起きない
    if (HasScreen("S2b_Anamnesis")) {
        SetState("scan_anamnesis", "既往症画面がまだ開いています")
        Arm(500)
        return
    }
    h := FindScreen("S3_Scheme")
    if (!h) {
        if (StateTimedOut(CI("TransitionTimeoutSec"), "スキーム画面の表示"))
            return
        Arm(500)
        return
    }
    ; アンカー（インタラクティブ既往症 / 調査）が両方読めたら描画が済んだとみなす
    if (!AutoTherapyPoint(h, &cx, &cy, &how)) {
        if (StateTimedOut(CI("SchemeListWaitSec"), "スキーム画面の描画"))
            return
        Arm(700)
        return
    }
    SetState("scan_type")
    Arm(300)
}

;------------------------------------------------------------------------------
;  調査タイプ／マニュアル選択を設定する
;------------------------------------------------------------------------------
;  どちらも【描画されたボタン】で、開く一覧の項目も描画。文字が一つも読めないので
;  座標で押すしかない（2026-09-15 のトレースで判明）。位置は
;  「設定 → 調査タイプ／マニュアル選択の位置を登録」で記録する。
;
;  カードによって選択が変わるため、★毎回かならず設定し直す★。
;
;  進み方（G.optStep）
;    0 ボタンを押す → 1 一覧が開くのを待つ → 2 項目を押す → 3 閉じて作り直しが終わるのを待つ
;------------------------------------------------------------------------------
TickScanOption(grp) {
    global G
    jp := (grp = "ScanType") ? "調査タイプ" : "マニュアル選択"
    want := (grp = "ScanType") ? CS("ScanTypeName") : CS("ManualName")
    if (Trim(want) = "") {
        NextAfterOption(grp, jp " は指定なし")
        Arm(300)
        return
    }
    ; 「どれも選ばない」＝青い項目を押して外す（マニュアル選択のみ）
    ;   ★青い項目は、押せば外れる★（2026-09-17 利用者に確認）
    ;   ただし一覧の「選択を解除」は【測定項目のチェックを全消し】するボタンなので、
    ;   絶対に使わない。記録もさせていない。
    noneMode := (grp = "Manual" && Trim(want) = "なし")
    idx := noneMode ? 1 : OptIndex(grp, want)
    if (!noneMode && idx = 0) {
        Log("WARN", Format("{1}「{2}」の位置が記録されていないため、設定を飛ばします"
            . "（設定 →「測定値を設定し直す」→「調査タイプ／マニュアル選択の位置を登録」）", jp, want))
        NextAfterOption(grp, jp " は位置が未記録")
        Arm(300)
        return
    }
    h := FindScreen("S3_Scheme")
    if (!h) {
        if (StateTimedOut(CI("TransitionTimeoutSec"), jp " の設定"))
            return
        Arm(500)
        return
    }
    sp := OptSpot(grp, idx)
    ; ★毎回いまの位置から計算する★ ウィンドウの大きさが変わっても追随する
    ; ★計算を優先★ 覚えた位置は、計算できないときの予備
    btn := SchemeDrawnButton(h, grp)
    if (!btn["ok"])
        btn := SpotFromAnchor(h, sp["btnAnchor"], sp["btnDX"], sp["btnDY"])
    if (!btn["ok"]) {
        ; ★ここで諦めない★
        ;   ボタンの位置は「インタラクティブ既往症／調査／現在の分析」の文字から計算している。
        ;   ソフトが一覧を作り直している間は文字が消えるので、一時的に計算できないだけ。
        ;   2026-09-17、項目を押した直後の作り直し中にこれで「基準が不明」と誤判定し、
        ;   マニュアル選択が毎回とばされていた。待てば戻る。
        G.optNoBtn++
        if (G.optNoBtn < 45) {                      ; 45 秒ほどは待つ（「詳細」は作り直しに 20 秒近くかかる）
            Arm(1000)
            return
        }
        Log("WARN", Format("{1} のボタンの位置を計算できません（45 秒待ちました）。設定を飛ばします"
            . "／基準にしている文字: {2} ・ {3} ・ {4}"
            , jp, CS("AnchorLeftText"), CS("AnchorRightText"), CS("SchemeRowRefText")))
        G.optWarn .= (G.optWarn = "" ? "" : " / ") jp "の位置を計算できず"
        NextAfterOption(grp, jp " は基準が不明")
        Arm(300)
        return
    }
    G.optNoBtn := 0
    vis := false
    if (G.optAlt != "")
        sp["panel"] := G.optAlt                     ; この状態で見つけた、実際の一覧のパネル
    if (sp["panel"] != "") {
        try vis := ControlGetVisible(sp["panel"], "ahk_id " h)
    }
    ; ★記録したパネルが存在しないときは、ボタンの真下に開いたパネルを一覧とみなす★（3.10.27）
    ;   パネルの番号（TPanel3 など）は、画面にある同じ種類の部品の数で決まる。対象ソフトを起動した直後は
    ;   パネルが 1 つ少なく、調査タイプの一覧は TPanel2 になる（2026-10-13 21:00 のある顧客で、一覧は開いたのに
    ;   記録した TPanel3 を見続けて「開かない」と判定し、3 回押して開閉を繰り返した）。
    ;   記録したパネルが【ある】ときは、これまでどおり、それだけを見る。
    if (!vis && G.optStep = 1 && G.optAlt = "") {
        alt := OptAltPanel(h, sp["panel"], btn["x"], btn["y"])
        if (alt != "") {
            G.optAlt := alt
            sp["panel"] := alt
            vis := true
            Log("INFO", Format("{1} の一覧は、記録した {2} ではなく {3} で開きました（記録したパネルが画面にありません）"
                , jp, OptSpot(grp, idx)["panel"], alt))
        }
    }
    if (StateTimedOut(CI("SchemeListWaitSec"), jp " の設定"))
        return

    switch G.optStep {
        case 0:                                     ; 一覧を開く
            if (!SchemeReady(h)) {
                Arm(1000)
                return
            }
            ; ★画面に入った直後は押さない★
            ;   2026-09-16、スキーム画面の 2 秒後に押して一覧が開かなかった。
            ;   項目が多いカードでは、描画が終わるまで押しても反応しない。
            if (StateSec() < CI("SchemeSettleSec") * (G.freshApp ? 3 : 1)) {
                Arm(1000)
                return
            }
            if (CB("DryRun")) {
                Log("INFO", Format("[DryRun] {1} を「{2}」にするつもり", jp, want))
                NextAfterOption(grp, "DryRun")
                Arm(300)
                return
            }
            ; ★すでに開いているなら押さない★
            ;   押すと【閉じて】しまう。利用者が先に開けていることがある
            ;   （2026-09-17 指摘。試験中は画面を見ながら手で開けることが多い）。
            ;   これまでは必ず押していたため、開いていた一覧を閉じてしまい、
            ;   「6 秒たっても開かない」と警告して押し直していた。
            if (vis) {
                Log("INFO", jp " の一覧はすでに開いています（押さずに進みます）")
                G.optStep := 2
                Arm(300)
                return
            }
            if (ClickAt(h, btn["x"], btn["y"], jp " を開く")) {
                G.optStep  := 1
                G.optTS    := A_Now
                G.optTries += 1
            }
            Arm(800)
        case 1:                                     ; 開くのを待つ
            if (vis || sp["panel"] = "") {
                Log("INFO", jp " の一覧が開きました（" sp["panel"] "）")
                G.optStep := 2
                Arm(400)
                return
            }
            ; ★開かなければ押し直す。3 回だめなら止める★
            ;   黙って飛ばすと、カードに残っていた別の調査タイプのまま調査してしまう
            if (SecSince(G.optTS) >= CI("SchemeOpenRetrySec")) {
                ; ★開かなかったとき、画面の実際の状態を記録する★（2026-10-11）
                ;   「開いた」の判定は、一覧のコントロール（{panel}）が「表示」かどうかだけ。
                ;   押しても反応しなかったのか、開いたのに別のコントロールを見ているのか、
                ;   ログから切り分けられるよう、パネルの状態を残す。
                OptDiagLog(h, jp, sp["panel"], btn["x"], btn["y"])
                if (G.optTries >= (G.freshApp ? 6 : 3)) {
                    ; ★ここで止めない★
                    ;   2026-09-16、位置の記録ミスで 3 件続けて失敗し、運転全体が止まった。
                    ;   調査そのものは動くのだから、警告を残して先へ進む。
                    ;   設定できなかったことは【確認待ち】にも出るので、見落とさない。
                    msg := Format("{1} を「{2}」に設定できませんでした（{3} 回押しても一覧が開かず{8}）。"
                        . "押した位置 x{4} y{5}（基準 {6} / 一覧 {7}）。"
                        . "設定 →「測定値を設定し直す」→「調査タイプ／マニュアル選択の位置を登録」で記録し直してください"
                        , jp, want, G.optTries, btn["x"], btn["y"]
                        , sp["btnAnchor"] = "" ? "計算" : sp["btnAnchor"], sp["panel"]
                        , G.freshApp ? "／起動直後のため 6 回まで待ちました" : "")
                    Log("WARN", msg)
                    G.optWarn .= (G.optWarn = "" ? "" : " / ") jp "を設定できず"
                    G.optStep := 0
                    NextAfterOption(grp, jp " は設定できませんでした")
                    Arm(500)
                    return
                }
                Log("WARN", Format("{1} の一覧が {2} 秒たっても開かないので、もう一度押します（{3} 回目）"
                    , jp, CI("SchemeOpenRetrySec"), G.optTries))
                G.optStep := 0
            }
            Arm(500)
        case 2:                                     ; 何を押すか決めて、押す
            if (sp["panel"] = "") {
                Log("WARN", Format("{1} の一覧が記録されていません。設定を飛ばします", jp))
                G.optStep := 0
                NextAfterOption(grp, jp " は一覧が不明")
                return
            }
            ; ★一覧が閉じていたら、読まない・押さない★
            ;   2026-09-17、項目を外した直後に一覧が閉じたのに読み続け、
            ;   下の画面（グラフ）の色を読んで「スキーム 1 が青い」と誤判定し、
            ;   一覧ではない場所を押してしまった。
            ;   実測: 2 回目の読みは #0000FF・#FFFFFF・#6AEFEF ばかりだった。
            ;   一覧の色は #E1E1E1（通常）と #CCE4F7（選択中）である。
            if (!vis) {
                Log("INFO", jp " の一覧が閉じているので、開き直してから確かめます")
                G.optStep := 0
                Arm(800)
                return
            }
            if (noneMode) {
                ; ★どれも選ばれていない状態にする★
                ;   読む前にカーソルを一覧の外（ボタンの上）へ逃がす。
                ;   カーソルが乗っている行は薄青くなるので、選択中と間違える。
                MouseMove btn["x"], btn["y"], 0
                on := HighlightedOptIndex(h, grp)
                if (on = -1) {                 ; 読み取れなかった
                    Log("WARN", jp " でどれが選ばれているかを読み取れませんでした。"
                        . "操作せずに進みます（押すと、外すつもりが選択されるため）")
                    G.optWarn .= (G.optWarn = "" ? "" : " / ") jp "の状態を読めず"
                    G.optStep := 4
                    Arm(300)
                    return
                }
                if (on = 0) {
                    Log("INFO", jp " は、どれも選ばれていません")
                    G.optStep := 4
                    Arm(300)
                    return
                }
                if (G.optOff >= 8) {
                    Log("WARN", jp " の選択を外しきれませんでした")
                    G.optWarn .= (G.optWarn = "" ? "" : " / ") jp "の選択を外せず"
                    G.optStep := 4
                    Arm(300)
                    return
                }
                ; ★同じものを押しても外れないなら、そこで止める★
                ;   2026-09-16、スキーム 1 を 5 回押し続けた。
                ;   マニュアル選択の項目は「動作」なので、押すたびに実害がある。
                if (on = G.optLast) {
                    Log("WARN", Format("{1}「{2}」を押しても外れないので、"
                        . "これ以上は操作しません", jp, OptNameAt(grp, on)))
                    G.optWarn .= (G.optWarn = "" ? "" : " / ") jp "の選択を外せず"
                    G.optStep := 4
                    Arm(300)
                    return
                }
                G.optLast := on
                nm    := OptNameAt(grp, on)
                offSp := OptSpot(grp, on)
                if (ClickCtrlAt(h, sp["panel"], offSp["dx"], offSp["dy"]
                    , jp "「" nm "」の選択を外す")) {
                    G.optOff++
                    G.optStep := 3
                    G.optTS   := A_Now
                    G.optBusy := false
                }
                Arm(1000)
                return
            }
            ; ★調査タイプだけは「すでに選ばれていれば押さない」★
            ;   調査タイプは選択状態が残る（詳細が青いまま）。押す必要がない。
            ;   マニュアル選択は【動作の一覧】で、選択状態が残らない。
            ;   2026-09-17 の実測では、どの項目も青くならなかった（B-R ≒ 0）。
            ;   しかも色を読む点が文字の上に乗っており（自動選択 #4C555C, B-R+16）、
            ;   しきい値 20 のすぐ下。誤って「選択済み」と判定すると、
            ;   項目を選び直さないまま調査が走る（＝1 項目になる）。
            ;   マニュアル選択では判定せず、毎回かならず押す。
            MouseMove btn["x"], btn["y"], 0
            if (grp = "ScanType"
                && ItemHighlight(h, sp["panel"], sp["dx"], sp["dy"])["hit"] >= CI("HighlightHitMin")) {
                Log("INFO", Format("{1}「{2}」はすでに選ばれています", jp, want))
                G.optStep := 4
                Arm(300)
                return
            }
            ; ★一覧そのものを名指しして押す★（重なっている項目リストに入らないように）
            if (ClickCtrlAt(h, sp["panel"], sp["dx"], sp["dy"], jp "「" want "」")) {
                G.optStep := 3
                G.optTS   := A_Now
                G.optBusy := false
            }
            Arm(1000)
        case 3:                                     ; 作り直しが終わるのを待つ
            ; ★作り直しは押した直後ではなく、数秒遅れて始まる★
            ;   トレース（2026-09-15）: 詳細を押して 6 秒後にボタンの文字が消え、14 秒後に戻った。
            ;   押して 1.5 秒で「ビジーでない＝終わった」と判断すると、
            ;   これから始まる作り直しの最中に次のボタンを押してしまう。
            ;   → 「ビジーになって、戻った」を見届ける。
            ;     同じ項目を選び直したときなど作り直しが起きないこともあるので、
            ;     15 秒たっても始まらなければ、終わったものとみなす。
            ready := SchemeReady(h)
            if (!ready && !G.optBusy) {
                G.optBusy := true
                Log("INFO", jp " を反映中（ソフトが一覧を作り直しています）")
            }
            if (ready && (G.optBusy || SecSince(G.optTS) >= 15)) {
                Log("INFO", Format("{1} を反映しました（{2} 秒）", jp, SecSince(G.optTS)))
                G.optStep := noneMode ? 2 : 4      ; 外す場合は、もう一度ぜんぶ見直す
                Arm(600)
                return
            }
            Arm(1000)
        case 4:                                     ; 一覧が開いたままなら閉じて、次へ
            if (vis) {
                ClickAt(h, btn["x"], btn["y"], jp " の一覧を閉じる")
                Arm(1200)
                return
            }
            if (!SchemeReady(h)) {
                Arm(1000)
                return
            }
            G.optStep := 0
            NextAfterOption(grp, jp "＝" (noneMode ? "どれも選ばない" : want))
            Arm(800)
    }
}

; つぎの状態へ。★行き先をここに文字どおり書いておく★
;   変数で渡すと、配布前チェックが「どこからも遷移しない状態」と誤検知する。
;   読む人にとっても、この 2 つしかないことが分かるほうがよい。
NextAfterOption(grp, note := "") {
    if (grp = "ScanType")
        SetState("scan_manual", note)
    else
        SetState("scan_go", note)
}

; スキーム画面が操作を受け付けられる状態か（作り直し中はボタンの文字が消える）
SchemeReady(hwnd) {
    t := ""
    try t := Trim(ControlGetText(CS("SchemeScanClassNN"), "ahk_id " hwnd))
    return (t != "")
}

TickScanGo() {
    global G
    if (HasScreen("S2b_Anamnesis")) {           ; 同上
        SetState("scan_anamnesis", "既往症画面がまだ開いています")
        Arm(500)
        return
    }
    h := FindScreen("S3_Scheme")
    if (!h) {
        Arm(500)
        return
    }
    ; 調査が始まった＝ウィンドウ名が長い方へ変わる（仕様書 §5.3-(1)）
    if (ScanIsRunning(h)) {
        G.scanStartTS := A_Now
        SetState("scan_running")
        Arm(2000)
        return
    }
    if (StateTimedOut(CI("ScanStartTimeoutSec"), "調査の開始")) {
        return
    }
    TryClick(h, CS("SchemeScanClassNN"), CS("SchemeScanText"))
    Arm(2000)
}

; 調査中か：Polling のウィンドウ名が「実行中の名前」になっている、
; または項目スキャン画面が出ている
ScanIsRunning(hPolling := 0) {
    if (!hPolling)
        hPolling := FindScreen("S3_Scheme")
    if (hPolling) {
        t := ""
        try t := WinGetTitle("ahk_id " hPolling)
        if (t != "" && InStr(t, CS("SchemeBusyTitleHint")))
            return true
    }
    return HasScreen("S4_ScanItem")
}

TickScanRunning() {
    global G
    ; 進行の目印: 項目スキャン画面のウィンドウ名（臓器名）が変わり続ける
    now := ""
    if (h := FindScreen("S4_ScanItem")) {
        try now := WinGetTitle("ahk_id " h)
    }
    if (now != "" && now != G.lastScanItem) {
        G.lastScanItem := now
        G.scanProgressTS := A_Now
        G.scanItems++
        Log("INFO", Format("調査 {1} 項目目: {2}", G.scanItems, now))
    }
    if (G.scanProgressTS = "")
        G.scanProgressTS := A_Now

    if (ScanIsRunning()) {
        if (SecSince(G.scanProgressTS) > CI("ScanStallTimeoutSec")) {
            Abort(Format("調査の進行が {1} 以上止まっています。`n最後の項目: {2}"
                , FmtDur(CI("ScanStallTimeoutSec")), G.lastScanItem))
            return
        }
        Arm(2000)
        return
    }
    ; 実行中でなくなった → 完了ダイアログを探す
    dur := SecSince(G.scanStartTS)
    Log("INFO", Format("調査が終わったようです（{1} / {2} 項目）", FmtDur(dur), G.scanItems))
    G.scanSec := dur
    SetState("scan_dialog")
    Arm(500)
}

; 調査完了のダイアログ（「はい」1 個）を押す。
;   ★このダイアログは【毎回は出ない】★
;     2026-09-13 の 38 項目では出たが、2026-09-14 の 35 項目では出なかった（実機確認）。
;     出る条件は不明。したがって「出たら押す・出なければ待たずに進む」の両対応にする。
TickScanDialog() {
    global G
    if (h := FindScreen("Dialog")) {
        Log("INFO", "調査の完了ダイアログが出ました")
        TryClick(h, CS("DialogOkClassNN"), CS("DialogOkText"))
        G.dialogSeen := true
        Arm(800)
        return
    }
    ; 一度出て押したあとは、閉じたことを確認してすぐ進む
    if (G.dialogSeen) {
        SetState("scan_check", "ダイアログを閉じました")
        Arm(800)
        return
    }
    ; 出ないまま画面が落ち着いているなら、猶予だけ見て進む（60 秒も待たない）
    if (!ScanIsRunning() && StateSec() >= CI("DialogGraceSec")) {
        SetState("scan_check", "ダイアログは出ませんでした")
        Arm(500)
        return
    }
    if (StateSec() >= CI("DialogWaitSec")) {
        SetState("scan_check", "ダイアログの待ち時間を超えました")
        Arm(500)
        return
    }
    Arm(500)
}

; ★カード選択からやり直す★（2026-09-28 指摘）
;   調査が空振りしたとき、その場で確認待ちにせず、もう一度だけ試す。
;   一時的な取りこぼし（一覧の反映待ち・選択の失敗）で一晩分を落とさないため。
;   やり直すのは【カードを選ぶところから】。開いているカードは信用しない。
RetryFromCard(why) {
    global G
    if (G.jobRetry >= CI("JobRetryMax"))
        return false                               ; もうやり直さない
    G.jobRetry++
    Log("WARN", Format("{1} → カード選択からやり直します（{2} 回目）"
        , why, G.jobRetry))
    ; 調査まわりを初期に戻す
    G.scanItems := 0, G.scanSec := 0, G.lastScanItem := "", G.dialogSeen := false
    G.scanBefore := "", G.scanStartTS := "", G.scanProgressTS := ""
    ; 顧客の選び直し（開いているカードは使わない）
    G.searched := false, G.rowClicked := false, G.rowTry := 1
    G.lastCard := "", G.rowExtra := 0
    G.gotSei := "", G.gotMei := "", G.gotMid := ""
    ; 調査タイプ／マニュアル選択も、もう一度そろえ直す
    G.optStep := 0, G.optTS := "", G.optTries := 0, G.optBusy := false
    G.optOff := 0, G.optLast := 0, G.optNoBtn := 0, G.optWarn := "", G.optAlt := ""
    G.stable := 0, G.repeat := 0, G.lastTarget := "", G.lastTargetState := ""
    SetState("homing", "やり直し")
    Arm(1500)
    return true
}

; ★G2★ 本当に調査が走ったかを件数で裏取りする
TickScanCheck() {
    global G, STATEINI
    ; ダイアログが残っていれば先に片付ける（モーダルなので他は押せない）
    if (hd := FindScreen("Dialog")) {
        TryClick(hd, CS("DialogOkClassNN"), CS("DialogOkText"))
        Arm(800)
        return
    }
    h := FindScreen("S2_Card")
    if (!h) {
        ; スキーム画面に残っているなら戻す
        if (hs := FindScreen("S3_Scheme"))
            TryClick(hs, CS("SchemeBackClassNN"), CS("SchemeBackText"))
        if (StateTimedOut(CI("TransitionTimeoutSec"), "カード画面へ戻る処理"))
            return
        Arm(1000)
        return
    }
    after := ReadRecordCount(h)
    ; ★増えていなくても「止める」まではしない★
    ;   以前は Abort（＝失敗）だった。失敗が 3 回続くと運転全体が止まるので、
    ;   一覧の表示が更新されていないだけで一晩分が潰れる恐れがある。
    ;   セラピーへは進めず、確認待ちに回す（A-3 と同じ重さ）。
    if (G.scanBefore != "" && after != "" && after = G.scanBefore) {
        ; ★こちらも一度だけやり直す★ 調査が実質行われていないため
        if (RetryFromCard("調査の記録が増えていませんでした（履歴件数 " . after . " のまま）"))
            return
        G.needCheck := Format("履歴件数が {1} のまま（調査の記録が増えていません）", after)
        Finish(4, Format("調査の記録が増えていません（履歴件数が「{1}」のまま）。`n`n"
            . "考えられるのは次の 3 つです。`n"
            . "  1. 項目が 1 つもチェックされていなかった`n"
            . "  2. 手動で止めた`n"
            . "  3. 一覧の表示がまだ更新されていないだけ`n`n"
            . "セラピーへは進んでいません。カードの履歴を確認してください。", after))
        return
    }
    ; ★「読めなかった」を「OK」と書かない★
    ;   件数を読めないのに「裏取り OK」と記録していたため、
    ;   何も確認していないのに確認済みに見えていた（2026-09-14）。
    ; 件数の表示は一覧の左下（例「1/16020」）。総件数だけを比べる。
    ;   設定していなければ、これまでどおり調査項目数（A-3）だけで確かめる。
    if (G.scanBefore != "" && after != "")
        Log("INFO", Format("★G2 裏取り OK: 履歴件数 {1} → {2}", G.scanBefore, after))
    ; ★調査項目が少なすぎるときは、完了にしない★
    ;   0 項目になるのは、次の 3 つのどれか（2026-09-17 利用者と整理）。
    ;     1. すでに調査済みで、調べるものが無かった
    ;     2. 手動で止めた（試験中はこれが最も多い）
    ;     3. 何らかの異常
    ;   画面からは見分けられないので、勝手に判断しない。
    ;   ★セラピーへは進まない★ 調べていないものにセラピーを行わないため。
    ;   失敗とも呼ばない（手動停止が多く、連続失敗で運転を止めてはいけない）。
    ; ★「その人の前回」と比べる★
    ;   0 項目でなくても、ふだん 50 項目の人が 3 項目で終わったらおかしい。
    ;   カード側の選択が壊れていても、件数を見なければ気づけない。
    least   := CI("MinScanItems")
    prev    := 0
    sameSet := false
    if (G.schedCurrent != "") {
        hm   := IniLoad(STATEINI)
        prev := ToInt(IniGet(hm, "History." G.schedCurrent, "LastScanItems", "0"), 0)
        ; ★前回と同じ設定のときだけ比べる★
        ;   マニュアル選択や調査タイプを変えれば、項目数は正当に半分以下になりうる。
        ;   設定が違うのに前回と比べると、正常な運転を確認待ちにしてしまう（2026-09-20 指摘）。
        sameSet := (Trim(IniGet(hm, "History." G.schedCurrent, "LastScanSig", "")) = ScanSig())
        if (prev > 0 && !sameSet)
            Log("INFO", "前回と設定が違うので、項目数の比較はしません（" . ScanSig() . "）")
    }
    ; ★前回の半分まで引き上げない★（2026-09-28）
    ;   前回 60 項目の方が 20 項目で終わると止まっていた。
    ;   少ないこと自体は異常ではないので、固定の下限だけで見る。
    if (CB("RunInvestigation") && G.scanItems < least) {
        ; ★一度だけ、カード選択からやり直す★（2026-09-28 指摘）
        ;   一時的な取りこぼしで一晩分を落とさないため。
        if (RetryFromCard(Format("調査が {1} 項目しかありませんでした（下限 {2}）"
            , G.scanItems, least)))
            return
        G.needCheck := Format("調査 {1} 項目（{2}）{3}", G.scanItems, FmtDur(G.scanSec)
            , (prev > 0 && sameSet) ? Format("／前回は {1} 項目", prev) : "")
        Finish(4, Format("調査が {1} 項目で終わりました（所要 {2}）。"
            . ((prev > 0 && sameSet) ? Format("`nこの方の前回は {1} 項目でした。", prev) : "") . "`n`n"
            . "考えられるのは次の 3 つです。`n"
            . "  1. すでに調査済みで、調べるものが無かった`n"
            . "  2. 手動で止めた`n"
            . "  3. 何らかの異常`n`n"
            . "どれに当たるかは画面からは判別できません。"
            . "セラピーへは進んでいません。カードを確認してください。"
            , G.scanItems, FmtDur(G.scanSec)))
        return
    }
    SetState("therapy_ready")
    Arm(500)
}

;==============================================================================
;  セラピー（AutoTherapy v4 の判定をそのまま流用 — 仕様書 §9.1）
;==============================================================================

; v4 の IsTherapyRunning() と同じ。★サイズを見てはいけない★（§5.3-1）
TherapyIsRunning() {
    global G
    ind := CS("IndicatorClass")
    for w in TargetWindows(G.pid) {
        if (w["class"] = ind)
            return true
    }
    return false
}

; スキーム画面まで戻ってセラピーを打てる状態にする
TickTherapyReady() {
    global G
    if (G.cycle >= CI("TherapyCount")) {
        SetState("cleanup", "指定回数を完了")
        Arm(500)
        return
    }
    if (HasScreen("S3_Scheme")) {
        SetState("therapy_click")
        Arm(500)
        return
    }
    if (HasScreen("S2b_Anamnesis")) {
        if (h := FindScreen("S2b_Anamnesis"))
            TryClick(h, CS("AnamnesisNextClassNN"), CS("AnamnesisNextText"))
        Arm(1000)
        return
    }
    if (StateTimedOut(CI("TransitionTimeoutSec"), "スキーム画面へ戻る処理"))
        return
    if (h := FindScreen("S2_Card"))
        TryClick(h, CS("CardScanClassNN"), CS("CardScanText"))
    Arm(1000)
}

TickTherapyClick() {
    global G
    ; DryRun は画面が動かない。ここで往復させず、回数だけ数えて先へ進める
    if (CB("DryRun")) {
        G.cycle++
        G.cycleStartTS := A_Now
        Log("INFO", Format("[DryRun] セラピー {1}/{2} 回目を押したつもり"
            , G.cycle, CI("TherapyCount")))
        SetState("therapy_start")
        Arm(500)
        return
    }
    h := FindScreen("S3_Scheme")
    if (!h) {
        SetState("therapy_ready")
        Arm(500)
        return
    }
    ; まだ前のセラピーが動いているなら打たない
    if (TherapyIsRunning()) {
        Log("INFO", "指標ウィンドウが残っています。落ち着くまで待ちます")
        Arm(3000)
        return
    }
    if (!AutoTherapyPoint(h, &cx, &cy, &how)) {
        if (StateTimedOut(CI("SchemeListWaitSec"), "自動セラピーの位置の特定"))
            return
        Arm(700)
        return
    }
    if (StateTimedOut(CI("TherapyStartTimeoutSec"), "セラピーの開始"))
        return
    G.cycle++
    G.cycleStartTS := A_Now
    Log("INFO", Format("--- セラピー {1}/{2} 回目 --- {3} → x{4} y{5}"
        , G.cycle, CI("TherapyCount"), how, cx, cy))
    ClickAt(h, cx, cy, "自動セラピー")
    SetState("therapy_start")
    Arm(1000)
}

; 押した結果ちゃんと始まったか（実測では 1 秒で指標が出る）
TickTherapyStart() {
    global G
    if (TherapyIsRunning()) {
        Log("INFO", Format("セラピー {1} 回目が始まりました", G.cycle))
        G.therapySeenTS := A_Now
        SetState("therapy_run")
        Arm(CI("PollIntervalMs"))
        return
    }
    if (CB("DryRun")) {
        SetState("therapy_run", "DryRun のため開始したことにする")
        Arm(1000)
        return
    }
    if (StateSec() > CI("VerifyTimeoutSec")) {
        Abort(Format("セラピーを押しましたが {1} 秒たっても始まりません。`n"
            . "クリックが有効になっていない可能性があります（管理者権限で実行してください）。"
            , CI("VerifyTimeoutSec")))
        return
    }
    Arm(500)
}

; v4 と同じ: 指標ウィンドウが StableChecks 回連続で見えなければ完了
; セラピーの完了と判定するのに、指標ウィンドウが何回続けて消えていればよいか。
;
;  ★実測した最大の途切れの 2 倍を必ず下回らないようにする★
;    途切れは 2026-09-13 に 4 秒、09-14 に 6 秒、09-15 に 7 秒と伸びている。
;    config.ini の StableChecks は固定値なので、環境が重くなると追いつかない。
;    しかも設定ファイルは更新で配り直さない方針なので、こちらから直せない。
;    そこで【そのジョブで実際に観測した途切れ】から下限を自動で引き上げる。
StableNeeded() {
    global G
    base := CI("StableChecks")
    poll := CI("PollIntervalMs") / 1000
    if (poll <= 0)
        return base
    ; 実測の最大途切れ × 2 ＋ 3 秒 を満たす回数
    need := Ceil((G.maxGap * 2 + 3) / poll)
    return Max(base, need)
}

TickTherapyRun() {
    global G
    if (CB("DryRun")) {
        SetState("therapy_rest", "DryRun")
        Arm(500)
        return
    }
    if (TherapyIsRunning()) {
        gap := SecSince(G.therapySeenTS)
        if (gap > G.maxGap) {
            G.maxGap := gap
            ; 完了と判定する閾値（下限）に対して、途切れが半分を超えたら知らせる。
            ; 閾値に迫っているなら StableChecks を増やすべきという合図
            limit := StableNeeded() * CI("PollIntervalMs") / 1000
            Log("WARN", Format("指標ウィンドウの途切れが {1} 秒（完了と判定する下限は {2} 秒）"
                , gap, Round(limit, 1)))
        }
        G.therapySeenTS := A_Now
        G.stable := 0
        if (SecSince(G.cycleStartTS) > CI("TherapyMaxSec")) {
            Abort(Format("セラピーが {1} を超えても終わりません。", FmtDur(CI("TherapyMaxSec"))))
            return
        }
        if (G.runLogTS = "" || SecSince(G.runLogTS) >= 300) {
            G.runLogTS := A_Now
            Log("INFO", Format("セラピー {1} 回目 実行中 {2} 経過", G.cycle, FmtDur(SecSince(G.cycleStartTS))))
        }
        Arm(CI("PollIntervalMs"))
        return
    }
    G.stable++
    if (G.stable < StableNeeded()) {
        Arm(CI("PollIntervalMs"))
        return
    }
    dur := SecSince(G.cycleStartTS)
    G.durations.Push(dur)
    G.runLogTS := ""
    Log("INFO", Format("cycle={1}/{2} event=cycle_done duration={3} 指標の最大途切れ={4}秒"
        , G.cycle, CI("TherapyCount"), FmtDur(dur), G.maxGap))
    if (!CheckCycleDuration(dur))
        return
    SaveState()
    SetState("therapy_rest")
    Arm(500)
}

; S5: 所要時間の異常検知。1 回目を基準に、2 回目以降のズレを見る
CheckCycleDuration(dur) {
    global G
    lo := CI("ExpectedCycleMinSec"), hi := CI("ExpectedCycleMaxSec")
    if (lo > 0 && dur < lo) {
        Abort(Format("セラピー {1} 回目が {2} で終わりました（想定の下限 {3} より短い）。`n"
            . "セラピーが正しく行われていない可能性があるため停止します。"
            , G.cycle, FmtDur(dur), FmtDur(lo)))
        return false
    }
    if (hi > 0 && dur > hi) {
        Abort(Format("セラピー {1} 回目が {2} かかりました（想定の上限 {3} より長い）。"
            , G.cycle, FmtDur(dur), FmtDur(hi)))
        return false
    }
    ; 1 回目を基準にした相対チェック（同一顧客内のばらつきは実測で数秒）
    if (G.durations.Length >= 2) {
        base := G.durations[1]
        tol  := Max(60, base * CI("CycleTolerancePct") // 100)
        if (Abs(dur - base) > tol) {
            Log("WARN", Format("1 回目 {1} に対して {2} 回目が {3}（差 {4} 秒）"
                , FmtDur(base), G.cycle, FmtDur(dur), Abs(dur - base)))
            if (CB("AbortOnAnomaly")) {
                Abort(Format("セラピーの所要時間が 1 回目と大きく違います。`n"
                    . "  1 回目: {1}`n  {2} 回目: {3}`n`n"
                    . "セラピーが同じように行われていない可能性があるため停止します。"
                    , FmtDur(base), G.cycle, FmtDur(dur)))
                return false
            }
        }
    }
    return true
}

TickTherapyRest() {
    global G
    if (StateSec() < CI("RestBetweenSec")) {
        Arm(1000)
        return
    }
    SetState("therapy_ready")
    Arm(500)
}

;==============================================================================
;  後始末
;==============================================================================
TickCleanup() {
    global G
    if (hd := FindScreen("Dialog")) {
        TryClick(hd, CS("DialogOkClassNN"), CS("DialogOkText"))
        Arm(800)
        return
    }
    if (HasScreen("S2_Card") && !HasScreen("S3_Scheme")) {
        Finish(0, "指定した内容を完了しました")
        return
    }
    if (StateTimedOut(CI("TransitionTimeoutSec"), "後始末")) {
        return
    }
    if (h := FindScreen("S3_Scheme"))
        TryClick(h, CS("SchemeBackClassNN"), CS("SchemeBackText"))
    Arm(1000)
}


;==============================================================================
;  停止・終了・状態の記録
;==============================================================================

; 停止手段 4 系統（v4 と同じ）。どれでも 5 秒以内に止まる。
;   ★止めるのは「次のクリックから」。実行中のセラピーは中断しない（G8）
CheckStopFiles() {
    global G, STOPFILE, REMOTEFILE
    if FileExist(STOPFILE) {
        Finish(3, "STOP ファイルを検出しました")
        return true
    }
    if FileExist(REMOTEFILE) {
        body := ""
        try body := Trim(FileRead(REMOTEFILE, "UTF-8"))
        if (InStr(body, FormatTime(A_Now, "yyyy-MM-dd"))) {
            Finish(3, "遠隔停止ファイル（REMOTE_STOP）を検出しました")
            return true
        }
    }
    return false
}

Abort(reason) {
    Log("ERROR", "中止: " StrReplace(reason, "`n", " / "))
    Finish(2, reason)
}

; トレイから終わらせるとき。メニューへ戻さずに終了する
TrayQuit() {
    global G
    G.fromMenu := false
    Finish(3, "トレイから停止しました")
}

Finish(code, reason) {
    global G, APP_NAME, LIVEFILE
    if (G.stopping)
        return
    G.stopping := true
    SetTimer(Tick, 0)
    SaveState()
    ; --- スケジュール運転中は、ここで終了せずスケジューラへ制御を返す ---------
    if (G.schedOn) {
        ResumeMaybe(code, reason)                  ; 対象ソフトが消えたときは、続きの札を残す
        summary := BuildSummary(code, reason)
        Log("INFO", "ジョブ終了 code=" code " reason=" StrReplace(reason, "`n", " / "))
        G.lastJobEnd := A_Now
        try FileAppend(CRLF("`n" summary "`n"), G.logFile, "UTF-8")
        NotifyJobResult(code, reason, summary)     ; ★通知（使う設定のときだけ）★
        G.stopping := false                        ; 次のジョブのために戻す
        SchedJobFinished(code, reason, summary)
        return
    }
    ClosePanel()
    try FileDelete(LIVEFILE)                       ; 単独実行はここで終わり
    summary := BuildSummary(code, reason)
    Log("INFO", "終了 code=" code " reason=" StrReplace(reason, "`n", " / "))
    try FileAppend(CRLF("`n" summary "`n"), G.logFile, "UTF-8")
    NotifyJobResult(code, reason, summary)         ; ★通知（使う設定のときだけ）★
    WriteStatus(true)
    icon := (code = 0) ? "Iconi 4096" : "Icon! 4096"
    MsgBox(summary, APP_NAME " - " (code = 0 ? "完了" : (code = 4 ? "要確認" : "停止")), icon)
    ; ★人がメニューから始めたなら、メニューへ戻す★
    ;   続けてもう 1 人を実行したいのに、毎回ソフトが消えていた（2026-09-22 指摘）。
    ;   状態を引きずらないよう、新しく起こし直してから自分は終わる。
    if (G.fromMenu)
        OpenMenuWindow()                       ; 二重に開かない仕組みを通す
    ExitApp(code)
}

BuildSummary(code, reason) {
    global G
    o := "=== AutoMeta 実行結果 ===`n"
    o .= "顧客       : 「" G.wantSei " " G.wantMei "」"
       . (G.gotSei = "" ? "（照合前）" : "  → 照合 OK") "`n"
    scanTxt := "実行しない設定"
    if (CB("RunInvestigation")) {
        scanTxt := (G.scanSec > 0) ? (FmtDur(G.scanSec) . " / " . G.scanItems . " 項目") : "未完了"
    }
    o .= "調査       : " . scanTxt . "`n"
    o .= "セラピー   : " G.cycle " / " CI("TherapyCount") " 回`n"
    if (G.durations.Length > 0) {
        list := ""
        for d in G.durations
            list .= (list = "" ? "" : " / ") FmtDur(d)
        o .= "各サイクル : " list "`n"
        o .= "指標の最大途切れ: " G.maxGap " 秒`n"
    }
    o .= "総クリック : " G.clicks " 回（上限 " MaxClicksTotal() "）`n"
    LogFlush()
    if (G.logLost > 0)
        o .= "★記録できなかったログ : " G.logLost " 行（ログを開いたままにしていませんか）`n"
    if (G.logLate > 0)
        o .= "書き込みが弾かれ、あとで書き足したログ : " G.logLate " 行（この運転のここまでの合計。欠けてはいません）`n"
    o .= "総所要時間 : " FmtDur(SecSince(G.startTS)) "`n"
    if (CB("DryRun"))
        o .= "`n※ DryRun のため、実際には何も押していません。`n"
    o .= "`n理由       : " reason "`n"
    ; ★調査タイプを確かめられなかったことを、完了の知らせにも出す★（2026-10-08 指示）
    ;   以前は確認待ちにだけ残り、完了の通知だけ見ると「問題なし」に見えた。
    if (G.optWarn != "")
        o .= "`n★確認: " . G.optWarn . "（調査は続行しました。調査タイプを確かめてください）`n"
    if (G.resumeNote != "")
        o .= "`n" . G.resumeNote . "`n"
    if (G.resumeRun)
        o .= "`n※ 中断した予定の続きです（残りの回数だけ実行しました）。`n"
    o .= "`n※ 本ツールは画面の状態しか見ていません。`n"
       . "   実際のセラピー完了は、ソフト側の履歴で確認してください。`n"
    return o
}

WriteStatus(force := false) {
    global G, STATUSTX, APP_VER
    if (!force && G.statusTS != "" && SecSince(G.statusTS) < 20)
        return
    G.statusTS := A_Now
    WriteLive()
    o := "AutoMeta " APP_VER "   " FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss") "`n"
    o .= "状態      : " G.state (CB("DryRun") ? "（DryRun）" : "") "`n"
    o .= "顧客      : " G.wantSei " " G.wantMei
       . (G.gotSei = "" ? "" : "  （照合 OK）") "`n"
    if (CB("RunInvestigation")) {
        st := (G.scanSec > 0) ? ("完了 " . FmtDur(G.scanSec)) : (G.scanItems . " 項目目")
        o .= "調査      : " . st . "`n"
    }
    o .= "セラピー  : " G.cycle " / " CI("TherapyCount") " 回`n"
    if (G.state = "therapy_run")
        o .= "  経過    : " FmtDur(SecSince(G.cycleStartTS)) "`n"
    o .= "経過      : " FmtDur(SecSince(G.startTS)) "`n"
    o .= "画面      : " ScreenNames() "`n"
    try {
        FileDelete(STATUSTX)
    }
    try FileAppend(CRLF(o), STATUSTX, "UTF-8")
}

SaveState() {
    global G, STATEINI
    IniSetMany(STATEINI, "Job", Map(
        "Patient",      G.wantSei " " G.wantMei,
        "State",        G.state,
        "TherapyDone",  G.cycle,
        "TherapyTotal", CI("TherapyCount"),
        "StartedAt",    FmtTS(G.startTS)))
}

; 異常時に画面を保存する（原因究明用）
SaveShot(tag) {
    global G, SHOTDIR
    if !DirExist(SHOTDIR)
        DirCreate(SHOTDIR)
    ; AHK 単体では画面キャプチャができないため、代わりに全ウィンドウの
    ; コントロール一覧をテキストで残す（原因究明にはこれで足りる）
    path := SHOTDIR "\" FormatTime(A_Now, "yyyyMMdd_HHmmss") "_" tag ".txt"
    o := "=== " tag "  " FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss") " ===`n"
    o .= "状態: " G.state "  / 顧客: " G.wantSei " " G.wantMei "`n`n"
    for w in TargetWindows(G.pid) {
        o .= "── 「" w["title"] "」  class=" w["class"]
           . "  判定=" ClassifyScreen(w["hwnd"])["id"] "`n"
        o .= CtrlsToText(DumpCtrls(w["hwnd"]))
        o .= "`n"
    }
    try FileAppend(CRLF(o), path, "UTF-8")
    Log("WARN", "画面の状態を保存しました: " path)
}

;==============================================================================
;  トレイ常駐とホットキー
;==============================================================================
; メニューを【別プロセスで】開く。
;   運転中のプロセスでメニューを開くと、設定や状態を書き換えてしまう恐れがある。
;   2_START.bat と同じことを、自分自身を起動してやる。
;   （毎回エクスプローラーからファイルを選ぶのが手間、というカマヤン指摘 2026-09-15）
OpenMenuWindow() {
    global APP_NAME
    ; ★すでに開いているメニューがあるなら、そちらを前に出す★
    ;   毎回 /menu で新しいプロセスを起こしていたため、
    ;   押した回数だけ窓が増えていた（2026-09-18 指摘）。
    if (MenuWindowHwnd()) {
        try WinActivate("ahk_id " MenuWindowHwnd())
        return
    }
    try {
        Run('"' A_AhkPath '" "' A_ScriptFullPath '" /menu', A_ScriptDir)
    } catch as e {
        MsgBox("メニューを開けませんでした: " e.Message "`n`n"
            . "system\2_START.bat（または menu.bat）から開いてください。"
            , APP_NAME, "Iconx 4096")
    }
}

; いま開いている AutoMeta のメニュー窓（無ければ 0）。
;   ★自分の窓は数えない★ タイトルだけで探すと自分自身を拾ってしまう。
;   ★運転パネルと間違えない★
;     パネルのタイトルは「AutoMeta  v2.5.2」で、以前の判定
;     （APP_NAME を含み " - " を含まない）にそのまま当てはまっていた。
;     そのため運転中はメニューを開けず、パネルが前に出るだけになっていた。
MenuWindowHwnd() {
    global APP_NAME
    mine := MyPid()
    want := APP_NAME . " - メニュー"
    for h in WinGetList() {
        t := "", pid := 0
        try {
            t := WinGetTitle("ahk_id " h)
            pid := WinGetPID("ahk_id " h)
        } catch
            continue
        if (pid != mine && InStr(t, want))
            return h
    }
    return 0
}

SetupTray() {
    global G, APP_NAME
    A_TrayMenu.Delete()
    A_TrayMenu.Add("パネルを表示", (*) => RestorePanel())
    A_TrayMenu.Add("メニューを開く", (*) => OpenMenuWindow())
    A_TrayMenu.Add()
    A_TrayMenu.Add("状態を表示", (*) => MsgBox(BuildSummary(9, "（実行中）"), APP_NAME, "Iconi 4096"))
    A_TrayMenu.Add("ログを開く", (*) => OpenFile(G.logFile))
    A_TrayMenu.Add()
    ; ★トレイの「終了」は、本当に終わる★ メニューを開き直さない
    A_TrayMenu.Add("終了（次のクリックから止める）", (*) => TrayQuit())
    A_TrayMenu.Default := "状態を表示"
    Hotkey("^!+s", (*) => Finish(3, "ホットキーで停止しました"))
    Hotkey("^!+m", (*) => OpenMenuWindow())        ; Ctrl+Alt+Shift+M でメニュー
    UpdateTrayTip()
    SetTimer(UpdateTrayTip, 5000)
}

UpdateTrayTip() {
    global G, APP_NAME
    try A_IconTip := APP_NAME "`n" G.wantSei " " G.wantMei
        . "`nセラピー " G.cycle "/" CI("TherapyCount") "`n" G.state
}

;==============================================================================
;  /run  単発実行（Phase 1 の入口）
;==============================================================================
ModeRun() {
    global G, C, APP_NAME, APP_VER, STOPFILE
    LicenseGate()                                  ; 利用の期限（止めるならここで終わる）
    EnsureSingleInstance()
    EnsureTarget()
    LoadScreens()
    try FileDelete(STOPFILE)                        ; 取り残しで動かなくならないように

    ; ★検索に必要な設定は、ここでは求めない★
    ;   「いま開いているカードで実行する」なら検索しないため。
    ;   検索を選んだときだけ、開始の直前で確かめる（2026-09-22）。
    if (!Preflight(&msg, false)) {
        MsgBox(msg, APP_NAME " - 実行できません", "Icon! 4096")
        ReopenAndExit(1)
    }

    dlg := Gui("+AlwaysOnTop", APP_NAME " - 実行" VerTag())
    dlg.MarginX := 18, dlg.MarginY := 14
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "w560", "1 人分を実行します（調査 1 回 ＋ セラピー N 回）")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w560 cGray", APP_VER "   対象ソフト: " CS("ExeName"))
    dlg.Add("Text", "w560 h1 0x10")

    ; ★顧客の決め方を選べるようにする★（2026-09-22 指摘）
    ;   開いているカードから始めれば、検索で取り違える余地がない。
    openWho := "", openSei := "", openMei := "", openMid := ""
    if (hCard := FindScreen("S2_Card")) {
        if (ReadPatientSettled(hCard, &openSei, &openMei, &wOpen)) {
            openMid := ReadMiddleName(hCard)
            openWho := openSei . " " . openMei
            if (openMid != "")
                openWho .= "（ミドル " . openMid . "）"
        }
    }
    dlg.SetFont("s10 Bold", "Meiryo UI")
    rSearch := dlg.Add("Radio", "xm w560 Checked", "名前で検索して開く")
    rOpen   := dlg.Add("Radio", "xm w560" (openWho = "" ? " Disabled" : "")
        , "いま開いているカードで実行する"
        . (openWho = "" ? "（カードが開いていません）" : "　→　" . openWho))
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "xm+20 w540 cGray"
        , "　開いているカードを使うときは、下の姓名は使いません。"
        . "開始の前に、もう一度カードの氏名を読んで確かめます。")

    dlg.SetFont("s10", "Meiryo UI")
    dlg.Add("Text", "xm w120", "姓")
    eSei := dlg.Add("Edit", "x+10 yp-4 w180", CS("LastName"))
    dlg.Add("Text", "x+20 yp+4 w60", "名")
    eMei := dlg.Add("Edit", "x+10 yp-4 w180", CS("FirstName"))
    dlg.Add("Text", "xm w120", "ミドル")
    eMid := dlg.Add("Edit", "x+10 yp-4 w180", CS("MiddleName"))
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "xm w560 cGray"
        , "  一覧の検索欄に「姓␣名」を入れて絞り込みます。開いたカードの姓名が"
        . "一致しなければ、何もせず中止します。`n"
        . "  ミドルは、同じ方の比較用カードと区別するときだけ入力します"
        . "（空欄＝ミドル無しのカードが対象）。")

    dlg.SetFont("s10", "Meiryo UI")
    cScan := dlg.Add("CheckBox", "xm w560 " (CB("RunInvestigation") ? "Checked" : "")
        , "調査を 1 回実行する")
    dlg.Add("Text", "xm w120", "セラピー回数")
    eCnt := dlg.Add("Edit", "x+10 yp-4 w60 Number", CI("TherapyCount"))
    dlg.Add("UpDown", "Range0-" . CI("MaxUnattendedCycles"), CI("TherapyCount"))
    ; 見積もりは行を分ける（横に置くと文字が切れる。2026-09-17 指摘）
    dlg.SetFont("s9", "Meiryo UI")
    lblEst := dlg.Add("Text", "xm+12 w548 cGray", "")
    dlg.SetFont("s10", "Meiryo UI")

    ; ★予定の編集画面と同じ選択肢を、ここにも出す★
    ;   ここに無いと、1 人だけ実行したときだけ設定が効かない（2026-09-17 指摘）
    stNames := OptNames("ScanType")
    mnNames := OptNames("Manual")
    stList  := [NoChangeLabel()]
    for nm in stNames
        stList.Push(nm)
    mnList := [NoChangeLabel(), NoneSelectLabel()]
    for nm in mnNames
        mnList.Push(nm)
    dlg.Add("Text", "xm w120", "調査タイプ")
    dST := dlg.Add("DropDownList", "x+10 yp-4 w140", stList)
    SelectByName(dST, stList, OptLabelOfValue(CS("ScanTypeName")))
    dlg.Add("Text", "x+16 yp+4 w110", "マニュアル選択")
    dMN := dlg.Add("DropDownList", "x+10 yp-4 w160", mnList)
    SelectByName(dMN, mnList, OptLabelOfValue(CS("ManualName")))
    if (!stNames.Length || !mnNames.Length) {
        dlg.SetFont("s9", "Meiryo UI")
        dlg.Add("Text", "xm+12 w548 cRed"
            , "※ 位置が未登録です（設定 →「測定値を設定し直す」→「調査タイプ／マニュアル選択の位置を登録」）")
        dlg.SetFont("s10", "Meiryo UI")
    }

    dlg.SetFont("s10", "Meiryo UI")
    cDry := dlg.Add("CheckBox", "xm w560 " (CB("DryRun") ? "Checked" : "")
        , "DryRun（画面は追うが、一切クリックしない）")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "xm w560 cGray"
        , "  はじめての顧客では、まず DryRun で画面遷移が想定どおりか確かめてください。")

    dlg.Add("Text", "xm w560 h1 0x10")
    dlg.SetFont("s10", "Meiryo UI")
    bGo := dlg.Add("Button", "xm w260 h40 Default", "開始")
    bNo := dlg.Add("Button", "x+20 yp w260 h40", "キャンセル")
    bGo.OnEvent("Click", DoRun)
    bNo.OnEvent("Click", (*) => ReopenAndExit(0))
    dlg.OnEvent("Close", (*) => ReopenAndExit(0))
    eCnt.OnEvent("Change", (*) => UpdateEst())
    UpdateEst()
    dlg.Show()
    return

    UpdateEst() {
        n := ToInt(eCnt.Value, 0)
        if (n = 0) {
            lblEst.Value := "0 回 ＝ セラピーは行いません（調査のみ）"
            return
        }
        lblEst.Value := Format("目安 {1}〜{2}（セラピー 1 回 6〜30 分の実測より）"
            , FmtDur(n * 360), FmtDur(n * CI("PlanCycleSec")))
    }

    DoRun(*) {
        global G, C
        useOpen := rOpen.Value
        sei := Trim(eSei.Value), mei := Trim(eMei.Value), mid := Trim(eMid.Value)
        if (useOpen) {
            ; ★押した時点で読み直す★ 画面の前でカードを切り替えたかもしれない
            h2 := FindScreen("S2_Card")
            if (!h2) {
                MsgBox("カード画面が見つかりません。`n`n"
                    . "顧客のカードを開いてから、もう一度押してください。"
                    , APP_NAME, "Icon! 4096")
                return
            }
            s2 := "", m2 := "", w2 := ""
            if (!ReadPatientSettled(h2, &s2, &m2, &w2)) {
                MsgBox("開いているカードの氏名が読めませんでした。`n`n  " . w2
                    , APP_NAME, "Icon! 4096")
                return
            }
            sei := s2, mei := m2, mid := ReadMiddleName(h2)
        }
        if (sei = "" || mei = "") {
            MsgBox("姓と名の両方を入れてください。`n"
                . "同姓の方が複数いるため、姓だけでは一意に絞れません。", APP_NAME, "Icon! 4096")
            return
        }
        ; 検索して開くときだけ、一覧まわりの設定がそろっているか確かめる
        if (!useOpen && !Preflight(&msg2, true)) {
            MsgBox(msg2, APP_NAME " - 検索して開けません", "Icon! 4096")
            return
        }
        n := ToInt(eCnt.Value, 0)
        if (n < 0) {
            MsgBox("セラピー回数は 0 以上にしてください。", APP_NAME, "Icon! 4096")
            return
        }
        if (n = 0 && !cScan.Value) {
            MsgBox("調査もセラピーも行わない設定です。`nどちらかを有効にしてください。"
                , APP_NAME, "Icon! 4096")
            return
        }
        if (n > CI("MaxUnattendedCycles")) {
            MsgBox(Format("セラピー回数の上限は {1} 回です。", CI("MaxUnattendedCycles"))
                , APP_NAME, "Icon! 4096")
            return
        }
        C["TherapyCount"]     := n
        C["RunInvestigation"] := cScan.Value ? "1" : "0"
        C["DryRun"]           := cDry.Value ? "1" : "0"
        C["ScanTypeName"]     := (dST.Value <= 1) ? "" : stList[dST.Value]
        C["ManualName"]       := (dMN.Value = 1) ? "" : ((dMN.Value = 2) ? "なし" : mnList[dMN.Value])
        G.wantSei := sei, G.wantMei := mei, G.wantMid := mid
        G.useOpenCard := useOpen ? true : false

        ; 警告文は先に組み立てる（行頭が ":" の継続行はラベルと紛れるため使わない）
        warn := ""
        if (!cDry.Value) {
            if (n = 0) {
                warn := "※ 回数が 0 なので、セラピーは行いません（調査のみ）。`n`n"
            } else {
                warn := "★実際にセラピーが始まります。顧客と回数をもう一度確認してください。★`n`n"
            }
        }
        est := (n = 0) ? "（セラピーなし）" : Format("（目安 {1}〜{2}）", FmtDur(n * 360), FmtDur(n * CI("PlanCycleSec")))
        howTxt := useOpen ? "いま開いているカード（探しに行きません）" : "名前で検索して開く"
        msg := Format("この内容で実行します。`n`n"
            . "  始め方    : {8}`n"
            . "  顧客      : 「{1} {2}」`n"
            . "  調査      : {3}`n"
            . "  セラピー  : {4} 回{5}`n"
            . "  DryRun    : {6}`n`n"
            . "{7}"
            . "開始してよろしいですか？"
            , sei, mei, cScan.Value ? "1 回実行する" : "実行しない", n
            , est
            , cDry.Value ? "はい（何も押しません）" : "いいえ（実際に操作します）"
            , warn, howTxt)
        opt := "YesNo Icon? 4096" . (cDry.Value ? "" : " Default2")
        if (MsgBox(msg, APP_NAME " - 最終確認", opt) != "Yes")
            return
        dlg.Destroy()
        SetupTray()
        ShowPanel()
        StartJob()
    }
}

; 起動前の点検
; needSelect = false なら、顧客の検索に関わる設定は要求しない
;   （自動セラピーは、いま開いているカードを使うので検索しない）
Preflight(&msg, needSelect := true) {
    global G
    msg := ""
    ng := []
    if (CS("ExeName") = "")
        ng.Push("対象ソフトが設定されていません（1_SETUP.bat）")
    if (CS("LastNameFieldClassNN") = "" || CS("FirstNameFieldClassNN") = "")
        ng.Push("姓名の欄が設定されていません（メニューの「読み取り可否を確認」を実行）")
    if (needSelect) {
        if (CS("SearchBoxClassNN") = "")
            ng.Push("検索欄が設定されていません（同上）")
        if (CI("ListFirstRowX") <= 0 || CI("ListFirstRowY") <= 0)
            ng.Push("一覧の先頭行の座標が設定されていません（config.ini の ListFirstRowX/Y）")
        if (!CB("VerifyPatientName"))
            ng.Push("VerifyPatientName=0 は許可されていません（氏名照合は省略できません）")
    }
    if (CS("IndicatorClass") = "")
        ng.Push("指標ウィンドウのクラスが設定されていません（config.ini の IndicatorClass）")
    ; 見込みの所要時間が、実行時間の上限を超えないか。
    ;   ExpectedCycleMaxSec（＝異常検知の上限 90 分）で見積もると過大になるため、
    ;   実測の上側（PlanCycleSec 既定 30 分）で見積もる
    worst := CI("TherapyCount") * CI("PlanCycleSec") + 1800
    if (CI("MaxRuntimeSec") > 0 && worst > CI("MaxRuntimeSec")) {
        ng.Push(Format("セラピー {1} 回だと最大 {2} かかる見込みで、実行時間の上限 {3} を超えます。`n"
            . "      回数を減らすか、config.ini の MaxRuntimeSec を延ばしてください"
            , CI("TherapyCount"), FmtDur(worst), FmtDur(CI("MaxRuntimeSec"))))
    }
    if (ng.Length = 0)
        return true
    msg := "次の設定が足りません。`n`n"
    for x in ng
        msg .= "  ・" x "`n"
    return false
}


;==============================================================================
;  Phase 3: スケジューラ
;  顧客ごとの予定に従い、ジョブを【1 件ずつ直列に】実行する。
;
;  ★設計の原則★
;    - 同時実行は絶対にしない（G6）
;    - 予定を大きく過ぎたものは実行しない（夜中の予定を翌朝まとめて実行しない）
;    - 1 人の失敗で全体を止めない。ただし連続して失敗するなら systemic とみなし停止
;==============================================================================

; 曜日の指定を受け取る（英語・日本語どちらでも）
;   1=日 2=月 3=火 4=水 5=木 6=金 7=土
DayNameToNum(name) {
    static m := Map("sun",1,"mon",2,"tue",3,"wed",4,"thu",5,"fri",6,"sat",7
                  , "sunday",1,"monday",2,"tuesday",3,"wednesday",4
                  , "thursday",5,"friday",6,"saturday",7
                  , "日",1,"月",2,"火",3,"水",4,"木",5,"金",6,"土",7
                  , "日曜",1,"月曜",2,"火曜",3,"水曜",4,"木曜",5,"金曜",6,"土曜",7)
    k := StrLower(Trim(name))
    return m.Has(k) ? m[k] : 0
}

DayNumToName(n) {
    static a := ["日","月","火","水","木","金","土"]
    return (n >= 1 && n <= 7) ? a[n] : "?"
}

; YYYYMMDD の曜日を返す（1=日 … 7=土）
;   FormatTime の曜日表記はロケール依存なので使わず、日数差から計算する。
;   1970-01-01 は木曜日。
WeekdayOf(ymd) {
    days := DateDiff(ymd "000000", "19700101000000", "Days")
    return Mod(Mod(days + 4, 7) + 7, 7) + 1
}

DaysInclude(spec, wd) {
    for part in StrSplit(spec, ",") {
        if (DayNameToNum(part) = wd)
            return true
    }
    return false
}

; "2026-09-20" / "20260920" どちらでも受ける
NormDate(s) {
    s := StrReplace(StrReplace(Trim(s), "-", ""), "/", "")
    return (StrLen(s) = 8) ? s : ""
}

; "21:00" → "2100"
; ★入れ方の揺れを吸収する★
;   「18:00」「1800」「18」「18時」「１８：００」のどれでも受け取る。
;   受け取れないときは空文字を返し、呼ぶ側が入れ直しを促す（2026-09-26）。
NormTime(s) {
    t := Trim(s)
    t := StrReplace(t, "：", ":")
    for zen, han in Map("０", "0", "１", "1", "２", "2", "３", "3", "４", "4"
                      , "５", "5", "６", "6", "７", "7", "８", "8", "９", "9")
        t := StrReplace(t, zen, han)
    t := RegExReplace(t, "[^0-9]", "")         ; 数字だけ残す（時・分・: を落とす）
    if (t = "")
        return ""
    hhPart := "", mmPart := "0"
    if (StrLen(t) <= 2)
        hhPart := t
    else if (StrLen(t) = 3)
        hhPart := SubStr(t, 1, 1), mmPart := SubStr(t, 2)
    else if (StrLen(t) = 4)
        hhPart := SubStr(t, 1, 2), mmPart := SubStr(t, 3)
    else
        return ""
    hourNum := ToInt(hhPart, -1), minNum := ToInt(mmPart, -1)
    if (hourNum < 0 || hourNum > 23 || minNum < 0 || minNum > 59)
        return ""
    return Format("{:02}{:02}", hourNum, minNum)
}

;==============================================================================
;  schedule.ini の読み込み
;==============================================================================
; 未設定またはプレビュー用の仮キーか（このまま保存すると全員が同じ節名になり上書きされる）
IsBlankSchedKey(k) {
    t := Trim("" . k)
    return (t = "" || t = "Patient.（新規）")
}

; 3.10.30 以前で [Patient.（新規）] のまま保存された予定を、氏名ごとの節名に直す。
;   同じ節名が複数あると IniLoad で後ろの 1 件に上書きされるため、読む前にファイル上で振り直す。
RepairNewKeySchedule() {
    global SCHEDINI
    if !FileExist(SCHEDINI)
        return
    txt := ""
    try txt := FileRead(SCHEDINI, "UTF-8")
    catch
        return
    if !InStr(txt, "[Patient.（新規）]")
        return
    raw := StrReplace(txt, Chr(0xFEFF), "")
    blocks := []
    curSec := ""
    curLines := []
    Loop Parse, raw, "`n", "`r" {
        line := A_LoopField
        t := Trim(line)
        if (SubStr(t, 1, 1) = "[" && SubStr(t, -1) = "]") {
            blocks.Push(Map("sec", curSec, "lines", curLines))
            curSec := Trim(t, "[] `t")
            curLines := [line]
            continue
        }
        curLines.Push(line)
    }
    blocks.Push(Map("sec", curSec, "lines", curLines))
    taken := []
    for blk in blocks {
        if (blk["sec"] != "" && !IsBlankSchedKey(blk["sec"]))
            taken.Push(Map("key", blk["sec"]))
    }
    replaced := []
    for blk in blocks {
        if (blk["sec"] != "Patient.（新規）")
            continue
        sei := "", mei := ""
        for rawLn in blk["lines"] {
            tl := Trim(rawLn)
            if (tl = "" || SubStr(tl, 1, 1) = ";" || SubStr(tl, 1, 1) = "#" || SubStr(tl, 1, 1) = "[")
                continue
            pos := InStr(tl, "=")
            if (pos < 2)
                continue
            k := Trim(SubStr(tl, 1, pos - 1))
            v := StripInlineComment(SubStr(tl, pos + 1))
            if (k = "LastName")
                sei := v
            else if (k = "FirstName")
                mei := v
        }
        nk := MakeSchedKey(sei, mei, taken)
        taken.Push(Map("key", nk))
        blk["sec"] := nk
        blk["lines"][1] := "[" . nk . "]"
        replaced.Push(nk)
    }
    if (replaced.Length = 0)
        return
    out := ""
    for idx, blk in blocks {
        for lIdx, rawLn in blk["lines"]
            out .= ((idx = 1 && lIdx = 1) ? "" : "`n") . rawLn
    }
    if !IniWriteBody(SCHEDINI, out)
        return
    if (replaced.Length = 1) {
        nk := replaced[1]
        oldC := ContactGet("Patient.（新規）")
        if (oldC["on"] || oldC["line"] != "") {
            curC := ContactGet(nk)
            if (!curC["on"] && curC["line"] = "")
                ContactSet(nk, oldC["on"], oldC["line"]), ContactPreSet(nk, ContactPreGet("Patient.（新規）"))
            ContactDelete("Patient.（新規）")
        }
        if (ContactMailHas("Patient.（新規）")) {
            oldM := ContactMailGet("Patient.（新規）")
            if (oldM != "" && !ContactMailHas(nk))
                ContactMailSet(nk, oldM)
            ContactMailSet("Patient.（新規）", "")
        }
        if (NotifyBodyHas("Patient.（新規）")) {
            oldB := NotifyBodyGet("Patient.（新規）")
            if (oldB != "" && !NotifyBodyHas(nk))
                NotifyBodySave(nk, oldB)
            NotifyBodyClear("Patient.（新規）")
        }
        MigrateHistoryKey("Patient.（新規）", nk)
    }
    for nk in replaced
        Log("INFO", "schedule.ini の仮の見出し [Patient.（新規）] を [" . nk . "] に直しました")
}

; 仮の見出し [History.Patient.（新規）] に記録されていた実行履歴を、本来の見出しへ引き継ぐ（3.10.32）
MigrateHistoryKey(oldKey, newKey) {
    global STATEINI
    if !FileExist(STATEINI)
        return false
    sm := IniLoad(STATEINI)
    oldSec := "History." . oldKey
    newSec := "History." . newKey
    if !sm.Has(oldSec)
        return false
    oldRuns := ToInt(IniGet(sm, oldSec, "RunCount", "0"), 0)
    oldLast := Trim(IniGet(sm, oldSec, "LastRunAt", ""))
    curRuns := ToInt(IniGet(sm, newSec, "RunCount", "0"), 0)
    curLast := Trim(IniGet(sm, newSec, "LastRunAt", ""))
    if (curRuns = 0 && curLast = "" && (oldRuns > 0 || oldLast != "")) {
        pairs := Map()
        for k, v in sm[oldSec]
            pairs[k] := v
        IniSetMany(STATEINI, newSec, pairs)
        Log("INFO", Format("state.ini の仮の見出し [{1}]（{2} 回）を [{3}] に引き継ぎました", oldSec, oldRuns, newSec))
    }
    IniSetSection(STATEINI, oldSec, Map())
    return true
}

; 3.10.31 で schedule.ini の見出しだけ直り、state.ini に [History.Patient.（新規）] が残っている場合の引き継ぎ（3.10.32）
RepairOrphanNewHistory(list) {
    global STATEINI
    if !FileExist(STATEINI)
        return
    sm := IniLoad(STATEINI)
    oldSec := "History.Patient.（新規）"
    if !sm.Has(oldSec)
        return
    oldRuns := ToInt(IniGet(sm, oldSec, "RunCount", "0"), 0)
    oldLast := Trim(IniGet(sm, oldSec, "LastRunAt", ""))
    if (oldRuns <= 0 && oldLast = "") {
        IniSetSection(STATEINI, oldSec, Map())
        return
    }
    noHist := []
    dated := []
    lastDay := (StrLen(oldLast) >= 8) ? SubStr(oldLast, 1, 8) : ""
    for p in list {
        k := p["key"]
        if IsBlankSchedKey(k)
            continue
        sec := "History." . k
        runs := ToInt(IniGet(sm, sec, "RunCount", "0"), 0)
        last := Trim(IniGet(sm, sec, "LastRunAt", ""))
        if (runs = 0 && last = "") {
            noHist.Push(k)
            if (p["start"] != "" && lastDay != "" && p["start"] <= lastDay)
                dated.Push(k)
        }
    }
    targetKey := ""
    if (dated.Length >= 1)
        targetKey := dated[1]
    else if (noHist.Length = 1)
        targetKey := noHist[1]
    if (targetKey != "")
        MigrateHistoryKey("Patient.（新規）", targetKey)
}

LoadSchedule(&err) {
    global SCHEDINI
    err := ""
    out := []
    if !FileExist(SCHEDINI) {
        err := "schedule.ini がありません: " SCHEDINI
        return out
    }
    RepairNewKeySchedule()
    m := IniLoad(SCHEDINI)
    for sec, kv in m {
        if (StrLower(SubStr(sec, 1, 8)) != "patient.")
            continue
        p := Map()
        p["key"]     := sec
        p["name"]    := SubStr(sec, 9)
        p["enabled"] := IniGet(m, sec, "Enabled", "1") = "1"
        p["sei"]     := Trim(IniGet(m, sec, "LastName", ""))
        p["mei"]     := Trim(IniGet(m, sec, "FirstName", ""))
        p["middle"]  := Trim(IniGet(m, sec, "MiddleName", ""))
        p["mode"]    := StrLower(Trim(IniGet(m, sec, "Mode", "weekly")))
        p["days"]    := IniGet(m, sec, "Days", "")
        p["time"]    := NormTime(IniGet(m, sec, "Time", ""))
        ; 時刻の扱い: at = その時刻ちょうど / queue = その時刻以降、空き次第 順番に
        p["timemode"] := (StrLower(Trim(IniGet(m, sec, "TimeMode", "at"))) = "queue")
                       ? "queue" : "at"
        p["interval"]:= ToInt(IniGet(m, sec, "IntervalDays", "0"), 0)
        p["scan"]    := IniGet(m, sec, "RunInvestigation", "1") = "1"
        ; 調査タイプ／マニュアル選択。書いていなければ既定（詳細／自動選択）
        p["scantype"] := Trim(IniGet(m, sec, "ScanType", CS("ScanTypeName")))
        p["manual"]   := Trim(IniGet(m, sec, "ManualSelect", CS("ManualName")))
        p["count"]   := ToInt(IniGet(m, sec, "TherapyCount", "1"), 1)
        p["start"]   := NormDate(IniGet(m, sec, "StartDate", ""))
        p["end"]     := NormDate(IniGet(m, sec, "EndDate", ""))
        p["maxruns"] := ToInt(IniGet(m, sec, "MaxRuns", "0"), 0)
        p["catchup"] := ToInt(IniGet(m, sec, "CatchUpWindowMin", "120"), 120)
        p["note"]    := IniGet(m, sec, "Note", "")
        p["order"]   := ToInt(IniGet(m, sec, "Order", "0"), 0)
        out.Push(p)
    }
    ; ★実行の順番は Order で決める★
    ;   AHK の Map の列挙順は仕様として保証されていない（実装上はキーの文字コード順）。
    ;   日本語のセクション名なら漢字の Unicode 番号順になり、五十音順でも画数順でもない。
    ;   つまり「ファイルに書いた順」には決してならないので、必ずここで並べ替える。
    out := SortByOrder(out)
    RepairOrphanNewHistory(out)
    if (out.Length = 0)
        err := "schedule.ini に [Patient.◯◯] の予定が 1 件もありません"
    return out
}

; Order の小さい順に並べ替える（Order が無いものは末尾。同値ならもとの順）
SortByOrder(list) {
    out := []
    for item in list {
        key := (item["order"] > 0) ? item["order"] : 9000
        pos := out.Length + 1
        Loop out.Length {
            oKey := (out[A_Index]["order"] > 0) ? out[A_Index]["order"] : 9000
            if (key < oKey) {
                pos := A_Index
                break
            }
        }
        out.InsertAt(pos, item)
    }
    return out
}

; 予定の書き方が正しいか。おかしければ理由を返す。
ValidateEntry(p, &why) {
    why := ""
    if (p["sei"] = "" || p["mei"] = "") {
        why := "LastName と FirstName の両方が必要です（同姓の方がいるため姓だけでは絞れません）"
        return false
    }
    if (p["time"] = "") {
        why := "Time の書き方が不正です（例: 21:00）"
        return false
    }
    if (p["count"] < 0 || p["count"] > CI("MaxUnattendedCycles")) {
        why := Format("TherapyCount は 0〜{1} にしてください", CI("MaxUnattendedCycles"))
        return false
    }
    if (p["count"] = 0 && !p["scan"]) {
        why := "調査もセラピーも行わない設定です"
        return false
    }
    if (p["mode"] = "weekly") {
        ok := false
        for part in StrSplit(p["days"], ",") {
            if (DayNameToNum(part) > 0)
                ok := true
        }
        if (!ok) {
            why := "Days の書き方が不正です（例: Mon,Wed,Fri または 月,水,金）"
            return false
        }
    } else if (p["mode"] = "interval") {
        if (p["interval"] <= 0) {
            why := "IntervalDays は 1 以上にしてください"
            return false
        }
    } else {
        why := "Mode は weekly か interval にしてください"
        return false
    }
    return true
}

;==============================================================================
;  実行履歴（state.ini）
;==============================================================================
HistLastRun(key) {
    global STATEINI
    if (IsBlankSchedKey(key))
        return ""
    return IniGet(IniLoad(STATEINI), "History." key, "LastRunAt", "")
}
; 次回の計算用。古い履歴は終了日時を使い、過去の予定日を推測しない。
HistLastSlot(key) {
    global STATEINI
    if (IsBlankSchedKey(key))
        return ""
    m := IniLoad(STATEINI)
    slot := IniGet(m, "History." key, "LastSlotAt", "")
    return (slot != "") ? slot : IniGet(m, "History." key, "LastRunAt", "")
}
HistRunCount(key) {
    global STATEINI
    if (IsBlankSchedKey(key))
        return 0
    return ToInt(IniGet(IniLoad(STATEINI), "History." key, "RunCount", "0"), 0)
}
; ★どの設定で調べたか★ 調査タイプとマニュアル選択の組み合わせ。
;   これが前回と違えば、項目数を比べても意味がない（2026-09-20 指摘）。
ScanSig() => Trim(CS("ScanTypeName")) . "|" . Trim(CS("ManualName"))

HistRecord(key, ok, slotTs) {
    global STATEINI, G
    ; 終了日時と、実行した予定枠を同時に保存する。失敗・見送りも枠を消費する。
    IniSetMany(STATEINI, "History." key, Map("LastRunAt", A_Now
        , "LastSlotAt", slotTs, "LastResult", ok ? "ok" : "failed"))
    if (ok) {
        IniSet(STATEINI, "History." key, "RunCount", HistRunCount(key) + 1)
        ; ★次回の「少なすぎないか」判定に使う★
        if (G.scanItems > 0) {
            IniSet(STATEINI, "History." key, "LastScanItems", G.scanItems)
            IniSet(STATEINI, "History." key, "LastScanSig", ScanSig())
        }
    }
}

;==============================================================================
;  「いま実行すべきか」の判定
;==============================================================================
DueNow(p, &why) {
    global G
    why := ""
    if (!p["enabled"]) {
        why := "無効（Enabled=0）"
        return false
    }
    if (!ValidateEntry(p, &vw)) {
        why := "設定が不正: " vw
        return false
    }
    now   := A_Now
    today := FormatTime(now, "yyyyMMdd")

    if (p["start"] != "" && today < p["start"]) {
        why := "開始日前（" p["start"] " から）"
        return false
    }
    if (p["end"] != "" && today > p["end"]) {
        why := "期間終了（" p["end"] " まで）"
        return false
    }
    runs := HistRunCount(p["key"])
    if (p["maxruns"] > 0 && runs >= p["maxruns"]) {
        why := Format("上限に到達（{1}/{2} 回）", runs, p["maxruns"])
        return false
    }

    ; ★「指定した日時」を基準にする★
    ;   SchedWaitSince は「いつから実行できる状態だったか」を返す。
    ;   これを過ぎていれば、日付をまたいでも実行対象のまま＝持ち越しになる。
    ;   23:00 の予定はその日の窓が 1 時間しかなく、1 件に 1 時間以上かかるため、
    ;   前の顧客が長引くと入れず、日付が変わると「今日の 23:00 待ち」へ戻って
    ;   いつまでも実行されなかった（2026-10-07 指摘）。
    ;   曜日・日数おき・初回を 1 か所で決めるので、判定が食い違わない。
    dueTs := SchedWaitSince(p)
    last  := HistLastSlot(p["key"])
    if (FormatTime(now, "yyyyMMddHHmmss") < dueTs) {
        why := "予定時刻前（" FormatTime(dueTs, "M/d HH:mm") "）"
        return false
    }
    if (last != "" && last >= dueTs) {
        why := "この予定は実行済み"
        return false
    }
    late := DateDiff(now, dueTs, "Minutes")
    ; ★遅れて起動したときの許容時間（catchup）★（3.10.34）
    ;   ・「この時刻ちょうどに（at）」は、予定時刻から catchup 分を過ぎていたら見送る。
    ;   ・「以降、空いたら順番に（queue）」は、下の開始の上限（3.10.39）に一本化した（3.10.42）。
    ;     120 分の決まりが先に判定して、上限の内側の予定まで見送っていた（2026-11-03 岸様）。
    ;     運転を長く止めていた予定が突然走らないよう、3 日より古い待ちだけを見送る。
    if (p["catchup"] > 0) {
        if (p["timemode"] = "at") {
            if (late > p["catchup"]) {
                why := Format("見送り（予定から {1} 分経過 / 上限 {2} 分）", late, p["catchup"])
                return false
            }
        } else {
            refTs := (G.schedOn && G.schedStartTS != "") ? G.schedStartTS : now
            if (SchedWaitTooOld(refTs, dueTs)) {
                why := Format("見送り（予定から {1} 時間遅れて運転開始 / 上限 {2} 時間）", DateDiff(refTs, dueTs, "Hours"), SchedWaitMaxH())
                return false
            }
        }
    }

    ; ★開始の遅れの上限★（3.10.39）ここは「見送り」にしない。回数を消費せず、翌日へ持ち越す
    if (!SchedLateOk(p, FormatTime(now, "yyyyMMddHHmmss"))) {
        why := Format("翌日へ持ち越し（{1} から再開）", FmtHHMM(p["time"]))
        return false
    }

    ; ★曜日・日数おき・初回の判定は SchedWaitSince に入っている★
    ;   ここで重ねて見ると、持ち越したぶんを自分で弾いてしまう。
    if (p["timemode"] = "queue")
        why := Format("実行する（順番待ち / {1} 以降）", FormatTime(dueTs, "HH:mm"))
    else
        why := Format("実行する（予定 {1} / {2} 分経過）", FormatTime(dueTs, "HH:mm"), late)
    return true
}

; ★終わった予定か★ 上限に到達・期間終了。
;   無効は含めない。自分で止めたものが消えると「あれ、消えた？」になる。
SchedIsDone(p) {
    if (!p["enabled"])
        return false
    if (p["maxruns"] > 0 && HistRunCount(p["key"]) >= p["maxruns"])
        return true
    if (p["end"] != "" && FormatTime(A_Now, "yyyyMMdd") > p["end"])
        return true
    return false
}

; ★順番待ちのものさし★ 小さいほど先に実行する。
;   「いつから実行できる状態だったか」＝ 待ち行列に入った時刻。
;   ★記録は増やさない★ 前回の実行日と設定から計算で出せる。
;
;   2026-10-07、ある顧客の番が一度も回ってこなかった。
;   以前は「一覧の上から最初の 1 人」だったため、00:00 の予定が 8 件あると
;   毎日 0 時にそこが埋まり、Order=16 の顧客まで届かなかった
;   （9/30 の開始日から 7 日間 0 回）。
;   待ちに入った順にすれば、先に待ち始めた顧客から必ず回る。
SchedWaitSince(p) {
    last := HistLastSlot(p["key"])
    ; 起点の日。未実行なら開始日（無ければ今日）、あとは前回からの間隔で決まる
    if (last = "")
        base := (Trim(p["start"]) != "") ? p["start"] : FormatTime(A_Now, "yyyyMMdd")
    else if (p["mode"] = "weekly")
        base := FormatTime(DateAdd(last, 1, "Days"), "yyyyMMdd")
    else
        base := FormatTime(DateAdd(last, p["interval"], "Days"), "yyyyMMdd")
    if (p["mode"] != "weekly")
        return base . p["time"] . "00"
    ; 曜日指定は、起点の日から数えて最初に当てはまる曜日
    day := base
    Loop 7 {
        if (DaysInclude(p["days"], WeekdayOf(day)))
            break
        day := FormatTime(DateAdd(day . "000000", 1, "Days"), "yyyyMMdd")
    }
    return day . p["time"] . "00"
}

; 次にいつ実行されるかを人が読める形で
NextDueText(p) {
    if (!p["enabled"])
        return "無効"
    if (!ValidateEntry(p, &vw))
        return "設定が不正: " vw
    runs := HistRunCount(p["key"])
    if (p["maxruns"] > 0 && runs >= p["maxruns"])
        return Format("完了（{1}/{2} 回）", runs, p["maxruns"])
    today := FormatTime(A_Now, "yyyyMMdd")
    if (p["end"] != "" && today > p["end"])
        return "期間終了"
    if (p["mode"] = "weekly") {
        names := ""
        for part in StrSplit(p["days"], ",") {
            n := DayNameToNum(part)
            if (n > 0)
                names .= (names = "" ? "" : "・") DayNumToName(n)
        }
        return Format("毎週 {1}  {2}", names, TimeLabel(p))
    }
    last := HistLastSlot(p["key"])
    if (last = "")
        return Format("次回 未実行（{1} 日おき  {2}）", p["interval"], TimeLabel(p))
    nextD := DateAdd(FormatTime(last, "yyyyMMdd") "000000", p["interval"], "Days")
    return Format("次回 {1}  {2}（{3} 日おき）", FormatTime(nextD, "M/d")
        , TimeLabel(p), p["interval"])
}

; 時刻の指定を人が読める形で
TimeLabel(p) {
    hhmm := FmtHHMM(p["time"])
    if (p["timemode"] != "queue")
        return hhmm
    ; 遅れの許容が「制限なし」の 0:00 だけが、時刻を問わない順番待ち
    return (p["time"] = "0000" && p["catchup"] <= 0) ? "順番待ち" : "順番待ち（" hhmm " 以降）"
}

; 1 回にかかる時間の見込み（最大）。順番待ちを始めてよいかの判断に使う
;   調査ありは 2026-10〜11 の実測（110 件）に合わせた。調査なしは実測が無いので従来のまま。
EstimateMaxMin(scan, count) {
    return scan ? (20 + count * 28) : (count * 30)
}

; ============================================================================
;  開始の遅れの上限と、翌日への持ち越し（3.10.39）
; ============================================================================
; ★順番待ちが朝や昼に始まるのを防ぐ★ 上限を過ぎた予定は始めず、回数も消費しない。
;   待ち始めの時刻は変わらないので、翌日の同じ時刻に、先に待っていた順で先頭に来る。
;   時刻の一律の区切りにしない（予定は夜とは限らず、使う時間帯は利用者ごとに違う）。
SchedLateList() => [3, 4, 6, 8, 10]
SchedWaitMaxH() => 72

SchedLateHours() {
    global CFG
    v := ToInt(IniGet(IniLoad(CFG), "Scheduler", "StartLateHours", "10"), 10)
    for n in SchedLateList() {
        if (n = v)
            return v
    }
    return 10
}

; ts 以前で最後の「予定の時刻」
SchedSlotStart(p, ts) {
    slot := SubStr(ts, 1, 8) . p["time"] . "00"
    return (slot > ts) ? DateAdd(slot, -1, "Days") : slot
}

; 実行した枠。日をまたいだ待機は直前の設定時刻に属する。
; 数日持ち越した場合は実際に開始した枠へ進め、古い分を連続実行しない。
SchedRecordSlot(p, ts) {
    dueTs := SchedWaitSince(p)
    slot := SchedSlotStart(p, ts)
    return (slot < dueTs) ? dueTs : slot
}

; ts に開始してよいか。遅れの許容を「制限なし」にした予定と時刻指定は、対象にしない。
SchedLateOk(p, ts) {
    if (p["timemode"] != "queue" || p["catchup"] <= 0)
        return true
    return (DateDiff(ts, SchedSlotStart(p, ts), "Minutes") <= SchedLateHours() * 60)
}

; ts 以降で、この予定を開始できる最初の時刻
SchedReadyAt(p, ts, dueTs) {
    if (dueTs > ts)
        return dueTs
    if (p["timemode"] != "queue") {
        if (p["catchup"] > 0 && DateDiff(ts, dueTs, "Minutes") > p["catchup"])
            return "99991231235959"                ; 時刻指定は見送りになる
        return ts
    }
    if (SchedLateOk(p, ts))
        return ts
    return DateAdd(SchedSlotStart(p, ts), 1, "Days")
}

; 待ち始めから長く経った予定か。運転を長く止めたあとに、古い予定を突然走らせない
SchedWaitTooOld(refTs, dueTs) {
    return (DateDiff(refTs, dueTs, "Hours") >= SchedWaitMaxH())
}

; 上限を過ぎた予定を記録し、新しく持ち越した方だけをセラピストへ知らせる
SchedCarryNote(plans) {
    global STATEINI
    names := "", n := 0
    for p in plans {
        dueTs := SchedWaitSince(p)
        slot := SchedSlotStart(p, A_Now)
        sec := "Carry." . p["key"]
        m := IniLoad(STATEINI)
        if (Trim(IniGet(m, sec, "Due", "")) = dueTs && Trim(IniGet(m, sec, "Slot", "")) = slot)
            continue
        IniSetMany(STATEINI, sec, Map("Due", dueTs, "Slot", slot))
        who := Trim(p["sei"] . " " . p["mei"])
        Log("WARN", Format("開始の上限（{1} 時間）を過ぎたため、翌日へ持ち越します: {2}", SchedLateHours(), p["key"]))
        names .= "　" . who . "（" . FmtHHMM(p["time"]) . " の予定）`n"
        n++
    }
    if (n > 0)
        NotifyAdmin("AutoMeta " . n . " 名を翌日へ持ち越しました"
            , "予定の時刻から " . SchedLateHours() . " 時間以内に順番が回らなかったため、開始しませんでした。`n"
            . "実行の回数は消費していません。翌日の同じ時刻になったら、先に待っていた順で実行します。`n"
            . "PC の使用中も、開始を待ちます。`n`n"
            . names . "`n"
            . "この PC 　" . A_ComputerName, false)
}

; 見込みの計算に使う、いまの運転の状態。予定の編集は別のプロセスなので live.txt から読む
SchedPlanState() {
    global G
    if (G.schedOn)
        return Map("on", true, "run", G.schedRunning, "key", G.schedCurrent, "job", G.startTS
            , "min", EstimateMaxMin(CB("RunInvestigation"), CI("TherapyCount"))
            , "since", G.schedStartTS, "done", G.schedDone, "who", Trim(G.wantSei . " " . G.wantMei))
    out := Map("on", false, "run", false, "key", "", "job", "", "min", 0, "since", "", "done", 0, "who", "")
    live := ReadLive()
    if (!live["fresh"] || live["SchedOn"] != "1")
        return out
    out["on"] := true
    out["run"] := (live.Has("SchedRun") && live["SchedRun"] = "1")
    for name, src in Map("key", "Key", "job", "JobStart", "since", "SchedStart") {
        if (live.Has(src))
            out[name] := live[src]
    }
    out["min"] := live.Has("JobMin") ? ToInt(live["JobMin"], 0) : 0
    out["done"] := live.Has("SchedDone") ? ToInt(live["SchedDone"], 0) : 0
    out["who"] := live["Patient"]
    return out
}

; 見込みに入れる予定か
SchedPlanEligible(p, horizon, st, &dueTs) {
    dueTs := ""
    key := p["key"]
    if (!p["enabled"] || !ValidateEntry(p, &vw) || SchedIsDone(p))
        return false
    if (st["run"] && st["key"] = key)
        return false
    dueTs := SchedWaitSince(p)
    last := HistLastSlot(key)
    if ((last != "" && last >= dueTs) || dueTs >= horizon)
        return false
    day := SubStr(dueTs, 1, 8)
    if ((p["start"] != "" && day < p["start"]) || (p["end"] != "" && day > p["end"]))
        return false
    if (dueTs >= A_Now || p["catchup"] <= 0)
        return true
    if (p["timemode"] != "queue")
        return (DateDiff(A_Now, dueTs, "Minutes") <= p["catchup"])
    refTs := (st["on"] && st["since"] != "") ? st["since"] : A_Now
    return !SchedWaitTooOld(refTs, dueTs)
}

; 次に開始を狙う「予定の時刻」と、そこから開始してよい最後の時刻
SchedFirstSlot(p, dueTs, nowTs) {
    if (dueTs >= nowTs || p["timemode"] != "queue" || p["catchup"] <= 0)
        return dueTs
    slot := SchedSlotStart(p, nowTs)
    return SchedLateOk(p, nowTs) ? slot : DateAdd(slot, 1, "Days")
}

SchedStartLimit(p, slot) {
    if (p["catchup"] <= 0)
        return "99991231235959"
    if (p["timemode"] = "queue")
        return DateAdd(slot, SchedLateHours(), "Hours")
    return DateAdd(slot, p["catchup"], "Minutes")
}

; ★これからの順番の見込み★ 予告の判断・通知・図で食い違わせないよう、見込みの計算はここだけ。
;   1 件ずつ順に実行するので、予定の時刻より前の時間は使えない。時間帯は問わない。
;   要素は Map：p／due／slot／limit／at（開始の見込み）／until（終了の見込み）／held（上限までに回らない）
SchedPlanAhead(horizon := "") {
    out := []
    if (horizon = "")
        horizon := DateAdd(A_Now, 24, "Hours")
    list := LoadSchedule(&err)
    if (err != "")
        return out
    st := SchedPlanState()
    nowTs := A_Now
    left := []
    for p in SchedLimitFilter(list) {
        if (!SchedPlanEligible(p, horizon, st, &dueTs))
            continue
        slot := SchedFirstSlot(p, dueTs, nowTs)
        left.Push(Map("p", p, "due", dueTs, "slot", slot, "limit", SchedStartLimit(p, slot)
            , "need", EstimateMaxMin(p["scan"], p["count"]), "at", "", "until", "", "held", false))
    }
    cursor := nowTs
    if (st["run"] && st["job"] != "") {
        jobEnd := DateAdd(st["job"], st["min"], "Minutes")
        if (jobEnd > cursor)
            cursor := jobEnd
    }
    maxJobs := CI("MaxJobsPerDay")
    restSec := CI("RestBetweenJobsSec")
    dayNow := FormatTime(nowTs, "yyyyMMdd")
    used := st["done"]
    heldList := []
    while (left.Length > 0) {
        pick := 0, pickAt := ""
        for idx, w in left {
            ready := SchedReadyAt(w["p"], cursor, w["due"])
            if (pick = 0 || ready < pickAt || (ready = pickAt && w["due"] < left[pick]["due"]))
                pick := idx, pickAt := ready
        }
        if (pickAt >= horizon)
            break
        if (pickAt > left[pick]["limit"]) {        ; 上限までに回らない。時間は使わない
            w := left.RemoveAt(pick)
            w["held"] := true
            heldList.Push(w)
            continue
        }
        day := SubStr(pickAt, 1, 8)
        if (day != dayNow)
            dayNow := day, used := 0
        if (maxJobs > 0 && used >= maxJobs) {      ; 本日の上限。日付が変わると数は戻る
            cursor := DateAdd(day . "000000", 1, "Days")
            continue
        }
        w := left.RemoveAt(pick)
        w["at"] := pickAt
        w["until"] := DateAdd(pickAt, w["need"], "Minutes")
        cursor := DateAdd(w["until"], restSec, "Seconds")
        used++
        out.Push(w)
    }
    for w in left {                                ; 見る範囲の外は、まだ判断しない
        if (w["limit"] < horizon) {
            w["held"] := true
            heldList.Push(w)
        }
    }
    for w in heldList
        out.Push(w)
    return out
}

; 回らない見込みの方を、間に合ううちにセラピストへ知らせる（1 回の予定につき 1 回）
;   送信しない時間帯の中の予定は予告の時刻に、それ以外は予定の 3 時間前に。
SchedCrowdNote(plan) {
    global STATEINI
    night := PreNoticeNight(&sTs, &eTs)
    names := "", n := 0
    for w in plan {
        if (!w["held"])
            continue
        slot := w["slot"]
        noteAt := (night && slot >= sTs && slot < eTs)
            ? DateAdd(sTs, -PreNoticeLeadMin(), "Minutes") : DateAdd(slot, -180, "Minutes")
        if (A_Now < noteAt)
            continue
        sec := "Crowd." . w["p"]["key"]
        m := IniLoad(STATEINI)
        if (Trim(IniGet(m, sec, "Due", "")) = w["due"] && Trim(IniGet(m, sec, "Slot", "")) = slot)
            continue
        IniSetMany(STATEINI, sec, Map("Due", w["due"], "Slot", slot))
        names .= "　" . Trim(w["p"]["sei"] . " " . w["p"]["mei"]) . "（" . FormatTime(slot, "M/d H:mm") . " の予定）`n"
        n++
    }
    if (n = 0)
        return
    Log("WARN", n . " 名は順番が回らない見込みです")
    NotifyAdmin("AutoMeta " . n . " 名は順番が回らない見込みです"
        , "予定の時刻から " . SchedLateHours() . " 時間以内に順番が回らない見込みです。`n"
        . "この方々には予告を送信しません。`n`n"
        . names . "`n"
        . "別の日時へ移す場合は「予定の編集」で変更してください。そのままの場合、前の方が早く終われば実行し、"
        . "間に合わなければ翌日へ持ち越します。`n"
        . "──────────`n"
        . "この PC 　" . A_ComputerName, false)
}

; ★PC の使用中は始めない★ 使う時間帯は利用者ごとに違うので、時刻ではなく操作の有無で見る。
SchedIdleList() => [0, 5, 10, 15, 30]

SchedIdleMin() {
    global CFG
    v := ToInt(IniGet(IniLoad(CFG), "Scheduler", "StartIdleMin", "10"), 10)
    for n in SchedIdleList() {
        if (n = v)
            return v
    }
    return 10
}

;   ★自分の操作を数えない★ A_TimeIdle には、本体の操作も入る。
;   ジョブの終了や運転の開始より前の入力は、使用中の証拠にしない
;   （「運転を開始」を押した直後に待たせない。ジョブのあとに 10 分空けない）。
SchedPcBusy(&idleSec) {
    global G
    mins := SchedIdleMin()
    idleSec := A_TimeIdle // 1000
    if (mins <= 0 || idleSec >= mins * 60)
        return false
    baseTs := G.schedStartTS
    if (G.lastJobEnd != "" && (baseTs = "" || G.lastJobEnd > baseTs))
        baseTs := G.lastJobEnd
    if (baseTs != "" && idleSec + 60 >= SecSince(baseTs))
        return false
    return true
}

SchedStartOptSave(section, hours) {
    global CFG
    IniSetMany(CFG, "Scheduler", Map(section, hours))
    Log("INFO", Format("予定の開始の設定を変更しました: {1}={2}", section, hours))
}

; ============================================================================
;  これからの見込みの図（3.10.40・F-10）
; ============================================================================
; 図の中の時刻を、横の位置へ
SchedChartX(ts, t0, X0, unit) {
    px := X0 + DateDiff(ts, t0, "Minutes") * unit // 60
    return Min(Max(px, X0), X0 + 24 * unit)
}

; 図の中の、送信しない時間帯
SchedQuietSpans(t0, tEnd) {
    out := []
    f := QuietStart(), t := QuietEnd()
    if (f = t)
        return out
    Loop 3 {
        day := FormatTime(DateAdd(t0, A_Index - 2, "Days"), "yyyyMMdd")
        s := day . f . "00", e := day . t . "00"
        if (e <= s)
            e := DateAdd(e, 1, "Days")
        if (e > t0 && s < tEnd)
            out.Push([s, e])
    }
    return out
}

; 1 行を塗る。spans は [左, 右, 色]。後ろのものが上に来る。重ねずに切り分ける（Windows の部品は重ねると崩れる）
SchedChartBar(dlg, y, X0, unit, spans) {
    pts := Map(X0, 1, X0 + 24 * unit, 1)
    for sp in spans {
        pts[sp[1]] := 1
        pts[sp[2]] := 1
    }
    prev := ""
    for px in pts {
        if (prev != "" && px > prev) {
            col := "F2F2F2"
            for sp in spans {
                if (sp[1] <= prev && sp[2] >= px)
                    col := sp[3]
            }
            dlg.Add("Text", Format("x{1} y{2} w{3} h18 Background{4}", prev, y, px - prev, col))
        }
        prev := px
    }
}

SchedChartOpen() {
    global APP_NAME
    t0 := SubStr(A_Now, 1, 10) . "0000"
    tEnd := DateAdd(t0, 24, "Hours")
    plan := SchedPlanAhead(tEnd)
    st := SchedPlanState()
    X0 := 176, unit := 26
    colQuiet := "D9D9D9", colWait := "A6A6A6", colRun := "1D9E75", colNow := "378ADD", colHeld := "E24B4A"
    quietPx := []
    for sp in SchedQuietSpans(t0, tEnd)
        quietPx.Push([SchedChartX(sp[1], t0, X0, unit), SchedChartX(sp[2], t0, X0, unit), colQuiet])
    okN := 0, heldN := 0
    for w in plan {
        if (w["held"])
            heldN++
        else
            okN++
    }
    dlg := Gui("+AlwaysOnTop", APP_NAME . " - これからの見込み" . VerTag())
    dlg.MarginX := 16, dlg.MarginY := 12
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "xm y12 w940", "これからの見込み（今から 24 時間）")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "xm y38 w940 " . (heldN > 0 ? "cC00000" : "cGray")
        , Format("実行の見込み {1} 件　／　上限までに順番が回らない見込み {2} 件　　（保存済みの予定から計算。実際の時刻は前後します）", okN, heldN))
    y := 66
    Loop 9 {
        hourOff := (A_Index - 1) * 3
        dlg.Add("Text", Format("x{1} y{2} w48", X0 + hourOff * unit, y), FormatTime(DateAdd(t0, hourOff, "Hours"), "H:mm"))
    }
    y += 20
    dlg.Add("Text", Format("xm y{1} w154", y), "送信しない時間帯")
    SchedChartBar(dlg, y, X0, unit, quietPx)
    y += 26
    rowsLeft := 16
    if (st["run"] && st["job"] != "") {
        jobEnd := DateAdd(st["job"], st["min"], "Minutes")
        spans := quietPx.Clone()
        spans.Push([SchedChartX(st["job"], t0, X0, unit), SchedChartX(jobEnd, t0, X0, unit), colNow])
        dlg.Add("Text", Format("xm y{1} w154", y), st["who"])
        SchedChartBar(dlg, y, X0, unit, spans)
        dlg.Add("Text", Format("x{1} y{2} w150", X0 + 24 * unit + 8, y), "実行中（〜" . FormatTime(jobEnd, "H:mm") . "）")
        y += 24
        rowsLeft--
    }
    shown := 0
    for w in plan {
        if (shown >= rowsLeft)
            break
        shown++
        spans := quietPx.Clone()
        if (w["held"]) {
            limitTs := (w["limit"] < tEnd) ? w["limit"] : tEnd
            spans.Push([SchedChartX(w["slot"], t0, X0, unit), SchedChartX(limitTs, t0, X0, unit), colWait])
            spans.Push([SchedChartX(limitTs, t0, X0, unit), SchedChartX(DateAdd(limitTs, 120, "Minutes"), t0, X0, unit), colHeld])
            memo := "翌日へ持ち越し"
        } else {
            if (w["at"] > w["slot"])
                spans.Push([SchedChartX(w["slot"], t0, X0, unit), SchedChartX(w["at"], t0, X0, unit), colWait])
            spans.Push([SchedChartX(w["at"], t0, X0, unit), SchedChartX(w["until"], t0, X0, unit), colRun])
            memo := FormatTime(w["at"], "H:mm") . "〜" . FormatTime(w["until"], "H:mm")
        }
        dlg.Add("Text", Format("xm y{1} w154", y), Trim(w["p"]["sei"] . " " . w["p"]["mei"]))
        SchedChartBar(dlg, y, X0, unit, spans)
        dlg.Add("Text", Format("x{1} y{2} w150{3}", X0 + 24 * unit + 8, y, w["held"] ? " cC00000" : ""), memo)
        y += 24
    }
    if (plan.Length = 0)
        dlg.Add("Text", Format("xm y{1} w940 cGray", y), "24 時間以内に実行する予定はありません。"), y += 24
    if (plan.Length > shown)
        dlg.Add("Text", Format("xm y{1} w940 cGray", y), "ほか " . (plan.Length - shown) . " 件"), y += 24
    y += 6
    dlg.Add("Text", Format("x{1} y{2} w14 h12 Background{3}", 16, y + 3, colRun))
    dlg.Add("Text", "x+4 yp-3 w110", "実行の見込み")
    dlg.Add("Text", Format("x+10 yp+3 w14 h12 Background{1}", colWait))
    dlg.Add("Text", "x+4 yp-3 w90", "順番待ち")
    dlg.Add("Text", Format("x+10 yp+3 w14 h12 Background{1}", colHeld))
    dlg.Add("Text", "x+4 yp-3 w130", "翌日へ持ち越し")
    dlg.Add("Text", Format("x+10 yp+3 w14 h12 Background{1}", colNow))
    dlg.Add("Text", "x+4 yp-3 w90", "実行中")
    y += 30
    dlg.SetFont("s10", "Meiryo UI")
    bAgain := dlg.Add("Button", Format("xm y{1} w220 h34", y), "最新の状態に更新")
    bQuit := dlg.Add("Button", "x+10 yp w220 h34 Default", "閉じる")
    bAgain.OnEvent("Click", (*) => (dlg.Destroy(), SchedChartOpen()))
    bQuit.OnEvent("Click", (*) => dlg.Destroy())
    dlg.OnEvent("Close", (*) => dlg.Destroy())
    dlg.Show()
}

; 今日これから来る「時刻指定」の予定まで、あと何分か。無ければ -1
MinutesToNextTimed(list) {
    now   := A_Now
    today := FormatTime(now, "yyyyMMdd")
    best  := -1
    for p in list {
        if (!p["enabled"] || p["timemode"] = "queue")
            continue
        if (!ValidateEntry(p, &vw))
            continue
        if (p["start"] != "" && today < p["start"])
            continue
        if (p["end"] != "" && today > p["end"])
            continue
        if (p["maxruns"] > 0 && HistRunCount(p["key"]) >= p["maxruns"])
            continue
        if (p["mode"] = "weekly") {
            if (!DaysInclude(p["days"], WeekdayOf(today)))
                continue
        } else {
            last := HistLastSlot(p["key"])
            if (last != "") {
                elapsed := DateDiff(today "000000", FormatTime(last, "yyyyMMdd") "000000", "Days")
                if (elapsed < p["interval"])
                    continue
            }
        }
        dueTs := today . p["time"] . "00"
        if (dueTs <= now)
            continue                                ; もう過ぎている分は別途 due 判定される
        mins := DateDiff(dueTs, now, "Minutes")
        if (best < 0 || mins < best)
            best := mins
    }
    return best
}

;==============================================================================
;  スケジューラ本体
;==============================================================================
; ★「本日」の数は、日付が変わったら 0 に戻す★（3.10.4）
;   2026-10-10、数えるのは運転を始めたときの 0 からで、日付では戻していなかった。
;   10/8 19:11 に運転を始めてから 8 件に達し、翌日になっても「本日の上限」のまま、
;   13 時間 1 件も実行されなかった（00:00 の予定 2 件と、22:00 の予定 1 件が待たされた）。
SchedDayRoll() {
    global G
    today := FormatTime(A_Now, "yyyyMMdd")
    if (G.schedDay = today)
        return
    if (G.schedDay != "")
        Log("INFO", Format("日付が変わりました。本日の数を戻します（前日：完了 {1} / 要確認 {2} / 失敗 {3} / 見送り {4}）"
            , G.schedDone, G.schedCheck, G.schedFailed, G.schedSkipped))
    G.schedDay     := today
    G.schedDone    := 0
    G.schedCheck   := 0
    G.schedFailed  := 0
    G.schedSkipped := 0
}

StartScheduler() {
    global G, STATEINI
    G.schedOn      := true
    G.schedRunning := false
    G.schedCurrent := ""
    G.schedDone    := 0
    G.schedFailed  := 0
    G.schedSkipped := 0
    G.schedCheck   := 0
    G.schedDay     := FormatTime(A_Now, "yyyyMMdd")
    G.appLaunchTS  := ""
    G.appWarnTS    := ""
    G.schedFailStreak := 0
    G.schedStartTS := A_Now
    Log("INFO", "=== スケジュール運転を開始しました ===")
    SetupTray()
    ShowPanel()
    WriteLive()
    WriteSchedStatus()
    SetTimer(WatchTherapyRequest, 1000)            ; 自動セラピーの依頼を 1 秒ごとに見る
    SetTimer(SchedTick, -1000)
    ; ★「運転中」の印を残す★
    ;   これが残ったまま次に起動したら、前回は【落ちた】ということ。
    ;   正常に終わるときは OnExit で消すので、印は電源断や強制終了でだけ残る。
    IniSet(STATEINI, "Scheduler", "Running", "1")
    IniSet(STATEINI, "Scheduler", "StartedAt", FmtTS(A_Now))
    OnExit(SchedExitMark)
}

; 正常に終わったときに「運転中」の印を消す（電源断では呼ばれない＝印が残る）
SchedExitMark(*) {
    global STATEINI
    IniSet(STATEINI, "Scheduler", "Running", "0")
    IniSet(STATEINI, "Scheduler", "StoppedAt", FmtTS(A_Now))
}

; ★対象ソフトが生きているか、毎回見る★
;   2026-09-24 指摘。落ちていても、次の予定の時刻まで誰も気づかなかった。
;   予定が無い時間帯こそ、直すのに使える時間。見つけ次第、知らせて起こす。
WatchTargetAlive() {
    global G, APP_NAME
    exe := CS("ExeName")
    if (exe = "")
        return
    if (G.pid := FindPidByExe(exe)) {
        if (!G.appAlive) {
            Log("INFO", "対象ソフトが戻りました: " exe)
            ; 自分で起こしたときは、起こした時刻を残す。人が起こしたときは、いまを起点にする
            if (G.appUpTS = "" || SecSince(G.appUpTS) > 600)
                G.appUpTS := A_Now
        }
        G.appAlive  := true
        G.appDownTS := ""
        return
    }
    if (G.appAlive) {                          ; 落ちた瞬間
        G.appAlive  := false
        G.appDownTS := A_Now
        Log("WARN", "対象ソフト「" exe "」が起動していません。予定は始められません")
        try TrayTip("対象ソフトが起動していません`n" exe, APP_NAME)
        NotifyAdmin("AutoMeta 対象ソフトが起動していません"
            , "対象ソフト「" . exe . "」が見つかりません。`n"
            . "予定の時刻が来ても始められません。`n`n"
            . "　この PC 　" . A_ComputerName . "`n"
            . "　気づいた時刻　" . FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss") . "`n`n"
            . "10 分おきに自動で再起動します。`n"
            . "※ AutoMeta が自動でお送りしています。")
    }
    ; ★起こし直すのは 10 分に 1 回まで★
    ;   すぐ落ちるソフトを毎分起こすと、プロセスが積み上がる。
    if (G.appTryTS != "" && SecSince(G.appTryTS) < 600)
        return
    G.appTryTS := A_Now
    why := ""
    EnsureTargetRunning(&why)                  ; 起動を試みる（結果はログへ）
    if (why != "")
        Log("INFO", "対象ソフトの復帰: " why)
}

; ★再起動のあとは、画面が整うまで次の予定を始めない★（2026-10-08 指摘）
;   プロセスが現れた時点では、画面はまだ読み込み中。2026-10-08、再起動の 40 秒後に
;   次の予定が始まり、調査タイプの一覧が開かず「設定できませんでした」になった。
;   同じ形が 9/25・9/26・9/27・9/29・10/1 にも出ていた（再起動の直後の予定だけ）。
;   待っているあいだも、運転は止めない（パネルも「止める」も効く）。
AppSettling() {
    global G
    ; ★人が起こしたソフトも、起動直後なら待つ★（2026-10-11）
    ;   自分で起こしたときだけ起点を持っていたので、人が起こした直後の予定は待たずに始まっていた。
    ;   プロセスの作成時刻から起動後の秒数を測り、整うまでの残りを待つ。2 分に 1 回だけ測る。
    static lastAgeTS := ""
    if (G.appUpTS = "" && G.pid && (lastAgeTS = "" || SecSince(lastAgeTS) >= 120)) {
        lastAgeTS := A_Now
        age := ProcessAgeSec(G.pid)
        if (age >= 0 && age < CI("AppSettleSec")) {
            G.appUpTS := DateAdd(A_Now, -age, "Seconds")
            Log("INFO", Format("対象ソフトは起動して {1} 秒です。画面が整うまで待ちます", age))
        }
    }
    if (G.appUpTS = "")
        return false
    left := CI("AppSettleSec") - SecSince(G.appUpTS)
    if (left <= 0) {
        G.appUpTS := ""
        G.appSettleLogTS := ""
        return false
    }
    if (G.appSettleLogTS = "" || SecSince(G.appSettleLogTS) >= 60) {
        G.appSettleLogTS := A_Now
        Log("INFO", Format("対象ソフトが整うまで、次の予定を待ちます（あと {1} 秒）", left))
    }
    WriteSchedStatus()
    SetTimer(SchedTick, -10000)
    return true
}

SchedTick() {
    global G, APP_NAME
    static lastCopy := ""
    LogFlush()                                     ; 書き足せていない行があれば、ここで書く
    ; 運転中の最新のログを、10 分に 1 回、従来の場所（同期される側）へ写す（3.10.26）。
    ;   3.10.24 から、書き込み先を PC の中に移したため、写さないと Drive に最大 1 時間出ない。
    if (lastCopy = "" || SecSince(lastCopy) >= 600) {
        lastCopy := A_Now
        LogCopyOut()
    }
    if (!G.schedOn)
        return
    try PreNoticeTick()                            ; ジョブの最中も見る（1 件に 1 時間以上かかるため）
    if (G.schedRunning) {                          ; ジョブ実行中は操作しない（G6）
        WriteLive()
        ; ★送信は送信係にまかせる★
        ;   本体が送ると、その数秒〜数十秒だけ画面の見張りが止まる。
        ;   送信係が立っていないときだけ、安全な瞬間に自分で送る（保険）。
        ;   ★送信係が止まっていたら、ジョブの最中でも引き継がせる★（3.10.27）別のプロセスなので、画面の操作には影響しない。
        ;   印が無い／5 分以上古いときだけ（数通を順に送っている最中に、二重に起こさない）。
        if (NotifyOn() && NotifyReadyCount() > 0 && !NotifierAlive()
            && (NotifierStaleSec() < 0 || NotifierStaleSec() >= 300)) {
            NotifierKillStale()
            NotifierEnsure()
        }
        if (!NotifierAlive() && NotifySafeNow())
            NotifyFlush()
        SetTimer(SchedTick, -5000)
        return
    }
    if (CheckStopFiles())
        return
    WatchTargetAlive()                         ; 落ちていないか、毎回見る
    if (NotifyOn() && NotifyReadyCount() > 0) {
        NotifierKillStale()                    ; 止まっている送信係がいれば、終了させる
        NotifierEnsure()                       ; 送信係にまかせる
        if (!NotifierAlive())
            NotifyFlush()                      ; 立てられなければ自分で送る
    }
    RegPollAll()                               ; 登録の受け取りを見に行く
    ExpiryNoticeMaybe()                        ; 事業者の期限の予告を、自分宛に送る
    WriteLive()
    ; ★手動の自動セラピーの依頼が最優先★
    ;   目の前にお客様がいる。予定より先に通す。
    if (TakeTherapyRequest())
        return
    if (AppSettling())                             ; 再起動の直後は、画面が整うまで待つ
        return
    SchedDayRoll()                                 ; 日付が変わったら「本日」の数え直し
    ; 1 日あたりの上限
    if (CI("MaxJobsPerDay") > 0 && G.schedDone >= CI("MaxJobsPerDay")) {
        ; ★毎分は書かない★ 2026-10-10、同じ行が 13 時間で 722 回並び、本当の原因が埋もれた
        static limitLogTS := ""
        if (limitLogTS = "" || SecSince(limitLogTS) >= 1800) {
            limitLogTS := A_Now
            Log("INFO", Format("本日の実行上限 {1} 件に達しました（日付が変わると再開します。以後 30 分に 1 回記録）"
                , CI("MaxJobsPerDay")))
        }
        SetTimer(SchedTick, -CI("SchedulerTickSec") * 1000)
        return
    }
    list := LoadSchedule(&err)                     ; 毎回読み直す（編集が即反映される）
    if (err != "") {
        Log("WARN", err)
        SetTimer(SchedTick, -CI("SchedulerTickSec") * 1000)
        return
    }
    ; ★一般は顧客 N 人まで★ 超えた顧客は、並び順の後ろから外す（運転は止めない）
    list := SchedLimitFilter(list)
    ; ★中断したジョブの続きが、ふつうの予定より先★
    ;   途中で止まった方を、他の方より後回しにしない。
    resume := ResumePick(list)
    pickList := IsObject(resume) ? [] : list
    ; --- 1 件だけ拾う --------------------------------------------------------
    ;   ★時刻を指定した予定が先★ 順番待ちは、その空き時間に流す。
    best := 0, bestTs := "", waiting := 0, carried := [], skipped := ""
    for p in pickList {
        if (!DueNow(p, &why)) {
            if (InStr(why, "見送り")) {
                Log("WARN", Format("{1}: {2}", p["key"], why))
                G.schedSkipped++
                HistRecord(p["key"], false, SchedRecordSlot(p, A_Now))        ; 同じ予定を何度も見送らないよう印を付ける
                skipped .= "　" . Trim(p["sei"] . " " . p["mei"]) . "（" . why . "）`n"
            } else if (InStr(why, "持ち越し")) {
                carried.Push(p)
            }
            continue
        }
        if (p["timemode"] = "queue") {
            ; ★先に待ち始めた顧客から★ 同じなら一覧の上の方（先に見た方を残す）
            if (!IsObject(waiting) || SchedWaitSince(p) < SchedWaitSince(waiting))
                waiting := p
            continue
        }
        ts := FormatTime(A_Now, "yyyyMMdd") . p["time"] . "00"
        if (bestTs = "" || ts < bestTs) {
            best := p, bestTs := ts
        }
    }
    if (carried.Length > 0)
        SchedCarryNote(carried)
    if (skipped != "")
        NotifyAdmin("AutoMeta 予定を見送りました"
            , "次の予定は実行していません。次回は、設定の間隔のあとです。`n"
            . "早く実施する場合は、手動で実行してください。`n`n"
            . skipped . "`n"
            . "この PC 　" . A_ComputerName, false)
    ; 時刻指定が 1 件もなければ、順番待ちを始める。
    ; ただし★これから来る時刻指定の予定を遅らせないこと★を確かめる。
    if (!IsObject(best) && IsObject(waiting)) {
        ; ★なぜこの顧客を選んだかを残す★
        ;   以前は何も書いていなかったため、「番が回ってこない」理由が
        ;   ログから分からなかった（2026-10-07）。1 件に 1 時間以上かかるので、
        ;   毎回書いても量は増えない。
        qTxt := "", qN := 0
        for p2 in list {
            if (p2["timemode"] != "queue")
                continue
            if (!DueNow(p2, &w2))
                continue
            qN++
            if (qN <= 4) {
                qTxt .= (qTxt = "" ? "" : "／") . Trim(p2["sei"] . " " . p2["mei"])
                      . "（" . FormatTime(SchedWaitSince(p2), "M/d HH:mm") . " から）"
            }
        }
        if (qN > 4)
            qTxt .= " ほか " . (qN - 4) . " 件"
        Log("INFO", Format("順番待ち {1} 件: {2} → 「{3} {4}」を選びました（待ちに入った順）"
            , qN, qTxt, waiting["sei"], waiting["mei"]))
        need := EstimateMaxMin(waiting["scan"], waiting["count"])
        gap  := MinutesToNextTimed(list)
        if (gap >= 0 && gap < need) {
            Log("INFO", Format("順番待ちの「{1} {2}」は待機します"
                . "（あと {3} 分で時刻指定の予定 / この顧客の所要見込み 最大 {4} 分）"
                , waiting["sei"], waiting["mei"], gap, need))
        } else {
            best := waiting
        }
    }
    if (IsObject(resume))
        best := resume
    if (!IsObject(best)) {
        WriteSchedStatus()
        SetTimer(SchedTick, -CI("SchedulerTickSec") * 1000)
        return
    }
    ; ★PC の使用中は始めない★ 時間帯は問わない（3.10.40）。上限を過ぎたら翌日へ持ち越す
    static busyLogTS := ""
    G.pcBusy := SchedPcBusy(&idleSec)
    if (G.pcBusy) {
        if (busyLogTS = "" || SecSince(busyLogTS) >= 1800) {
            busyLogTS := A_Now
            Log("INFO", Format("PC の使用中のため、開始を待ちます（最後の操作から {1} 秒／基準 {2} 分。以後 30 分に 1 回記録）"
                , idleSec, SchedIdleMin()))
        }
        WriteSchedStatus()
        SetTimer(SchedTick, -CI("SchedulerTickSec") * 1000)
        return
    }
    ; ★対象ソフトがいないなら、予定を始めない★
    ;   始めれば必ず失敗し、失敗だけが積み上がる。落ちているなら起動して待つ。
    whyApp := ""
    if (!EnsureTargetRunning(&whyApp)) {
        if (G.appWarnTS = "" || SecSince(G.appWarnTS) >= 600) {
            Log(InStr(whyApp, "待ち") || InStr(whyApp, "起動しました") ? "INFO" : "WARN"
              , "予定はまだ始めません: " whyApp)
            try TrayTip("予定を開始できません`n" whyApp, APP_NAME)
            G.appWarnTS := A_Now
        }
        WriteSchedStatus()
        SetTimer(SchedTick, -CI("SchedulerTickSec") * 1000)
        return
    }
    G.appWarnTS := ""
    RunScheduled(best)
}

; ============================================================================
;  中断した予定の続き（2026-10-08 指示：復帰後に続きを実行できるように）
; ============================================================================
; 対象ソフトが途中で消えたとき、あとで続きをやれるように「札」を残す。
;   ★基準は「終わった回数」★ 始めた回数（G.cycle）ではない。
;     途中だった回は、最初からやり直す（中途半端な回を数えない）。
;   ★調査の途中で止まったなら、調査からやり直す★ 何も届けていないので。
;   札は state.ini の [Resume] に 1 件だけ。続きを始めるたびに Tries を増やし、
;   ResumeMaxTries を超えるか、ResumeMaxHours を過ぎたら、人に返す（確認待ち）。
ResumeLostReason(reason) => InStr(reason, "対象ソフトのウィンドウが見えなくなりました") ? true : false

ResumeMaybe(code, reason) {
    global G, STATEINI
    G.resumeNote := ""
    if (code = 0 || code = 4 || G.manualJob || G.schedCurrent = "")
        return
    if (!ResumeLostReason(reason))
        return                                     ; ほかの理由の失敗は、続きをやらない
    total   := CI("TherapyCount")
    done    := G.durations.Length                  ; 終わった回数
    scanOn  := CB("RunInvestigation")
    needScan := scanOn && !(G.scanSec > 0)
    remain  := needScan ? total : (total - done)
    if (!needScan && remain < 1)
        return                                     ; やり残しが無い
    tries := 0
    if (G.resumeRun)                               ; 続きの最中にまた消えた
        tries := ToInt(IniGet(IniLoad(STATEINI), "Resume", "Tries", "0"), 0)
    IniSetMany(STATEINI, "Resume", Map("Key", G.schedCurrent
        , "Sei", G.wantSei, "Mei", G.wantMei, "Remain", remain, "Total", total
        , "Due", G.schedDueTs, "Slot", G.schedSlotTs
        , "NeedScan", needScan ? 1 : 0, "At", FormatTime(A_Now, "yyyyMMddHHmmss"), "Tries", tries))
    what := needScan ? "調査からやり直します" : "セラピー残り " . remain . " 回を実行します"
    G.resumeNote := "★対象ソフトが復帰して画面が整ったら、続きを自動で実行します（" . what . "）。"
    Log("INFO", Format("中断した予定の続きを予約しました: {1}／{2}／試行 {3} 回目まで済み"
        , G.schedCurrent, what, tries))
}

ResumeClear() {
    global STATEINI
    IniSetSection(STATEINI, "Resume", Map())
}

; 続きを人に返す（確認待ちに残し、管理者へ知らせる）
ResumeGiveUp(sei, mei, why) {
    global PENDFILE
    line := FormatTime(A_Now, "yyyyMMddHHmmss") . "|0|" . sei . "|" . mei
          . "|★中断した予定の続きを実行できませんでした（" . why . "）　ソフト側の履歴で、どこまで行われたか確認してください"
    try FileAppend(CRLF(line . "`n"), PENDFILE, "UTF-8")
    Log("WARN", "中断した予定の続きを見送りました: " . Trim(sei . " " . mei) . "（" . why . "）")
    NotifyAdmin("AutoMeta 中断した予定の続きを見送りました"
        , "　顧客　" . Trim(sei . " " . mei) . "`n　理由　" . why . "`n`n"
        . "ソフト側の履歴で、どこまで行われたか確認してください。`n"
        . "※ AutoMeta が自動でお送りしています。")
    ResumeClear()
}

; 続きをやる予定を返す。無ければ ""。
ResumePick(list) {
    global STATEINI
    m := IniLoad(STATEINI)
    key := Trim(IniGet(m, "Resume", "Key", ""))
    if (key = "")
        return ""
    sei := Trim(IniGet(m, "Resume", "Sei", "")), mei := Trim(IniGet(m, "Resume", "Mei", ""))
    at  := Trim(IniGet(m, "Resume", "At", ""))
    tries := ToInt(IniGet(m, "Resume", "Tries", "0"), 0)
    if (at = "" || DateDiff(A_Now, at, "Hours") >= CI("ResumeMaxHours")) {
        ResumeGiveUp(sei, mei, "中断から " . CI("ResumeMaxHours") . " 時間を過ぎました")
        return ""
    }
    if (tries >= CI("ResumeMaxTries")) {
        ResumeGiveUp(sei, mei, "続きを " . tries . " 回試しましたが、完了しませんでした")
        return ""
    }
    for p in list {
        if (p["key"] != key)
            continue
        if (!p["enabled"]) {
            ResumeGiveUp(sei, mei, "予定が無効になっています")
            return ""
        }
        p2 := Map()
        for k, v in p
            p2[k] := v
        p2["scan"]   := (IniGet(m, "Resume", "NeedScan", "0") = "1")
        p2["count"]  := ToInt(IniGet(m, "Resume", "Remain", "0"), 0)
        p2["resume"] := true
        ; 旧版の中断記録には枠が無い。履歴の基準を維持して再開する。
        p2["resumeDue"] := IniGet(m, "Resume", "Due", HistLastSlot(key))
        p2["resumeSlot"] := IniGet(m, "Resume", "Slot", HistLastSlot(key))
        return p2
    }
    ResumeGiveUp(sei, mei, "予定が見つかりません")
    return ""
}

RunScheduled(p) {
    global G, C, APP_NAME, STATEINI
    G.schedRunning := true
    ; ★続きの実行か★ 続きなら、試した回数を増やす（無限に繰り返さないため）
    G.resumeRun := (p.Has("resume") && p["resume"]) ? true : false
    if (G.resumeRun) {
        tr := ToInt(IniGet(IniLoad(STATEINI), "Resume", "Tries", "0"), 0) + 1
        IniSet(STATEINI, "Resume", "Tries", tr)
        Log("INFO", Format("--- 中断した予定の続きを実行します（{1} 回目）---", tr))
    }
    G.manualJob    := false
    G.skipSelect   := false                        ; 予定のジョブは必ず検索・選択から
    G.useOpenCard  := false                        ; 開いているカードを流用しない
    G.schedCurrent := p["key"]
    G.schedDueTs   := G.resumeRun ? p["resumeDue"] : SchedWaitSince(p)
    G.schedSlotTs  := G.resumeRun ? p["resumeSlot"] : SchedRecordSlot(p, A_Now)
    Log("INFO", "実行する予定枠: " . G.schedSlotTs . "／待ち始め: " . G.schedDueTs)
    G.preDone      := false
    C["TherapyCount"]     := p["count"]
    C["RunInvestigation"] := p["scan"] ? "1" : "0"
    C["ScanTypeName"]     := p.Has("scantype") ? p["scantype"] : ""
    C["ManualName"]       := p.Has("manual")   ? p["manual"]   : ""
    G.wantSei := p["sei"], G.wantMei := p["mei"]
    G.wantMid := p.Has("middle") ? p["middle"] : ""
    Log("INFO", Format("--- スケジュール実行: {1}「{2} {3}」 調査={4} セラピー={5}回 ---"
        , p["key"], p["sei"], p["mei"], p["scan"] ? "する" : "しない", p["count"]))
    try TrayTip("開始: " p["sei"] " " p["mei"], APP_NAME)
    WriteLive()
    StartJob()
}

; ジョブが終わったときにスケジューラへ戻る（Finish から呼ばれる）
SchedJobFinished(code, reason, summary := "") {
    global G, APP_NAME
    ok  := (code = 0)
    chk := (code = 4)                              ; 要確認（調査の項目が少なすぎた）
    ; --- 手動の自動セラピーは、予定の実績とは別に扱う -------------------------
    if (G.manualJob) {
        Log("INFO", (ok ? "手動の自動セラピー 完了" : "手動の自動セラピー 失敗: ")
            . (ok ? "" : StrReplace(reason, "`n", " / ")))
        try TrayTip((ok ? "自動セラピー 完了" : "自動セラピー 停止") "`n" G.wantSei " " G.wantMei
            , APP_NAME)
        G.manualJob    := false
        G.skipSelect   := false
        G.useOpenCard  := false
        G.schedRunning := false
        G.schedCurrent := ""
        G.state        := "idle"                   ; 終わったら「何もしていない」に戻す
        G.wantSei := "", G.wantMei := ""
        WriteLive()
        WriteSchedStatus()
        SetTimer(SchedTick, -CI("RestBetweenJobsSec") * 1000)
        ; ★手動のときは結果を画面で見せる（既存の自動セラピーツールと同じ）★
        ;   予定のジョブでは出さない。無人運転でダイアログを溜めないため。
        ;   先に待機へ戻してから出すので、この間もスケジュール運転は動き続ける。
        if (summary != "") {
            MsgBox(summary, APP_NAME " - 自動セラピー " (ok ? "完了" : "停止")
                , ok ? "Iconi 4096" : "Icon! 4096")
        }
        return                                     ; 連続失敗の数にも入れない
    }
    ; ★終わったことを見落とさないための控え★
    ;   この方へ結果を報告する必要がある。トレイ通知は消えてしまうので、
    ;   ✓ を付けて消去するまで運転パネルに出し続ける。
    PendingAdd(ok)
    try SoundPlay(ok ? "*64" : "*48")              ; 席を外していても気づけるように
    key := G.schedCurrent
    if (key != "")
        HistRecord(key, ok, G.schedSlotTs)
    ; ★続きを実行した結果★ 終わったか、別の理由で失敗したなら、札はもう要らない。
    ;   また対象ソフトが消えたときは、ResumeMaybe が札を書き直している（G.resumeNote が入っている）。
    if (G.resumeRun && (ok || G.resumeNote = "")) {
        ResumeClear()
        Log("INFO", ok ? "中断した予定の続きを実行して、完了しました" : "中断した予定の続きは、失敗で終わりました（札を外します）")
    }
    if (ok) {
        G.schedDone++
        G.schedFailStreak := 0
        Log("INFO", Format("スケジュール実行 完了: {1}", key))
    } else if (chk) {
        ; ★要確認は「失敗」ではない★
        ;   手動で止めた／すでに調査済み、のことが多い（2026-09-17 利用者）。
        ;   連続失敗の数にも入れない。入れると試験中に運転が止まってしまう。
        G.schedCheck++
        G.schedFailStreak := 0
        Log("WARN", Format("スケジュール実行 要確認: {1} / {2}", key
            , StrReplace(reason, "`n", " / ")))
        try TrayTip("要確認: " G.wantSei " " G.wantMei "`n" SubStr(reason, 1, 80), APP_NAME)
    } else {
        G.schedFailed++
        G.schedFailStreak++
        Log("ERROR", Format("スケジュール実行 失敗: {1} / {2}", key
            , StrReplace(reason, "`n", " / ")))
        try TrayTip("失敗: " G.wantSei " " G.wantMei "`n" SubStr(reason, 1, 80), APP_NAME)
    }
    G.schedRunning := false
    G.schedCurrent := ""
    G.state        := "idle"                       ; 終わったら「何もしていない」に戻す
    G.wantSei := "", G.wantMei := ""        ; 待機中に前の顧客を出したままにしない
    ; 連続して失敗するなら、ソフト側かPC側の問題。全体を止める
    if (G.schedFailStreak >= CI("MaxConsecutiveFailures")) {
        StopScheduler(Format("{1} 件続けて失敗しました。`n`n最後の理由:`n{2}"
            , G.schedFailStreak, reason))
        return
    }
    WriteLive()
    WriteSchedStatus()
    SetTimer(SchedTick, -CI("RestBetweenJobsSec") * 1000)
}

StopScheduler(reason) {
    global G, APP_NAME, LIVEFILE, REQFILE
    G.schedOn := false
    try FileDelete(LIVEFILE)                       ; もう受け付けない
    try FileDelete(REQFILE)
    ClosePanel()
    SetTimer(SchedTick, 0)
    SetTimer(WatchTherapyRequest, 0)
    SetTimer(Tick, 0)
    o := Format("=== スケジュール運転を終了しました ===`n`n"
        . "  実行     : {1} 件`n  要確認   : {2} 件`n  失敗     : {3} 件`n  見送り   : {4} 件`n"
        . "  稼働時間 : {5}`n`n  理由     : {6}`n"
        , G.schedDone, G.schedCheck, G.schedFailed, G.schedSkipped
        , FmtDur(SecSince(G.schedStartTS)), reason)
    Log("INFO", StrReplace(o, "`n", " / "))
    try FileAppend(CRLF("`n" o "`n"), G.logFile, "UTF-8")
    WriteSchedStatus()
    MsgBox(o, APP_NAME " - スケジュール運転", "Iconi 4096")
    ; ★止めてもソフトは閉じない★
    ;   2026-09-22 指摘。止めた直後に予定を直したいことが多いのに、
    ;   毎回ソフトごと消えて、開き直す手間がかかっていた。
    ;   運転の状態を引きずらないよう、メニューを起こし直してから終わる。
    OpenMenuWindow()
    ExitApp(0)
}

WriteSchedStatus() {
    global G, STATUSTX, APP_VER
    o := "AutoMeta " APP_VER "  スケジュール運転`n"
    o .= FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss") "`n`n"
    if (G.schedRunning) {
        o .= "■ 実行中: " G.wantSei " " G.wantMei "（" G.schedCurrent "）`n"
        o .= "   状態  : " G.state "`n"
        o .= "   セラピー: " G.cycle " / " CI("TherapyCount") " 回`n"
        if (G.state = "therapy_run")
            o .= "   経過  : " FmtDur(SecSince(G.cycleStartTS)) "`n"
    } else {
        o .= "■ 待機中`n"
    }
    o .= "`n■ 予定`n"
    list := LoadSchedule(&err)
    if (err != "") {
        o .= "  " err "`n"
    } else {
        for p in list {
            mark := (p["key"] = G.schedCurrent) ? "▶" : "  "
            o .= Format("{1} {2} {3}  … {4}  [調査{5} セラピー{6}回]  実行 {7} 回`n"
                , mark, p["sei"], p["mei"], NextDueText(p)
                , p["scan"] ? "有" : "無", p["count"], HistRunCount(p["key"]))
        }
    }
    o .= "`n■ 本日  完了 " G.schedDone " / 要確認 " G.schedCheck
       . " / 失敗 " G.schedFailed " / 見送り " G.schedSkipped "`n"
    o .= "稼働時間: " FmtDur(SecSince(G.schedStartTS)) "`n"
    try FileDelete(STATUSTX)
    try FileAppend(CRLF(o), STATUSTX, "UTF-8")
}

;==============================================================================
;  /schedule  スケジュール運転を始める
;==============================================================================
; autoStart: 予定の編集画面から「運転を開始」を押したときは true。
;   すでに押して決めているので、同じ内容の確認の画面（もう一度「開始」を押させる）は出さない。
;   設定に不備のある予定があるときだけ、画面を出して知らせる。
ModeSchedule(autoStart := false) {
    global G, APP_NAME, APP_VER, STOPFILE, SCHEDINI
    LicenseGate()                                  ; 利用の期限（止めるならここで終わる）
    EnsureSingleInstance()
    EnsureTargetForSchedule()                      ; ★落ちていても止めない★
    LoadScreens()
    try FileDelete(STOPFILE)

    if (!Preflight(&msg)) {
        MsgBox(msg, APP_NAME " - 実行できません", "Icon! 4096")
        ReopenAndExit(1)
    }
    list := LoadSchedule(&err)
    if (err != "") {
        MsgBox(err "`n`n" SCHEDINI " を編集してください。", APP_NAME, "Icon! 4096")
        try Run('notepad.exe "' SCHEDINI '"')
        ReopenAndExit(1)
    }

    if (autoStart) {
        nBad := 0
        for p in list {
            if (!ValidateEntry(p, &vw0))
                nBad++
        }
        if (nBad = 0) {
            Log("INFO", "予定の編集画面から、そのまま運転を開始します")
            StartScheduler()
            return
        }
    }
    dlg := Gui("+AlwaysOnTop", APP_NAME " - スケジュール運転" VerTag())
    dlg.MarginX := 16, dlg.MarginY := 12
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "w860", "この予定で自動実行します")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w860 cGray"
        , APP_VER "   1 件ずつ順番に実行します（同時には走りません）。"
        . "停止するときはトレイか Ctrl+Alt+Shift+S。")
    lv := dlg.Add("ListView", "w860 h260 -Multi"
        , ["顧客", "予定", "調査", "セラピー", "実行済", "状態"])
    bad := 0
    for p in list {
        st := ""
        if (!ValidateEntry(p, &vw)) {
            st := "★" vw
            bad++
        } else if (!p["enabled"]) {
            st := "無効"
        } else {
            DueNow(p, &why)
            st := why
        }
        lv.Add(, p["sei"] " " p["mei"], NextDueText(p), p["scan"] ? "有" : "無"
            , p["count"] " 回", HistRunCount(p["key"]) " 回", st)
    }
    lv.ModifyCol(1, 150), lv.ModifyCol(2, 200), lv.ModifyCol(3, 50)
    lv.ModifyCol(4, 80),  lv.ModifyCol(5, 70),  lv.ModifyCol(6, 290)
    dlg.SetFont("s10", "Meiryo UI")
    if (bad > 0) {
        dlg.SetFont("s10 Bold", "Meiryo UI")
        dlg.Add("Text", "w860 cRed", "★ 設定に不備のある予定が " bad " 件あります（その行は実行されません）")
        dlg.SetFont("s10", "Meiryo UI")
    }
    dlg.Add("Text", "w860 cGray"
        , "※ schedule.ini は 1 分ごとに読み直します。運転中に編集しても反映されます。")
    bGo  := dlg.Add("Button", "w270 h40 Default", "この予定で運転を開始")
    bEd  := dlg.Add("Button", "x+15 yp w270 h40", "予定を編集")
    bNo  := dlg.Add("Button", "x+15 yp w270 h40", "キャンセル")
    bGo.OnEvent("Click", (*) => (dlg.Destroy(), StartScheduler()))
    bEd.OnEvent("Click", (*) => (dlg.Destroy(), ModeScheduleEditor()))
    bNo.OnEvent("Click", (*) => ReopenAndExit(0))
    dlg.OnEvent("Close", (*) => ReopenAndExit(0))
    dlg.Show()
}

;==============================================================================
;  自動セラピー — いま開いているカードに、セラピーだけを N 回
;==============================================================================
;  目の前の方には、調査は手で行う（ツールを介する必要がない）。
;  ツールに任せたいのは「セラピーを決めた回数くりかえす」ところだけ。
;  ＝ 既存の自動セラピーツール（AutoTherapy v4）と同じ役割。
;
;  ★顧客の検索も選択も行わない★
;    いま画面に開いているカードがそのまま対象。
;    そのかわり、開いているカードの氏名を読んで【必ず画面に見せてから】開始する。
;==============================================================================

; 動作中の版へ「この方にセラピーを N 回してほしい」と頼む
WriteTherapyRequest(count, sei, mei) {
    global REQFILE
    o := "[Therapy]`nCount=" count "`nSei=" sei "`nMei=" mei "`nAt=" A_Now "`n"
    try {
        if FileExist(REQFILE)
            FileDelete(REQFILE)
        FileAppend(CRLF(o), REQFILE, "UTF-8")
    } catch {
        return false
    }
    return true
}

; ★依頼の見張り★
;   SchedTick は 60 秒おきなので、そこで拾うと最大 1 分待たされる。
;   目の前にお客様がいるので待たせたくない（カマヤン指摘 2026-09-15）。
;   ファイルの有無を見るだけの軽い処理を 1 秒ごとに回す。
WatchTherapyRequest() {
    global G, REQFILE
    if (!G.schedOn || G.schedRunning)
        return
    if !FileExist(REQFILE)
        return
    TakeTherapyRequest()
}

; 依頼が来ていたら受け取って始める（スケジューラ側）
TakeTherapyRequest() {
    global G, C, REQFILE, APP_NAME
    if !FileExist(REQFILE)
        return false
    m := IniLoad(REQFILE)
    cnt := ToInt(IniGet(m, "Therapy", "Count", "1"), 1)
    sei := Trim(IniGet(m, "Therapy", "Sei", ""))
    mei := Trim(IniGet(m, "Therapy", "Mei", ""))
    try FileDelete(REQFILE)                         ; 二度実行しないよう先に消す
    ; ★先に占有する★
    ;   このあと氏名の照合で最大 15 秒待つ。その間に SchedTick が
    ;   予定のジョブを始めてしまうと、2 つが同じ画面を取り合う。
    G.schedRunning := true
    if (cnt < 1 || cnt > CI("MaxUnattendedCycles")) {
        Log("ERROR", "自動セラピーの依頼を却下: 回数が範囲外 " cnt)
        G.schedRunning := false
        return false
    }
    ; ★依頼したときのカードと、いま開いているカードが同じか確かめる★
    ;   間に別のカードを開かれていたら、別人にセラピーを行ってしまう。
    if (sei != "") {
        ok := false
        if (h := FindScreen("S2_Card")) {
            if (ReadPatientSettled(h, &s2, &m2, &w2))
                ok := (Norm(s2) = Norm(sei) && Norm(m2) = Norm(mei))
        }
        if (!ok) {
            Log("ERROR", Format("自動セラピーの依頼を取り消しました："
                . "開いているカードが「{1} {2}」ではありません", sei, mei))
            try TrayTip("自動セラピーを中止しました`n開いているカードが違います", APP_NAME)
            G.schedRunning := false
            return false
        }
    }
    C["RunInvestigation"] := "0"
    C["TherapyCount"]     := cnt
    G.wantSei := sei, G.wantMei := mei
    G.wantMid     := ""                            ; 開いているカードが対象。前の指定は持ち越さない
    G.skipSelect  := true
    G.manualJob   := true
    G.schedCurrent := ""
    Log("INFO", Format("--- 手動の自動セラピー: 「{1} {2}」 セラピー {3} 回 ---", sei, mei, cnt))
    try TrayTip("自動セラピーを開始: " sei " " mei, APP_NAME)
    StartJob()
    return true
}

ModeTherapy() {
    global G, C, APP_NAME, APP_VER, STOPFILE
    LicenseGate()                                  ; 利用の期限（止めるならここで終わる）
    LoadScreens()
    C["RunInvestigation"] := "0"                    ; 調査は行わない

    ; ★スケジュール運転を止めずに、自動セラピーを使えるようにする★
    ;   画面を操作してよいのは常に 1 つだけ。2 つが同時に触ると必ず壊れる。
    ;   そこで、すでに動いている版があるときは【自分では動かさず、その版に頼む】。
    other := AnotherInstanceRunning()
    live  := other ? ReadLive() : Map("Running", "0", "SchedOn", "0", "Patient", ""
                                    , "Cycle", "", "fresh", false)
    ; 頼めるのは「スケジュール運転が、いま待機中」のときだけ。
    ;   live.txt が無い/古いときは様子が分からないので頼まない（安全側）。
    canAsk := (other && live["fresh"] && live["SchedOn"] = "1" && live["Running"] = "0")
    busy   := (other && !canAsk)

    ; ★ここで EnsureTarget() を呼ばない★
    ;   呼ぶと対象ソフトが無いときに画面すら出ずに終わってしまう。
    ;   「何が足りないのか」はダイアログの中で見せ、開始のときに止める。
    who := "", warn := "", sei0 := "", mei0 := ""
    exe := CS("ExeName")
    if (exe = "") {
        warn := "対象ソフトがまだ設定されていません（設定 →「測定値を設定し直す」で、対象ソフトを選んでください）。"
    } else if (!(G.pid := FindPidByExe(exe))) {
        warn := "対象ソフト「" exe "」が起動していません。起動してから実行してください。"
    } else if (!Preflight(&msg, false)) {
        warn := StrReplace(msg, "`n", " ")
    } else if (h := FindScreen("S2_Card")) {
        if (ReadPatientSettled(h, &sei0, &mei0, &w0))
            who := sei0 " " mei0
        else
            warn := "氏名が読めません: " w0
    } else {
        warn := "カード画面が見つかりません。顧客のカードを開いてから実行してください。"
    }

    dlg := Gui("+AlwaysOnTop", APP_NAME " - 自動セラピー" VerTag())
    dlg.MarginX := 18, dlg.MarginY := 14
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "w560", "セラピーを繰り返します（調査は行いません）")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w560 cGray", APP_VER "   対象ソフト: " CS("ExeName"))
    if (other) {
        dlg.SetFont("s10", "Meiryo UI")
        if (busy) {
            dlg.Add("Text", "w560 cRed"
                , "⚠ ほかの AutoMeta が実行中です"
                . (live["Patient"] = "" ? "" : "（" live["Patient"] "  セラピー " live["Cycle"] "）"))
            dlg.SetFont("s9", "Meiryo UI")
            dlg.Add("Text", "w560 cGray"
                , "　終わるまで開始できません。急ぐ場合は運転パネルの「止める」で中断してください。")
        } else {
            dlg.Add("Text", "w560 cGreen", "◌ スケジュール運転は待機中です")
            dlg.SetFont("s9", "Meiryo UI")
            dlg.Add("Text", "w560 cGray"
                , "　開始すると、待機中のスケジュール運転が、そのまま実行します"
                . "（運転は止まりません）。")
        }
    }
    dlg.Add("Text", "w560 h1 0x10")

    dlg.SetFont("s10", "Meiryo UI")
    dlg.Add("Text", "w560", "いま開いているカード")
    if (who != "") {
        dlg.SetFont("s16 Bold", "Meiryo UI")
        dlg.Add("Text", "xm+12 w540 cNavy", who)
        dlg.SetFont("s9", "Meiryo UI")
        dlg.Add("Text", "xm+12 w540 cGray"
            , "この方にセラピーを行います。違う場合はキャンセルし、ソフト側でカードを開き直してください。")
    } else {
        dlg.SetFont("s11 Bold", "Meiryo UI")
        dlg.Add("Text", "xm+12 w540 cRed", "★ 読み取れません")
        dlg.SetFont("s9", "Meiryo UI")
        dlg.Add("Text", "xm+12 w540 cGray", warn)
    }

    dlg.SetFont("s10", "Meiryo UI")
    dlg.Add("Text", "xm w560 h1 0x10")
    dlg.Add("Text", "xm w120", "セラピーの回数")
    cntList := []
    Loop CI("MaxUnattendedCycles")
        cntList.Push(String(A_Index))
    dCnt := dlg.Add("DropDownList", "x+10 yp-4 w80", cntList)
    dCnt.Value := (CI("TherapyCount") >= 1 && CI("TherapyCount") <= cntList.Length)
                  ? CI("TherapyCount") : 1
    dlg.Add("Text", "x+8 yp+4 w40", "回")
    lblEst := dlg.Add("Text", "xm+12 w540 cGray", "")

    dlg.SetFont("s10", "Meiryo UI")
    cDry := dlg.Add("CheckBox", "xm w560 " (CB("DryRun") ? "Checked" : "")
        , "DryRun（画面は追うが、一切クリックしない）")

    dlg.Add("Text", "xm w560 h1 0x10")
    dlg.SetFont("s11 Bold", "Meiryo UI")
    bGo := dlg.Add("Button", "xm w260 h44 Default", "開始")
    dlg.SetFont("s10", "Meiryo UI")
    bNo := dlg.Add("Button", "x+20 yp w260 h44", "キャンセル")
    bGo.OnEvent("Click", DoTherapy)
    bNo.OnEvent("Click", (*) => ReopenAndExit(0))
    dlg.OnEvent("Close", (*) => ReopenAndExit(0))
    dCnt.OnEvent("Change", (*) => UpdateEst())
    UpdateEst()
    dlg.Show()
    return

    UpdateEst() {
        n := dCnt.Value
        lblEst.Value := Format("目安 {1}〜{2}（セラピー 1 回 6〜30 分の実測より）"
            , FmtDur(n * 360), FmtDur(n * CI("PlanCycleSec")))
    }

    DoTherapy(*) {
        global G, C, APP_NAME, STOPFILE
        n := dCnt.Value
        ; 開始の直前に、対象ソフトが本当にいるかを確かめる
        if (CS("ExeName") = "" || !(G.pid := FindPidByExe(CS("ExeName")))) {
            MsgBox("対象ソフトが見つからないため、開始できません。`n`n" warn
                , APP_NAME " - 実行できません", "Iconx 4096")
            return
        }
        if (who = "") {
            ans := MsgBox("いま開いているカードの氏名が読めませんでした。`n`n"
                . warn "`n`n"
                . "このまま進めると、【画面に開いている方】にセラピーを "
                . n " 回行います。`n続けますか？", APP_NAME, "YesNo Iconx 4096")
            if (ans != "Yes")
                return
        }
        ; --- すでに動いている版がある場合 ---------------------------------------
        if (AnotherInstanceRunning()) {
            now := ReadLive()
            if (!(now["fresh"] && now["SchedOn"] = "1" && now["Running"] = "0")) {
                MsgBox("ほかの AutoMeta が動いているため、開始できません。`n`n"
                    . "　顧客　　: " (now["Patient"] = "" ? "（不明）" : now["Patient"]) "`n"
                    . "　セラピー: " (now["Cycle"] = "" ? "（不明）" : now["Cycle"]) "`n`n"
                    . "2 つが同じ画面を操作すると必ず誤動作するため、開始できません。`n"
                    . "終わるのを待つか、運転パネルの「止める」で中断してください。"
                    , APP_NAME " - いまは実行できません", "Iconx 4096")
                return
            }
            if (!WriteTherapyRequest(n, (who = "") ? "" : sei0, (who = "") ? "" : mei0)) {
                MsgBox("依頼を書き込めませんでした。", APP_NAME, "Iconx 4096")
                return
            }
            dlg.Destroy()
            MsgBox("待機中のスケジュール運転へ実行を引き渡しました。`n`n"
                . "　" (who = "" ? "（開いているカード）" : who) "　セラピー " n " 回`n`n"
                . "数秒で始まります。進み具合は運転パネルで確認できます。`n"
                . "スケジュール運転はそのまま続きます。"
                , APP_NAME, "Iconi 4096")
            ReopenAndExit(0)
        }
        ; --- 自分で動かす -------------------------------------------------------
        EnsureSingleInstance()
        try FileDelete(STOPFILE)
        C["TherapyCount"] := n
        C["DryRun"]       := cDry.Value ? "1" : "0"
        G.wantSei := (who = "") ? "" : sei0
        G.wantMei := (who = "") ? "" : mei0
        G.skipSelect := true                        ; ★検索も選択もしない★
        dlg.Destroy()
        SetupTray()
        ShowPanel()
        StartJob()
    }
}

;==============================================================================
;  予定の編集画面
;==============================================================================
;  schedule.ini を手で書くと、TherapyCount・Days・Time の打ち間違いに気づけない。
;  氏名だけは G1（照合）が守ってくれるが、回数・曜日・時刻には安全網がない。
;  そこで「選ぶだけで書ける」画面を用意し、保存の前に必ず検証する。
;==============================================================================

; 実測にもとづく所要時間の見積もり
;   調査   : 35〜38 項目 × 8.4 秒 ≒ 5〜7 分（2026-09-14 実測 05:01 / 05:28）
;   セラピー: 1 回 6〜30 分（実測 06:04 / 07:25。30 分を超える例もある）
EstimateText(scan, count) {
    lo := (scan ? 5 : 0) + count * 6
    hi := (scan ? 7 : 0) + count * 30
    if (lo = 0 && hi = 0)
        return "何も行いません"
    return Format("およそ {1}〜{2} 分", lo, hi)
}

; 実行履歴を消す（回数の上限に達した人を、もう一度回せるようにする）
HistReset(key) {
    global STATEINI
    IniSet(STATEINI, "History." key, "LastRunAt", "")
    IniSet(STATEINI, "History." key, "LastSlotAt", "")
    IniSet(STATEINI, "History." key, "LastResult", "")
    IniSet(STATEINI, "History." key, "RunCount", "0")
}

NewPatientMap() {
    return Map("key", "", "name", "", "enabled", true
             , "sei", "", "mei", "", "mode", "interval", "days", "月,水,金"
             , "order", 0
             , "time", "2100", "timemode", "queue"
             , "interval", 3, "scan", true, "count", 1
             , "scantype", CS("ScanTypeName"), "manual", CS("ManualName")
             , "start", FormatTime(A_Now, "yyyyMMdd"), "end", ""
             , "maxruns", 3, "catchup", 120, "note", "")
}

; 重複しない [Patient.◯◯] の名前を作る
MakeSchedKey(sei, mei, list, selfKey := "") {
    base := StrReplace(StrReplace(Trim(sei) Trim(mei), " ", ""), "]", "")
    if (base = "")
        base := "Patient"
    num := 0
    Loop {
        cand := "Patient." base . (num = 0 ? "" : num)
        used := false
        for item in list {
            if (item["key"] = cand && cand != selfKey)
                used := true
        }
        if (!used)
            return cand
        num++
    }
}

;==============================================================================
;  schedule.ini の書き出し
;==============================================================================
SaveSchedule(list, &err) {
    global SCHEDINI
    err := ""
    ; --- 検証（有効な予定だけ厳しく見る）-------------------------------------
    for item in list {
        if (!item["enabled"])
            continue
        if (!ValidateEntry(item, &why)) {
            err := Format("「{1} {2}」の設定が正しくありません。`n`n{3}"
                , item["sei"], item["mei"], why)
            return false
        }
    }
    ; --- 書き出し（元のファイルは .bak に残す）-------------------------------
    if FileExist(SCHEDINI) {
        try FileDelete(SCHEDINI ".bak")
        try FileCopy(SCHEDINI, SCHEDINI ".bak", 1)
    }
    ; 画面に並んでいる順を、そのまま実行の順番として書き出す
    for idx, item in list {
        if (IsBlankSchedKey(item["key"]))
            item["key"] := MakeSchedKey(item["sei"], item["mei"], list)
        item["order"] := idx
    }
    txt := "; ============================================================="
        . "`n;  AutoMeta  schedule  — 顧客ごとの予定"
        . "`n;  文字コード: UTF-8 (BOM付き) / 改行: CRLF"
        . "`n;"
        . "`n;  ★このファイルは「予定を編集する」画面が書き出しています。"
        . "`n;    手で書き換えても構いませんが、次に画面から保存すると"
        . "`n;    この見出し以外のコメントは失われます。"
        . "`n;    直前の内容は schedule.ini.bak に残しています。"
        . "`n;"
        . "`n;  最終更新: " FormatTime(A_Now, "yyyy-MM-dd HH:mm")
        . "`n; =============================================================`n"
    for item in list {
        txt .= "`n[" item["key"] "]`n"
        txt .= "Order=" item["order"] "`n"
        txt .= "Enabled=" (item["enabled"] ? "1" : "0") "`n"
        txt .= "LastName=" item["sei"] "`n"
        txt .= "FirstName=" item["mei"] "`n"
        txt .= "MiddleName=" (item.Has("middle") ? item["middle"] : "") "`n"
        txt .= "RunInvestigation=" (item["scan"] ? "1" : "0") "`n"
        txt .= "ScanType=" item["scantype"] "`n"
        txt .= "ManualSelect=" item["manual"] "`n"
        txt .= "TherapyCount=" item["count"] "`n"
        txt .= "Mode=" item["mode"] "`n"
        ; 両方書いておく。Mode を切り替えたときに、もう片方の設定を失わないため
        txt .= "Days=" item["days"] "`n"
        txt .= "IntervalDays=" item["interval"] "`n"
        txt .= "Time=" SubStr(item["time"], 1, 2) ":" SubStr(item["time"], 3, 2) "`n"
        txt .= "TimeMode=" item["timemode"] "`n"
        txt .= "StartDate=" FmtYmd(item["start"]) "`n"
        txt .= "EndDate=" FmtYmd(item["end"]) "`n"
        txt .= "MaxRuns=" item["maxruns"] "`n"
        txt .= "CatchUpWindowMin=" item["catchup"] "`n"
        txt .= "Note=" item["note"] "`n"
    }
    try {
        if FileExist(SCHEDINI)
            FileDelete(SCHEDINI)
        FileAppend(CRLF(txt), SCHEDINI, "UTF-8")      ; BOM 付きで書く
    } catch as e {
        err := "schedule.ini に書き込めませんでした: " e.Message
        return false
    }
    return true
}

; 日付の入力欄（クリックするとカレンダーが出る）
;   左のチェックを外すと「指定なし」になる。
;   ymd は "" か YYYYMMDD。
AddDateBox(dlg, opts, ymd) {
    ; ★オプション番号に注意★
    ;     1 = カレンダーのボタンを【上下ボタンに置き換える】← これを指定すると
    ;         クリックしてもカレンダーが出ない（2026-09-15 の取り違え）
    ;     2 = 左にチェックボックスを出す（外すと「指定なし」）
    ;   何も指定しなければ、右の ▼ でカレンダーが開く。
    o := opts . " 2 " . ((StrLen(ymd) = 8) ? "Choose" ymd : "ChooseNone")
    try
        return dlg.Add("DateTime", o, "yyyy-MM-dd")
    catch as e {
        ; ★万一この環境でカレンダー部品が使えなくても、画面が開かなくならないように★
        Log("WARN", "カレンダー部品を作れませんでした（文字入力に切り替えます）: " e.Message)
        return dlg.Add("Edit", opts, FmtYmd(ymd))
    }
}

; 日付の入力欄から YYYYMMDD を取り出す。指定なしなら "" を返す。
DateBoxValue(ctrl) {
    v := ""
    try v := ctrl.Value
    v := "" . v
    if (ctrl.Type = "Edit")                         ; 代替の文字入力だったとき
        return NormDate(v)
    if (StrLen(v) >= 8 && RegExMatch(SubStr(v, 1, 8), "^\d{8}$"))
        return SubStr(v, 1, 8)
    return ""
}

; 一覧の中から名前が一致するものを選ぶ。無ければ先頭。
; 「変更しない」の表示名（空っぽ＝触らない、を表す）
NoChangeLabel() => "（変更しない）"

; 予定に入っている値を、一覧に出す表示名に直す
OptLabelOfValue(v) {
    v := Trim("" . v)
    if (v = "")
        return NoChangeLabel()
    if (v = "なし")
        return NoneSelectLabel()
    return v
}

OptLabelOf(item, key) {
    return OptLabelOfValue(item.Has(key) ? item[key] : "")
}

SelectByName(ddl, names, want) {
    if (!names.Length)
        return
    for i, nm in names {
        if (nm = Trim(want)) {
            ddl.Value := i
            return
        }
    }
    ddl.Value := 1
}

FmtYmd(ymd) {
    if (StrLen(ymd) != 8)
        return ""
    return SubStr(ymd, 1, 4) "-" SubStr(ymd, 5, 2) "-" SubStr(ymd, 7, 2)
}

;==============================================================================
;  一覧画面
;==============================================================================
ModeScheduleEditor() {
    global APP_NAME, APP_VER, SCHEDINI, SCHEDUI

    LeftoverContactAsk()                            ; スタンダードプランで宛先が残っていれば、1 度だけ聞く（一覧を読む前に）
    list := LoadSchedule(&err)                      ; err は「1 件もない」だけなら無視
    SCHEDUI := Map("list", list, "dirty", false, "gone", [])

    dlg := Gui("+Resize", APP_NAME " - 予定の編集" VerTag())
    dlg.MarginX := 16, dlg.MarginY := 12
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "w700", "予定の編集")
    ; ★運転が動いているかを、いつも見える所に出す★（保存しただけで放置するのを防ぐ）
    tRun := dlg.Add("Text", "x+10 yp w230 Right", "")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "xm w940 h34 cGray"
        , "行をダブルクリックすると編集できます。"
        . "「順番に実行する」方は、この表の上から順に実行されます（▲▼ で入れ替え）。`n"
        . "保存すると schedule.ini に書き出します（直前の内容は schedule.ini.bak に残ります）。")

    dlg.SetFont("s10", "Meiryo UI")
    ; ★終わった方と実行中の方が混ざって見づらい★ 既定で隠す（2026-10-06 指摘）
    cHide := dlg.Add("Checkbox", "xm w260 Checked", "終わった予定を隠す")
    tCnt  := dlg.Add("Text", "x+10 yp+3 w470 cGray", "")
    ; ★一般の上限を超えているときの案内★ 超えていなければ空のまま・ボタンは隠れる
    bGuide := dlg.Add("Button", "x+10 yp-5 w190 h26", "プロプランのご案内")
    bGuide.Visible := false
    bGuide.OnEvent("Click", (*) => GuideOpen())
    tLim  := dlg.Add("Text", "xm w940 h40 cRed", "")
    dlg.Add("Text", "xm w120", "順番待ちの予定は")
    lateList := SchedLateList()
    dLate := dlg.Add("DropDownList", "x+4 yp-4 w190", ["予定の時刻から 3 時間", "予定の時刻から 4 時間", "予定の時刻から 6 時間", "予定の時刻から 8 時間", "予定の時刻から 10 時間"])
    for idx, n in lateList {
        if (n = SchedLateHours())
            dLate.Value := idx
    }
    dlg.Add("Text", "x+8 yp+4 w600", "を過ぎたら、その回は開始せず翌日の同じ時刻へ持ち越し（実行の回数は消費しません）")
    dLate.OnEvent("Change", (*) => SchedStartOptSave("StartLateHours", lateList[dLate.Value]))
    dlg.Add("Text", "xm w120", "PC の使用中は")
    idleList := SchedIdleList()
    dIdle := dlg.Add("DropDownList", "x+4 yp-4 w300", ["待たずに開始", "操作なしが 5 分続いてから開始", "操作なしが 10 分続いてから開始", "操作なしが 15 分続いてから開始", "操作なしが 30 分続いてから開始"])
    for idx, n in idleList {
        if (n = SchedIdleMin())
            dIdle.Value := idx
    }
    dIdle.OnEvent("Change", (*) => SchedStartOptSave("StartIdleMin", idleList[dIdle.Value]))
    bChart := dlg.Add("Button", "x+20 yp-1 w220 h28", "これからの見込み →")
    bChart.OnEvent("Click", (*) => SchedChartOpen())
    lv := dlg.Add("ListView", "xm w940 r12 -Multi Grid"
        , ["順", "", "顧客", "実行内容", "繰り返し", "次に実行される", "回数", "配信設定"])
    lv.OnEvent("DoubleClick", SchedEditOpen)

    dlg.SetFont("s10", "Meiryo UI")
    bNew := dlg.Add("Button", "xm w150 h36", "＋ 追加")
    bEdt := dlg.Add("Button", "x+8 yp w150 h36", "編集")
    bDup := dlg.Add("Button", "x+8 yp w150 h36", "複製")
    bDel := dlg.Add("Button", "x+8 yp w150 h36", "削除")
    bTgl := dlg.Add("Button", "x+8 yp w150 h36", "有効／無効")
    bUp  := dlg.Add("Button", "x+24 yp w80 h36", "▲ 上へ")
    bDn  := dlg.Add("Button", "x+8 yp w80 h36", "▼ 下へ")

    dlg.Add("Text", "xm w940 h1 0x10")
    dlg.SetFont("s11 Bold", "Meiryo UI")
    bRun  := dlg.Add("Button", "xm w360 h46 Default", "▶  この予定で運転を開始")
    dlg.SetFont("s10", "Meiryo UI")
    bSave := dlg.Add("Button", "x+10 yp w270 h46", "保存して閉じる")
    bCls  := dlg.Add("Button", "x+10 yp w270 h46", "閉じる")

    cHide.OnEvent("Click", (*) => SchedEditRefresh())
    bNew.OnEvent("Click",  (*) => SchedEditNew())
    bEdt.OnEvent("Click",  (*) => SchedEditOpen())
    bDup.OnEvent("Click",  (*) => SchedEditDup())
    bDel.OnEvent("Click",  (*) => SchedEditDel())
    bTgl.OnEvent("Click",  (*) => SchedEditToggle())
    bUp.OnEvent("Click",   (*) => SchedEditMove(-1))
    bDn.OnEvent("Click",   (*) => SchedEditMove(1))
    bSave.OnEvent("Click", (*) => SchedEditSave(true))
    bRun.OnEvent("Click",  (*) => SchedEditRun())
    bCls.OnEvent("Click",  (*) => SchedEditClose())
    dlg.OnEvent("Close",   (*) => SchedEditClose())

    SCHEDUI["dlg"]  := dlg
    SCHEDUI["lv"]   := lv
    SCHEDUI["hide"] := cHide
    SCHEDUI["cnt"]  := tCnt
    SCHEDUI["run"]  := tRun
    SCHEDUI["lim"]  := tLim
    SCHEDUI["guide"] := bGuide
    SchedEditRefresh()
    dlg.Show()
    ; ★この画面でも登録を受け取る★
    ;   QR を出すのはここなので、運転を始めなくても
    ;   開いたまま待っていれば確認の画面が出る（2026-10-02 指摘）。
    SetTimer(RegPollAll, 20000)
    RegPollAll()                                   ; 開いた直後にも 1 回
    SchedEditRunState()
    SetTimer(SchedEditRunState, 10000)             ; 運転の状態を 10 秒ごとに見直す
}

; 運転が動いているか。運転中の本体が 1 分ごとに書く live.txt を見る（5 分以上古ければ止まっているとみなす）
SchedRunLive() {
    live := ReadLive()
    return (live["fresh"] && live["SchedOn"] = "1")
}

; 予定の編集画面の右上に、運転の状態を色つきで出す
SchedEditRunState() {
    global SCHEDUI
    if (!IsObject(SCHEDUI) || !SCHEDUI.Has("run"))
        return
    on := SchedRunLive()
    try {
        SCHEDUI["run"].Opt(on ? "c1E7B34" : "cC00000")
        SCHEDUI["run"].Value := on ? "● 運転中" : "● 運転は停止中です"
    }
}

SchedEditRefresh() {
    global SCHEDUI
    lv := SCHEDUI["lv"]
    hide := SchedHiding()
    lv.Delete()
    nLive := 0, nDone := 0
    for item in SCHEDUI["list"] {
        ; ★数えるのは全件、出すのは絞ったぶん★ 件数は隠しても変わらない
        if (SchedIsDone(item)) {
            nDone++
            if (hide)
                continue
        } else {
            nLive++
        }
        todo := ""
        if (item["scan"])
            todo := "調査"
        if (item["scan"] && item.Has("scantype") && item["scantype"] != "")
            todo .= "（" item["scantype"]
                 . (item.Has("manual") && item["manual"] != "" ? " / " item["manual"] : "") "）"
        if (item["count"] > 0)
            todo .= (todo = "" ? "" : " ＋ ") "セラピー " item["count"] " 回"
        if (todo = "")
            todo := "（なし）"
        todo .= "   " EstimateText(item["scan"], item["count"])

        if (item["mode"] = "weekly")
            rep := "毎週 " DaysLabel(item["days"]) "  " TimeLabel(item)
        else
            rep := item["interval"] " 日おき  " TimeLabel(item)

        runs := HistRunCount(item["key"])
        if (item["maxruns"] > 0)
            cnt := runs " / " item["maxruns"] " 回"
        else
            cnt := runs " 回（上限なし）"

        ; ★1 列目は配列の位置★ 絞り込んでも、ここから本当の位置を引ける
        lv.Add("", A_Index, item["enabled"] ? "✓" : "－"
             , item["sei"] " " item["mei"], todo, rep, NextDueText(item), cnt, NotifyListText(item["key"]))
    }
    if (SCHEDUI.Has("cnt")) {
        word := Format("実行中 {1} 件 ／ 終わった {2} 件", nLive, nDone)
        if (nDone > 0 && hide)
            word .= "（終わった方は隠しています）"
        SCHEDUI["cnt"].Value := word
    }
    if (SCHEDUI.Has("lim")) {
        nAll := TargetCountOf(SCHEDUI["list"])
        lim  := TargetLimit()
        over := (lim > 0 && nAll > lim)
        warn := ""
        if (over)
            warn := Format("{1} 人以上のご利用には、プロプランへの登録が必要です。`n"
                . "プロプランへ登録しない場合は、登録済みの予定を削除し、顧客を {2} 人以内にしてください。（現在の登録：{3} 人）"
                , lim + 1, lim, nAll)
        SCHEDUI["lim"].Value := warn
        SCHEDUI["guide"].Visible := over
    }
    lv.ModifyCol(1, 34)
    lv.ModifyCol(2, 34)
    lv.ModifyCol(3, 120)
    lv.ModifyCol(4, 190)
    lv.ModifyCol(5, 140)
    lv.ModifyCol(6, 170)
    lv.ModifyCol(7, 100)
    lv.ModifyCol(8, 140)
    ; ★表示の行番号で選び直さない★ 絞り込むと位置がずれる
    if (SCHEDUI.Has("sel")) {
        want := SCHEDUI["sel"]
        Loop lv.GetCount() {
            if (ToInt(Trim(lv.GetText(A_Index, 1)), 0) = want) {
                lv.Modify(A_Index, "Select Focus Vis")
                break
            }
        }
    }
}

SchedHiding() {
    global SCHEDUI
    return SCHEDUI.Has("hide") && SCHEDUI["hide"].Value = 1
}

; row から dir の向きに、いま表示されている次の位置を探す
SchedNextShown(row, dir) {
    global SCHEDUI
    hide := SchedHiding()
    i := row + dir
    while (i >= 1 && i <= SCHEDUI["list"].Length) {
        if (!hide || !SchedIsDone(SCHEDUI["list"][i]))
            return i
        i += dir
    }
    return 0
}

; ★表示の行番号を、予定の並びの位置に直す★
;   列の見出しを押すと【表示だけ】が並べ替わり、内部の並びはそのまま。
;   表示の行番号で配列を引くと、別の方を編集・複製・削除してしまう
;   （2026-10-02、名前で並べ替えて気づいた）。
;   1 列目の「順」が内部の位置そのものなので、そこから引き直す。
SchedPicked(why) {
    global SCHEDUI
    row := SCHEDUI["lv"].GetNext()
    if (row < 1) {
        MsgBox(why . "行を選んでください。", "予定の編集", "Icon! 4096")
        return 0
    }
    idx := ToInt(Trim(SCHEDUI["lv"].GetText(row, 1)), 0)
    if (idx < 1 || idx > SCHEDUI["list"].Length) {
        MsgBox("選んだ行を読み取れませんでした。`n`n"
            . "「順」の列を押して並べ直してから、もう一度お試しください。"
            , "予定の編集", "Icon! 4096")
        return 0
    }
    return idx
}

; 実行の順番を入れ替える（dir = -1 で上へ / +1 で下へ）
SchedEditMove(dir) {
    global SCHEDUI
    row := SchedPicked("動かしたい")
    if (row < 1)
        return
    ; ★見えている行どうしで入れ替える★
    ;   終わった予定を隠しているとき、隠れた行は飛び越える。
    ;   終わった予定は実行されないので、実行順は壊れない。
    dst := SchedNextShown(row, dir)
    if (dst < 1)
        return
    tmp := SCHEDUI["list"][row]
    SCHEDUI["list"][row] := SCHEDUI["list"][dst]
    SCHEDUI["list"][dst] := tmp
    SCHEDUI["sel"]   := dst
    SCHEDUI["dirty"] := true
    SchedEditRefresh()
}

FmtHHMM(t) {
    return (StrLen(t) = 4) ? SubStr(t, 1, 2) ":" SubStr(t, 3, 2) : "??:??"
}

DaysLabel(spec) {
    out := ""
    for part in StrSplit(spec, ",") {
        num := DayNameToNum(part)
        if (num > 0)
            out .= (out = "" ? "" : "・") DayNumToName(num)
    }
    return (out = "") ? "？" : out
}

SchedEditNew() {
    global SCHEDUI
    if (SchedAddAtLimit(SCHEDUI["list"]))          ; 上限に達していれば、入力画面を出さない
        return
    item := NewPatientMap()
    if (!PatientDialog(item, true)) {
        ; 届け先だけ先に入れて取りやめたときは、残さない
        if (!IsBlankSchedKey(item["key"]))
            ContactDelete(item["key"])
        return
    }
    ; ★すでに決まっているなら作り直さない★
    ;   届け先の画面で先に結びつけ先を決めている場合がある（2026-10-05）。
    ; ★一般の上限を超える追加は、ここで止める★ 入力のあとなので、同じ方の予定を足すだけなら通る
    if (SchedAddBlocked(SCHEDUI["list"], item)) {
        if (!IsBlankSchedKey(item["key"])) {
            ContactDelete(item["key"])
            ContactMailSet(item["key"], "")
            NotifyBodyClear(item["key"])
        }
        return
    }
    if (IsBlankSchedKey(item["key"]))
        item["key"] := MakeSchedKey(item["sei"], item["mei"], SCHEDUI["list"])
    SaveContactOf(item)                            ; 連絡先は別の場所へ
    OfferRestore(item)                             ; 前の宛先が残っていれば戻せる
    SCHEDUI["list"].Push(item)
    SCHEDUI["dirty"] := true
    SchedEditRefresh()
}

; 以前この方の宛先を取り下げていたら、戻すか聞く
OfferRestore(item) {
    global APP_NAME
    if (ContactGet(item["key"])["line"] != "")
        return                                     ; いま入っているなら触らない
    if (ContactGoneAt(item["key"]) = "")
        return
    old  := ContactGoneOf(item["key"])
    ; ★メールは、節を消してもファイルが残っている★
    ;   以前は何も聞かないため、届け先の画面を開くと前の方の宛先が
    ;   入ったままになっていた（2026-10-05 の点検）。
    hasMail := ContactMailHas(item["key"])
    mail    := hasMail ? ContactMailGet(item["key"]) : ""
    ways := ""
    if (old != "")
        ways .= "　LINE　　" . LineMask(old) . "`n"
    if (hasMail) {
        mailShown := (mail != "") ? MailMask(mail) : "（この PC では復号できません）"
        ways .= "　メール　" . mailShown . "`n"
    }
    if (ways = "")
        return
    if (MsgBox(Format("「{1} {2}」さんのお知らせの届け先が、取り下げたまま残っています。`n`n"
        . "{3}`n"
        . "この予定で、そのまま使いますか？`n"
        . "（誤って予定を消したときは「はい」。別の方なら「いいえ」）"
        , item["sei"], item["mei"], ways)
        , APP_NAME . " - 以前の宛先", "YesNo Icon? 4096") = "Yes") {
        ContactRestore(item["key"])
        item["notify"] := 1
        MsgBox("戻しました。登録のやり直しは要りません。", APP_NAME, "Iconi 4096")
        return
    }
    ; ★「いいえ」なら、メールはその場で削除★
    ;   残すと、届け先の画面に前の方の宛先が入ったまま出てしまう。
    ;   LINE は発行し直しが必要で作り直せないため、30 日の自動削除に任せる。
    if (hasMail) {
        ContactMailSet(item["key"], "")
        Log("INFO", "別の方のため、以前のメールの宛先を削除しました（" . item["key"] . "）")
    }
}

SchedEditOpen(args*) {
    global SCHEDUI
    row := SchedPicked("編集したい")
    if (row < 1)
        return
    item := SCHEDUI["list"][row]
    if (!PatientDialog(item, false))
        return
    SaveContactOf(item)                            ; 連絡先は別の場所へ
    SCHEDUI["dirty"] := true
    SchedEditRefresh()
}

SchedEditDup() {
    global SCHEDUI
    row := SchedPicked("複製したい")
    if (row < 1)
        return
    src := SCHEDUI["list"][row]
    item := Map()
    for k, v in src
        item[k] := v
    ; ★宛先は引き継がない★ key を残すと、元の方の LINE ID を読み込んでしまい、
    ;   同じ宛先の予定が 2 つできて、1 回のセラピーで 2 通届く（2026-10-01）。
    item["key"] := "", item["sei"] := "", item["mei"] := "", item["enabled"] := true
    if (!PatientDialog(item, true)) {
        if (!IsBlankSchedKey(item["key"]))
            ContactDelete(item["key"])
        return
    }
    if (SchedAddBlocked(SCHEDUI["list"], item)) {
        if (!IsBlankSchedKey(item["key"])) {
            ContactDelete(item["key"])
            ContactMailSet(item["key"], "")
            NotifyBodyClear(item["key"])
        }
        return
    }
    if (IsBlankSchedKey(item["key"]))
        item["key"] := MakeSchedKey(item["sei"], item["mei"], SCHEDUI["list"])
    SaveContactOf(item)                            ; 連絡先は別の場所へ
    SCHEDUI["list"].Push(item)
    SCHEDUI["dirty"] := true
    SchedEditRefresh()
}

SchedEditDel() {
    global SCHEDUI
    row := SchedPicked("削除したい")
    if (row < 1)
        return
    item := SCHEDUI["list"][row]
    hasLine := (ContactGet(item["key"])["line"] != "" || ContactMailHas(item["key"]))
    ; ★失うものを書く★ 人数を整理するための削除でも、何が消えるかが分かるように
    lost := "この方の予定は失われます。`n`n"
    if (NotifyBodyHas(item["key"]))
        lost := "この方の予定と、顧客ごとの文面の設定は失われます。`n`n"
    ans := MsgBox(Format("「{1} {2}」の予定を削除します。よろしいですか？`n`n"
        . "{4}{3}"
        . "（実行の履歴は残ります。保存するまでファイルは変わりません。`n"
        . "　保存せずに閉じれば、元のままです）"
        , item["sei"], item["mei"]
        , hasLine ? "この方のお知らせの届け先も、あわせて取り下げます。`n"
                  . "30 日以内に同じ方を登録し直せば、そのまま戻せます。`n`n" : ""
        , lost)
        , "予定の編集", "YesNo Icon? 4096")
    if (ans != "Yes")
        return
    ; ★ファイルはまだ触らない★ 予定の削除は保存のときに効くので、
    ;   宛先だけ先に消すと、保存せずに閉じたときに宛先だけ失われる（2026-10-01）。
    if (Trim(item["key"]) != "") {
        if (!SCHEDUI.Has("gone"))
            SCHEDUI["gone"] := []
        SCHEDUI["gone"].Push(item["key"])
    }
    SCHEDUI["list"].RemoveAt(row)
    SCHEDUI["dirty"] := true
    SchedEditRefresh()
}

SchedEditToggle() {
    global SCHEDUI
    row := SchedPicked("切り替えたい")
    if (row < 1)
        return
    SCHEDUI["sel"] := row
    SCHEDUI["list"][row]["enabled"] := !SCHEDUI["list"][row]["enabled"]
    SCHEDUI["dirty"] := true
    SchedEditRefresh()
}

SchedEditSave(thenClose := true) {
    global SCHEDUI, APP_NAME
    if (!SchedSaveAllowed(SCHEDUI["list"]))        ; 一般の上限を超える「増やす保存」は通さない
        return
    if (!SaveSchedule(SCHEDUI["list"], &err)) {
        MsgBox(err, APP_NAME " - 保存できません", "Iconx 4096")
        return
    }
    SCHEDUI["dirty"] := false
    ContactArchiveGone()                           ; 消した予定の宛先を取り下げる
    Log("INFO", "schedule.ini を保存しました（" SCHEDUI["list"].Length " 件）")
    if (!thenClose) {
        SchedEditRefresh()
        return
    }
    SetTimer(RegPollAll, 0)                        ; この画面での受け取りを止める
    SetTimer(SchedEditRunState, 0)
    ; ★保存したあと、運転が動いているかを伝える★ 保存しただけで放置するのを防ぐ（A-11）
    startNow := false
    if (SchedRunLive()) {
        MsgBox("保存しました。`n`n運転中です。変更は 1 分以内に反映されます。"
            , APP_NAME, "Iconi T6 4096")
    } else {
        r := MsgBox("保存しました。`n`n運転は始まっていません。`n"
            . "このままでは、予定の時刻になっても実行されません。`n`n"
            . "運転を開始しますか？`n`n"
            . "　はい　　　運転を開始`n"
            . "　いいえ　　保存のみ（運転は始めません）"
            , APP_NAME . " - 運転が止まっています", "YesNo Icon! 4096")
        startNow := (r = "Yes")
    }
    SCHEDUI["dlg"].Destroy()
    if (startNow)
        ModeSchedule(true)
    else
        ModeMenu()
}

; 変更があれば保存してから運転へ。無ければそのまま運転へ
SchedEditRun() {
    global SCHEDUI, APP_NAME
    if (SCHEDUI["dirty"]) {
        if (!SchedSaveAllowed(SCHEDUI["list"]))    ; 一般の上限を超える「増やす保存」は通さない
            return
        if (!SaveSchedule(SCHEDUI["list"], &err)) {
            MsgBox(err, APP_NAME " - 保存できません", "Iconx 4096")
            return
        }
        SCHEDUI["dirty"] := false
        ContactArchiveGone()                       ; 消した予定の宛先を取り下げる
        Log("INFO", "schedule.ini を保存しました（" SCHEDUI["list"].Length " 件）")
    }
    SetTimer(RegPollAll, 0)                        ; この画面での受け取りを止める
    SetTimer(SchedEditRunState, 0)
    SCHEDUI["dlg"].Destroy()
    ModeSchedule(true)
}

SchedEditClose() {
    global SCHEDUI
    if (SCHEDUI["dirty"]) {
        ans := MsgBox("保存していない変更があります。破棄して閉じますか？"
            , "予定の編集", "YesNo Icon! 4096")
        if (ans != "Yes")
            return
    }
    SetTimer(RegPollAll, 0)                        ; この画面での受け取りを止める
    SetTimer(SchedEditRunState, 0)
    SCHEDUI["dlg"].Destroy()
    ModeMenu()
}

;==============================================================================
;  1 人ぶんの編集フォーム
;==============================================================================
;  戻り値: true = OK が押されて item が書き換わった / false = やめた
; 予定の「連絡先」だけを、同期されない場所へ保存する
SaveContactOf(item) {
    if (!item.Has("key") || item["key"] = "")
        return
    ; ★画面で扱っていないなら触らない★
    ;   届け先は別の画面が直接書く。ここで空を書くと消えてしまう（2026-10-03）。
    if (!item.Has("lineid"))
        return
    onOff  := item.Has("notify") ? (item["notify"] = 1) : false
    lineId := item.Has("lineid") ? item["lineid"] : ""
    ContactSet(item["key"], onOff, lineId)
}

PatientDialog(item, isNew) {
    global APP_NAME, SCHEDUI, REGUI
    accepted := false
    finished := false

    dlg := Gui("+AlwaysOnTop", APP_NAME (isNew ? " - 予定を追加" : " - 予定を編集") VerTag())
    dlg.MarginX := 16, dlg.MarginY := 6

    ; ★縦を詰める★
    ;   画面の小さい環境では、下の OK ボタンが画面外に出てしまう（2026-09-15 指摘）。
    ;   説明文は 1 行に収め、関連する入力は同じ行に並べること。
    W := 700

    ; --- 顧客 ---------------------------------------------------------------
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "w80", "顧客")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "x+6 yp+4 w" (W - 90) " cGray"
        , "検索欄と同じ氏名に（実行前に照合）／ミドルは比較用カードと区別するときだけ")
    dlg.SetFont("s10", "Meiryo UI")
    dlg.Add("Text", "xm+12 w30", "姓")
    eSei := dlg.Add("Edit", "x+4 yp-4 w100", item["sei"])
    dlg.Add("Text", "x+14 yp+4 w30", "名")
    eMei := dlg.Add("Edit", "x+4 yp-4 w100", item["mei"])
    dlg.Add("Text", "x+14 yp+4 w60", "ミドル")
    eMid := dlg.Add("Edit", "x+4 yp-4 w100", item.Has("middle") ? item["middle"] : "")
    cOn := dlg.Add("Checkbox", "x+24 yp+4 w200" (item["enabled"] ? " Checked" : "")
        , "この予定を有効にする")
    dlg.SetFont("s9", "Meiryo UI")

    ; --- この方へのお知らせ（V3）---------------------------------------------
    ;   ★連絡先は予定のファイルに書かない★ この PC の中だけに置く
    ; ★届け先は別の画面にまとめた★
    ;   LINE とメールの両方を扱うと、この画面の高さが上限（700）を超える。
    ;   連絡先どうしは関連が強いので、分けたほうが探しやすい（2026-10-03）。
    bTo := dlg.Add("Button", "xm+12 w230 h26", "お知らせの届け先")
    tTo := dlg.Add("Text", "x+10 yp+4 w400 cGray", ContactSummary(item["key"]))
    bTo.OnEvent("Click", (*) => OpenTo())

    OpenTo() {
        ; ★新しい予定でも、ここで結びつけ先を決めてしまう★
        ;   以前は「先に保存してください」と突き返していたが、
        ;   追加しながら届け先も入れたいのが自然（2026-10-05 指摘）。
        ;   姓が決まれば結びつけ先を作れるので、その場で割り当てる。
        if (IsBlankSchedKey(item["key"])) {
            if (Trim(eSei.Value) = "") {
                MsgBox("先に「姓」を入れてください。`n`n"
                    . "お名前が決まると、届け先を結びつけられます。"
                    , APP_NAME, "Icon! 4096")
                return
            }
            item["key"] := MakeSchedKey(Trim(eSei.Value), Trim(eMei.Value), SCHEDUI["list"])
            Log("INFO", "新しい予定の結びつけ先を決めました: " . item["key"])
        }
        ContactDialog(item["key"], Trim(eSei.Value . " " . eMei.Value))
        tTo.Value := ContactSummary(item["key"])
    }


    ; --- やること -------------------------------------------------------------
    dlg.Add("Text", "xm w" W " h1 0x10")
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "xm w" W, "実行内容")
    dlg.SetFont("s10", "Meiryo UI")
    cScan := dlg.Add("Checkbox", "xm+12 w150" (item["scan"] ? " Checked" : ""), "調査を行う")
    dlg.Add("Text", "x+20 yp w70", "セラピー")
    cntList := []
    Loop (CI("MaxUnattendedCycles") + 1)
        cntList.Push(String(A_Index - 1))
    dCnt := dlg.Add("DropDownList", "x+4 yp-4 w70", cntList)
    dCnt.Value := item["count"] + 1
    dlg.Add("Text", "x+6 yp+4 w30", "回")

    ; 調査タイプ／マニュアル選択（位置を教えてあれば選べる）
    ; 先頭は必ず「変更しない」。
    ;   マニュアル選択は【設定】ではなく【動作】で、押すと調査項目が選び直される。
    ;   「自動選択」を押したら項目が 1 つに減った（2026-09-16 実機）。
    ;   触らないでおけるようにしておく。
    stNames := OptNames("ScanType")
    mnNames := OptNames("Manual")
    stList  := [NoChangeLabel()]
    for nm in stNames
        stList.Push(nm)
    mnList := [NoChangeLabel(), NoneSelectLabel()]
    for nm in mnNames
        mnList.Push(nm)
    dlg.Add("Text", "xm+12 w70", "調査タイプ")
    dST := dlg.Add("DropDownList", "x+4 yp-4 w150", stList)
    SelectByName(dST, stList, OptLabelOf(item, "scantype"))
    dlg.Add("Text", "x+20 yp+4 w90", "マニュアル選択")
    dMN := dlg.Add("DropDownList", "x+4 yp-4 w170", mnList)
    SelectByName(dMN, mnList, OptLabelOf(item, "manual"))
    dlg.SetFont("s9", "Meiryo UI")
    ; ★説明文は、位置が未登録のときの知らせだけ★（縦を詰めるため。2026-10-11）
    ;   マニュアル選択は【押すと調査項目が選び直される動作】。迷ったら「（変更しない）」のまま。
    if (!stNames.Length || !mnNames.Length)
        dlg.Add("Text", "xm+12 w" (W - 12) " cRed"
            , "※ 位置が未登録です（設定 →「測定値を設定し直す」→「調査タイプ／マニュアル選択の位置を登録」）")
    dlg.SetFont("s10", "Meiryo UI")

    ; --- 繰り返し -------------------------------------------------------------
    dlg.Add("Text", "xm w" W " h1 0x10")
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "xm w" W, "繰り返しと実行方法")
    dlg.SetFont("s10", "Meiryo UI")
    rWeek := dlg.Add("Radio", "xm+12 w90" (item["mode"] = "weekly" ? " Checked" : ""), "毎週")
    dayBoxes := []
    Loop 7 {
        opt := (A_Index = 1 ? "x+0 yp w48" : "x+2 yp w48")
        dayBoxes.Push(dlg.Add("Checkbox", opt
            . (DaysInclude(item["days"], A_Index) ? " Checked" : ""), DayNumToName(A_Index)))
    }
    rIntv := dlg.Add("Radio", "xm+12 w90" (item["mode"] = "weekly" ? "" : " Checked"), "日数で")
    ivList := []
    Loop 30
        ivList.Push(String(A_Index))
    dIv := dlg.Add("DropDownList", "x+0 yp-4 w70", ivList)
    dIv.Value := (item["interval"] >= 1 && item["interval"] <= 30) ? item["interval"] : 3
    dlg.Add("Text", "x+8 yp+4 w280", "日おき（前回の実行日から数えます）")

    ; --- 実行方法（上の「繰り返し」と同じ見出しの下）-----------------------------
    dlg.Add("Text", "xm+12 w40", "時刻")
    hrList := []
    Loop 24
        hrList.Push(Format("{:02}", A_Index - 1))
    dHr := dlg.Add("DropDownList", "x+4 yp-4 w66", hrList)
    dHr.Value := ToInt(SubStr(item["time"], 1, 2), 21) + 1
    dlg.Add("Text", "x+4 yp+4 w12", ":")
    ; ★分の一覧を mnList と呼ばないこと★
    ;   2026-09-22 まで、マニュアル選択の一覧と同じ名前を使い回していた。
    ;   さらに選択欄も dMN（マニュアル選択）と dMn（分）で、AHK は
    ;   大文字小文字を区別しないため【同じ変数】になっていた。
    ;   そのため保存時に読んでいたのは分の番号で、
    ;   マニュアル選択で選んだ内容が毎回捨てられていた（利用者の指摘）。
    minList := []
    Loop 12
        minList.Push(Format("{:02}", (A_Index - 1) * 5))
    curMn := ToInt(SubStr(item["time"], 3, 2), 0)
    if (Mod(curMn, 5) = 0) {
        mnIdx := curMn // 5 + 1
    } else {                                        ; 5 分刻みでない値も失わない
        minList.Push(Format("{:02}", curMn))
        mnIdx := minList.Length
    }
    dMinute := dlg.Add("DropDownList", "x+2 yp-4 w66", minList)
    dMinute.Value := mnIdx

    isQueue := (item["timemode"] = "queue")
    rAt := dlg.Add("Radio", "x+24 yp+4 w220" (isQueue ? "" : " Checked"), "この時刻ちょうどに")
    rQu := dlg.Add("Radio", "x+0 yp w220" (isQueue ? " Checked" : ""), "以降、空いたら順番に")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "xm+12 w" (W - 12) " cGray"
        , "順番に＝前の方が長引いても、終わりしだい続けて実行。"
        . "開始の上限は、予定の一覧の設定に従います")

    ; --- 期間と回数 -----------------------------------------------------------
    ;   ★隠さない★（2026-10-11 指摘）。見出しだけを省いて縦を詰めた。
    dlg.Add("Text", "xm w" W " h1 0x10")
    dlg.SetFont("s10", "Meiryo UI")
    dlg.Add("Text", "xm+12 w50", "開始日")
    eSt := AddDateBox(dlg, "x+4 yp-4 w150", item["start"])
    dlg.Add("Text", "x+14 yp+4 w50", "終了日")
    eEn := AddDateBox(dlg, "x+4 yp-4 w150", item["end"])
    dlg.Add("Text", "x+18 yp+4 w40", "上限")
    ; ★一覧は 30 行まで（無制限＋1〜29）★ Windows の一覧は 30 行までしか出ず、
    ;   31 行あると先頭の「無制限」が上に隠れる（2026-10-11 指摘）。
    ;   30 回以上の予定は、その数を末尾に足して失わない。
    mrList := ["無制限"], mrVals := [0]
    Loop 29 {
        mrList.Push(String(A_Index))
        mrVals.Push(A_Index)
    }
    if (item["maxruns"] > 29) {
        mrList.Push(String(item["maxruns"]))
        mrVals.Push(item["maxruns"])
    }
    dMr := dlg.Add("DropDownList", "x+4 yp-4 w86", mrList)
    dMr.Value := 1
    for idx, val in mrVals {
        if (val = item["maxruns"])
            dMr.Value := idx
    }
    dlg.Add("Text", "x+6 yp+4 w60", "回で終了")

    dlg.Add("Text", "xm+12 w110", "遅れて起動したとき")
    cuList := ["制限なし", "30 分", "60 分", "120 分", "180 分", "360 分", "720 分"]
    cuVals := [0, 30, 60, 120, 180, 360, 720]
    dCu := dlg.Add("DropDownList", "x+4 yp-4 w100", cuList)
    dCu.Value := 4
    for idx, val in cuVals {
        if (val = item["catchup"])
            dCu.Value := idx
    }
    dlg.Add("Text", "x+6 yp+4 w120", "以内なら実行する")
    dCu.Enabled := !isQueue                        ; 順番待ちは、一覧の開始の上限に従う
    dlg.Add("Text", "x+10 yp w40", "メモ")
    eNote := dlg.Add("Edit", "x+4 yp-4 w220", item["note"])

    ; --- このとおりに実行されます ---------------------------------------------
    ; ★見出しは省く★ 青い文が「このとおりに実行されます」の内容（縦を詰めるため。2026-10-11）
    dlg.Add("Text", "xm w" W " h1 0x10")
    dlg.SetFont("s10", "Meiryo UI")
    tPrev := dlg.Add("Text", "xm w" W " h58 cBlue", "")

    ; --- ボタン（必ず 1 行に収める）-------------------------------------------
    dlg.SetFont("s10", "Meiryo UI")
    bHist := dlg.Add("Button", "xm w200 h40", "この顧客の実行履歴を削除")
    dlg.SetFont("s11 Bold", "Meiryo UI")
    bOk := dlg.Add("Button", "x+" (W - 200 - 160 - 160 - 20) " yp w160 h40 Default", "OK")
    dlg.SetFont("s10", "Meiryo UI")
    bNg := dlg.Add("Button", "x+20 yp w160 h40", "キャンセル")

    ; ★ラジオの間にチェックボックスを挟むと Windows のグループが切れる★
    ;   どちらも押せてしまうので、排他は自分で面倒を見る。
    rWeek.OnEvent("Click", (*) => PickMode(true))
    rIntv.OnEvent("Click", (*) => PickMode(false))
    rAt.OnEvent("Click",   (*) => PickTiming(true))
    rQu.OnEvent("Click",   (*) => PickTiming(false))

    ; 入力の種類ごとにイベント名が違う（Edit / DDL は Change、Checkbox は Click）
    for ctrl in [eSei, eMei, eMid, eSt, eEn]
        ctrl.OnEvent("Change", (*) => Preview())
    for ctrl in [dCnt, dST, dMN, dIv, dHr, dMinute, dMr, dCu]
        ctrl.OnEvent("Change", (*) => Preview())
    for ctrl in [cOn, cScan]
        ctrl.OnEvent("Click", (*) => Preview())
    for box in dayBoxes
        box.OnEvent("Click", (*) => Preview())

    bHist.OnEvent("Click", (*) => ResetHist())
    bOk.OnEvent("Click",   (*) => Accept())
    bNg.OnEvent("Click",   (*) => Cancel())
    dlg.OnEvent("Close",   (*) => Cancel())
    dlg.OnEvent("Escape",  (*) => Cancel())        ; Esc でキャンセル

    Preview()
    if (SCHEDUI.Has("dlg"))
        SCHEDUI["dlg"].Opt("+Disabled")            ; 編集中に一覧を触らせない
    ; 画面の上端から出す。小さい画面でも下のボタンが隠れにくいように。
    ;   （それでも入りきらない場合のために、Enter = OK / Esc = やめる が効く）
    dlg.Show("y6")
    ; タスクバーの分を除いた「使える高さ」と比べる（画面の高さそのものではなく）
    wkT := 0, wkB := A_ScreenHeight
    try MonitorGetWorkArea(, , &wkT, , &wkB)
    if (!IsSet(wkT))                           ; 失敗すると未設定に戻る
        wkT := 0
    if (!IsSet(wkB))
        wkB := A_ScreenHeight
    wh := 0
    try WinGetPos(, , , &wh, "ahk_id " dlg.Hwnd)
    if (!IsSet(wh))
        wh := 0
    if (wh > wkB - wkT - 6)
        Log("WARN", Format("編集画面の高さ {1}px が使える高さ {2}px に収まりません（拡大 {3}%）"
            . "（Enter で決定、Esc でキャンセル）", wh, wkB - wkT, Round(A_ScreenDPI / 96 * 100)))
    while (!finished)
        Sleep(60)
    REGUI := Map()                              ; もう受け取り先ではない
    try dlg.Destroy()                           ; ×で閉じた場合はすでに壊れている
    if (SCHEDUI.Has("dlg")) {
        try SCHEDUI["dlg"].Opt("-Disabled")
        try WinActivate("ahk_id " SCHEDUI["dlg"].Hwnd)
    }
    return accepted

    Cancel() {
        finished := true
    }

    PickMode(weekly) {
        rWeek.Value := weekly ? 1 : 0
        rIntv.Value := weekly ? 0 : 1
        Preview()
    }

    PickTiming(exact) {
        rAt.Value := exact ? 1 : 0
        rQu.Value := exact ? 0 : 1
        dCu.Enabled := exact
        Preview()
    }

    ; --- 画面の入力から Map を作る -------------------------------------------
    Collect() {
        out := Map()
        for k, v in item
            out[k] := v
        out["sei"]     := Trim(eSei.Value)
        out["mei"]     := Trim(eMei.Value)
        out["middle"]  := Trim(eMid.Value)
        out["enabled"] := (cOn.Value = 1)
        out["scan"]    := (cScan.Value = 1)
        out["count"]   := dCnt.Value - 1
        out["scantype"] := (dST.Value >= 2) ? stList[dST.Value] : ""
        out["manual"]   := (dMN.Value = 1) ? "" : ((dMN.Value = 2) ? "なし" : mnList[dMN.Value])
        out["mode"]    := (rWeek.Value = 1) ? "weekly" : "interval"
        days := ""
        for idx, box in dayBoxes {
            if (box.Value = 1)
                days .= (days = "" ? "" : ",") DayNumToName(idx)
        }
        out["days"]     := days
        out["interval"] := dIv.Value
        out["time"]     := hrList[dHr.Value] . minList[dMinute.Value]
        out["timemode"] := (rQu.Value = 1) ? "queue" : "at"
        out["start"]    := DateBoxValue(eSt)
        out["end"]      := DateBoxValue(eEn)
        out["maxruns"]  := mrVals[dMr.Value]
        out["catchup"]  := cuVals[dCu.Value]
        out["note"]     := Trim(eNote.Value)
        if (out["key"] = "")
            out["key"] := "Patient.（新規）"
        return out
    }

    ; --- 入力のたびに「結局どうなるか」を見せる ------------------------------
    Preview() {
        cur := Collect()
        lines := ""
        if (cur["start"] != "" && cur["end"] != "" && cur["end"] < cur["start"])
            lines .= "⚠ 終了日が開始日より前になっています`n"
        if (!ValidateEntry(cur, &why)) {
            tPrev.Opt("cRed")
            tPrev.Value := lines "⚠ " why
            tPrev.Redraw()
            return
        }
        tPrev.Opt("cBlue")
        lines .= NextDueText(cur) "`n"
        if (cur["timemode"] = "queue") {
            if (cur["time"] = "0000")
                lines .= "その日のうちに、空いたら実行します（時刻の指定なし）`n"
            else
                lines .= FmtHHMM(cur["time"]) " 以降に、空いたら実行します`n"
        }
        lines .= "1 回の所要 " EstimateText(cur["scan"], cur["count"])
        if (cur["maxruns"] > 0) {
            done := (cur["key"] = "Patient.（新規）") ? 0 : HistRunCount(cur["key"])
            left := Max(0, cur["maxruns"] - done)
            lines .= Format("    残り {1} 回（{2}/{3} 回 済み）", left, done, cur["maxruns"])
            if (cur["mode"] = "interval" && left > 0) {
                base := (cur["start"] != "") ? cur["start"] : FormatTime(A_Now, "yyyyMMdd")
                fin  := DateAdd(base "000000", cur["interval"] * (left - 1), "Days")
                lines .= "`n最後の回は " FormatTime(fin, "M月d日") " ごろの見込みです"
            }
        }
        ; ★「いま保存したらすぐ走る」かどうかを、その場で見せる★
        ;   2026-09-15、開始日=今日・06:00 以降・順番待ち の予定が、
        ;   設定した直後（19 時台）に走って驚かせてしまった。
        ;   仕様どおりだが、事前に分かるようにしておく。
        if (cur["enabled"] && DueNow(cur, &dw)) {
            lines .= "`n★ いまこの時点で条件を満たしています"
                  . "（運転を開始すると、すぐに始まります）"
        }
        tPrev.Value := lines
        tPrev.Redraw()
    }

    ResetHist() {
        if (IsBlankSchedKey(item["key"])) {
            MsgBox("まだ保存していない予定なので、履歴はありません。", APP_NAME, "Iconi 4096")
            return
        }
        ans := MsgBox(Format("「{1} {2}」の実行履歴（{3} 回）を削除します。`n`n"
            . "回数の上限に達した方を、もう一度はじめから実行したいときに使用します。`n"
            . "よろしいですか？", item["sei"], item["mei"], HistRunCount(item["key"]))
            , APP_NAME, "YesNo Icon? 4096")
        if (ans != "Yes")
            return
        HistReset(item["key"])
        Log("INFO", "実行履歴を消しました: " item["key"])
        Preview()
    }

    Accept() {
        cur := Collect()
        if (cur["enabled"] && !ValidateEntry(cur, &why)) {
            MsgBox("この内容では実行できません。`n`n" why
                . "`n`n（修正するか、「この予定を有効にする」のチェックを外してください）"
                , APP_NAME, "Iconx 4096")
            return
        }
        if (cur["sei"] = "" || cur["mei"] = "") {
            MsgBox("姓と名の両方を入れてください。", APP_NAME, "Iconx 4096")
            return
        }
        for k, v in cur {
            if (k = "key" && IsBlankSchedKey(v))
                continue
            item[k] := v
        }
        accepted := true
        finished := true
    }
}

;==============================================================================
;  確認待ち — 終わったことを見落とさないための控え
;==============================================================================
;  スケジュール運転が 1 人ぶん終わったら、その方へ結果を報告する必要がある
;  （LP の「3 日ごとの定期遠隔調律＆フォロー通知」）。
;
;  トレイ通知は数秒で消えるので、席を外していると気づけない。
;  ★終わったことは、こちらが ✓ を付けて消去するまで残す★
;  ファイルに持つので、ツールを再起動しても消えない。
;
;  1 行 = 完了時刻 | 成否 | 姓 | 名 | 内容
;==============================================================================

PendingLoad() {
    global PENDFILE
    out := []
    if !FileExist(PENDFILE)
        return out
    txt := ""
    try txt := FileRead(PENDFILE, "UTF-8")
    txt := StrReplace(txt, Chr(0xFEFF), "")
    for line in StrSplit(txt, "`n", "`r") {
        if (Trim(line) = "")
            continue
        f := StrSplit(line, "|")
        if (f.Length < 5)
            continue
        out.Push(Map("ts", f[1], "ok", f[2] = "1", "sei", f[3], "mei", f[4]
                   , "text", f[5], "raw", line))
    }
    return out
}

PendingSave(list) {
    global PENDFILE
    o := ""
    for it in list
        o .= it["raw"] "`n"
    try {
        if FileExist(PENDFILE)
            FileDelete(PENDFILE)
        if (o != "")
            FileAppend(CRLF(o), PENDFILE, "UTF-8")
    }
}

; ジョブが終わったところで積む（G をまだ初期化する前に呼ぶこと）
PendingAdd(ok) {
    global G, PENDFILE
    if (G.wantSei = "" && G.wantMei = "")
        return
    line := FormatTime(A_Now, "yyyyMMddHHmmss") "|" (ok ? "1" : "0")
          . "|" G.wantSei "|" G.wantMei "|" PendingText()
    try FileAppend(CRLF(line "`n"), PENDFILE, "UTF-8")
}

; 一覧に出す 1 行ぶんの内容
PendingText() {
    global G
    t := ""
    if (CB("RunInvestigation") && G.scanItems > 0)
        t := "調査 " FmtDur(G.scanSec) " / " G.scanItems " 項目"
    if (CI("TherapyCount") > 0)
        t .= (t = "" ? "" : " ＋ ") "セラピー " G.cycle " / " CI("TherapyCount") " 回"
    if (t = "")
        t := "（内容なし）"
    if (G.optWarn != "")
        t .= "　★" G.optWarn
    if (G.needCheck != "")
        t .= "　★要確認: " G.needCheck
    return t "　所要 " FmtDur(SecSince(G.startTS))
}

; 確認待ちの 1 行に出す、顧客へのお知らせの状態。失敗したジョブは、送らない（設計）
PendingNoticeText(it) {
    if (!it["ok"])
        return "—（失敗のため送りません）"
    return NotifyStatusText(it["sei"], it["mei"], it["ts"])
}

PendFmtTS(ts) {
    return (StrLen(ts) = 14) ? FormatTime(ts, "M/d HH:mm") : ts
}

;------------------------------------------------------------------------------
;  確認待ちの一覧（運転パネルから開く。運転は止まらない）
;------------------------------------------------------------------------------
ShowPendingDialog(*) {
    global APP_NAME, PENDUI
    if (PENDUI.Has("dlg")) {                       ; すでに開いていれば前面に出すだけ
        try {
            PENDUI["dlg"].Show()
            return
        }
    }
    list := PendingLoad()
    dlg := Gui("+AlwaysOnTop", APP_NAME " - 確認待ち" VerTag())
    dlg.MarginX := 16, dlg.MarginY := 12
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "w900", "確認待ち")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w900 cGray"
        , "実行が完了した分の控えです。内容を確認したら ✓ を付け、下のボタンで削除してください。"
        . "✓ を付けて消去するまで、運転パネルに出続けます。")
    dlg.SetFont("s10", "Meiryo UI")
    ; ★Checked を付けると各行にチェックボックスが出る★
    lv := dlg.Add("ListView", "xm w900 r10 Checked Grid", ["", "終了", "顧客", "顧客へのお知らせ", "内容"])
    for it in list {
        lv.Add("", it["ok"] ? "済" : "★失敗", PendFmtTS(it["ts"])
             , it["sei"] " " it["mei"], PendingNoticeText(it), it["text"])
    }
    lv.ModifyCol(1, 50), lv.ModifyCol(2, 90), lv.ModifyCol(3, 120), lv.ModifyCol(4, 250), lv.ModifyCol(5, 360)

    dlg.SetFont("s10", "Meiryo UI")
    lblCnt := dlg.Add("Text", "xm w900 cGray", "")
    lblQ   := dlg.Add("Text", "xm w900 cGray", NotifyQueueSummary())

    bDone := dlg.Add("Button", "xm w260 h40 Default", "✓ の行を確認済みにする")
    bAll  := dlg.Add("Button", "x+10 yp w200 h40", "すべてに ✓ を付ける")
    bCls  := dlg.Add("Button", "x+10 yp w200 h40", "閉じる")
    bDone.OnEvent("Click", (*) => ClearChecked())
    bAll.OnEvent("Click",  (*) => CheckAll())
    bCls.OnEvent("Click",  (*) => Close())
    lv.OnEvent("ItemCheck", (*) => UpdateCount())
    dlg.OnEvent("Close",  (*) => Close())
    dlg.OnEvent("Escape", (*) => Close())
    PENDUI["dlg"] := dlg
    PENDUI["lv"]  := lv
    UpdateCount()
    dlg.Show()
    return

    ; いま何件あって、何件に ✓ が付いているか
    UpdateCount() {
        total := lv.GetCount()
        done  := 0, row := 0
        Loop {
            row := lv.GetNext(row, "Checked")
            if (!row)
                break
            done++
        }
        if (total = 0)
            lblCnt.Value := "確認待ちはありません。"
        else
            lblCnt.Value := Format("全 {1} 件　／　✓ を付けた行 {2} 件", total, done)
        lblCnt.Redraw()
    }

    CheckAll() {
        Loop lv.GetCount()
            lv.Modify(A_Index, "Check")
        UpdateCount()
    }

    ClearChecked() {
        checked := [], row := 0
        Loop {
            row := lv.GetNext(row, "Checked")
            if (!row)
                break
            checked.Push(row)
        }
        if (checked.Length = 0) {
            MsgBox("確認できた行に ✓ を付けてください。", APP_NAME, "Icon! 4096")
            return
        }
        cur := PendingLoad()
        ; ★後ろの行から消す★ 先頭から消すと、以降の行番号がずれる
        idx := checked.Length
        while (idx >= 1) {
            r := checked[idx]
            if (r <= cur.Length) {
                Log("INFO", "確認済みにしました: " cur[r]["sei"] " " cur[r]["mei"])
                cur.RemoveAt(r)
            }
            lv.Delete(r)
            idx--
        }
        PendingSave(cur)
        RefreshPanelPending(true)
        UpdateCount()
    }

    Close() {
        global PENDUI
        try dlg.Destroy()
        PENDUI.Delete("dlg")
        PENDUI.Delete("lv")
    }
}

; 運転パネルの「確認待ち」行を作る
PendingPanelText() {
    list := PendingLoad()
    if (list.Length = 0)
        return "確認待ちはありません"
    ; ★欄に収まるぶんだけ出す★
    ;   5 件のとき 5 行書いていたが、欄は 2 行ぶんしかなく、
    ;   名前が途中で切れて表示されていた（2026-10-06 の画面）。
    ;   一目で見る場所なので件数と先頭だけにして、中身はクリックで開く。
    out := "★ 未確認 " list.Length " 件　← クリックで開く"
    it := list[1]
    line := "　・" it["sei"] " " it["mei"] "　" PendFmtTS(it["ts"])
          . (it["ok"] ? "" : "　失敗")
    if (list.Length > 1)
        line .= "　ほか " (list.Length - 1) " 件"
    return out . "`n" . line
}

RefreshPanelPending(force := false) {
    global G
    static lastTS := ""
    if (G.panelPend = "")
        return
    if (!force && lastTS != "" && SecSince(lastTS) < 3)
        return                                      ; 毎秒ファイルを読まない
    lastTS := A_Now
    t := PendingPanelText()
    G.panelPend.Value := t
    G.panelPend.Opt(InStr(t, "★") ? "cRed" : "cGray")
    G.panelPend.Redraw()
}

;==============================================================================
;  運転パネル — 動いていることが「ひと目で分かる」ようにする
;
;  トレイ常駐だけだと、Windows がトレイアイコンを隠すため
;  動いているのか止まっているのか分からない（カマヤン指摘 2026-09-14）。
;  タスクバーに出る小さな窓を常に表示する。
;==============================================================================

; トレイから呼ばれたとき。最小化しているなら元に戻し、無ければ作る
RestorePanel() {
    global G
    if (G.panel != "") {
        try G.panel.Restore()
        try WinActivate("ahk_id " G.panel.Hwnd)
        return
    }
    ShowPanel()
}

ShowPanel() {
    ; ★ローカル変数に g を使ってはいけない★
    ;   AHK は大文字小文字を区別しないため、g := Gui(...) がグローバルの G（実行時状態）を
    ;   丸ごと上書きしてしまう。2026-09-14 に「Gui に schedOn がありません」で落ちた原因。
    global G, APP_NAME, APP_VER
    if (G.panel != "")
        return
    pnl := Gui("+AlwaysOnTop +Resize", APP_NAME VerTag())
    ; ★タスクバーのボタンを必ず持たせる★（WS_EX_APPWINDOW）
    ;   2026-09-22、×で引っ込めるとタスクバーからも消え、動いているのか
    ;   分からなくなった。この指定があれば、最小化しても必ず残る。
    try pnl.Opt("+E0x40000")
    pnl.MarginX := 14, pnl.MarginY := 10
    pnl.BackColor := "FFFFFF"

    pnl.SetFont("s12 Bold", "Meiryo UI")
    G.panelState := pnl.Add("Text", "w400 cGreen", "● 準備中")

    pnl.SetFont("s10", "Meiryo UI")
    G.panelWho := pnl.Add("Text", "w400", "顧客 : -")
    G.panelJob := pnl.Add("Text", "w400", "")
    pnl.SetFont("s9", "Meiryo UI")
    G.panelSub := pnl.Add("Text", "w400 cGray", "")

    pnl.Add("Text", "w400 h1 0x10")
    pnl.SetFont("s10 Bold", "Meiryo UI")
    G.panelPend := pnl.Add("Text", "w400 h58 cRed +0x100", "")   ; 0x100 = クリックを拾う
    G.panelPend.OnEvent("Click", ShowPendingDialog)
    pnl.Add("Text", "w400 h1 0x10")
    pnl.SetFont("s9", "Meiryo UI")
    ; ★人数が増えても全員読めるように、スクロールできる欄にする★
    ;   （Text だと入りきらない。2026-09-15 指摘）
    G.panelNext := pnl.Add("Edit", "w400 h130 ReadOnly -WantReturn +VScroll cGray", "")

    pnl.SetFont("s10", "Meiryo UI")
    bMenu := pnl.Add("Button", "w94 h34", "メニュー")
    bStop := pnl.Add("Button", "x+8 yp w94 h34", "止める")
    bLog  := pnl.Add("Button", "x+8 yp w94 h34", "ログ")
    bHide := pnl.Add("Button", "x+8 yp w94 h34", "隠す")
    G.panelBtns := [bMenu, bStop, bLog, bHide]
    bMenu.OnEvent("Click", (*) => OpenMenuWindow())
    bStop.OnEvent("Click", (*) => PanelStop())
    bLog.OnEvent("Click", (*) => OpenLogReportWindow())
    bHide.OnEvent("Click", (*) => pnl.Minimize())
    ; ★×では止めない★
    ;   閉じるボタンで運転ごと終わっていた。誤って押すとスケジュールが機能しない
    ;   （2026-09-17 指摘）。×は「隠す」だけにして、止めるのは
    ;   「止める」ボタンとトレイの終了だけにする。
    pnl.OnEvent("Close", (*) => PanelHide())

    pnl.OnEvent("Size", PanelResize)               ; 広げたら予定欄も伸びる
    ; ★出してから、実際の大きさを測って置き直す★
    ;   画面の高さから 500 を引いた決め打ちだったため、解像度や文字の
    ;   拡大率が違うと中途半端な位置に出ていた（2026-09-22 指摘）。
    ;   ★隠したままでは実寸が取れない★ 出してから測る。
    ;   いったん既定の位置に出て、すぐ右下へ動くように見えるが、
    ;   拡大率に関係なく必ず画面内へ収まる方を取る。
    pnl.Show("NoActivate w430")
    PanelPlace(pnl)
    G.panel := pnl
    SetTimer(UpdatePanel, 1000)
    UpdatePanel()
}

; ★運転パネルの置き場所★
;   ふだんは「作業領域の右下」。タスクバーにも画面の外にもはみ出さない。
;   前に人が動かしていたら、その場所を覚えていて、そこに出す。
PanelPlace(pnl) {
    global G
    ; ★毎回かならず「作業領域の右下」に置く★
    ;   2026-09-22、位置を覚える仕組みを入れたところ、真ん中に出た版の
    ;   位置を覚えてしまい、直したあとも真ん中に出続けた。
    ;   覚える機能は外した。出る場所が毎回同じ方が、迷いようがない。
    ; ★WinGetPos は失敗すると、渡した変数を「未設定」に戻す★
    w := 0, h := 0
    try WinGetPos(, , &w, &h, "ahk_id " pnl.Hwnd)
    if (!IsSet(w) || w <= 0)
        w := 430
    if (!IsSet(h) || h <= 0)
        h := 460
    ; ★対象ソフトが出ている画面の右下に置く★ 別のモニタに飛ばさない
    n := 1
    try {
        if (G.pid) {
            for wn in TargetWindows(G.pid) {
                n := MonitorOfWindow(wn["hwnd"])   ; いちばん手前の窓に合わせる
                break
            }
        }
    }
    l := 0, t := 0, r := A_ScreenWidth, b := A_ScreenHeight
    try MonitorGetWorkArea(n, &l, &t, &r, &b)
    if (!IsSet(l) || !IsSet(t) || !IsSet(r) || !IsSet(b))
        l := 0, t := 0, r := A_ScreenWidth, b := A_ScreenHeight
    x := r - w - 16
    y := b - h - 16
    if (x < l)
        x := l
    if (y < t)
        y := t
    ; ★動かすのは WinMove★ Gui.Move() は拡大率のかかった単位で動くため
    try WinMove(x, y, , , "ahk_id " pnl.Hwnd)
    ; ★測った値をログに残す★ ずれたときに、推測ではなく数字で追えるように
    gx := 0, gy := 0
    try WinGetPos(&gx, &gy, , , "ahk_id " pnl.Hwnd)
    if (!IsSet(gx))
        gx := -1
    if (!IsSet(gy))
        gy := -1
    Log("DEBUG", Format("パネル配置: 大きさ {1}x{2} ／ 画面{3} の作業領域 "
        . "{4},{5}-{6},{7} ／ 狙い {8},{9} ／ 実際 {10},{11} ／ 拡大 {12}%"
        , w, h, n, l, t, r, b, x, y, gx, gy, Round(A_ScreenDPI / 96 * 100)))
}

; どのモニタに出ている窓か
MonitorOfWindow(hwnd) {
    wx := 0, wy := 0, ww := 0, wh := 0
    try WinGetPos(&wx, &wy, &ww, &wh, "ahk_id " hwnd)
    if (!IsSet(wx) || !IsSet(wy) || !IsSet(ww) || !IsSet(wh))
        return 1
    cx := wx + ww // 2, cy := wy + wh // 2
    Loop MonitorGetCount() {
        l := 0, t := 0, r := 0, b := 0
        try MonitorGet(A_Index, &l, &t, &r, &b)
        if (!IsSet(l) || !IsSet(t) || !IsSet(r) || !IsSet(b))
            continue
        if (cx >= l && cx < r && cy >= t && cy < b)
            return A_Index
    }
    return 1
}

; 窓を広げたら、予定欄を伸ばしてボタンを下へ送る
;   人数が増えると予定欄を大きくしたくなるため（2026-09-15）
PanelResize(pnl, minMax, w, h) {
    global G
    if (minMax = -1 || G.panel = "" || G.panelNext = "")
        return
    try {
        m := 14, btnH := 34
        G.panelNext.GetPos(, &ny)
        newH := h - ny - btnH - m * 2
        if (newH < 60)
            newH := 60
        G.panelNext.Move(, , w - m * 2, newH)
        by := ny + newH + 10
        bw := (w - m * 2 - 24) // 4
        for idx, b in G.panelBtns
            b.Move(m + (idx - 1) * (bw + 8), by, bw, btnH)
    }
}

PanelStop() {
    global G, APP_NAME
    ; 手動の自動セラピー中は、そのぶんだけ止めて、スケジュール運転は続ける
    if (G.manualJob) {
        Finish(3, "パネルの「止める」が押されました（自動セラピー）")
        return
    }
    if (G.schedOn) {
        if (G.schedRunning) {
            ans := MsgBox("いま実行中のジョブごと、スケジュール運転を終了します。`n`n"
                . "　顧客: " G.wantSei " " G.wantMei "`n`n"
                . "よろしいですか？", APP_NAME, "YesNo Icon! 4096")
            if (ans != "Yes")
                return
        }
        StopScheduler("パネルの「止める」が押されました")
        return
    }
    Finish(3, "パネルの「止める」が押されました")
}

; ×で閉じられたとき。運転は続けたまま、パネルだけ引っ込める
;   ★消さずに最小化する★
;     2026-09-22 指摘。消してしまうとタスクバーからも居なくなり、
;     裏で動いているのかどうかが分からない。最小化なら、
;     タスクバーに残るので「動いている」と一目で分かり、押せば戻る。
PanelHide() {
    global G, APP_NAME
    if (G.panel != "") {
        try G.panel.Minimize()
        try TrayTip((G.schedOn ? "スケジュール運転は続いています" : "実行は続いています") "`n"
            . "タスクバーに残してあります。押すと元に戻ります。", APP_NAME)
        ; ★1 を返して、AHK の既定の動き（窓を隠す）を止める★
        ;   2026-09-22、最小化したそばから AHK が窓を隠していた。
        ;   そのためタスクバーから消え、トレイにしか残らなかった。
        return 1
    }
    ClosePanel()
    return 0
}

ClosePanel() {
    global G
    SetTimer(UpdatePanel, 0)
    if (G.panel != "") {
        try G.panel.Destroy()
        G.panel := ""
        G.panelPend := ""
    }
}

UpdatePanel() {
    global G
    if (G.panel = "")
        return
    ; --- 1 行目: いま何をしているか -------------------------------------------
    if (G.schedOn && !G.schedRunning && !G.appAlive) {
        ; ★落ちていることを、待機中より前に出す★（2026-09-24 指摘）
        G.panelState.Opt("cRed")
        down := (G.appDownTS = "") ? "" : ("／" . FmtDur(SecSince(G.appDownTS)) . " 前から")
        G.panelState.Value := "⚠ 対象ソフトが起動していません" . down
    } else if (G.schedOn && !G.schedRunning) {
        G.panelState.Opt("cGray")
        waitMsg := "◌ 待機中（予定の時刻を待っています）"
        pend := NotifyOn() ? NotifyPendingCount() : 0
        wait := NotifyOn() ? NotifyWaitingCount() : 0
        if (wait > 0)
            waitMsg .= "／あとで送る " . wait . " 件"
        if (pend - wait > 0)
            waitMsg .= "／未送信 " . (pend - wait) . " 件"
        G.panelState.Value := waitMsg
    } else if (G.state = "therapy_run") {
        G.panelState.Opt("cRed")
        G.panelState.Value := G.manualJob ? "● 自動セラピー実行中（手動）" : "● セラピー実行中"
    } else if (G.state = "scan_running") {
        G.panelState.Opt("cBlue")
        G.panelState.Value := "● 調査中"
    } else if (G.state = "verify") {
        G.panelState.Opt("cBlue")
        G.panelState.Value := "● 氏名を確認中"
    } else if (G.state = "idle" || G.state = "") {
        G.panelState.Opt("cGray")
        G.panelState.Value := "◌ 準備中"
    } else {
        G.panelState.Opt("cBlue")
        G.panelState.Value := "● 動作中（" . StateLabel(G.state) . "）"
    }

    ; --- 2 行目: 顧客 -------------------------------------------------------
    if (G.wantSei = "") {
        G.panelWho.Value := "顧客 : -"
    } else {
        mark := (G.gotSei = "") ? "" : "  ✓ 照合 OK"
        G.panelWho.Value := "顧客 : " . G.wantSei . " " . G.wantMei . mark
    }

    ; --- 3 行目: 進捗 ---------------------------------------------------------
    t := ""
    if (G.schedOn && !G.schedRunning) {
        t := "本日  完了 " . G.schedDone . " / 要確認 " . G.schedCheck
           . " / 失敗 " . G.schedFailed . " / 見送り " . G.schedSkipped
    } else if (CB("RunInvestigation") && G.scanSec = 0 && G.scanItems > 0) {
        t := "調査 " . G.scanItems . " 項目目"
    } else if (CI("TherapyCount") > 0) {
        t := "セラピー " . G.cycle . " / " . CI("TherapyCount") . " 回"
        if (G.state = "therapy_run")
            t .= "    経過 " . FmtDur(SecSince(G.cycleStartTS))
    } else if (G.scanSec > 0) {
        t := "調査 完了 " . FmtDur(G.scanSec) . " / " . G.scanItems . " 項目"
    }
    G.panelJob.Value := t

    ; --- 4 行目: 補足 ---------------------------------------------------------
    sub := ""
    if (G.startTS != "" && !(G.schedOn && !G.schedRunning))
        sub := "経過 " . FmtDur(SecSince(G.startTS))
    if (CB("DryRun"))
        sub .= (sub = "" ? "" : "    ") . "※ DryRun（何も押しません）"
    G.panelSub.Value := sub

    ; --- 確認待ち -------------------------------------------------------------
    RefreshPanelPending()                          ; 中で 3 秒に 1 回だけ読む

    ; --- 予定 -----------------------------------------------------------------
    if (G.schedOn) {
        ; 予定の判定は state.ini を読むので、毎秒はやらない
        if (G.panelNextTS = "" || SecSince(G.panelNextTS) >= 10) {
            G.panelNextTS := A_Now
            G.panelNext.Value := CRLF(NextUpText())
        }
    } else {
        G.panelNext.Value := "1 人だけの実行です（スケジュール運転ではありません）"
    }
    G.panelState.Redraw()
}

; 状態名を日本語に
StateLabel(st) {
    static m := Map(
        "homing","起点へ戻しています", "open_index","患者一覧を開いています",
        "search","検索しています",     "pick_row","カードを開いています",
        "verify","氏名を確認中",       "scan_open","調査を開こうとしています",
        "scan_anamnesis","既往症画面を通過中", "scan_scheme","スキーム画面を待っています",
        "scan_type","調査タイプを設定中", "scan_manual","マニュアル選択を設定中",
        "scan_go","調査を開始しています", "scan_running","調査中",
        "scan_dialog","完了の確認中",   "scan_check","実行を確認中",
        "therapy_ready","セラピーの準備中", "therapy_click","セラピーを開始します",
        "therapy_start","開始を確認中", "therapy_run","セラピー実行中",
        "therapy_rest","次まで待機中",  "cleanup","後始末中")
    return m.Has(st) ? m[st] : st
}

; 次に実行される予定を 1 行で
; パネルに出す予定の一覧。
;   ★有効な予定は全員ぶん出す★
;     以前は先頭 2 件で切っていたため、3 人目を足した方が
;     「追加したのに出てこない」と見えてしまった（2026-09-15 指摘）。
;   併せて「なぜ今ではないのか」を DueNow の理由でそのまま見せる。
NextUpText() {
    global G
    list := LoadSchedule(&err)
    if (err != "")
        return err
    out := "", n := 0
    doneNames := []
    for p in list {
        if (!p["enabled"])
            continue
        n++
        ; ★終わった予定は 1 行にまとめる★
        ;   上限に到達した方が並ぶと、実行中・順番待ちが押し出されて読めない
        ;   （2026-10-06 指摘。予定の編集の絞り込みと同じ判定を使う）。
        if (SchedIsDone(p)) {
            doneNames.Push(Trim(p["sei"] . " " . p["mei"]))
            continue
        }
        mark := (G.schedRunning && p["key"] = G.schedCurrent) ? "▶" : "・"
        why  := ""
        if (G.schedRunning && p["key"] = G.schedCurrent)
            why := "実行中"
        else if (DueNow(p, &w2))
            why := G.pcBusy ? "順番待ち（PC の使用中のため待機）" : "順番待ち"
        else
            why := w2
        out .= (out = "" ? "" : "`n") . mark " " p["sei"] " " p["mei"] "　" why
    }
    if (doneNames.Length > 0) {
        head := ""
        for i, nm in doneNames {
            if (i > 3)
                break
            head .= (head = "" ? "" : "・") . nm
        }
        if (doneNames.Length > 3)
            head .= " ほか " . (doneNames.Length - 3) . " 名"
        out .= (out = "" ? "" : "`n")
             . "・終わった予定 " . doneNames.Length . " 件（" . head . "）"
    }
    return (out = "") ? "有効な予定がありません" : out
}
;==============================================================================
;  /listread  ★氏名照合ゲート（G1）が実装できるかを判定する★
;  読み取り専用。唯一「検索欄への入力テスト」だけは確認を取ってから行い、
;  終わったら必ず入力を消す。
;==============================================================================
ModeListRead() {
    global C, CFG, APP_NAME
    pid := EnsureTarget()
    wins := TargetWindows(pid)
    if (wins.Length = 0) {
        MsgBox("対象ウィンドウが表示されていません。最小化していないか確認してください。", APP_NAME, "Icon! 4096")
        ReopenAndExit(1)
    }

    out := "=== AutoMeta /listread  読み取り可否レポート ===`n"
    out .= FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss") "`n"
    out .= "対象: " CS("ExeName") " (pid " pid ")  権限: " (A_IsAdmin ? "管理者" : "通常ユーザー") "`n`n"

    foundIndex := 0, foundCard := 0
    verdict := []

    for w in wins {
        rows := DumpCtrls(w["hwnd"])
        cls  := ClassifyScreen(w["hwnd"], rows)
        out .= "── ウィンドウ: 「" w["title"] "」  class=" w["class"] "  判定=" cls["id"]
             . (cls["hit"] = "" ? "" : "（『" cls["hit"] "』を検出）") "`n"
        out .= CtrlsToText(rows)
        out .= "`n"

        if (cls["id"] = "S1_Index" && !foundIndex) {
            foundIndex := w["hwnd"]
            out .= AnalyzeIndex(w["hwnd"], rows, &verdict)
        }
        if (cls["id"] = "S2_Card" && !foundCard) {
            foundCard := w["hwnd"]
            out .= AnalyzeCard(w["hwnd"], rows, &verdict)
        }
    }

    if (!foundIndex)
        verdict.Push("[--] カードインデックス（一覧）が開いていないため未判定です")
    if (!foundCard)
        verdict.Push("[--] カード画面が開いていないため未判定です（★G1 の可否はここで決まります）")

    out .= "`n======================================================================`n"
    out .= "■ 判定`n"
    for v in verdict
        out .= "  " v "`n"
    out .= "`n■ この結果の読み方`n"
    out .= "  ・姓と名が読めた   → G1（氏名照合ゲート）を実装できます。顧客の自動選択に進めます`n"
    out .= "  ・姓と名が読めない → 顧客の自動選択は【行いません】。`n"
    out .= "                       人が顧客を開いてから調査＋セラピーを自動実行する半自動版にします`n"
    out .= "  ・一覧が読めた     → 方式 B（行を読んで選ぶ）が使えます`n"
    out .= "  ・検索欄があった   → 方式 A（氏名で絞り込む）が使えます。これが第 1 候補です`n"

    path := A_ScriptDir "\listread.txt"
    try FileDelete(path)
    FileAppend(CRLF(out), path, "UTF-8")

    msg := "判定結果`n`n"
    for v in verdict
        msg .= "  " v "`n"
    msg .= "`n詳細は listread.txt に出力しました。`n"
    msg .= "★このファイルの中身をそのまま Claude に貼ってください。`n`n"
    msg .= "続けて「検索欄への入力テスト」を行いますか？`n"
    msg .= "（検索欄に文字を入力して絞り込めるかを確認し、終了後に削除します。`n"
    msg .= " 　ソフトのデータは一切変更しません）"

    if (foundIndex && MsgBox(msg, APP_NAME " - 判定", "YesNo Icon? 4096") = "Yes") {
        TestSearchBox(foundIndex)
    } else if (!foundIndex) {
        MsgBox(msg, APP_NAME " - 判定", "Iconi 4096")
    }
    OpenFile(path)
    ReopenAndExit(0)
}

; 一覧画面の分析
AnalyzeIndex(hwnd, rows, &verdict) {
    out := "     ▼ カードインデックス（一覧）の分析`n"
    edits := [], lists := []
    for r in rows {
        cn := r["cnn"]
        if (RegExMatch(cn, "i)edit"))
            edits.Push(r)
        if (RegExMatch(cn, "i)listview|listbox|SysListView|grid|TStringGrid|TListBox|TDBGrid"))
            lists.Push(r)
    }
    if (edits.Length > 0) {
        out .= "       [OK] 入力欄（検索欄の候補）が " edits.Length " 件`n"
        for r in edits
            out .= "            - " . r["cnn"] . Format("  x{1} y{2} w{3} h{4}", r["x"], r["y"], r["w"], r["h"]) . "`n"
        verdict.Push("[OK] 検索欄の候補あり → 方式 A（氏名で絞り込む）が使える可能性が高い")
        IniSet(A_ScriptDir "\config.ini", "Select", "SearchBoxClassNN", edits[1]["cnn"])
    } else {
        out .= "       [NG] 入力欄が 1 つも見つかりません（検索欄は描画かもしれません）`n"
        verdict.Push("[NG] 検索欄がコントロールとして見つからない → 方式 A は不可")
    }

    if (lists.Length > 0) {
        for r in lists {
            out .= "       [??] 一覧の候補: " r["cnn"] "`n"
            content := ""
            try content := ListViewGetContent("", r["cnn"], "ahk_id " hwnd)
            catch                                   ; ListView でなければ例外になる＝読めない
                content := ""
            if (content != "") {
                n := 0
                Loop Parse, content, "`n", "`r" {
                    if (A_LoopField = "")
                        continue
                    n++
                    if (n <= 5)
                        out .= "            " n ": " A_LoopField "`n"
                }
                out .= "       [OK] " n " 行を読み取れました`n"
                verdict.Push("[OK] 一覧の行を読める（" r["cnn"] " / " n " 行）→ 方式 B が使える")
                IniSet(A_ScriptDir "\config.ini", "Select", "ListClassNN", r["cnn"])
            } else {
                out .= "       [NG] " r["cnn"] " の中身は読み取れません（Delphi の独自描画グリッドの可能性）`n"
            }
        }
    } else {
        out .= "       [NG] 一覧に相当するコントロールが見つかりません`n"
        verdict.Push("[NG] 一覧がコントロールとして見つからない → 方式 B は不可。方式 C（座標）＋ G1 で対応")
    }
    return out "`n"
}

; カード画面の分析（★ここが G1 の可否を決める★）
AnalyzeCard(hwnd, rows, &verdict) {
    out := "     ▼ カード画面の分析（★氏名照合ゲート G1 の可否★）`n"
    edits := []
    for r in rows {
        if (RegExMatch(r["cnn"], "i)edit") && r["x"] != "")
            edits.Push(r)
    }
    if (edits.Length = 0) {
        out .= "       [NG] 入力欄が 1 つも見つかりません`n"
        verdict.Push("[NG] ★カード画面の姓名が読めません → 顧客の自動選択は行いません（半自動版へ）")
        return out "`n"
    }
    ; 上から順に並べ替え、左側の列にある上位 2 件を 姓 / 名 の候補とする
    sorted := []
    for r in edits
        sorted.Push(r)
    Loop sorted.Length - 1 {
        i := A_Index
        Loop sorted.Length - i {
            j := A_Index
            if (sorted[j]["y"] > sorted[j + 1]["y"]) {
                tmp := sorted[j], sorted[j] := sorted[j + 1], sorted[j + 1] := tmp
            }
        }
    }
    out .= "       入力欄（上から順）:`n"
    withText := 0
    for r in sorted {
        tx := Trim(r["text"])
        if (tx != "")
            withText++
        out .= Format("            - {1:-16} x{2} y{3}  値=「{4}」`n", r["cnn"], r["x"], r["y"], tx)
    }
    ; 姓・名の欄を選ぶ。DB 連動の入力欄（TDBEdit）を上から 2 件とるのが最も確実。
    ; 実機では TDBEdit3(y20)=姓 / TDBEdit5(y63)=名 だった。
    ; 検索欄は素の TEdit なので、この選び方なら自然に除外できる。
    dbeds := []
    for r in sorted {
        if RegExMatch(r["cnn"], "i)dbedit")
            dbeds.Push(r)
    }
    a := 0, b := 0, how := ""
    if (dbeds.Length >= 2) {
        a := dbeds[1], b := dbeds[2]
        how := "DB 連動の入力欄（TDBEdit）を上から 2 件"
    } else if (withText >= 2) {
        filled := []
        for r in sorted {
            if (Trim(r["text"]) != "")
                filled.Push(r)
        }
        a := filled[1], b := filled[2]
        how := "中身の入っている入力欄を上から 2 件"
    }
    if !IsObject(a) {
        out .= "       [NG] 姓・名にあたる入力欄を特定できません（権限不足かもしれません）`n"
        verdict.Push("[NG] ★姓名を読み取れません → 管理者版で再実行してください。それでも駄目なら半自動版へ")
        return out "`n"
    }
    ta := Trim(a["text"]), tb := Trim(b["text"])
    out .= "       採用基準: " how "`n"
    out .= "       [OK] 姓の欄: " a["cnn"] " =「" ta "」`n"
    out .= "       [OK] 名の欄: " b["cnn"] " =「" tb "」`n"
    IniSet(A_ScriptDir "\config.ini", "Select", "LastNameFieldClassNN", a["cnn"])
    IniSet(A_ScriptDir "\config.ini", "Select", "FirstNameFieldClassNN", b["cnn"])
    ; ★3 つ目の入力欄はミドルネーム★（姓 / 名前 / ミドルネーム の順に並んでいる）
    ;   同姓同名で「ミドルネームだけ違う比較用カード」を見分けるのに使う。
    if (dbeds.Length >= 3) {
        IniSet(A_ScriptDir "\config.ini", "Select", "MiddleNameFieldClassNN", dbeds[3]["cnn"])
        out .= "       [OK] ミドルの欄: " dbeds[3]["cnn"] " =「" Trim(dbeds[3]["text"]) "」`n"
    } else {
        out .= "       [??] ミドルネームの欄は見つかりませんでした`n"
    }
    if (ta = "" || tb = "") {
        out .= "       [??] 欄は特定できましたが中身が空です。顧客のカードを開いた状態で実行してください`n"
        verdict.Push("[??] 姓名の欄は見つかりましたが中身が空でした（カードを開いてから再実行）")
    } else {
        out .= "       ★ この 2 つが画面の 姓 / 名 と一致していれば、G1 を実装できます`n"
        verdict.Push("[OK] ★姓名を読み取れました（" ta " / " tb "）→ G1 実装可能")
    }
    return out "`n"
}

; 検索欄への入力テスト（確認済みのときだけ実行し、必ず元に戻す）
TestSearchBox(hwnd) {
    global C, APP_NAME
    cn := IniGet(IniLoad(A_ScriptDir "\config.ini"), "Select", "SearchBoxClassNN", "")
    if (cn = "") {
        MsgBox("検索欄の候補が記録されていないためテストできません。", APP_NAME, "Icon! 4096")
        return
    }
    word := ""
    ib := InputBox("検索欄に入力して試す文字を指定してください。`n（顧客の姓など。あとで自動的に削除します）"
                 , APP_NAME " - 入力テスト", "w480 h160")
    if (ib.Result != "OK" || Trim(ib.Value) = "")
        return
    word := Trim(ib.Value)

    before := SnapText(hwnd)
    ok := false
    try {
        ControlSetText(word, cn, "ahk_id " hwnd)
        ControlFocus(cn, "ahk_id " hwnd)
        ok := true
    }
    if (!ok) {
        MsgBox("検索欄に入力できませんでした（権限不足か、コントロールではない可能性）。", APP_NAME, "Icon! 4096")
        return
    }
    Sleep(1500)
    after := SnapText(hwnd)
    changed := (before != after)

    ; 必ず元に戻す
    try ControlSetText("", cn, "ahk_id " hwnd)
    Sleep(400)

    if (changed) {
        res := "[OK] 入力したら画面の表示が変わりました → 検索欄として使えます"
    } else {
        res := "[??] 入力しても表示が変わりませんでした（Enter が必要／別の欄かもしれません）"
    }
    MsgBox("入力テストの結果`n`n  検索欄: " cn "`n  入力した文字: " word "`n`n  " res "`n`n"
        . "入力した文字は削除しました。", APP_NAME, "Iconi 4096")
    try FileAppend(CRLF("`n[検索欄テスト] " cn " に「" word "」を入力 → " res "`n")
                 , A_ScriptDir "\listread.txt", "UTF-8")

    SnapText(h) {
        s := ""
        rows := DumpCtrls(h)
        for r in rows
            s .= r["cnn"] "=" r["text"] "|"
        return s
    }
}

;==============================================================================
;  /pickrow  患者一覧の「先頭行」の位置を実測して記録する
;  ★推測で座標を置かない。v4 の /pickpos と同じ考え方★
;==============================================================================
ModePickRow() {
    global CFG, APP_NAME, G
    pid := EnsureTarget()
    h := 0
    for w in TargetWindows(pid) {
        if (ClassifyScreen(w["hwnd"])["id"] = "S1_Index") {
            h := w["hwnd"]
            break
        }
    }
    if (!h) {
        MsgBox("患者一覧が開いていません。`n`n"
            . "メタアナライザーで「カードを選択します」を押して"
            . "一覧を表示してから、もう一度実行してください。", APP_NAME, "Icon! 4096")
        ; ★案内の途中なら閉じない★ 準備ができたら続けられるように戻す
        if (G.backTo = "wizard") {
            ModeWizard()
            return
        }
        ReopenAndExit(1)
    }
    grid := CS("ListClassNN")
    gr := CtrlRect(h, grid)
    gx := gr["x"], gy := gr["y"], gw := gr["w"], gh := gr["h"]

    dlg := Gui("+AlwaysOnTop", APP_NAME " - 先頭行の位置を登録" VerTag())
    dlg.MarginX := 16, dlg.MarginY := 12
    dlg.SetFont("s11 Bold", "Meiryo UI")
    step := 1, y1 := 0
    ; ★見出しは書き換えられるようにしておく★
    ;   2026-09-22、2 行目を待っているのに見出しが「1 行目」のままで、
    ;   同じ行をもう一度教えてしまう人がいた（他社の PC で発生）。
    lblHead := dlg.Add("Text", "w640", "一覧の【1 行目】の上にマウスを置いて、F1 を押してください")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w640 cGray"
        , "  検索で絞り込んだあと、いちばん上に出る行の位置を記録します。`n"
        . "  クリックはしません。マウスを合わせるだけです。`n"
        . "  ★1 行目のあと、続けて【2 行目】も登録してください（行の間隔を測ります）。`n"
        . "  　2 行目が無いときは Esc で中止すれば、1 行目だけ記録されます。")
    dlg.SetFont("s10", "Consolas")
    lbl := dlg.Add("Text", "w640 h90", "")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w640 cGray", "中止するときは Esc。")
    dlg.Show()

    Hotkey("F1", Pick)
    Hotkey("Esc", (*) => QuitRow())
    SetTimer(Watch, 100)
    Watch()
    return

    ; ★やめ方★ 1 行目だけ記録済みなら、設定画面へ戻る（落とさない）
    QuitRow() {
        SetTimer(Watch, 0)
        try Hotkey("F1", "Off")
        try Hotkey("Esc", "Off")
        try dlg.Destroy()
        if (step = 2) {
            MsgBox("1 行目だけ記録しました。`n`n"
                . "★行の間隔は記録していません★`n"
                . "このままだと、狙いのカードが 2 行目以降にあるとき"
                . "「別のカードが開いています」で中止します。`n`n"
                . "比較用カード（ミドルネーム違い）をお使いなら、"
                . "もう一度この画面を開いて 2 行目まで登録してください。"
                , APP_NAME, "Icon! 4096")
            ModeMore()
            return
        }
        ReopenAndExit(0)
    }

    Watch() {
        if (!WinExist("ahk_id " dlg.Hwnd)) {   ; 閉じたあとは書き換えない
            SetTimer(Watch, 0)
            return
        }
        MouseGetPos(&mx, &my)
        WinGetPos(&wx, &wy, , , "ahk_id " h)
        rx := mx - wx, ry := my - wy
        inGrid := (gw > 0 && rx >= gx && ry >= gy && rx <= gx + gw && ry <= gy + gh)
        lbl.Value := Format("ウィンドウ内 : x{1}  y{2}`n"
                          . "グリッド     : {3} (x{4} y{5} w{6} h{7})`n"
                          . "グリッド内   : x{8}  y{9}`n"
                          . "判定         : {10}"
            , rx, ry, grid = "" ? "（未設定）" : grid, gx, gy, gw, gh
            , rx - gx, ry - gy, inGrid ? "★グリッドの中です★" : "グリッドの外です")
    }

    Pick(*) {
        MouseGetPos(&mx, &my)
        WinGetPos(&wx, &wy, , , "ahk_id " h)
        rx := mx - wx, ry := my - wy
        if (gw > 0 && (rx < gx || ry < gy || rx > gx + gw || ry > gy + gh)) {
            MsgBox(Format("いま指している場所はグリッドの外です。`n"
                . "一覧の {1} 行目の上に合わせてから F1 を押してください。", step)
                , APP_NAME, "Icon! 4096")
            return
        }
        if (step = 1) {
            ; ★モデルごとの節に書く★ 18D は [Select]、別モデルは [Select.<モデル>]
            ;   2026-09-22、読む側だけモデル対応していて、書く側が共通だった。
            ;   モデルを戻したときに、前の実測値が生きているようにする。
            IniSet(CFG, ModelSec("Select"), "ListFirstRowX", rx)
            IniSet(CFG, ModelSec("Select"), "ListFirstRowY", ry)
            y1 := ry, step := 2
            dlg.Title := APP_NAME . " - 2 行目の位置を登録" . VerTag()
            lblHead.Value := "★いま【2 行目】を待っています★　"
                . "2 行目の上にマウスを置いて、F1 を押してください"
            MsgBox(Format("1 行目を記録しました（x{1} y{2}）。`n`n"
                . "続けて【2 行目】の上にマウスを置いて F1 を押してください。`n"
                . "行の間隔が分かると、狙いのカードが 2 行目以降にあるときも選べます。`n`n"
                . "2 行目が無いときは Esc で中止してください（1 行目だけ記録されます）。"
                , rx, ry), APP_NAME, "Iconi 4096")
            return
        }
        ; ★2 行目★ 差が行の間隔になる
        pitch := ry - y1
        if (pitch <= 0) {
            MsgBox("2 行目は 1 行目より下を指してください。", APP_NAME, "Icon! 4096")
            return
        }
        IniSet(CFG, ModelSec("Select"), "ListRowPitchY", pitch)
        ; ★見張りとキーを外してから閉じる★
        ;   外さないと、消えた文字欄を書き換えようとして落ちる（2026-09-22）。
        SetTimer(Watch, 0)
        try Hotkey("F1", "Off")
        try Hotkey("Esc", "Off")
        MsgBox(Format("記録しました。`n`n  ListFirstRowY = {1}`n  ListRowPitchY = {2}`n`n"
            . "1 行目を開いて氏名が違えば、{2}px ずつ下の行を試します。"
            , y1, pitch), APP_NAME, "Iconi 4096")
        ; ★保存したら閉じずに設定画面へ戻る★
        ;   続けて別の設定をしたいのに、毎回ソフトが消えていた（2026-09-22 指摘）。
        try dlg.Destroy()
        BackToSettings()
        return
    }
}

;==============================================================================
;  /inspect  いま開いている対象ソフトの全画面・全コントロールを列挙
;==============================================================================
ModeInspect() {
    global C, APP_NAME
    pid := EnsureTarget()
    out := "=== AutoMeta /inspect  画面とコントロールの一覧 ===`n"
    out .= FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss") "`n"
    out .= "対象: " CS("ExeName") " (pid " pid ")  権限: " (A_IsAdmin ? "管理者" : "通常ユーザー") "`n`n"
    wins := TargetWindows(pid)
    for w in wins {
        rows := DumpCtrls(w["hwnd"])
        cls  := ClassifyScreen(w["hwnd"], rows)
        out .= "── ウィンドウ: 「" w["title"] "」`n"
        out .= "     ahk_class : " w["class"] "`n"
        out .= "     判定      : " . cls["id"] . (cls["hit"] = "" ? "" : "（『" . cls["hit"] . "』を検出）") . "`n"
        out .= "     hwnd      : " w["hwnd"] "`n"
        out .= CtrlsToText(rows)
        out .= "`n"
    }
    if (wins.Length = 0)
        out .= "（可視ウィンドウがありません）`n"
    path := A_ScriptDir "\inspect.txt"
    try FileDelete(path)
    FileAppend(CRLF(out), path, "UTF-8")
    MsgBox("ウィンドウ " wins.Length " 件を inspect.txt に出力しました。", APP_NAME, "Iconi 4096")
    OpenFile(path)
    ReopenAndExit(0)
}

;==============================================================================
;  /watchall  対象プロセスの変化を監視する（AutoTherapy v4 と同じ道具）
;==============================================================================
ModeWatchAll() {
    global APP_NAME
    pid := EnsureTarget()
    buf := "=== AutoMeta /watchall  変化の監視 " FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss") " ===`r`n`r`n"
    prev := ""

    dlg := Gui("+AlwaysOnTop", APP_NAME " - 変化の監視" VerTag())
    dlg.MarginX := 14, dlg.MarginY := 10
    dlg.SetFont("s10", "Meiryo UI")
    dlg.Add("Text", "w900", "対象プロセスのウィンドウを 1 秒ごとに調べ、変化したときだけ記録します。")
    dlg.Add("Text", "w900 cGray", "終わったら × で閉じると watchall.txt に保存されます。")
    dlg.SetFont("s9", "Consolas")
    ed := dlg.Add("Edit", "w900 h420 ReadOnly -Wrap +VScroll")
    dlg.OnEvent("Close", (*) => Done())
    dlg.Show()
    SetTimer(WatchTick, 1000)
    WatchTick()
    return

    WatchTick() {
        snap := ""
        for w in TargetWindows(pid)
            snap .= "  「" w["title"] "」 [" w["class"] "]`r`n"
        if (snap != prev) {
            buf .= FormatTime(A_Now, "HH:mm:ss") "  ★変化★`r`n" snap "`r`n"
            prev := snap
            ed.Value := buf
            try SendMessage(0x0115, 7, 0, ed)
            Save()
        }
    }
    Save() {
        path := A_ScriptDir "\watchall.txt"
        try FileDelete(path)
        try FileAppend(CRLF(buf), path, "UTF-8")
    }
    Done(*) {
        SetTimer(WatchTick, 0)
        Save()
        OpenFile(A_ScriptDir "\watchall.txt")
        ReopenAndExit(0)
    }
}

;==============================================================================
;  /doctor  自己診断
;==============================================================================
ModeDoctor() {
    global C, CFG, SCRINI, APP_NAME, APP_VER, APP_BUILD
    out := "=== AutoMeta 自己診断 ===`n"
    out .= FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss") "`n`n"
    out .= "バージョン   : " APP_VER "  (build " APP_BUILD ")`n"
    out .= "AHK          : " A_AhkVersion "  " (A_Is64bitOS ? "(64bit OS)" : "") "`n"
    out .= "権限         : " (A_IsAdmin ? "管理者" : "通常ユーザー") "`n"
    out .= "フォルダ     : " A_ScriptDir "`n`n"

    exe := CS("ExeName")
    out .= "対象ソフト   : " (exe = "" ? "（未設定 → 1_SETUP.bat を実行）" : exe) "`n"
    if (exe != "") {
        pid := FindPidByExe(exe)
        out .= "起動状態     : " (pid ? "起動中 (pid " pid ")" : "★見つかりません★") "`n"
        if (pid) {
            out .= "`n見えている画面:`n"
            for w in TargetWindows(pid) {
                cls := ClassifyScreen(w["hwnd"])
                out .= Format("  {1:-16} class={2:-22} title=「{3}」`n", cls["id"], w["class"], w["title"])
            }
        }
    }
    out .= "`n--- config.ini ---`n" SafeRead(CFG)
    out .= "`n--- screens.ini ---`n" SafeRead(SCRINI)
    out .= "`n--- 生成済みファイル ---`n"
    for f in ["trace.txt", "listread.txt", "inspect.txt", "watchall.txt"] {
        p := A_ScriptDir "\" f
        when := "（未作成）"
        if FileExist(p)
            when := FormatTime(FileGetTime(p, "M"), "yyyy-MM-dd HH:mm") . " に更新"
        out .= Format("  {1:-16} {2}`n", f, when)
    }
    path := A_ScriptDir "\doctor.txt"
    try FileDelete(path)
    FileAppend(CRLF(out), path, "UTF-8")
    MsgBox("doctor.txt に出力しました。`n中身をそのまま Claude に貼り付ければ原因を切り分けられます。", APP_NAME, "Iconi 4096")
    OpenFile(path)
    ReopenAndExit(0)
}

SafeRead(p) {
    if !FileExist(p)
        return "（ありません）`n"
    try return FileRead(p, "UTF-8") "`n"
    return "（読めません）`n"
}

;==============================================================================
;  /code  利用者コードを登録（オンラインの利用確認）
;==============================================================================
;   ★画面を出すのはここだけ★ 以降は起動時に黙って確認する。
;   無人で夜間に動くツールなので、毎回ログインを求める形にはしない。
;==============================================================================
;  ショートカット（デスクトップ ／ スタートメニュー）
;==============================================================================
; ★タスクバーへのピン留めは、Windows 10 以降プログラムから行えない★
;   仕様で塞がれているので、最後の 1 手順（右クリック）だけ利用者に案内する。
;   自動セラピー（AutoTherapy）と同じ作法に合わせた。
CreateDesktopShortcut(&msg) {
    global APP_NAME
    icon := FileExist(A_ScriptDir . "\AutoMeta.ico") ? A_ScriptDir . "\AutoMeta.ico" : A_AhkPath
    made := [], failed := []
    for target in [A_Desktop . "\AutoMeta.lnk", A_Programs . "\AutoMeta.lnk"] {
        try {
            FileCreateShortcut(A_AhkPath, target, A_ScriptDir
                , Chr(34) . A_ScriptFullPath . Chr(34) . " /menu"
                , "AutoMeta メタアナライザー自動操作", icon, , 1)
            made.Push(target)
        } catch as e {
            failed.Push(target . " : " . e.Message)
        }
    }
    if (made.Length = 0) {
        msg := "ショートカットを作れませんでした。`n" . (failed.Length ? failed[1] : "")
        return false
    }
    msg := "ショートカットを作りました。`n`n"
         . "　・デスクトップ`n"
         . "　・スタートメニュー（スタートボタンから「AutoMeta」で検索できます）`n`n"
         . "―――――――――――――――――――――――`n"
         . "【タスクバーに入れたい場合】`n"
         . "Windows の仕様でプログラムからは登録できないため、`n"
         . "お手数ですが次の操作をお願いします（1 回だけ）。`n`n"
         . "　1. デスクトップの「AutoMeta」を右クリック`n"
         . "　2. 「タスクバーにピン留めする」を選ぶ`n"
         . "　　（Windows 11 では「その他のオプションを表示」の中にあります）"
    if (failed.Length > 0)
        msg .= "`n`n※ 一部作れませんでした: " . failed[1]
    return true
}

; 「設定」から押されたとき（画面は閉じない）
ShortcutNow() {
    global APP_NAME
    msg := ""
    ok := CreateDesktopShortcut(&msg)
    Log(ok ? "INFO" : "WARN", "ショートカット作成: " . (ok ? "成功" : "失敗"))
    MsgBox(msg, APP_NAME, ok ? "Iconi 4096" : "Icon! 4096")
}

;==============================================================================
;  /model  対象ソフトのモデルを選ぶ
;==============================================================================
;   選択中の項目の色がモデルで違うため、どちらかを記録しておく。
;==============================================================================
;  /schemename  スキームの名前を変える
;==============================================================================
;   ソフト側で利用者がスキームに名前を付けられるため、こちらも合わせられるようにする。
;   ★モデルごとに保存する★ 18D と別モデルで名前が違ってよい。
;   ★予定の記載も追従させる★ 名前だけ変えると、予定が指す先を見失う。
ModeSchemeNames() {
    global CFG, SCHEDINI, APP_NAME
    m   := IniLoad(CFG)
    sec := ModelSecRead(m, "Manual")
    dlg := Gui("+AlwaysOnTop", APP_NAME . " - スキームの名前" . VerTag())
    dlg.MarginX := 16, dlg.MarginY := 12
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "w560", "マニュアル選択の名前を、お使いのソフトに合わせます")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w560 h46 cGray"
        , "ソフト側で付けた名前に合わせておくと、予定を組むときに迷いません。`n"
        . "押す位置は変わりません。名前だけを付け替えます。`n"
        . "保存先: [" . sec . "]（いまのモデル）")
    dlg.SetFont("s10", "Meiryo UI")
    olds := [], eds := []
    Loop 5 {
        cur := Trim(IniGet(m, sec, "Name" A_Index, "スキーム " A_Index))
        olds.Push(cur)
        dlg.Add("Text", "xm w110 h30 +0x200", A_Index . " 番目")
        eds.Push(dlg.Add("Edit", "x+8 yp w440", cur))
    }
    bOk := dlg.Add("Button", "xm w270 h38 Default", "保存")
    bNo := dlg.Add("Button", "x+20 yp w270 h38", "キャンセル")
    bNo.OnEvent("Click", (*) => ReopenAndExit(0))
    dlg.OnEvent("Close", (*) => ReopenAndExit(0))
    bOk.OnEvent("Click", (*) => Save())
    dlg.Show()
    return

    Save() {
        changed := 0, fixed := 0
        Loop 5 {
            nw := Trim(eds[A_Index].Value)
            od := olds[A_Index]
            if (nw = "" || nw = od)
                continue
            IniSet(CFG, sec, "Name" A_Index, nw)
            changed++
            ; 予定が古い名前を指していたら、新しい名前に直す
            sm := IniLoad(SCHEDINI)
            for key, vals in sm {
                if (SubStr(key, 1, 8) != "Patient.")
                    continue
                if (Trim(IniGet(sm, key, "ManualSelect", "")) = od) {
                    IniSet(SCHEDINI, key, "ManualSelect", nw)
                    fixed++
                }
            }
            Log("INFO", Format("スキーム名を変更: 「{1}」→「{2}」（予定 {3} 件を追従）", od, nw, fixed))
        }
        msg := "変更はありませんでした。"
        if (changed > 0)
            msg := Format("{1} 件の名前を変えました。`n予定側も {2} 件を合わせています。", changed, fixed)
        MsgBox(msg, APP_NAME, "Iconi 4096")
        try dlg.Destroy()
        BackToSettings()
        return
    }
}

ModeModel() {
    global CFG, C, APP_NAME
    now := Trim(CS("ModelName"))
    dlg := Gui("+AlwaysOnTop", APP_NAME . " - モデルの選択" . VerTag())
    dlg.MarginX := 16, dlg.MarginY := 12
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "w560", "お使いのソフトのモデルを選んでください")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w560 h52 cGray"
        , "マニュアル選択などで「選ばれているか」を色で見分けています。`n"
        . "モデルによって選択中の色が違うため、ここで切り替えます。`n"
        . "正しく判定されないときは、もう一方を選択してください。")
    dlg.SetFont("s11", "Meiryo UI")
    r1 := dlg.Add("Radio", "xm w560 h30" . (now = "MetaAnalyzer" ? "" : " Checked")
        , "18D-NLS（選択中は淡い青）")
    r2 := dlg.Add("Radio", "xm w560 h30" . (now = "MetaAnalyzer" ? " Checked" : "")
        , "Meta Analyzer（選択中は淡いクリーム）")
    dlg.SetFont("s10", "Meiryo UI")
    bOk := dlg.Add("Button", "xm w270 h38 Default", "保存")
    bNo := dlg.Add("Button", "x+20 yp w270 h38", "キャンセル")
    bNo.OnEvent("Click", (*) => ReopenAndExit(0))
    dlg.OnEvent("Close", (*) => ReopenAndExit(0))
    bOk.OnEvent("Click", (*) => Save())
    dlg.Show()
    return

    Save() {
        name := r2.Value ? "MetaAnalyzer" : "18D"
        C["ModelName"] := name
        IniSet(CFG, "Model", "ModelName", name)
        Log("INFO", "モデルを記録しました: " . name)
        MsgBox("モデルを「" . name . "」にしました。", APP_NAME, "Iconi 4096")
        dlg.Destroy()
        ModeMore()
    }
}

ModeCode() {
    global C, CFG, APP_NAME
    dlg := Gui("+AlwaysOnTop", APP_NAME . " - 利用者コード" . VerTag())
    dlg.MarginX := 16, dlg.MarginY := 12
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "w620", "お渡しした利用者コードを入力してください")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w620 h58 cGray"
        , "一度登録すれば、あとは自動で確認します。通常は何も表示されません。`n"
        . "インターネットにつながらない日が続いても、14 日間はそのまま動きます。`n"
        . "コードが分からないときは、お渡しした案内をご確認ください。")
    dlg.SetFont("s12", "Consolas")
    edt := dlg.Add("Edit", "xm w620", Trim(CS("UserCode")))
    dlg.SetFont("s10 Bold", "Meiryo UI")
    lbl := dlg.Add("Text", "xm w620 h50 cNavy", "")
    dlg.SetFont("s10", "Meiryo UI")
    bOk  := dlg.Add("Button", "xm w300 h38 Default", "確認して保存")
    bDel := dlg.Add("Button", "x+20 yp w140 h38", "登録を解除")
    bNo  := dlg.Add("Button", "x+20 yp w140 h38", "閉じる")
    bOk.OnEvent("Click", (*) => Check())
    bDel.OnEvent("Click", (*) => Clear())
    bNo.OnEvent("Click", (*) => ReopenAndExit(0))
    dlg.OnEvent("Close", (*) => ReopenAndExit(0))
    dlg.Show()
    return

    Check() {
        global C, CFG, APP_NAME
        code := Trim(edt.Value)
        if (code = "") {
            lbl.Value := "コードが空です"
            return
        }
        lbl.Value := "確認しています…"
        why := ""
        C["UserCode"] := code
        if (PassRenew(code, &why)) {
            IniSet(CFG, "License", "UserCode", code)
            p   := PassCheck()
            lic := p["ok"] ? p["lic"] : Map("name", "", "why", "")
            ; ★一般には「2 週間に 1 度」を出さない★ つながらなくても一般として動き続けるため。
            tail := "【お願い】2 週間に 1 度は、インターネットにつないだ状態で`n"
                  . "このソフトを開いてください。それだけで確認が完了します。"
            if (IsGeneralPlan())
                tail := "つながらない日が続いても、スタンダードプランとして動作します。"
            MsgBox("確認できました。`n`n"
                . "　利用者: " . lic["name"] . "`n"
                . "　" . lic["why"] . "`n`n"
                . "これ以降は自動で確認します。画面は出ません。`n`n"
                . tail
                , APP_NAME, "Iconi 4096")
            ; ★ここで終わらせない★ 登録のあとは、そのまま使い始められるように
            ;   メニューへ進む（2026-09-19 指摘）。
            dlg.Destroy()
            ModeMenu()
            return
        }
        lbl.Value := "確認できませんでした: " . why
    }

    ; ★入れたものは外せるようにする★
    ;   コードを入れると config.ini に残り、画面からは消せなかった。
    ;   試すたびに手で設定を触ることになる（2026-09-19 指摘）。
    Clear() {
        global C, CFG, PASSFILE, APP_NAME
        C["UserCode"] := ""
        IniSet(CFG, "License", "UserCode", "")
        try FileDelete(PASSFILE)
        Log("INFO", "利用者コードの登録を解除しました")
        MsgBox("登録を解除しました。`n`n"
            . "このままでは調査・セラピーは実行できません。`n"
            . "もう一度使うときは、同じ画面でコードを入力し直してください。"
            , APP_NAME, "Iconi 4096")
        dlg.Destroy()
        ModeMenu()
        return
    }
}

;==============================================================================
;  /menu  調査メニュー
;==============================================================================
ModeMenu() {
    global APP_NAME, APP_VER, APP_CHANNEL, C
    try PreNoticeMenuCheck()                       ; 電源断のあとなど、運転が判定できなかった分
    ; ★二重に開かれたら、先に開いている方を使ってもらう★
    if (h := MenuWindowHwnd()) {
        try WinActivate("ahk_id " h)
        ExitApp(0)
    }
    exe := CS("ExeName")
    ; ★メニュー窓だけの目印を付ける★
    ;   運転パネルも「AutoMeta v2.5.2」と同じ形のタイトルで、
    ;   タイトルだけでは見分けがつかなかった（2026-09-18）。
    dlg := Gui("+AlwaysOnTop", APP_NAME " - メニュー" VerTag())
    dlg.MarginX := 20, dlg.MarginY := 16
    dlg.SetFont("s12 Bold", "Meiryo UI")
    dlg.Add("Text", "w560", "AutoMeta")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w560 cGray", "メタアナライザー自動操作   " APP_VER)
    if (APP_CHANNEL != "") {
        dlg.SetFont("s10 Bold", "Meiryo UI")
        dlg.Add("Text", "w560 cRed"
            , "★" APP_CHANNEL "★　試験中の版です。利用者へ配るものではありません")
        dlg.SetFont("s10", "Meiryo UI")
    }
    dlg.SetFont("s10", "Meiryo UI")
    dlg.Add("Text", "w560 " (exe = "" ? "cRed" : "cGreen")
        , (exe = "" ? "★対象ソフトが未設定です" : "対象ソフト: " exe))
    ; ★ご利用の区分を出す★ スタンダードプランは「顧客 3／5 人」まで。区分の情報が無い通行証では出さない。
    planWord := ""
    try planWord := PlanLabel()
    if (planWord != "")
        dlg.Add("Text", "w560 cGray", "ご利用: " . planWord)
    overWord := ""
    try overWord := PlanOverText()
    if (overWord != "")
        dlg.Add("Text", "w560 cRed", overWord)

    ; ★設定が足りないことを、メニューの一番上で知らせる★
    ;   2026-09-22、新しい PC で「何をすればよいか」が分からなかった。
    ;   設定の奥に入らないと気づけないのでは遅い。
    wizLeft := 0, wizNext := ""
    for st in SetupSteps() {
        if (st["d"] || !st["must"])
            continue
        wizLeft++
        if (wizNext = "")
            wizNext := st["t"]
    }
    if (wizLeft > 0) {
        dlg.SetFont("s11 Bold", "Meiryo UI")
        dlg.Add("Text", "w560 cRed"
            , Format("★この PC は、まだ設定が {1} 件のこっています★", wizLeft))
        dlg.SetFont("s9", "Meiryo UI")
        dlg.Add("Text", "w560 cGray", "　つぎ: " wizNext "　／　終わるまで運転できません")
        dlg.SetFont("s11 Bold", "Meiryo UI")
        bWiz := dlg.Add("Button", "w560 h44", "🔧　はじめての設定（順番に案内）")
        bWiz.OnEvent("Click", (*) => Go("wizard"))
        dlg.SetFont("s10", "Meiryo UI")
    }

    dlg.Add("Text", "w560 h1 0x10")

    dlg.SetFont("s13 Bold", "Meiryo UI")
    bSch := dlg.Add("Button", "w560 h62 Default", "⏰　スケジュール")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w560 cGray"
        , "　予定を決めて、その予定どおりに自動で回します。ふだんの運用はこちら。")

    dlg.SetFont("s13 Bold", "Meiryo UI")
    bOne := dlg.Add("Button", "w560 h62", "👤　1 人だけ今すぐ実行")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w560 cGray"
        , "　検索して顧客を選び、調査 ＋ セラピーを 1 回だけ回します（予定には入れません）。")

    dlg.SetFont("s13 Bold", "Meiryo UI")
    bThe := dlg.Add("Button", "w560 h62", "▶　自動セラピー")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w560 cGray"
        , "　いま開いているカードに、セラピーだけを繰り返します（調査は行いません）。")

    dlg.Add("Text", "w560 h1 0x10")
    dlg.SetFont("s10", "Meiryo UI")
    bMore := dlg.Add("Button", "w176 h38", "⚙  設定")
    bHelp := dlg.Add("Button", "x+16 yp w176 h38", "お問い合わせ")
    bEnd  := dlg.Add("Button", "x+16 yp w176 h38", "閉じる")

    bSch.OnEvent("Click",  (*) => Go("schededit"))
    bOne.OnEvent("Click",  (*) => Go("run"))
    bThe.OnEvent("Click",  (*) => Go("therapy"))
    bMore.OnEvent("Click", (*) => Go("more"))
    bHelp.OnEvent("Click", (*) => Go("diag"))
    bEnd.OnEvent("Click",  (*) => ExitApp(0))
    dlg.OnEvent("Close",   (*) => ExitApp(0))
    dlg.Show()
    ; ★メニューを開いているあいだも受け取る★
    ;   予定の編集と運転中しか受け取れないと、QR を渡したあと
    ;   メニューに戻って待っていても何も起きない（2026-10-02 指摘）。
    SetTimer(RegPollAll, 20000)
    RegPollAll()
    return

    Go(mode) {
        global G, APP_NAME
        dlg.Destroy()
        G.mode := mode
        ; ★メニューから始めた実行は、終わってもソフトを閉じない★
        ;   2026-09-22、1 人だけ実行が終わるとソフトごと消えていた。
        G.fromMenu := true
        G.backTo := "menu"
        switch mode {
            case "run":       ModeRun()
            case "wizard":    ModeWizard()
            case "schedule":  ModeSchedule()
            case "schededit": ModeScheduleEditor()
            case "therapy":   ModeTherapy()
            case "more":      ModeMore()
            case "diag":      ModeDiag()
            case "code":      ModeCode()
            case "setup":     ModeSetup()
            case "trace":     ModeTrace()
            case "listread":  ModeListRead()
            case "pickrow":   ModePickRow()
            case "inspect":   ModeInspect()
            case "watchall":  ModeWatchAll()
            case "doctor":    ModeDoctor()
            default:
                ; ★ここに落ちると、窓が 1 つも無くなって黙って終了してしまう★
                ;   2026-09-15 に「設定」「自動セラピー」で画面が消えたのがこれ。
                MsgBox("行き先「" mode "」が実装されていません。`n"
                    . "メニューに戻ります。", APP_NAME, "Iconx 4096")
                Log("ERROR", "未実装の行き先: " mode)
                ModeMenu()
        }
    }
}

;==============================================================================
;  調査タイプ／マニュアル選択の位置を登録
;==============================================================================
;  スキーム画面の「調査タイプ」「マニュアル選択」は【描画されたボタン】で、
;  開くポップアップ（TPanel3 / TPanel1）の中の項目も描画。
;  文字がひとつも読めないので、座標で押すしかない（2026-09-15 のトレースで判明）。
;
;  ★クリックさせない★
;    項目をクリックするとポップアップが閉じ、ソフトが 14 秒ほど作り直しを始める。
;    マウスを乗せて F1 を押すだけにすれば、開いたまま全項目を記録できる。
;==============================================================================

; 調査タイプ／マニュアル選択の記録は、config.ini の [ScanType] / [Manual] にある。
;   C（設定の一覧）は DEFAULTS のキーしか持たず、しかも節をまたぐと名前がぶつかるので、
;   ここだけは節を指定して読む。
; 指定した位置にいちばん近い TImageButton を探す。
;   描画ボタンの位置を「絶対座標」で覚えると、ウィンドウの大きさが変わった瞬間に
;   全部ずれる（2026-09-15 に実際に起きた）。近くの本物のボタンからの差で覚える。
; コントロールの位置を安全に取る。
;   ★ControlGetPos は失敗すると、出力の変数を「未代入」に戻す★
;     あらかじめ px := 0 と入れておいても消えるので、IsSet で確かめる必要がある。
;     （2026-09-15、マウスを AutoMeta の窓に移した瞬間に落ちた）
CtrlRect(hwnd, cnn) {
    ng := Map("ok", false, "x", 0, "y", 0, "w", 0, "h", 0)
    if (cnn = "" || !hwnd)
        return ng
    x := "", y := "", w := "", h := ""
    try ControlGetPos(&x, &y, &w, &h, cnn, "ahk_id " hwnd)
    if (!IsSet(x) || !IsSet(y) || !IsSet(w) || !IsSet(h))
        return ng
    if (x = "" || y = "" || w = "" || h = "")
        return ng
    return Map("ok", true, "x", x, "y", y, "w", w, "h", h)
}

NearestButton(hwnd, rx, ry) {
    best := Map("cnn", "", "dx", 0, "dy", 0, "dist", 999999)
    list := []
    try list := WinGetControls("ahk_id " hwnd)
    for cnn in list {
        if (SubStr(cnn, 1, 12) != "TImageButton")
            continue
        r := CtrlRect(hwnd, cnn)
        if (!r["ok"] || r["w"] <= 0)
            continue
        mx := r["x"] + r["w"] // 2, my := r["y"] + r["h"] // 2
        d := Sqrt((rx - mx) ** 2 + (ry - my) ** 2)
        if (d < best["dist"])
            best := Map("cnn", cnn, "dx", rx - r["x"], "dy", ry - r["y"], "dist", Round(d))
    }
    return best
}

; スキーム画面の「調査タイプ」「マニュアル選択」は描画ボタンで、位置を直接は読めない。
;   実測（2026-09-16 /inspect）: ボタンは 44px おきの行で並んでいる。
;     右列  カードインデックス y23 ／ 調査 y110 ／ 現在の分析 y154 ／【マニュアル選択 y198】
;     左列  インタラクティブ既往症 y110 ／ アイコン y154 ／【調査タイプ y198】
;     一覧  TPanel3 x706 y265（左列の下）／ TPanel1 x1080 y240（右列の下）
;   ★本物のコントロールから毎回計算する★
;     座標を覚えないので、窓の大きさが変わっても、記録がずれていても狂わない。
;     （2026-09-16、覚えた座標が空白を指していて 3 件連続で失敗した）
SchemeDrawnButton(hwnd, grp) {
    ng   := Map("ok", false, "x", 0, "y", 0)
    left := FindCtrlByText(hwnd, CS("AnchorLeftText"))     ; インタラクティブ既往症
    top  := FindCtrlByText(hwnd, CS("AnchorRightText"))    ; 調査
    mid  := FindCtrlByText(hwnd, CS("SchemeRowRefText"))   ; 現在の分析
    if (!left.Has("x") || !top.Has("x") || !mid.Has("x"))
        return ng
    gap := mid["y"] - top["y"]                             ; 行の間隔（実測 44）
    if (gap <= 0 || gap > 200)
        gap := 44
    row3 := mid["y"] + gap                                 ; 3 行目の上端
    if (grp = "ScanType")
        return Map("ok", true, "x", left["x"] + left["w"] // 2, "y", row3 + left["h"] // 2)
    return Map("ok", true, "x", mid["x"] + mid["w"] // 2, "y", row3 + mid["h"] // 2)
}

; 記録したパネルが画面に【無い】とき、ボタンの真下に表示されている別の TPanel を返す（無ければ空）。
;   記録したパネルがあるなら、何も返さない（取り違えを防ぐ）。★読むだけ★
OptAltPanel(hwnd, recorded, bx, by) {
    found := ""
    try {
        for cn in WinGetControls("ahk_id " hwnd) {
            if (cn = recorded)
                return ""                           ; 記録したパネルはある。別のものを探さない
            if (SubStr(cn, 1, 6) != "TPanel")
                continue
            vi := false
            try vi := ControlGetVisible(cn, "ahk_id " hwnd)
            if (!vi)
                continue
            r := CtrlRect(hwnd, cn)
            if (!r["ok"])
                continue
            ; ボタンの x を含み、ボタンの下 0〜300 に上端がある
            if (bx >= r["x"] && bx <= r["x"] + r["w"] && r["y"] >= by - 5 && r["y"] - by <= 300 && found = "")
                found := cn
        }
    }
    return found
}

; 一覧が開かなかったときの記録。パネル（TPanel）ごとの表示・位置と、押した位置を残す。
;   ★読むだけ★ 何も押さない。
OptDiagLog(hwnd, jp, panel, bx, by) {
    line := ""
    n := 0
    try {
        for cn in WinGetControls("ahk_id " hwnd) {
            if (SubStr(cn, 1, 6) != "TPanel")
                continue
            vi := "?"
            try vi := ControlGetVisible(cn, "ahk_id " hwnd) ? "表示" : "非表示"
            r := CtrlRect(hwnd, cn)
            line .= (line = "" ? "" : " ／ ") . cn . "=" . vi
                  . (r["ok"] ? Format("({1},{2} {3}x{4})", r["x"], r["y"], r["w"], r["h"]) : "")
            n++
        }
    }
    wr := ""
    try {
        WinGetPos(&wx, &wy, &ww, &wh, "ahk_id " hwnd)
        wr := Format("{1},{2} {3}x{4}", wx, wy, ww, wh)
    }
    Log("INFO", Format("{1} の一覧が開かない：見ているパネル {2}／押した位置 x{3} y{4}／ウィンドウ {5}／パネル {6} 個／{7}"
        , jp, panel, bx, by, wr, n, line))
}

; 選択されている（青い）かどうかを色で見分ける。
;   実測（2026-09-16 の録画より）
;     通常     #DBDBDB  青み B-R =  0
;     カーソル #DDEFF9  青み B-R = +28
;     選択中   #C0DDF6  青み B-R = +54
; ★モデルごとの「選択中の色」★
;   18D-NLS は淡い青、Meta Analyzer は淡いクリーム。
;   「青みが +20 以上なら選択中」という以前の決め方では、クリームを拾えない
;   （黄みは青みがマイナスになる）。2026-09-21 に別モデルの録画で判明。
; 実行ファイル名からモデルを見分ける（初期設定で自動記録する）
;   18D-NLS.exe        → 18D
;   META ANALYZER.exe  → MetaAnalyzer
GuessModel(exe) {
    e := StrUpper(Trim(exe))
    if (InStr(e, "META") && InStr(e, "ANALYZER"))
        return "MetaAnalyzer"
    if (InStr(e, "18D"))
        return "18D"
    return ""                                       ; 分からなければ変えない
}

ModelProfile() {
    static P := Map(
        "18D",          Map("sel", 0xC0DDF6, "normal", 0xDBDBDB),
        "MetaAnalyzer", Map("sel", 0xEEEFE4, "normal", 0xD1D1D1))
    n := Trim(CS("ModelName"))
    base := P.Has(n) ? P[n] : P["18D"]
    ; 設定で上書きされていればそちらを優先する（現場で微調整できるように）
    sel := Trim(CS("SelectedColor")), nor := Trim(CS("NormalColor"))
    return Map("sel",    (sel != "") ? Integer("0x" . StrReplace(sel, "#", "")) : base["sel"]
             , "normal", (nor != "") ? Integer("0x" . StrReplace(nor, "#", "")) : base["normal"])
}

; 2 つの色の隔たり（大きいほど違う色）
ColorDist(a, b) {
    dr := Abs(((a >> 16) & 0xFF) - ((b >> 16) & 0xFF))
    dg := Abs(((a >> 8)  & 0xFF) - ((b >> 8)  & 0xFF))
    db := Abs((a & 0xFF) - (b & 0xFF))
    return dr + dg + db
}

; 選択中の色に近いか（モデルの既定色と見比べる）
IsHighlighted(col) {
    if (col < 0)
        return false
    p := ModelProfile()
    return (ColorDist(col, p["sel"]) < ColorDist(col, p["normal"]))
}

; 項目の行を横に走査して、青い点が何点あるかを数える。
;   ★1 点だけ読むと文字の上に乗る★
;   2026-09-17、自動選択が青く光っているのに #4C555C（B-R+16）と読み、
;   「選ばれていない」と判定して外せなかった。読んでいたのは文字の色だった。
;   行の背景は文字の左右にも広がっているので、横に並べて読めば必ず当たる。
;   一覧の外は読まない（外は別の色で、いくらでも青がありうる）。
ItemHighlight(hwnd, cnn, dx, dy) {
    ng := Map("ok", false, "hit", 0, "max", 0, "col", -1)
    r := CtrlRect(hwnd, cnn)
    if (!r["ok"] || r["w"] <= 0 || r["h"] <= 0)
        return ng
    cx := "", cy := ""
    try WinGetClientPos(&cx, &cy, , , "ahk_id " hwnd)
    if (!IsSet(cx) || !IsSet(cy) || cx = "" || cy = "")
        return ng
    hit := 0, best := 0, bestCol := -1, read := 0
    for oy in [-5, 0, 5] {
        py := dy + oy
        if (py < 2 || py > r["h"] - 3)
            continue
        ox := -75
        while (ox <= 150) {
            px := dx + ox
            ox += 15
            if (px < 2 || px > r["w"] - 3)
                continue
            col := -1
            try col := PixelGetColor(cx + r["x"] + px, cy + r["y"] + py)
            if (col < 0)
                continue
            read++
            blue := (col & 0xFF) - ((col >> 16) & 0xFF)
            if (bestCol < 0 || blue > best) {
                best := blue
                bestCol := col
            }
            if (IsHighlighted(col))
                hit++
        }
    }
    if (read = 0)
        return ng
    return Map("ok", true, "hit", hit, "max", best, "col", bestCol)
}

; ★カーソルを当てても色が変わらない＝すでに選ばれている★
;   Meta Analyzer では、選択済みのボタンだけカーソルに反応しない（2026-09-21 指摘）。
;   色の値そのものはモデルや環境で変わるが、「反応するかどうか」は変わらない。
;   戻り値: true = 変わらなかった（選択済み）
ItemUnchangedOnHover(hwnd, panel, dx, dy) {
    return ItemHoverProbe(hwnd, panel, dx, dy)["un"]
}

; ★実測した色をそのまま返す★
;   2026-09-22、別モデルで「外したのに選択済みのまま」と読み違えた。
;   反応あり／なしだけでは原因が追えないので、色と差をログに残せるようにする。
ItemHoverProbe(hwnd, panel, dx, dy) {
    ng := Map("ok", false, "un", false, "c1", -1, "c2", -1, "d", -1)
    r := CtrlRect(hwnd, panel)
    if (!r["ok"])
        return ng
    WinGetPos(&wx, &wy, , , "ahk_id " hwnd)
    px := wx + r["x"] + dx, py := wy + r["y"] + dy
    away := Map("x", wx + r["x"] - 20, "y", wy + r["y"] - 20)
    MouseGetPos(&ox, &oy)
    c1 := -1, c2 := -1
    try {
        MouseMove(away["x"], away["y"], 0)
        Sleep(150)
        c1 := PixelGetColor(px, py)
        MouseMove(px, py, 0)
        Sleep(200)
        c2 := PixelGetColor(px, py)
        MouseMove(away["x"], away["y"], 0)
        Sleep(80)
    } catch as e {
        Log("WARN", "色の確認でつまずきました: " . e.Message)
    }
    try MouseMove(ox, oy, 0)
    if (c1 < 0 || c2 < 0)
        return ng
    d := ColorDist(c1, c2)
    lim := CI("HoverDiffMin")
    if (lim <= 0)
        lim := 12
    ; 差が小さい＝カーソルに反応しなかった＝選択済み
    return Map("ok", true, "un", (d < lim), "c1", c1, "c2", c2, "d", d)
}

; ★記録はモデルごとに分ける★
;   18D で覚えた位置を、別モデルの記録で上書きしないため（2026-09-22 指摘）。
;   18D … これまでどおり [Manual] / [ScanType]（既存の設定をそのまま使える）
;   ほか … [Manual.MetaAnalyzer] のようにモデル名を付けた節
ModelSec(grp) {
    n := Trim(CS("ModelName"))
    if (n = "" || n = "18D")
        return grp
    return grp . "." . n
}

; 読むときは、モデル専用の節があればそちら。無ければ従来の節。
ModelSecRead(m, grp) {
    sec := ModelSec(grp)
    if (sec != grp && Trim(IniGet(m, sec, "Panel", "")) != "")
        return sec
    return grp
}

; 記録した項目のうち、いま選ばれているものは何番目か。0 = どれも選ばれていない
HighlightedOptIndex(hwnd, grp) {
    global CFG
    m := IniLoad(CFG)
    grp := ModelSecRead(m, grp)
    panel := Trim(IniGet(m, grp, "Panel", ""))
    if (panel = "")
        return 0
    n := ToInt(IniGet(m, grp, "Count", "0"), 0)
    ; ★カーソルを当てた状態を拾わない★
    ;   マウスが項目の上にあると、その項目だけ色が変わる（別モデルで確認）。
    ;   読む前に一覧の外へ退避させれば、見分ける状態が 2 つに減る。
    rw := CtrlRect(hwnd, panel)
    if (rw["ok"]) {
        WinGetPos(&wx, &wy, , , "ahk_id " hwnd)
        try MouseMove(wx + rw["x"] - 20, wy + rw["y"] - 20, 0)
        Sleep(120)
    }
    ; ★カーソルで色を見るなら、窓が前面にないと反応しない★
    ;   一覧は「前面にしないクリック」で開いているので、そのままでは
    ;   どの項目も色が変わらず、全部「選択済み」と読めてしまう
    ;   （2026-09-23 のログで、8 項目すべてが差 0 になっていた）。
    if (CB("HoverTest")) {
        try WinActivate("ahk_id " hwnd)
        Sleep(150)
    }
    found := 0, note := "", reacted := 0
    bestHit := 0, bestIdx := 0
    Loop n {
        dx := ToInt(IniGet(m, grp, "DX" A_Index, "0"), 0)
        dy := ToInt(IniGet(m, grp, "DY" A_Index, "0"), 0)
        if (CB("HoverTest")) {
            ; カーソルに反応しない項目＝選択済み
            pb := ItemHoverProbe(hwnd, panel, dx, dy)
            un := pb["un"]
            det := "(色を読めず)"
            if (pb["ok"])
                det := Format("(#{:06X}→#{:06X} 差{:d})", pb["c1"], pb["c2"], pb["d"])
            note .= (note = "" ? "" : " / ") Trim(IniGet(m, grp, "Name" A_Index, A_Index))
                 . (un ? "=反応なし（選択済み）" : "=反応あり") . det
            if (!un)
                reacted++
            if (found = 0 && un)
                found := A_Index
        } else {
            hh := ItemHighlight(hwnd, panel, dx, dy)
            lbl := (!hh["ok"]) ? "=読めず" : Format("=#{:06X}(青{:d}点/最大{:+d})", hh["col"], hh["hit"], hh["max"])
            note .= (note = "" ? "" : " / ") Trim(IniGet(m, grp, "Name" A_Index, A_Index)) lbl
            if (hh["ok"] && hh["hit"] > bestHit) {
                bestHit := hh["hit"]
                bestIdx := A_Index
            }
        }
    }
    ; ★「最初に基準を超えた項目」ではなく、「青い点がいちばん多い項目」を選ぶ★（3.10.29）
    ;   2026-10-17・10-19・10-20 の 3 件で、マニュアル選択を「どれも選ばない」にしようとして失敗した。
    ;   選ばれていたのは「自動選択」（青い点 45）なのに、基準が 3 点と低く、色が少し青い「スキーム 5」（4 点）を
    ;   先に見つけて押してしまい、スキーム 5 が選ばれた。選ばれた項目は、青い点が 20 点以上ある。
    ;   20 点に届かなければ「どれも選ばれていない」と読む（ノイズ程度の青さを選択済みと読まない）。
    if (!CB("HoverTest")) {
        strong := Max(CI("HighlightHitMin"), CI("HighlightStrongMin"))
        found := (bestHit >= strong) ? bestIdx : 0
    }
    ; ★色の実測をログに残す★ 誤判定したときに、あとから原因が分かるように
    Log("DEBUG", grp " の色: " note)
    ; ★どれも反応しなかったら、読めていない★
    ;   「全部が選択済み」はあり得ない。前面でない・描き直しが間に合わない
    ;   などで、色が動かなかっただけ。この状態で押すと、外すつもりが
    ;   逆に選んでしまう。-1 を返して、触らずに進んでもらう（2026-09-23）。
    if (CB("HoverTest") && n > 0 && reacted = 0)
        return -1
    return found
}

OptNameAt(grp, idx) {
    global CFG
    m := IniLoad(CFG)
    return Trim(IniGet(m, ModelSecRead(m, grp), "Name" idx, ""))
}

NoneSelectLabel() => "（どれも選ばない）"

; コントロールの左上を基準にした位置を、いまのウィンドウの座標に直す
SpotFromAnchor(hwnd, cnn, dx, dy) {
    r := CtrlRect(hwnd, cnn)
    if (!r["ok"] || r["w"] <= 0)
        return Map("ok", false, "x", 0, "y", 0)
    return Map("ok", true, "x", r["x"] + dx, "y", r["y"] + dy)
}

OptNames(grp) {
    global CFG
    m := IniLoad(CFG)
    grp := ModelSecRead(m, grp)
    out := []
    n := ToInt(IniGet(m, grp, "Count", "0"), 0)
    Loop n {
        nm := Trim(IniGet(m, grp, "Name" A_Index, ""))
        if (nm != "")
            out.Push(nm)
    }
    return out
}

; 名前 → 何番目か（0 = 見つからない）
OptIndex(grp, name) {
    for i, nm in OptNames(grp) {
        if (nm = Trim(name))
            return i
    }
    return 0
}

; grp の設定をまとめて返す（BtnX/BtnY/Panel と、指定した番号の X/Y）
OptSpot(grp, idx) {
    global CFG
    m := IniLoad(CFG)
    grp := ModelSecRead(m, grp)
    return Map("btnAnchor", Trim(IniGet(m, grp, "BtnAnchor", ""))
             , "btnDX", ToInt(IniGet(m, grp, "BtnDX", "0"), 0)
             , "btnDY", ToInt(IniGet(m, grp, "BtnDY", "0"), 0)
             , "panel", Trim(IniGet(m, grp, "Panel", ""))
             , "dx",    ToInt(IniGet(m, grp, "DX" idx, "0"), 0)
             , "dy",    ToInt(IniGet(m, grp, "DY" idx, "0"), 0))
}

TeachScanSteps() {
    ; ★ボタンの位置は覚えない★
    ;   「調査タイプ」「マニュアル選択」は本物のコントロールから計算できる
    ;   （SchemeDrawnButton）。覚えるのは一覧の中の項目だけ。
    out := []
    for nm in ["エクスプレス", "標準", "詳細", "科学"]
        out.Push(Map("grp", "ScanType", "kind", "item", "label", nm))
    ; ★一覧には他に「設定」「選択を解除」「トップに選択しました」もあるが、記録しない★
    ;   「選択を解除」は測定項目のチェックを全部外すボタン（2026-09-17 利用者の指摘）。
    ;   記録すると選択肢に出てしまい、誤って押せてしまうため、載せない。
    for nm in ["スキーム 1", "スキーム 2", "スキーム 3", "スキーム 4", "スキーム 5"
             , "自動選択", "リンクされた臓器", "すべて"]
        out.Push(Map("grp", "Manual", "kind", "item", "label", nm))
    return out
}

; 画面のタイトルに付ける版の文字（例: "  v2.1.1"）
;   ★どの画面からでも版を確かめられるように★
;   2026-09-17、別 PC の版を確かめたくても記録画面に表示がなく、
;   閉じると記録が消えるためログを開いてもらうしかなかった。
VerTag() {
    global APP_VER, APP_CHANNEL
    t := "  v" StrSplit(APP_VER, " ")[1]
    if (APP_CHANNEL != "")
        t .= "  ★" APP_CHANNEL "★"
    return t
}

ModeTeachScan() {
    global CFG, APP_NAME, APP_VER, G
    pid := EnsureTarget()
    LoadScreens()
    hw := FindScreen("S3_Scheme")
    if (!hw) {
        MsgBox("スキーム画面（調査のスキーム）が開いていません。`n`n"
            . "顧客のカードを開いて「調査」を押し、スキーム画面を出してから"
            . "もう一度実行してください。`n"
            . "※ 調査は開始しないでください。", APP_NAME, "Icon! 4096")
        ; ★案内の途中なら閉じない★ 準備ができたら続けられるように戻す
        if (G.backTo = "wizard") {
            ModeWizard()
            return
        }
        ReopenAndExit(1)
    }

    steps := TeachScanSteps()
    idx   := 1
    got   := Map()
    grabLeft := 0                                  ; "grp|label" → Map("x","y","panel")

    dlg := Gui("+AlwaysOnTop", APP_NAME " - 調査タイプ／マニュアル選択を登録" VerTag())
    dlg.MarginX := 16, dlg.MarginY := 12
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "w660", "位置を登録してください（クリックはしません）")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w660 h64 cGray"
        , "項目の上にマウスを合わせて F1 を押すだけです。クリックすると"
        . "ポップアップが閉じるため、押さないでください。`n"
        . "ボタン（調査タイプ／マニュアル選択）だけは、記録したあとクリックして開きます。`n"
        . "位置は「近くのボタンからの差」で覚えるので、窓の大きさが変わってもずれません。`n"
        . "F2 = 1 つ戻る　／　行をダブルクリック = その項目だけ取り直す")

    dlg.SetFont("s13 Bold", "Meiryo UI")
    lblNext := dlg.Add("Text", "xm w660 cNavy", "")
    dlg.SetFont("s10", "Meiryo UI")
    lblHow  := dlg.Add("Text", "xm w660 h44", "")
    dlg.SetFont("s10", "Consolas")
    lblPos  := dlg.Add("Text", "xm w660 h52", "")

    dlg.SetFont("s10", "Meiryo UI")
    ; ★一覧の高さは画面に合わせて決める★
    ;   行数を 12 行で固定していたため、拡大表示のある環境で画面からはみ出し、
    ;   下にある「保存して終わる」が押せなくなった（2026-09-17、別の PC）。
    wkT := 0, wkB := A_ScreenHeight
    try MonitorGetWorkArea(, , &wkT, , &wkB)
    availH := (IsSet(wkT) && IsSet(wkB) && wkB > wkT) ? (wkB - wkT) : A_ScreenHeight
    ; ★画面の実ピクセルと、GUI の指定値は単位が違う★
    ;   拡大表示（125% など）では h300 と書いても実際には 375px 描かれる。
    ;   作業領域は実ピクセルで返ってくるので、同じ単位に直してから引く。
    ;   2026-09-17、1920×1080 の別 PC で「直したのにまだ切れる」と指摘を受けた点。
    scale := (A_ScreenDPI > 0) ? (A_ScreenDPI / 96) : 1
    availH := Floor(availH / scale)
    lvH := availH - 520                            ; 一覧以外に要る高さ
    if (lvH < 110)
        lvH := 110
    if (lvH > 300)
        lvH := 300
    lv := dlg.Add("ListView", "xm w660 h" lvH " -Multi Grid", ["#", "区分", "項目", "位置"])
    for st in steps
        lv.Add("", A_Index, (st["grp"] = "ScanType" ? "調査タイプ" : "マニュアル選択")
             , st["label"], "")
    lv.ModifyCol(1, 34), lv.ModifyCol(2, 100), lv.ModifyCol(3, 170), lv.ModifyCol(4, 330)
    lv.OnEvent("DoubleClick", (*) => JumpTo())     ; 行をダブルクリックで、そこからやり直す

    dlg.SetFont("s10", "Meiryo UI")
    lblKey := dlg.Add("Text", "xm w660 cGray", "F1 を待っています（まだ一度も受け取っていません）")
    bGrab := dlg.Add("Button", "xm w660 h34", "F1 が使えないとき → 3 秒後に記録")
    bTest := dlg.Add("Button", "xm w660 h34", "★ 記録した位置を確認（保存前に動作を確認）")
    bSave := dlg.Add("Button", "xm w320 h38 Default", "保存して閉じる")
    bQuit := dlg.Add("Button", "x+16 yp w320 h38", "キャンセル")
    bGrab.OnEvent("Click", (*) => StartGrab())
    bTest.OnEvent("Click", (*) => TestSpots())
    bSave.OnEvent("Click", (*) => SaveAll())
    bQuit.OnEvent("Click", (*) => ReopenAndExit(0))
    dlg.OnEvent("Close", (*) => ReopenAndExit(0))
    ; ★画面の一番上に出す★ 下に置くほど、ボタンがはみ出しやすくなる
    dlg.Show("y" wkT)

    ; F1 が別のところに取られることがあるので、F9 でも受け付ける。
    ; * を付けて、修飾キーが押されていても反応するようにする。
    Hotkey("*F1", (*) => Pick())
    Hotkey("*F9", (*) => Pick())
    Hotkey("*F2", (*) => Undo())
    ; ★Esc では終了しない★
    ;   ソフト側の一覧を閉じようとして Esc を押すことがある。
    ;   そこで記録画面ごと消えると、それまでの記録が失われる。
    Hotkey("Esc", (*) => AskQuit())
    SetTimer(Watch, 200)
    ShowNext()
    Watch()
    return

    AskQuit() {
        ans := MsgBox("記録を中止しますか？`n`n"
            . "（ソフトの一覧を閉じたいだけなら「いいえ」を選んでください）"
            , APP_NAME, "YesNo Icon? 4096")
        if (ans = "Yes")
            ReopenAndExit(0)
    }

    ShowNext() {
        if (idx > steps.Length) {
            lblNext.Value := "★ 登録が完了しました。「保存して閉じる」を押してください"
            lblHow.Value  := ""
            return
        }
        st := steps[idx]
        grpName := (st["grp"] = "ScanType") ? "調査タイプ" : "マニュアル選択"
        lblNext.Value := Format("{1} / {2}　つぎ: {3}　の　{4}"
            , idx, steps.Length, grpName, st["label"])
        firstItem := (st["kind"] = "item")
                  && (idx = 1 || steps[idx - 1]["grp"] != st["grp"]
                     || steps[idx - 1]["kind"] = "btn")
        if (st["kind"] = "btn") {
            lblHow.Value := "まだ押さないでください。" grpName
                . " のボタンの上に【マウスを合わせるだけ】で F1。"
        } else if (firstItem) {
            lblHow.Value := grpName " のボタンを【クリックして】一覧を開いてください。`n"
                . "開いたら「" st["label"] "」の上に【マウスを合わせるだけ】で F1。"
                . "（項目はクリックしないでください）"
        } else {
            lblHow.Value := "続けて「" st["label"] "」の上に【マウスを合わせるだけ】で F1。"
        }
    }

    Watch() {
        ; ★画面が消えていたら、何もせずに見張りを止める★
        ;   閉じたあとに書き換えようとすると落ちる（2026-09-22）。
        if (!WinExist("ahk_id " dlg.Hwnd)) {
            SetTimer(Watch, 0)
            return
        }
        mx := 0, my := 0, uw := 0, ctrl := ""
        MouseGetPos(&mx, &my, &uw, &ctrl)
        wx := 0, wy := 0, ww := 0, wh := 0
        try WinGetPos(&wx, &wy, &ww, &wh, "ahk_id " hw)
        ; ★失敗すると未設定に戻る★ 使う前に必ず確かめる（2026-09-22）
        if (!IsSet(wx) || !IsSet(wy) || !IsSet(ww) || !IsSet(wh))
            wx := 0, wy := 0, ww := 0, wh := 0
        ucls := ""
        try ucls := WinGetClass("ahk_id " uw)
        same := (uw = hw)
        rx := mx - wx, ry := my - wy
        ; どこを基準に覚えることになるか、その場で見せる
        base := ""
        if (!same) {
            base := "（スキーム画面の外です）"
        } else if (ctrl != "") {
            pr := CtrlRect(hw, ctrl)
            if (pr["ok"])
                base := Format("{1} から +{2},{3}", ctrl, rx - pr["x"], ry - pr["y"])
            else
                base := ctrl "（位置が取れません）"
        } else if (same) {
            nb := NearestButton(hw, rx, ry)
            if (nb["cnn"] = "")
                base := "（基準が見つかりません）"
            else
                base := Format("{1} から +{2},{3}", nb["cnn"], nb["dx"], nb["dy"])
        }
        ; カーソル下の色。「選ばれている（青）」と「選ばれていない（灰）」を
        ; 見分けられるか確かめるために出す。
        col := ""
        try col := Format("0x{:06X}", PixelGetColor(mx, my))
        lblPos.Value := Format("スキーム画面 : x{1} y{2} ({3}×{4})　ウィンドウ内: x{5} y{6}　{7}`n"
                             . "いまの場所   : {8}　窓: {9}　色: {10}`n"
                             . "覚え方       : {11}"
            , wx, wy, ww, wh, rx, ry
            , same ? "" : "★スキーム画面の上ではありません★"
            , (ctrl = "") ? "（コントロールなし＝描画部分）" : ctrl
            , ucls = "" ? "?" : ucls, col = "" ? "?" : col, base)
    }

    ; ★記録した位置が本当に当たるかを、その場で確かめる★
    ;   2026-09-16、ずれた位置を記録したまま運転し、3 件続けて失敗して
    ;   その晩の運転が止まった。30 分のジョブを回さずに確かめられるようにする。
    TestSpots() {
        out := ""
        for grp in ["ScanType", "Manual"] {
            jp    := (grp = "ScanType") ? "調査タイプ" : "マニュアル選択"
            sp := SchemeDrawnButton(hw, grp)
            if (!sp["ok"]) {
                out .= jp "：位置を計算できません"
                     . "（インタラクティブ既往症／調査／現在の分析 が読めません）`n`n"
                continue
            }
            ; この区分で記録済みの項目から、一覧（パネル）の名前を拾う
            panel := ""
            for st in steps {
                k := st["grp"] "|" st["label"]
                if (st["grp"] = grp && st["kind"] = "item" && got.Has(k)) {
                    panel := got[k]["panel"]
                    break
                }
            }
            try ControlClick(Format("x{1} y{2}", sp["x"], sp["y"]), "ahk_id " hw
                , , "Left", 1, "NA")
            ; ★開くまで待つ★
            ;   1.5 秒しか待たずに判定していたため、位置が正しくても
            ;   「開きません」と出ていた（2026-09-17、別の PC でのセットアップ）。
            ;   このソフトは一覧が出るまで 6 秒以上かかることがある。
            vis := false
            waited := 0
            while (waited < 10000) {
                if (panel != "") {
                    try vis := ControlGetVisible(panel, "ahk_id " hw)
                    if (vis)
                        break
                }
                Sleep(500)
                waited += 500
            }
            out .= Format("{1}`n　押した位置 : x{2} y{3}（本物のボタンから計算）`n"
                        . "　一覧 {4} : {5}`n`n"
                , jp, sp["x"], sp["y"]
                , panel = "" ? "（未記録）" : panel
                , (panel = "") ? "確かめられません" : (vis ? "★開きました" : "開きません（10 秒待っても出ませんでした）"))
            if (vis) {                              ; 開いたら、もう一度押して閉じる
                try ControlClick(Format("x{1} y{2}", sp["x"], sp["y"]), "ahk_id " hw
                    , , "Left", 1, "NA")
                Sleep(800)
            }
        }
        MsgBox(out "両方とも「★開きました」であれば問題ありません。"
            , APP_NAME " - 試した結果", "Iconi 4096")
    }

    ; 押したボタンから 3 秒後に記録する。F1 が届かない環境のための逃げ道。
    StartGrab() {
        grabLeft := 3
        lblKey.Value := "3 秒後に、いまマウスがある場所を記録します…"
        SetTimer(GrabTick, 1000)
    }

    GrabTick() {
        grabLeft--
        if (grabLeft > 0) {
            lblKey.Value := grabLeft " 秒後に記録します… 記録したい場所にマウスを置いてください"
            return
        }
        SetTimer(GrabTick, 0)
        Pick()
    }

    Pick() {
        ; ★最初にここを更新する★
        ;   これが動かなければ「F1 が届いていない」、
        ;   動くのに記録されなければ「届いたが弾かれた」と切り分けられる。
        lblKey.Value := "受け取りました: " FormatTime(A_Now, "HH:mm:ss")
        if (idx > steps.Length)
            return
        mx := 0, my := 0, ctrl := ""
        MouseGetPos(&mx, &my, , &ctrl)
        wx := 0, wy := 0, ww := 0, wh := 0
        try WinGetPos(&wx, &wy, &ww, &wh, "ahk_id " hw)
        ; ★失敗すると未設定に戻る★ 使う前に必ず確かめる（2026-09-22）
        if (!IsSet(wx) || !IsSet(wy) || !IsSet(ww) || !IsSet(wh))
            wx := 0, wy := 0, ww := 0, wh := 0
        rx := mx - wx, ry := my - wy
        st := steps[idx]
        ; ★スキーム画面の外を指していたら受け付けない★
        ;   2026-09-15、マニュアル選択のボタンが y=-31 で記録された。
        ;   ウィンドウの外（上）を指したまま F1 を押したため。
        if (rx < 0 || ry < 0 || (ww > 0 && rx > ww) || (wh > 0 && ry > wh)) {
            ; ★止めない。数字を見せて判断してもらう★
            ;   こちらの座標の取り方が違っている可能性もあるので、
            ;   「外だから受け付けない」と決めつけない（2026-09-15）
            uw2 := 0
            MouseGetPos(, , &uw2)
            ucls2 := ""
            try ucls2 := WinGetClass("ahk_id " uw2)
            ans := MsgBox(Format("記録しようとしている位置が、スキーム画面の範囲から外れています。`n`n"
                . "　ウィンドウ内 : x{1} y{2}`n"
                . "　画面の大きさ : {3} × {4}`n"
                . "　カーソルの下 : {5}`n`n"
                . "指している場所が正しければ、このまま記録して構いません。`n"
                . "記録しますか？", rx, ry, ww, wh, ucls2 = "" ? "?" : ucls2)
                , APP_NAME, "YesNo Icon! 4096")
            if (ans != "Yes")
                return
        }
        ; 項目はポップアップ（TPanel…）の上にあるはず
        if (st["kind"] = "item" && ctrl = "") {
            ans := MsgBox("いま指している場所に、ポップアップがありません。`n`n"
                . "先に " (st["grp"] = "ScanType" ? "「調査タイプ」" : "「マニュアル選択」")
                . " を押して一覧を開いてから、項目の上で F1 を押してください。`n`n"
                . "それでもこの位置で記録しますか？", APP_NAME, "YesNo Icon! 4096")
            if (ans != "Yes")
                return
        }
        ; ★絶対座標では覚えない★ 近くの本物のボタン／ポップアップからの差で覚える
        pr := (ctrl = "") ? Map("ok", false) : CtrlRect(hw, ctrl)
        if (st["kind"] = "item" && ctrl != "" && pr["ok"]) {
            got[st["grp"] "|" st["label"]] := Map("anchor", ctrl
                , "dx", rx - pr["x"], "dy", ry - pr["y"], "panel", ctrl)
            lv.Modify(idx, "Col4", Format("{1} から +{2},{3}　→ いま x{4} y{5}", ctrl
                , rx - pr["x"], ry - pr["y"], rx, ry))
        } else {
            nb := NearestButton(hw, rx, ry)
            if (nb["cnn"] = "") {
                MsgBox("近くに基準にできるボタンが見つかりませんでした。`n"
                    . "スキーム画面の上で操作しているか確かめてください。", APP_NAME, "Iconx 4096")
                return
            }
            got[st["grp"] "|" st["label"]] := Map("anchor", nb["cnn"]
                , "dx", nb["dx"], "dy", nb["dy"], "panel", "")
            lv.Modify(idx, "Col4", Format("{1} から +{2},{3}　→ いま x{4} y{5}"
                , nb["cnn"], nb["dx"], nb["dy"], rx, ry))
        }
        lv.Modify(idx, "Select Focus")
        idx++
        ShowNext()
    }

    ; 一覧の行をダブルクリックしたら、その項目から記録し直す
    JumpTo() {
        row := lv.GetNext()
        if (row < 1)
            return
        idx := row
        ShowNext()
    }

    Undo() {
        if (idx <= 1)
            return
        idx--
        st := steps[idx]
        got.Delete(st["grp"] "|" st["label"])
        lv.Modify(idx, "Col4", "")
        ShowNext()
    }

    SaveAll() {
        ; ★「まだ何番目か」ではなく、実際に記録できていない数を数える★
        ;   行をダブルクリックして 1 つだけ取り直したときに、
        ;   そのあとの項目まで「空」と誤解しないため。
        miss := 0
        for st in steps {
            if (!got.Has(st["grp"] "|" st["label"]))
                miss++
        }
        if (miss > 0) {
            ans := MsgBox("まだ " miss " 件が空です。`n"
                . "空のままの項目は、予定の編集画面に出てきません。`n`n"
                . "このまま保存しますか？", APP_NAME, "YesNo Icon? 4096")
            if (ans != "Yes")
                return
        }
        for grp in ["ScanType", "Manual"] {
            head := [], items := [], n := 0, panel := ""
            for st in steps {
                if (st["grp"] != grp)
                    continue
                key := grp "|" st["label"]
                if (!got.Has(key))
                    continue
                ; ★ローカル変数に g を使ってはいけない★
                ;   AHK は大文字小文字を区別しないので、g := … は
                ;   グローバルの G（実行時状態）を丸ごと壊す。
                ;   2026-09-22 にこの関数へ global G を足したことで、
                ;   それまで無害だったこの行が牙を剥いた。
                ;   「保存して終わる」を押すと G が Map に化け、
                ;   画面が変わらないまま壊れていた（2026-09-23 指摘）。
                rec := got[key]
                if (st["kind"] = "btn") {
                    head.Push(["BtnAnchor", rec["anchor"]])
                    head.Push(["BtnDX", rec["dx"]])
                    head.Push(["BtnDY", rec["dy"]])
                    continue
                }
                n++
                items.Push(["Name" n, st["label"]])
                items.Push(["DX" n, rec["dx"]])
                items.Push(["DY" n, rec["dy"]])
                if (panel = "" && rec["panel"] != "")
                    panel := rec["panel"]           ; ポップアップの正体（TPanel3 など）
            }
            ; ★何も記録していない区分は触らない★
            ;   節ごと書き換えるので、空で書くと前回の記録が消えてしまう
            if (!head.Length && !items.Length)
                continue
            pairs := []
            for pr in head
                pairs.Push(pr)
            if (panel != "")
                pairs.Push(["Panel", panel])
            pairs.Push(["Count", n])
            for pr in items
                pairs.Push(pr)
            IniSetSection(CFG, ModelSec(grp), pairs)   ; モデルごとに分けて保存
        }
        Log("INFO", "調査タイプ／マニュアル選択の位置を保存しました")
        MsgBox("config.ini に保存しました。`n`n"
            . "予定の編集画面の「実行内容」に、選べるようになります。`n"
            . "既定は 調査タイプ＝詳細 / マニュアル選択＝自動選択 です。"
            , APP_NAME, "Iconi 4096")
        ; ★保存したら閉じずに設定画面へ戻る★
        ;   続けて別の設定をしたいのに、毎回ソフトが消えていた（2026-09-22 指摘）。
        CloseTeach()
        BackToSettings()
        return
    }

    ; ★画面を閉じる前に、見張りとキーを必ず外す★
    ;   2026-09-22、閉じたあとも 0.2 秒ごとの見張りが動き続け、
    ;   消えたはずの文字欄を書き換えようとして
    ;   「Error: The control is destroyed.」が出た。
    CloseTeach() {
        SetTimer(Watch, 0)
        SetTimer(GrabTick, 0)
        try Hotkey("*F1", "Off")
        try Hotkey("*F9", "Off")
        try Hotkey("*F2", "Off")
        try Hotkey("Esc", "Off")
        try dlg.Destroy()
    }
}

;==============================================================================
;  設定 — 初期設定と診断（ふだんは使わないもの）
;==============================================================================
; 調査履歴の件数が出ている場所を覚える。
;   ここが空だと G2 の裏取りができず、「調査できたか」を画面の見た目だけで
;   判断することになる（毎回 WARN が出ていた）。判定する側の仕組みは既にある。
ModeTeachCount() {
    global CFG, APP_NAME
    EnsureTarget()
    picked := ""
    dlg := Gui("+AlwaysOnTop", APP_NAME " - 調査履歴の件数の位置を登録" VerTag())
    dlg.MarginX := 16, dlg.MarginY := 12
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "w660", "調査履歴の件数が表示される位置を登録してください")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w660 h78 cGray"
        , "顧客のカードを開くと、これまでの調査の履歴が出ます。"
        . "その【件数】が表示されている場所にマウスを合わせて F1 を押してください。`n"
        . "ここを覚えると、調査の前後で件数が増えたかどうかを見て"
        . "【本当に調査できたか】を確かめられるようになります。`n"
        . "分からなければ「キャンセル」で閉じて構いません。"
        . "その場合はこれまでどおり、画面の見た目だけで判断します。")
    dlg.SetFont("s10", "Consolas")
    lblNow := dlg.Add("Text", "xm w660 h52", "")
    dlg.SetFont("s10 Bold", "Meiryo UI")
    lblGot := dlg.Add("Text", "xm w660 h52 cNavy", "まだ受け取っていません")
    dlg.SetFont("s10", "Meiryo UI")
    bSave := dlg.Add("Button", "xm w320 h38 Default", "保存して閉じる")
    bQuit := dlg.Add("Button", "x+16 yp w320 h38", "キャンセル")
    bSave.OnEvent("Click", (*) => SaveIt())
    bQuit.OnEvent("Click", (*) => ReopenAndExit(0))
    dlg.OnEvent("Close", (*) => ReopenAndExit(0))
    dlg.Show()
    Hotkey("*F1", (*) => PickIt())
    Hotkey("*F9", (*) => PickIt())
    SetTimer(WatchIt, 200)
    WatchIt()
    return

    WatchIt() {
        if (!WinExist("ahk_id " dlg.Hwnd)) {   ; 閉じたあとは書き換えない
            SetTimer(WatchIt, 0)
            return
        }
        uw := 0, uc := ""
        MouseGetPos(, , &uw, &uc)
        t := ""
        if (uc != "" && uw)
            try t := Trim(ControlGetText(uc, "ahk_id " uw))
        lblNow.Value := "いまの場所 : " (uc = "" ? "（コントロールがありません）" : uc)
                      . "`n読める文字 : " (t = "" ? "（空）" : SubStr(t, 1, 60))
                      . "`n件数として読む値 : " (ParseCount(t) = "" ? "（数字なし）" : ParseCount(t))
    }
    PickIt() {
        global G
        uw := 0, uc := ""
        MouseGetPos(, , &uw, &uc)
        if (uc = "") {
            MsgBox("その場所にはコントロールがありません。`n`n"
                . "件数の数字が表示される位置に、正確に合わせてください。"
                , APP_NAME, "Icon! 4096")
            return
        }
        ; ★対象ソフトの上を指しているか確かめる★
        ;   これが無いと、この記録画面そのものを指したまま F1 を押せてしまい、
        ;   まったく別のコントロール名が記録される（2026-09-17 の見直しで発見）。
        upid := 0
        try upid := WinGetPID("ahk_id " uw)
        if (!upid || upid != G.pid) {
            wexe := ""
            try wexe := WinGetProcessName("ahk_id " uw)
            MsgBox("いま指しているのは対象ソフトではありません。`n`n"
                . "　指している窓 : " (wexe = "" ? "（不明）" : wexe) "`n"
                . "　対象ソフト   : " CS("ExeName") "`n`n"
                . "対象ソフトのカード画面で、履歴の件数に合わせてから F1 を押してください。"
                , APP_NAME, "Icon! 4096")
            return
        }
        t := ""
        try t := Trim(ControlGetText(uc, "ahk_id " uw))
        picked := uc
        lblGot.Value := "受け取りました : " uc
                      . "`n読めた文字 : " (t = "" ? "（空）" : SubStr(t, 1, 60))
                      . "`n件数として読む値 : " (ParseCount(t) = "" ? "★数字なし★" : ParseCount(t))
    }
    SaveIt() {
        global CFG, APP_NAME
        if (picked = "") {
            MsgBox("まだ受け取っていません。件数の上で F1 を押してください。"
                , APP_NAME, "Icon! 4096")
            return
        }
        IniSet(CFG, ModelSec("Ctrl"), "RecordCountClassNN", picked)
        MsgBox("config.ini に記録しました。`n`n  RecordCountClassNN = " picked "`n`n"
            . "これから調査のたびに、履歴の件数が増えたかを確かめます。"
            . "増えていなければ完了とは判断しません。", APP_NAME, "Iconi 4096")
        ; ★保存したら閉じずに設定画面へ戻る★
        ;   続けて別の設定をしたいのに、毎回ソフトが消えていた（2026-09-22 指摘）。
        ;   見張りとキーを外してから閉じる（外し忘れると消えた文字欄を
        ;   書き換えようとして落ちる）。
        SetTimer(WatchIt, 0)
        try Hotkey("*F1", "Off")
        try Hotkey("*F9", "Off")
        try dlg.Destroy()
        BackToSettings()
        return
    }
}

; ★いま行の間隔が登録されているか、ボタンの字で見えるようにする★
;   2026-09-22、「設定したのに未登録と言われる」ことがあった。
;   設定ファイルを開かなくても確かめられるようにする。
; LINE のボタンの字
LineLabel() {
    if (LineReady())
        return "LINE の設定（" . LineMask(LineAdminId()) . " に送ります）"
    return "LINE の設定（まだ設定されていません）"
}

; メールのボタンの字
MailLabel() {
    if (MailReady())
        return "メールの設定（" . MailMask(MailFromAddr()) . " から送ります）"
    return "メールの設定（まだ設定されていません）"
}

; 通知のボタンの字。いまの状態が見えるようにする
NotifyLabel() {
    if (CB("NotifyEnabled"))
        return "通知の設定（いまは【使う】）"
    return "通知の設定（いまは【使わない】）"
}

; 「はじめての設定」ボタンの字。残りの件数が見えるようにする
SetupWizLabel() {
    left := 0
    for st in SetupSteps() {
        if (!st["d"] && st["must"])
            left++
    }
    if (left = 0)
        return "はじめての設定（順番に案内）　― 必要な設定は完了しています"
    return "★はじめての設定（順番に案内）　残り " . left . " 件★"
}

RowPitchLabel() {
    p := CI("ListRowPitchY")
    return "一覧の先頭行を登録（行の間隔: "
         . (p > 0 ? p . "px" : "★未登録★") . "）"
}

; ★人が開いた画面は、閉じずに前の画面へ戻す★
;   2026-09-22、あちこちで「やめる」や「×」がソフトごと終了していた。
;   いまのプロセスは終わらせ、戻り先を新しく起こす。こうすると、
;   止め忘れた見張りやホットキーを次の画面へ持ち込まない。
;   ★bat から直に開いたとき（人が画面をたどっていないとき）は、今までどおり終了する。
ReopenAndExit(code := 0) {
    global G
    if (G.fromMenu) {
        if (G.backTo = "wizard")
            RunSelf("/wizard")
        else if (G.backTo = "more")
            RunSelf("/more")
        else
            OpenMenuWindow()
    }
    ExitApp(code)
}

RunSelf(arg) {
    global APP_NAME
    try {
        Run(Chr(34) . A_AhkPath . Chr(34) . " " . Chr(34) . A_ScriptFullPath
            . Chr(34) . " " . arg, A_ScriptDir)
    } catch as e {
        Log("WARN", "画面を開き直せませんでした（" . arg . "）: " . e.Message)
    }
}

; ★設定を保存したあとに戻る先★
;   「はじめての設定」から入ったときは、そちらへ戻して続きを促す。
BackToSettings() {
    global G
    if (G.backTo = "wizard") {
        ModeWizard()
        return
    }
    ModeMore()
}

; モデル別の節を優先して読む（設定ファイルを開き直して、その場の値を見る）
CfgRead(m, sec, key, dflt := "") {
    mdl := Trim(CS("ModelName"))
    if (mdl != "" && mdl != "18D") {
        v := Trim(IniGet(m, sec . "." . mdl, key, ""))
        if (v != "")
            return v
    }
    return Trim(IniGet(m, sec, key, dflt))
}

; ★この PC で済ませるべきことの一覧★
;   2026-09-22、他社の PC に配って分かったこと。
;   設定はボタンが並んでいるだけで、どれが必須でどこまで済んだのかが分からなかった。
; full: true のときだけ、時間のかかる確認（タスクスケジューラ）を含む 3 つの手順も返す。
;   メニューを開くたびに呼ぶ側（必須の残りを数えるだけ）は false にして、軽く保つ。
SetupSteps(full := false) {
    global CFG
    m := IniLoad(CFG)
    exe := Trim(IniGet(m, "Target", "ExeName", ""))
    mdl := Trim(IniGet(m, "Model", "ModelName", ""))
    rowX := ToInt(CfgRead(m, "Select", "ListFirstRowX", "0"), 0)
    rowY := ToInt(CfgRead(m, "Select", "ListFirstRowY", "0"), 0)
    pitch := ToInt(CfgRead(m, "Select", "ListRowPitchY", "0"), 0)
    manN := ToInt(IniGet(m, ModelSecRead(m, "Manual"), "Count", "0"), 0)
    scanN := ToInt(IniGet(m, ModelSecRead(m, "ScanType"), "Count", "0"), 0)
    cnt := CfgRead(m, "Ctrl", "RecordCountClassNN", "")
    code := Trim(IniGet(m, "License", "UserCode", ""))
    rowVal := ""
    if (rowX > 0 && rowY > 0) {
        rowVal := "x" . rowX . " y" . rowY
        rowVal .= (pitch > 0) ? ("／間隔 " . pitch . "px") : "／★間隔が未登録★"
    }
    posVal := ""
    if (manN > 0 || scanN > 0)
        posVal := "調査タイプ " . scanN . " 件／マニュアル選択 " . manN . " 件"
    exeVal := ""
    if (exe != "")
        exeVal := exe . ((mdl = "") ? "" : ("（" . mdl . "）"))
    st := []
    ; scr: 先に開いておく画面（2026-10-11 カマヤンに確認）／ id: 画面の識別（違うときに知らせる）
    st.Push(Map("mode", "setup", "must", true
        , "t", "対象ソフトを選ぶ"
        , "scr", "どの画面でも構いません（対象ソフトを起動しておく）", "id", ""
        , "d", exe != "", "v", exeVal))
    st.Push(Map("mode", "pickrow", "must", true
        , "t", "一覧の 1 行目と 2 行目を登録"
        , "scr", "カード選択画面（顧客の一覧）を開いておく", "id", "S1_Index"
        , "d", (rowX > 0 && rowY > 0)
        , "v", rowVal))
    st.Push(Map("mode", "teachscan", "must", true
        , "t", "調査タイプ／マニュアル選択の位置を登録"
        , "scr", "調査のスキーム画面を開いておく", "id", "S3_Scheme"
        , "d", (manN > 0 || scanN > 0), "v", posVal))
    st.Push(Map("mode", "teachcount", "must", false
        , "t", "調査履歴の件数の位置を登録"
        , "scr", "カードを選択した後の画面を開いておく（件数は左下）", "id", "S2_Card"
        , "d", cnt != "", "v", cnt))
    st.Push(Map("mode", "code", "must", false
        , "t", "利用者コードを登録"
        , "scr", "どの画面でも構いません（インターネットにつないでおく）", "id", ""
        , "d", code != "", "v", code))
    if (full) {
        ; ★押すとその場で設定する手順★（別の画面は開かない）
        st.Push(Map("mode", "shortcut", "must", false, "quick", true
            , "t", "ショートカットを作成"
            , "scr", "", "id", ""
            , "d", (FileExist(A_Desktop . "\AutoMeta.lnk") != ""), "v", ""))
        st.Push(Map("mode", "startup", "must", false, "quick", true
            , "t", "PC 起動時の自動起動を登録"
            , "scr", "", "id", ""
            , "d", StartupIsOn(), "v", ""))
        st.Push(Map("mode", "watch", "must", false, "quick", true
            , "t", "異常終了時の自動再起動を登録"
            , "scr", "", "id", ""
            , "d", (WatchdogIsOn() && !WatchdogStale()), "v", ""))
    }
    return st
}

; ★はじめての設定の、その場で済む手順★
SetupQuick(md) {
    global APP_NAME
    if (md = "shortcut") {
        ShortcutNow()
    } else if (md = "startup") {
        if (StartupIsOn())
            MsgBox("PC 起動時の自動起動は、登録済みです。`n`n解除するときは、設定から行ってください。", APP_NAME, "Iconi 4096")
        else
            ToggleStartup()
    } else if (md = "watch") {
        if (WatchdogIsOn() && !WatchdogStale())
            MsgBox("異常終了時の自動再起動は、登録済みです。`n`n解除するときは、設定から行ってください。", APP_NAME, "Iconi 4096")
        else
            ToggleWatchdog()                       ; 古い場所のままなら、登録し直す
    }
}

; ★手順の前に、開いている画面を確かめる★（A-13）
;   違うときは知らせる。進めてよいか選べる。画面の見分けは完全ではないので、止めはしない。
;   戻り値: true = そのまま始める ／ false = 戻る
SetupScreenOk(stp) {
    global G, APP_NAME
    exe := Trim(CS("ExeName"))
    if (exe = "")
        return true                                ; 対象ソフトが未登録なら、確かめられない
    LoadScreens()                                  ; 画面の見分け方（画面の種類とウィンドウの対応）を読む
    G.pid := FindPidByExe(exe)
    if (!G.pid) {
        r := MsgBox("対象ソフト（" . exe . "）が見つかりません。`n`n"
            . "先に対象ソフトを起動し、次の画面を開いてから始めてください。`n`n"
            . "　" . stp["scr"] . "`n`n"
            . "このまま始めますか？", APP_NAME . " - 開いておく画面", "YesNo Icon! 4096")
        return (r = "Yes")
    }
    if (HasScreen(stp["id"]))
        return true
    r := MsgBox("いま開いているのは、別の画面のようです。`n`n"
        . "この手順の前に、次の画面を開いてください。`n`n"
        . "　" . stp["scr"] . "`n`n"
        . "このまま始めますか？`n（いいえ：戻って、画面を開いてからやり直す）"
        , APP_NAME . " - 開いておく画面", "YesNo Icon! 4096")
    return (r = "Yes")
}

; ★はじめての設定★ 必要なことを、順番に案内する
ModeWizard() {
    global APP_NAME, G
    G.backTo := "wizard"
    steps := SetupSteps(true)
    left := 0, nextMode := "", nextName := ""
    for st in steps {
        if (st["d"])
            continue
        if (st["must"])
            left++
        if (nextMode = "")
            nextMode := st["mode"], nextName := st["t"]
    }
    dlg := Gui("+AlwaysOnTop", APP_NAME " - はじめての設定" VerTag())
    dlg.MarginX := 20, dlg.MarginY := 12
    dlg.SetFont("s12 Bold", "Meiryo UI")
    dlg.Add("Text", "w640", "この PC で必要な設定を、上から順に進めてください")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w640 cGray"
        , "★の 3 つは、完了しないと運転できません。"
        . "それ以外は、あとからでも構いません。`n"
        . "測った値はこの PC にだけ残ります。ほかの PC の値は使えません。")
    dlg.Add("Text", "w640 h1 0x10")

    dlg.SetFont("s10", "Meiryo UI")
    for st in steps {
        mark := st["d"] ? "済" : (st["must"] ? "★まだ" : "任意")
        cap := Format("{1}　{2}", mark, st["t"])
        b := dlg.Add("Button", "xm w640 h36", cap)
        b.OnEvent("Click", MakeGo(st["mode"]))
        dlg.SetFont("s9", "Meiryo UI")
        if (!st.Has("quick")) {
            ; 先に開いておく画面を 1 行で添える。記録済みなら、その値も添える
            line := st["scr"]
            if (st["v"] != "")
                line .= "　／　記録: " . st["v"]
            else if (!st["d"])
                line .= "　／　まだ記録がありません"
            dlg.Add("Text", "xm+24 w600 " (st["d"] ? "cGreen" : "cGray"), line)
        }
        dlg.SetFont("s10", "Meiryo UI")
    }

    dlg.Add("Text", "xm w640 h1 0x10")
    dlg.SetFont("s10 Bold", "Meiryo UI")
    if (left = 0) {
        dlg.Add("Text", "w640 cGreen", "★必要な設定は完了しています★　運転を開始できます")
    } else {
        dlg.Add("Text", "w640 cRed", Format("あと {1} 件（次: {2}）", left, nextName))
    }
    dlg.SetFont("s10", "Meiryo UI")
    if (nextMode != "") {
        bNext := dlg.Add("Button", "xm w400 h38 Default", "次へ　→　" nextName)
        bNext.OnEvent("Click", MakeGo(nextMode))
        bBack := dlg.Add("Button", "x+16 yp w224 h38", "設定に戻る")
    } else {
        bBack := dlg.Add("Button", "xm w640 h38 Default", "設定に戻る")
    }
    bBack.OnEvent("Click", (*) => Leave())
    dlg.OnEvent("Close", (*) => Leave())
    dlg.Show()
    return

    ; ★ボタンごとに別の行き先を覚えさせる★
    ;   繰り返しの中で直接 (*) => Go(st["mode"]) と書くと、
    ;   すべてのボタンが最後の 1 つを指してしまう。
    MakeGo(md) {
        return (*) => Go(md)
    }

    Go(md) {
        global G
        dlg.Destroy()
        ; その場で済む 3 つの手順：やってから、この画面に戻る
        if (md = "shortcut" || md = "startup" || md = "watch") {
            SetupQuick(md)
            ModeWizard()
            return
        }
        ; 開いておく画面が違うときは、始める前に知らせる（知らせるだけ。進めるかは選べる）
        for stp in steps {
            if (stp["mode"] = md && stp["id"] != "" && !SetupScreenOk(stp)) {
                G.backTo := "wizard"
                ModeWizard()
                return
            }
        }
        G.mode := md
        G.fromMenu := true
        G.backTo := "wizard"
        switch md {
            case "setup":      ModeSetup()
            case "pickrow":    ModePickRow()
            case "teachscan":  ModeTeachScan()
            case "teachcount": ModeTeachCount()
            case "code":       ModeCode()
            default:           ModeMore()
        }
    }

    Leave() {
        global G
        G.backTo := "more"
        dlg.Destroy()
        ModeMore()
    }
}


;==============================================================================
;  V3 通知の土台 — 秘密の保管と、文面
;==============================================================================
; ★秘密（アプリパスワード・LINE のトークン）は平文で置かない★
;   Windows の DPAPI で暗号化して保存する。
;   復号できるのは【その PC の、そのログイン利用者】だけ。
;   ファイルを抜き取られても、別の PC では開けない。
;
; ★置き場所は同期されない場所★
;   ツールのフォルダはドライブにバックアップされていることがある。
;   秘密や写真がそこに入ると、意図せず複製される（2026-09-26 の点検）。
NotifyDir() {
    base := EnvGet("LOCALAPPDATA")
    if (base = "")
        base := A_ScriptDir                        ; 取れないときは仕方なく手元へ
    dir := base . "\AutoMeta"
    if !DirExist(dir)
        DirCreate(dir)
    return dir
}

SecretDir() {
    dir := NotifyDir() . "\secrets"
    if !DirExist(dir)
        DirCreate(dir)
    return dir
}

SecretPath(name) => SecretDir() . "\" . name . ".bin"

; 秘密を暗号化して保存する。空文字なら削除。
SecretSave(name, text) {
    path := SecretPath(name)
    if (text = "") {
        try FileDelete(path)
        return true
    }
    ; ★箱は終端の 0 のぶんまで確保する★
    ;   StrPut に渡す長さ（bytes + 1）より箱が小さいと Invalid Length で落ちる。
    ;   暗号化するのは終端を除いた bytes ぶんだけ（2026-09-26）。
    bytes := StrPut(text, "UTF-8") - 1             ; 終端の 0 は数えない
    src := Buffer(bytes + 1, 0)
    StrPut(text, src, bytes + 1, "UTF-8")
    inBlob := Buffer(A_PtrSize * 2, 0)
    NumPut("UInt", bytes, inBlob, 0)
    NumPut("Ptr", src.Ptr, inBlob, A_PtrSize)
    outBlob := Buffer(A_PtrSize * 2, 0)
    ok := DllCall("Crypt32\CryptProtectData", "Ptr", inBlob, "Ptr", 0
        , "Ptr", 0, "Ptr", 0, "Ptr", 0, "UInt", 0, "Ptr", outBlob)
    if (!ok) {
        Log("WARN", "秘密を暗号化できませんでした: " . name)
        return false
    }
    size := NumGet(outBlob, 0, "UInt")
    ptr  := NumGet(outBlob, A_PtrSize, "Ptr")
    out  := Buffer(size)
    DllCall("RtlMoveMemory", "Ptr", out.Ptr, "Ptr", ptr, "Ptr", size)
    DllCall("LocalFree", "Ptr", ptr)
    try FileDelete(path)
    try {
        fh := FileOpen(path, "w")
        fh.RawWrite(out, size)
        fh.Close()
    } catch as e {
        Log("WARN", "秘密を保存できませんでした: " . e.Message)
        return false
    }
    return true
}

; 保存した秘密を読み出す。無ければ空文字。
SecretLoad(name) {
    path := SecretPath(name)
    if !FileExist(path)
        return ""
    try {
        fh := FileOpen(path, "r")
        size := fh.Length
        enc := Buffer(size)
        fh.RawRead(enc, size)
        fh.Close()
    } catch as e {
        Log("WARN", "秘密を読めませんでした: " . e.Message)
        return ""
    }
    inBlob := Buffer(A_PtrSize * 2, 0)
    NumPut("UInt", size, inBlob, 0)
    NumPut("Ptr", enc.Ptr, inBlob, A_PtrSize)
    outBlob := Buffer(A_PtrSize * 2, 0)
    ok := DllCall("Crypt32\CryptUnprotectData", "Ptr", inBlob, "Ptr", 0
        , "Ptr", 0, "Ptr", 0, "Ptr", 0, "UInt", 0, "Ptr", outBlob)
    if (!ok) {
        ; ★別の PC へコピーされた・利用者が変わった、のどちらか★
        Log("WARN", "秘密を復号できませんでした（別の PC で作られた可能性）: " . name)
        return ""
    }
    outSize := NumGet(outBlob, 0, "UInt")
    outPtr  := NumGet(outBlob, A_PtrSize, "Ptr")
    text := StrGet(outPtr, outSize, "UTF-8")
    DllCall("RtlMoveMemory", "Ptr", outPtr, "Ptr", Buffer(outSize, 0).Ptr, "Ptr", outSize)
    DllCall("LocalFree", "Ptr", outPtr)
    return text
}

SecretHas(name) => FileExist(SecretPath(name)) ? true : false

;------------------------------------------------------------------------------
;  文面
;------------------------------------------------------------------------------
; ★差し込めるのはこの 6 つだけ★
;   氏名を自由文に書けるようにしない。書けてしまうと、宛名の設定
;   （なし／姓のみ／フルネーム）が意味を失う（2026-09-26 の点検 3 番）。
NotifyTemplatePath() => A_ScriptDir . "\notify_done.txt"

NotifyTemplateDefault() {
    return "{宛名}様`r`n`r`n"
         . "{日付} のセラピーが完了しました。`r`n`r`n"
         . "　実施時刻　{開始}〜{終了}`r`n"
         . "　セラピー　{回数} 回`r`n"
         . "　測定　　　全身 {項目数} か所`r`n`r`n"
         . "おつかれさまでした。ゆっくりお休みください。"
}

NotifyTemplate() {
    path := NotifyTemplatePath()
    if !FileExist(path)
        return NotifyTemplateDefault()
    txt := ""
    try txt := FileRead(path, "UTF-8")
    txt := StrReplace(txt, Chr(0xFEFF), "")
    return (Trim(txt) = "") ? NotifyTemplateDefault() : txt
}

NotifyTemplateSave(txt) {
    ; ★消してから書かない★
    ;   その一瞬、読む側には空に見える。空なら既定の文面に落ちるため、
    ;   セラピーの終了と重なると、直した文面ではなく既定の文面で届く。
    ;   エラーも出ないので気づけない（2026-10-05 の点検）。
    IniWriteBody(NotifyTemplatePath(), txt)
}

; 宛名に入れる名前を作る（設定に応じて。名前を出さない選択もできる）
;   ★「様」「さま」などの敬称は付けない★
;     敬称は文面側に書いてもらう（2026-09-26 指摘）。ここで付けると
;     文面の「{宛名}さま」と重なって「見本様さま」になる。
NotifyAddressee(sei, mei) {
    style := Trim(CS("NameStyle"))
    if (style = "none")
        return ""
    if (style = "full")
        return Trim(sei . " " . mei)
    return Trim(sei)                               ; 既定は姓のみ
}

; 文面に値を差し込む
NotifyFill(tpl, vals) {
    out := tpl
    ; ★名前を入れない設定のときは、宛名の行ごと消す★
    ;   そうしないと「様」だけが浮いた行が残る（2026-09-26）。
    if (vals.Has("宛名") && Trim(vals["宛名"]) = "") {
        kept := ""
        Loop Parse, out, "`n", "`r"
        {
            if (InStr(A_LoopField, "{宛名}"))
                continue
            kept .= (kept = "" ? "" : "`r`n") . A_LoopField
        }
        out := kept
    }
    for key, val in vals
        out := StrReplace(out, "{" . key . "}", val)
    ; 先頭に空行が残らないようにする
    out := RegExReplace(out, "^(\r\n)+", "")
    return out
}

; 使えない差し込みが残っていないか調べる（共通・個別で同じ判定を使う）
;   戻り値は、見つかった差し込みの名前。無ければ空。
NotifyBadPlaceholder(txt) {
    work := txt
    for nm in ["宛名", "日付", "開始", "終了", "回数", "項目数"]
        work := StrReplace(work, "{" . nm . "}", "")
    if (RegExMatch(work, "\{([^}]*)\}", &mm))
        return mm[1]
    return ""
}

;------------------------------------------------------------------------------
;  顧客ごとの文面（3.9）
;------------------------------------------------------------------------------
; ★「個別を使う」スイッチは作らない★
;   中身があれば個別、無ければ共通。これだけで決まる。
;   スイッチを置くと「オンだが空」「オフだが中身あり」の矛盾が作れてしまう
;   （2026-09-30 の整理と同じ考え方）。
;
; ★ファイル名に氏名を出さない★
;   暗号化メール（pm_）と同じく、予定のキーを 16 進に直して名前にする。
;   並べただけで誰のものか分からないようにする。
;
; ★暗号化はしない★
;   共通の文面が平文なので、そろえる。氏名は {宛名} で差し込む作りなので、
;   文面そのものには個人情報が入らない。
NotifyBodyDir() {
    dir := NotifyDir() . "\bodies"
    if !DirExist(dir)
        DirCreate(dir)
    return dir
}

NotifyBodyFile(key) {
    out := "nb_"
    for i, b in StrToUtf8Bytes(Trim(key))
        out .= Format("{:02x}", b)
    return out . ".txt"
}

NotifyBodyPath(key) => NotifyBodyDir() . "\" . NotifyBodyFile(key)

NotifyBodyGet(key) {
    if (Trim(key) = "")
        return ""
    path := NotifyBodyPath(key)
    if !FileExist(path)
        return ""
    txt := ""
    try txt := FileRead(path, "UTF-8")
    txt := StrReplace(txt, Chr(0xFEFF), "")
    return (Trim(txt) = "") ? "" : txt
}

NotifyBodyHas(key) => (NotifyBodyGet(key) != "")

; ★空は「個別をやめる」と同じ★
;   ただし黙って共通に落とさない。呼ぶ側で明示してからここへ来る。
NotifyBodySave(key, txt) {
    if (Trim(key) = "")
        return false
    if (Trim(txt) = "")
        return NotifyBodyClear(key)
    ; ★消してから書かない★ 読む側に空として見えると、共通に落ちてしまう
    return IniWriteBody(NotifyBodyPath(key), txt)
}

NotifyBodyClear(key) {
    if (Trim(key) = "")
        return false
    try FileDelete(NotifyBodyPath(key))
    return true
}

; ★送信側はこれだけ呼ぶ★ 呼び口を 1 つにしておけば、個別対応の漏れが出ない
NotifyTemplateFor(key) {
    body := NotifyBodyGet(key)
    return (body = "") ? NotifyTemplate() : body
}

; 届け先の画面に出す、いまの状態
NotifyBodyWord(key) => NotifyBodyHas(key) ? "★この顧客だけの文面" : "共通の文面を使用"

; ★数えるのは予定の一覧から★
;   フォルダを走査すると、消された顧客の残骸まで顧客として数えてしまう。
NotifyBodyOwners() {
    out := [], err := ""
    for p in LoadSchedule(&err) {
        if (NotifyBodyHas(p["key"]))
            out.Push(p)
    }
    return out
}

; 予定にない文面（消された顧客の残骸）
;   ★16 進から名前に戻さない★
;   予定の側から期待するファイル名を作り、そこに無いものを残骸とする。
NotifyBodyOrphans() {
    want := Map(), err := ""
    for p in LoadSchedule(&err)
        want[StrLower(NotifyBodyFile(p["key"]))] := true
    out := []
    Loop Files, NotifyBodyDir() . "\nb_*.txt"
    {
        if (!want.Has(StrLower(A_LoopFileName)))
            out.Push(A_LoopFileFullPath)
    }
    return out
}

NotifyBodyOwnersWord() {
    n := NotifyBodyOwners().Length
    if (n = 0)
        return "個別の文面を持つ顧客はいません。この文面が全員に届きます。"
    return "※ 個別の文面を持つ顧客が " . n . " 名います。この変更は届きません。"
}

; ★顧客ごとの文面を編集する画面★
;   共通の設定画面（ModeNotify）とは別の、小さな画面にする。
;   共通の画面はすでに縦の上限に近く、ここに足すと見切れる。
NotifyBodyDialog(key, whom) {
    global APP_NAME
    done := false
    cur  := NotifyBodyGet(key)
    ; ★白紙から書かせない★ 個別が無ければ共通を入れておく
    start := (cur = "") ? NotifyTemplate() : cur

    dlg := Gui("+AlwaysOnTop +ToolWindow", APP_NAME . " - 顧客ごとの文面")
    dlg.MarginX := 16, dlg.MarginY := 12
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "w640", (whom = "") ? "顧客ごとの文面" : (whom . " さんの文面"))
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w640 cGray"
        , "この顧客にだけ、別の文面でお送りします。"
        . "空にして保存すると、共通の文面に戻ります。`n"
        . "使用できる差し込みは {宛名} {日付} {開始} {終了} {回数} {項目数} の 6 つです。`n"
        . "★お名前を直接書かないでください★（宛名の設定が無効になります）")
    dlg.SetFont("s10", "Meiryo UI")
    eBody := dlg.Add("Edit", "xm w640 h150 Multi WantReturn", start)

    bView := dlg.Add("Button", "xm w152 h34", "プレビュー")
    bMine := dlg.Add("Button", "x+8 yp w152 h34", "テスト送信")
    bLoad := dlg.Add("Button", "x+8 yp w152 h34", "共通の文面を読み込む")
    bBack := dlg.Add("Button", "x+8 yp w152 h34", "共通に戻す")
    bSave := dlg.Add("Button", "xm w310 h38 Default", "保存")
    bNo   := dlg.Add("Button", "x+20 yp w310 h38", "キャンセル")

    bView.OnEvent("Click", (*) => Peek())
    bMine.OnEvent("Click", (*) => SendMine())
    bLoad.OnEvent("Click", (*) => LoadCommon())
    bBack.OnEvent("Click", (*) => BackToCommon())
    bSave.OnEvent("Click", (*) => Keep())
    bNo.OnEvent("Click",   (*) => Leave())
    dlg.OnEvent("Close",   (*) => Leave())
    dlg.Show()
    while (!done)
        Sleep(60)
    try dlg.Destroy()
    return

    ; ★その顧客の名前で組み立てる★ その方の見え方を確かめるための画面なので
    Made() {
        parts := StrSplit(Trim(whom), " ")
        sei := (parts.Length >= 1) ? parts[1] : ""
        mei := (parts.Length >= 2) ? parts[2] : ""
        tpl := NotifyDropZero(eBody.Value, "回数",   "3")
        tpl := NotifyDropZero(tpl, "項目数", "42")
        return NotifyFill(tpl, Map(
            "宛名",   NotifyAddressee(sei, mei),
            "日付",   FormatTime(A_Now, "M月d日(ddd)"),
            "開始",   "1:05",
            "終了",   "1:22",
            "回数",   "3",
            "項目数", "42"))
    }

    Peek() {
        MsgBox("この形でお送りします。`n`n"
            . "────────────────`n"
            . Made() . "`n"
            . "────────────────"
            , APP_NAME . " - プレビュー", "Iconi 4096")
    }

    ; ★送り先はご自身★ 顧客へは送らない
    SendMine() {
        if (NotifyGateBox())
            return
        if (!MailReady() && !LineReady()) {
            MsgBox("メールも LINE も、まだ設定されていません。`n`n"
                . "設定 →「メール」か「LINE」を先に済ませてください。"
                , APP_NAME, "Icon! 4096")
            return
        }
        ok := NotifyTestNow("AutoMeta 文面のテスト送信"
            , "これはテスト送信です。顧客には送信していません。`n`n"
            . "────────────────`n"
            . Made() . "`n"
            . "────────────────`n`n"
            . "　顧客　" . Trim(whom) . "`n"
            . "　送信時刻　" . FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss"))
        if (ok) {
            MsgBox("ご自身の宛先へお送りしました。`n`n"
                . "実際に顧客へ届くのと同じ文面・同じ見え方です。`n"
                . "※ 設定は保存していません。"
                , APP_NAME . " - 送信の結果", "Iconi 4096")
            return
        }
        MsgBox("送れませんでした。`n`n"
            . "理由はログの最後の行に出ています（その他 →「ログを見る」）。"
            , APP_NAME . " - 送信の結果", "Icon! 4096")
    }

    LoadCommon() {
        if (MsgBox("共通の文面を読み込みます。よろしいですか？`n`n"
            . "いま編集中の内容は失われます。"
            , APP_NAME, "YesNo Icon? 4096") = "Yes")
            eBody.Value := NotifyTemplate()
    }

    BackToCommon() {
        if (MsgBox("この顧客を、共通の文面に戻します。よろしいですか？`n`n"
            . "この顧客だけの文面は失われます。"
            , APP_NAME, "YesNo Icon? 4096") != "Yes")
            return
        NotifyBodyClear(key)
        Log("INFO", "顧客ごとの文面を削除しました（" . key . "）")
        MsgBox("共通の文面に戻しました。", APP_NAME, "Iconi 4096")
        done := true
    }

    Keep() {
        bad := NotifyBadPlaceholder(eBody.Value)
        if (bad != "") {
            MsgBox("文面に、使えない差し込みがあります: {" . bad . "}`n`n"
                . "使えるのは {宛名} {日付} {開始} {終了} {回数} {項目数} だけです。"
                , APP_NAME, "Icon! 4096")
            return
        }
        ; ★空のときは、黙って共通に落とさない★ そうなると明示して消す
        if (Trim(eBody.Value) = "") {
            if (MsgBox("文面が空です。共通の文面に戻しますか？`n`n"
                . "この顧客だけの文面は失われます。"
                , APP_NAME, "YesNo Icon? 4096") != "Yes")
                return
            NotifyBodyClear(key)
            Log("INFO", "顧客ごとの文面を削除しました（" . key . "）")
            done := true
            return
        }
        if (!NotifyBodySave(key, eBody.Value)) {
            MsgBox("保存できませんでした。`n`n"
                . "ほかの画面が同じファイルを開いている可能性があります。`n"
                . "少し待ってから、もう一度お試しください。"
                , APP_NAME, "Icon! 4096")
            return
        }
        Log("INFO", "顧客ごとの文面を保存しました（" . key . "）")
        done := true
    }

    Leave() {
        done := true
    }
}

; ★誰が個別の文面を持っているかを見せる画面★
;   共通の文面を直しても、ここに並ぶ顧客には届かない。
NotifyBodyListDialog() {
    global APP_NAME
    done := false
    owners := NotifyBodyOwners()

    dlg := Gui("+AlwaysOnTop +ToolWindow", APP_NAME . " - 顧客ごとの文面")
    dlg.MarginX := 16, dlg.MarginY := 12
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "w660", "個別の文面を持つ顧客")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w660 cGray"
        , "ここに並ぶ顧客には、共通の文面の変更が届きません。")
    dlg.SetFont("s10", "Meiryo UI")
    lv := dlg.Add("ListView", "xm w660 r8 Grid", ["順", "顧客", "文面のはじまり"])
    tOrphan := dlg.Add("Text", "xm w660 cRed", "")

    bEdit := dlg.Add("Button", "xm w160 h32", "文面を編集")
    bBack := dlg.Add("Button", "x+8 yp w160 h32", "共通に戻す")
    bSweep := dlg.Add("Button", "x+8 yp w160 h32", "残骸を削除")
    bClose := dlg.Add("Button", "x+8 yp w160 h32 Default", "閉じる")

    bEdit.OnEvent("Click",  (*) => EditOne())
    bBack.OnEvent("Click",  (*) => BackOne())
    bSweep.OnEvent("Click", (*) => Sweep())
    bClose.OnEvent("Click", (*) => Leave())
    dlg.OnEvent("Close",    (*) => Leave())
    Fill()
    dlg.Show()
    while (!done)
        Sleep(60)
    try dlg.Destroy()
    return

    Fill() {
        owners := NotifyBodyOwners()
        lv.Delete()
        for i, pp in owners {
            head := ""
            Loop Parse, NotifyBodyGet(pp["key"]), "`n", "`r"
            {
                if (Trim(A_LoopField) != "") {
                    head := Trim(A_LoopField)
                    break
                }
            }
            if (StrLen(head) > 34)
                head := SubStr(head, 1, 34) . "…"
            lv.Add("", i, Trim(pp["sei"] . " " . pp["mei"]), head)
        }
        lv.ModifyCol(1, 40), lv.ModifyCol(2, 170), lv.ModifyCol(3, 420)
        ; ★残骸は黙って消さない★ 件数を見せて、押したときだけ消す
        n := NotifyBodyOrphans().Length
        orphanWord := ""
        if (n > 0)
            orphanWord := "★ 予定から消された顧客の文面が " . n
                        . " 件残っています（「残骸を削除」で消せます）"
        tOrphan.Value := orphanWord
        bSweep.Enabled := (n > 0)
        bEdit.Enabled := (owners.Length > 0)
        bBack.Enabled := (owners.Length > 0)
    }

    ; ★表示の行番号を配列の位置に使わない★ 並べ替えでずれる（2026-10-02 の教訓）
    Picked(why) {
        row := lv.GetNext()
        if (row < 1) {
            MsgBox("一覧から、" . why . "顧客を選んでください。", APP_NAME, "Icon! 4096")
            return 0
        }
        idx := 0
        try idx := Integer(lv.GetText(row, 1))
        if (idx < 1 || idx > owners.Length) {
            MsgBox("選んだ行を読み取れませんでした。`n`n"
                . "一覧を開き直してから、もう一度お試しください。"
                , APP_NAME, "Icon! 4096")
            return 0
        }
        return idx
    }

    EditOne() {
        idx := Picked("編集したい")
        if (idx < 1)
            return
        pp := owners[idx]
        NotifyBodyDialog(pp["key"], Trim(pp["sei"] . " " . pp["mei"]))
        Fill()
    }

    BackOne() {
        idx := Picked("共通に戻したい")
        if (idx < 1)
            return
        pp := owners[idx]
        whom := Trim(pp["sei"] . " " . pp["mei"])
        if (MsgBox(whom . " さんを、共通の文面に戻します。よろしいですか？`n`n"
            . "この顧客だけの文面は失われます。"
            , APP_NAME, "YesNo Icon? 4096") != "Yes")
            return
        NotifyBodyClear(pp["key"])
        Log("INFO", "顧客ごとの文面を削除しました（" . pp["key"] . "）")
        Fill()
    }

    Sweep() {
        list := NotifyBodyOrphans()
        if (list.Length = 0)
            return
        if (MsgBox("予定にない文面を " . list.Length . " 件削除します。よろしいですか？`n`n"
            . "予定から消された顧客の文面です。元に戻せません。"
            , APP_NAME, "YesNo Icon? 4096") != "Yes")
            return
        gone := 0
        for f in list {
            try {
                FileDelete(f)
                gone++
            }
        }
        Log("INFO", "予定にない顧客ごとの文面を " . gone . " 件削除しました")
        MsgBox(gone . " 件削除しました。", APP_NAME, "Iconi 4096")
        Fill()
    }

    Leave() {
        done := true
    }
}

; 設定画面のプレビュー用。実在しない値で組み立てる
NotifySample() {
    return NotifyFill(NotifyTemplate(), Map(
        "宛名",   NotifyAddressee("見本", "花子"),
        "日付",   FormatTime(A_Now, "M月d日(ddd)"),
        "開始",   "1:05",
        "終了",   "1:22",
        "回数",   "3",
        "項目数", "42"))
}


;==============================================================================
;  送信だけを担当する別プロセス（V3・2026-09-30）
;==============================================================================
; ★なぜ分けるか★
;   メールや LINE の送信は数秒から数十秒かかる。本体が送ろうとすると、
;   その間だけ画面の見張りが止まり、セラピーの途切れと読み違える恐れがある。
;   送信を別のプロセスに出せば、本体は一切止まらない。
;   本体は「送ってほしいもの」を置くだけ。運ぶのはこちらの役目。
;
; ★二重に立てない★
;   生きている印（notifier.lock）を 30 秒ごとに書き、
;   その新しさで「もう動いているか」を見分ける。
NotifierLock() => NotifyDir() . "\notifier.lock"

; 印の中身。「…… start」なら、親が置いた【これから起こす】の印。
NotifierMark() {
    out := ""
    try out := Trim(FileRead(NotifierLock(), "UTF-8"))
    return out
}

; 印を書く。★消してから書かない★ 別名に書いて置き換える（読む側に、印が無い一瞬を見せない）。
NotifierLockWrite(text) {
    tmp := NotifierLock() . ".tmp"
    try {
        FileDelete(tmp)
    }
    try {
        FileAppend(text, tmp, "UTF-8")
        FileMove(tmp, NotifierLock(), 1)
    }
}

; 印を最後に書いてから何秒たったか。印が無い・読めないときは -1。
NotifierStaleSec() {
    if (!FileExist(NotifierLock()))
        return -1
    stamp := SubStr(NotifierMark(), 1, 14)
    return (StrLen(stamp) = 14) ? DateDiff(A_Now, stamp, "Seconds") : -1
}

; 印が古いのに残っている＝送信係が止まっている（送信の途中で戻ってこない）。
;   2026-10-14 00:20、管理者への通知を送っている途中で送信係が止まり、77 分のあいだ、誰も気づかなかった
;   （メールの部品 CDO は、相手が返事をしなくなると、いつまでも待つ）。
;   止まった送信係を終了させて、新しいものに引き継ぐ。番号が別のプロセスに使い回されていないか、
;   コマンドラインに /notifier があるかを確かめてから終了させる。
NotifierKillStale() {
    if (!FileExist(NotifierLock()) || NotifierAlive())
        return false
    mark := NotifierMark()
    if (!RegExMatch(mark, "pid=(\d+)", &mm))
        return false
    pid := Integer(mm[1])
    if (pid <= 0 || pid = ProcessExist() || !ProcessExist(pid))
        return false
    cmd := ""
    try {
        for pr in ComObjGet("winmgmts:").ExecQuery("Select CommandLine From Win32_Process Where ProcessId=" . pid)
            cmd := pr.CommandLine
    }
    if (!InStr(cmd, "/notifier"))
        return false
    sec := NotifierStaleSec()
    if (sec < 300)                                  ; 数通を順に送っていて時間がかかっているだけのことがある。5 分は待つ
        return false
    try ProcessClose(pid)
    Log("WARN", Format("送信係（{1}）が {2} 秒のあいだ応答しないため、終了させました。送信待ちの通知は、新しい送信係が送り直します", pid, sec))
    return true
}

; 送信係が生きているか
NotifierAlive() {
    if !FileExist(NotifierLock())
        return false
    mark := NotifierMark()
    stamp := SubStr(mark, 1, 14)
    if (StrLen(stamp) != 14)
        return false
    ; 起動の印は短めに切る。立ち上がらなかったときに詰まらせないため。
    limit := InStr(mark, "start") ? 60 : 90
    return (DateDiff(A_Now, stamp, "Seconds") < limit)
}

; 送るものを置いたら呼ぶ。いなければ起こす。
NotifierEnsure() {
    if (NotifierAlive())
        return
    ; ★起こす前に印をつける★
    ;   送信係は立ち上がるまで 3〜4 秒かかり、その間は印がない。
    ;   1 秒の間に 2 回呼ぶと 2 つ起動し、同じ通知を二重に送っていた
    ;   （2026-10-01、完了通知がメール・LINE とも 2 通ずつ）。
    ;   先に印をつけておけば、あとから呼ばれても起こさない。
    ;   起こせなかったときは印を消す。立ち上がらなくても 90 秒で切れる。
    NotifierLockWrite(FormatTime(A_Now, "yyyyMMddHHmmss") . " start")
    try {
        Run(Chr(34) . A_AhkPath . Chr(34) . " " . Chr(34) . A_ScriptFullPath
            . Chr(34) . " /notifier", A_ScriptDir, "Hide")
        Log("INFO", "送信係を起こしました")
    } catch as e {
        try FileDelete(NotifierLock())
        Log("WARN", "送信係を起こせませんでした: " . e.Message)
    }
}

; 送信係の本体。画面は出さない。
ModeNotifier() {
    global G
    ; ★親が置いた「start」の印は、自分へのバトン★
    ;   これを「ほかが動いている」と読むと、起動した瞬間に終わる。
    ;   2026-10-01 の変更でここを見落とし、送信係が 3 日間死んでいた。
    ;   その間、貯まった通知は 1 通も出ていかなかった（2026-10-04 発覚）。
    if (!InStr(NotifierMark(), "start") && NotifierAlive()) {
        Log("INFO", "送信係はすでに動いているため、終わります")
        ExitApp(0)
        return
    }
    Log("INFO", "送信係を始めます")
    G.notifierIdle := A_Now
    SetTimer(NotifierTick, 15000)
    NotifierTick()
}

NotifierTick() {
    global G
    LogFlush()
    ; 生きている印を更新する（番号つき。止まったときに、本体が終了させるため）
    NotifierLockWrite(FormatTime(A_Now, "yyyyMMddHHmmss") . " pid=" . ProcessExist())
    left := NotifyReadyCount()
    if (left > 0) {
        NotifyFlush()
        left := NotifyReadyCount()
    }
    if (left > 0) {
        G.notifierIdle := A_Now                    ; まだ仕事がある
        return
    }
    ; ★仕事が無い時間が続いたら、静かに終わる★
    ;   使っていないプロセスを、いつまでも残さない。
    if (SecSince(G.notifierIdle) >= 600) {
        Log("INFO", "送るものが 10 分ありません。送信係を終わります")
        try FileDelete(NotifierLock())
        ExitApp(0)
    }
}

;==============================================================================
;  顧客の連絡先（V3・ステップ 2）
;==============================================================================
; ★連絡先は、予定のファイルに書かない★
;   schedule.ini はドライブに同期されることがある。
;   お名前と LINE の ID が一緒に同期先へ複製されるのを避ける（2026-09-26 の点検）。
;   この PC の中の、同期されない場所にだけ置く。
ContactPath() => NotifyDir() . "\contacts.ini"

; ★contacts.ini は UTF-8。IniRead で読まない★
;   見出しは「Patient.〇〇」のように日本語になることがある。
;   Windows の ini 読み出しは別の文字コードとして扱うため見出しが一致せず、
;   日本語名の方は連絡先がまったく読めない（2026-10-03）。
;   書き込み（IniSetMany）は UTF-8 なので、読みだけが合っていなかった。
;   消すときは空文字を書く（IniGet は空を「無し」として扱う）。
ContactAll() => IniLoad(ContactPath())

; ★メールアドレスは暗号化して保管する★
;   LINE の ID は意味を持たない文字列だが、メールアドレスは
;   それ自体が個人情報。トークンと同じ金庫（この PC の中・同期しない）へ入れる。
;   ★ファイル名にも氏名を出さない★ 並べただけで誰か分かるのは良くない。
;   予定のキーを 16 進に直して名前にする。
ContactMailName(key) {
    out := "pm_"
    for i, b in StrToUtf8Bytes(Trim(key))
        out .= Format("{:02x}", b)
    return out
}
ContactMailGet(key) => (Trim(key) = "") ? "" : SecretLoad(ContactMailName(key))
ContactMailSet(key, addr) {
    if (Trim(key) = "")
        return
    SecretSave(ContactMailName(key), Trim(addr))
}
ContactMailHas(key) => (Trim(key) != "") && SecretHas(ContactMailName(key))

; 予定の一覧の「配信設定」の列。顧客へのお知らせの届け先と、送るかどうか。短く（列の幅に収まる長さ）。
;   未設定／LINE／メール／LINE＋メール／オフ（…）／対象外（プラン）。
NotifyListText(key) {
    if (Trim(key) = "")
        return "未設定"
    got := ContactGet(key)
    ways := ""
    if (got["line"] != "")
        ways := "LINE"
    if (ContactMailHas(key))
        ways .= (ways = "" ? "" : "＋") . "メール"
    if (ways = "")
        return "未設定"
    if (!NotifyAllowed())
        return "対象外（プラン）"
    if (!got["on"])
        return "オフ（" . ways . "）"
    return ways . (ContactPreGet(key) ? "＋事前" : "")
}

; 予定の一覧に出す、届け先のひとこと
ContactSummary(key) {
    if (Trim(key) = "")
        return "保存してから設定できます"
    got := ContactGet(key)
    ways := ""
    if (got["line"] != "")
        ways := "LINE"
    if (ContactMailHas(key))
        ways .= (ways = "" ? "" : " ／ ") . "メール"
    if (ways = "")
        return "まだ設定されていません"
    if (!got["on"])
        return ways . "（いまは送りません）"
    return ways . "　" . NotifyWhenWord()
}

; ★届け先の画面★ LINE とメールをここでまとめて扱う。
;   メールアドレスは暗号化して保管し、画面を閉じたら持ち回さない。
; ★登録用の QR を発行する★ 届け先の画面から呼ぶ。
;   以前は予定の編集の中にあったが、画面を分けたときに呼び出し元が無くなり、
;   「この画面を閉じてから『登録用の QR』を押してください」という
;   存在しないボタンへの案内だけが残っていた（2026-10-05 指摘）。
RegIssueFor(key, sei, mei, curId) {
    global APP_NAME
    ; ★保存前は、紐づけ先が決まっていない★
    ;   新しい予定の key は、この画面を閉じたあとに決まる。
    ;   先に発行すると、受け取った ID の行き先が無くなる（2026-10-01）。
    if (Trim(key) = "") {
        MsgBox("先にこの予定を保存してください。`n`n"
            . "　1. この画面を閉じ、予定の編集で「保存」を押す`n"
            . "　2. もう一度この方の行を開く`n"
            . "　3.「お知らせの届け先」→「登録用の QR」を押す`n`n"
            . "新しい予定は、保存するまで紐づけ先が決まりません。"
            , APP_NAME, "Icon! 4096")
        return
    }
    if (NotifyGateBox())                           ; 一般は、QR を出さない
        return
    if (!NotifyOn()) {
        MsgBox("通知が「使わない」になっています。`n`n"
            . "設定 →「通知」で「通知を使う」をオンにしてください。`n"
            . "オフのままでは、登録しても送信されません。"
            , APP_NAME, "Icon! 4096")
        return
    }
    if (!LineReady()) {
        MsgBox("LINE の設定が済んでいません。`n`n"
            . "設定 →「LINE」で、トークンとユーザー ID を登録してください。"
            , APP_NAME, "Icon! 4096")
        return
    }
    if (!RegReady()) {
        MsgBox("登録用の QR は、まだ使えません。`n`n"
            . "設定 →「登録用 QR」で、LIFF ID を登録してください。`n"
            . "同じ画面に手順があります。", APP_NAME, "Icon! 4096")
        return
    }
    if (Trim(curId) != "") {
        if (MsgBox("この方には、すでに LINE の ID が登録されています。`n`n"
            . "新しい QR を発行すると、読み取ったときに ID が入れ替わります。`n"
            . "続けますか？", APP_NAME, "YesNo Icon? 4096") != "Yes")
            return
    }
    code := RegCodeNew()
    ; ★古い承認待ちは捨てる★ 残しておくと、新しい QR を出したあとに
    ;   古い ID の承認画面が出て、そちらが入ってしまう（2026-10-02）。
    RegPendIdClear(key)
    RegPendSet(key, code)
    why := RegSheetOpen(sei, mei, code)
    A_Clipboard := RegQrUrl(code)
    if (why != "") {
        ; ★開けなくても登録はできる★ リンクさえ渡せば読んでもらえる
        MsgBox("登録用のページを開けませんでした。`n`n"
            . "　" . why . "`n`n"
            . "リンクはコピーしてあります。`n"
            . "LINE やメールでご本人にだけお送りいただければ、そのまま登録できます。"
            , APP_NAME . " - 登録用の QR", "Icon! 4096")
        return
    }
    ; ★リンクもすぐ使えるようにする★
    ;   遠隔の方には紙を渡せない。LINE やメールで送れるよう、
    ;   発行と同時にクリップボードへ入れておく（2026-10-01 指摘）。
    ; ★合言葉は出さない★ QR とリンクに入っていて、セラピストが使う場面がない
    MsgBox("登録用のページをブラウザで開きました。`n`n"
        . "　目の前の方　ページを見せるか印刷して、QR を読み取ってもらってください`n"
        . "　遠くの方　　リンクをコピーしました。"
        . "LINE やメールでご本人にだけお送りください`n`n"
        . "読み取られると、この画面に確認が出ます。`n"
        . "閉じているときは、スケジュール運転中に出ます。`n`n"
        . "※ QR とリンクは 14 日で使えなくなります。"
        , APP_NAME . " - 登録用の QR", "Iconi 4096")
}

ContactDialog(key, whom) {
    global APP_NAME, REGUI
    got  := ContactGet(key)
    mail := ContactMailGet(key)
    done := false

    dlg := Gui("+AlwaysOnTop +ToolWindow", APP_NAME . " - お知らせの届け先")
    dlg.MarginX := 16, dlg.MarginY := 12
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "w560", (whom = "") ? "お知らせの届け先" : (whom . " さんの届け先"))
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w560 cGray"
        , "セラピーが終わったときに、ここへお知らせします。"
        . "両方に入れると、両方へ届きます。`n"
        . "メールアドレスは暗号化して、この PC の中だけに保管します。")

    dlg.SetFont("s10", "Meiryo UI")
    cOn := dlg.Add("Checkbox", "w560" . (got["on"] ? " Checked" : "")
        , "セラピーが終わったら、お知らせを送る")
    cPre := ""
    if (FeatureOn("prenotice"))
        cPre := dlg.Add("Checkbox", "w560" . (ContactPreGet(key) ? " Checked" : "")
            , "セラピーの前にも、お知らせを送る（通知の設定の「事前のお知らせ」がオンのとき）")

    dlg.Add("Text", "xm w110", "LINE の ID")
    eLine := dlg.Add("Edit", "x+6 yp-4 w330", got["line"])
    bQr := dlg.Add("Button", "x+10 yp w110 h26", "登録用の QR")

    dlg.Add("Text", "xm w110", "メール")
    eMail := dlg.Add("Edit", "x+6 yp-4 w330", mail)
    bTest := dlg.Add("Button", "x+10 yp w110 h26", "テスト送信")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "xm w560 cGray"
        , "LINE は QR を読み取ってもらうと自動で入ります。メールは直接ご入力ください。")

    dlg.SetFont("s10", "Meiryo UI")
    dlg.Add("Text", "xm w110", "文面")
    tBody := dlg.Add("Text", "x+6 yp w330", NotifyBodyWord(key))
    bBody := dlg.Add("Button", "x+10 yp-4 w110 h26", "文面を編集")

    bSave := dlg.Add("Button", "xm w270 h34 Default", "保存")
    bNo   := dlg.Add("Button", "x+20 yp w270 h34", "キャンセル")

    bQr.OnEvent("Click",   (*) => MakeQr())
    bTest.OnEvent("Click", (*) => TestMail())
    bBody.OnEvent("Click", (*) => EditBody())
    bSave.OnEvent("Click", (*) => Keep())
    bNo.OnEvent("Click",   (*) => Leave())
    dlg.OnEvent("Close",   (*) => Leave())
    REGUI := Map("key", key, "line", eLine, "on", cOn)
    dlg.Show()
    while (!done)
        Sleep(60)
    REGUI := Map()
    try dlg.Destroy()
    return

    MakeQr() {
        RegIssueFor(key, whom, "", Trim(eLine.Value))
    }
    ; ★閉じたら、この画面の表示を入れ直す★
    ;   裏で変わった値を持たないままにしない（2026-10-02 の教訓）
    EditBody() {
        NotifyBodyDialog(key, whom)
        tBody.Value := NotifyBodyWord(key)
    }
    TestMail() {
        addr := Trim(eMail.Value)
        if (addr = "") {
            MsgBox("先にメールアドレスを入れてください。", APP_NAME, "Icon! 4096")
            return
        }
        if (!MailReady()) {
            MsgBox("メールの設定が済んでいません。`n`n"
                . "設定 →「メール」で、差出人とアプリパスワードを登録してください。"
                , APP_NAME, "Icon! 4096")
            return
        }
        err := ""
        body := "このメールが届いていれば、お知らせの準備は完了です。`n`n"
              . "セラピーが終わったときに、このアドレスへお知らせが届きます。`n`n"
              . "※ 受け取りをやめたいときは、お申し付けください。"
        if (MailSend(addr, NotifyMailSubject(), body, &err)) {
            MsgBox("お送りしました。`n`n　宛先　" . MailMask(addr) . "`n`n"
                . "届いていれば、このアドレスで間違いありません。"
                , APP_NAME . " - テスト送信", "Iconi 4096")
            return
        }
        MsgBox("送れませんでした。`n`n　理由　" . err, APP_NAME . " - テスト送信", "Icon! 4096")
    }
    Keep() {
        addr := Trim(eMail.Value)
        if (addr != "" && !RegExMatch(addr, "^[^@\s]+@[^@\s]+\.[^@\s]+$")) {
            MsgBox("メールアドレスの形が違うようです（いまの入力: 「" . addr . "」）。`n`n"
                . "example@gmail.com のような形で入れてください。"
                , APP_NAME, "Icon! 4096")
            return
        }
        ; ★同じ宛先が二重に付かないようにする★ 1 回のセラピーで 2 通届く
        if (addr != "") {
            for sec2, kv2 in ContactAll() {
                if (sec2 = "" || sec2 = "Default" || SubStr(sec2, 1, 1) = "~"
                    || sec2 = ContactSec(key))
                    continue
                if (ContactMailGet(sec2) = addr) {
                    MsgBox("このメールアドレスは、すでに別の予定に登録されています。`n`n"
                        . "　いまの登録先　" . (SchedNameOf(sec2) = "" ? sec2 : SchedNameOf(sec2)) . "`n`n"
                        . "このままだと、1 回のセラピーで同じ方へ 2 通届きます。`n"
                        . "どちらか一方にしてください。"
                        , APP_NAME, "Icon! 4096")
                    return
                }
            }
        }
        changed := (addr != mail)
        ; ★別のところで登録された LINE の ID を、開いたままの空の欄で上書きしない★
        ;   承認の窓は、最初に見つけたプロセスが出す。この画面を開いているプロセスとは限らない。
        ;   欄が開いたときのままで、ファイルのほうが変わっていれば、ファイルの値を使う。
        lineNow := Trim(eLine.Value)
        onNow   := cOn.Value ? true : false
        cur := ContactGet(key)
        if (lineNow = got["line"] && cur["line"] != got["line"]) {
            lineNow := cur["line"]
            onNow   := cur["on"]
        }
        ContactSet(key, onNow, lineNow)
        if (cPre != "")
            ContactPreSet(key, cPre.Value)
        ContactMailSet(key, addr)
        Log("INFO", Format("届け先を保存しました（{1}／LINE {2}／メール {3}／{4}）"
            , key, Trim(eLine.Value) = "" ? "なし" : "あり"
            , addr = "" ? "なし" : "あり", cOn.Value ? "送る" : "送らない"))
        done := true
        ; ★打ち間違いは、送ってみないと分からない★
        ;   LINE は読み取ってもらうので宛先を間違えないが、
        ;   メールは手で入れるため、1 文字違っても気づけない（2026-10-03）。
        if (changed && addr != "" && MailReady()) {
            if (MsgBox("確認のメールを 1 通お送りしますか？`n`n"
                . "　宛先　" . MailMask(addr) . "`n`n"
                . "届かなければ、アドレスが違っている可能性があります。"
                , APP_NAME . " - 届け先", "YesNo Icon? 4096") = "Yes") {
                err2 := ""
                body2 := "このメールが届いていれば、お知らせの準備は完了です。`n`n"
                       . "セラピーが終わったときに、このアドレスへお知らせが届きます。`n`n"
                       . "※ 受け取りをやめたいときは、お申し付けください。"
                if (MailSend(addr, NotifyMailSubject(), body2, &err2))
                    MsgBox("お送りしました。届いたかご確認ください。", APP_NAME, "Iconi 4096")
                else
                    MsgBox("送れませんでした。`n`n　理由　" . err2, APP_NAME, "Icon! 4096")
            }
        }
    }
    Leave() {
        done := true
    }
}

; メールの件名。屋号があれば頭に付ける。
NotifyMailSubject() {
    shop := Trim(CS("ShopName"))
    return (shop = "") ? "セラピー完了のお知らせ" : (shop . "　セラピー完了のお知らせ")
}

; 予定のキー（Patient.◯◯）ごとに、送り先と入切を持つ
ContactGet(key) {
    m := ContactAll()
    sec := ContactSec(key)
    return Map("on",   (Trim(IniGet(m, sec, "Notify", "0")) = "1")
             , "line", Trim(IniGet(m, sec, "LineId", "")))
}

ContactSet(key, onOff, lineId) {
    path := ContactPath()
    sec := ContactSec(key)
    IniSetMany(path, sec, Map("Notify", onOff ? 1 : 0, "LineId", Trim(lineId)))
}

; ini の節名に使えるように整える（[ ] を含む名前を避ける）
ContactSec(key) {
    out := StrReplace(StrReplace(Trim(key), "[", ""), "]", "")
    return (out = "") ? "unknown" : out
}

; 予定を消したら、連絡先も消す（残骸を作らない）
; ★消さずに取り下げる★
;   誤って予定を消しても、同じ方を登録し直せば宛先が戻るように。
;   ただし置きっぱなしにはしない。30 日たてば自動で消える。
ContactArchiveGone() {
    global SCHEDUI
    if (!SCHEDUI.Has("gone"))
        return
    for key in SCHEDUI["gone"]
        ContactArchiveOne(key)
    SCHEDUI["gone"] := []
    ContactPurgeGone()
}

; 1 人ぶんの宛先を取り下げる（30 日は戻せる）。予定の削除と、スタンダードプランでの宛先の削除が使う。
ContactArchiveOne(key) {
    got  := ContactGet(key)
    ; ★メールだけの顧客も取り下げる★
    ;   LINE があるときだけ記録していたため、メールだけの顧客は
    ;   取り下げの記録が残らず、30 日の自動削除が一度も効かなかった。
    ;   暗号化した宛先が消えずに残り続ける（2026-10-05 の点検）。
    hasMail := ContactMailHas(key)             ; 復号できなくても掃除の対象
    hasBody := NotifyBodyHas(key)              ; 顧客ごとの文面（3.9）
    if (got["line"] != "" || hasMail || hasBody) {
        IniSetMany(ContactPath(), "~" . ContactSec(key)
            , Map("LineId", got["line"]
                , "HadMail", (hasMail ? 1 : 0)
                , "HadBody", (hasBody ? 1 : 0)
                , "RemovedAt", FormatTime(A_Now, "yyyyMMddHHmmss")))
        Log("INFO", "お知らせの届け先を取り下げました（" . key . "／30 日は戻せます）")
    }
    ContactDelete(key)
}

; ★スタンダードプランで、顧客の宛先が残っているとき、1 度だけ「削除しますか？」と聞く★（3.10.25・A-6）
;   プロプランの期限が切れて（猶予も過ぎて）スタンダードプランに戻ると、通知は使えなくなるが、
;   顧客の LINE・メールの宛先は PC に残る。使わない連絡先を持ち続けないための確認。
;   「いいえ」なら、そのまま残す（プロプランへ戻れば続けて使える）。どちらでも、同じ状態で再び聞かない。
;   プロプランに戻ったら印を外すので、次にスタンダードプランへ戻ったときは、また 1 度聞く。
;   ★予定の一覧を読む前に呼ぶ★ 一覧は宛先を持ち、閉じるときに書き戻すので、先に消しておく。
LeftoverContactKeys() {
    keys := []
    if !FileExist(ContactPath())
        return keys
    all := ContactAll()
    for sec, kv in all {
        if (SubStr(sec, 1, 8) != "Patient.")
            continue
        if (Trim(IniGet(all, sec, "LineId", "")) != "" || ContactMailHas(sec))
            keys.Push(sec)
    }
    return keys
}

LeftoverContactAsk() {
    global APP_NAME, STATEINI
    asked := (IniGet(IniLoad(STATEINI), "Notify", "LeftoverAsked", "") = "1")
    if (NotifyAllowed()) {
        if (asked)
            IniSet(STATEINI, "Notify", "LeftoverAsked", "")
        return
    }
    if (asked)
        return
    keys := LeftoverContactKeys()
    if (keys.Length = 0)
        return
    IniSet(STATEINI, "Notify", "LeftoverAsked", "1")
    r := MsgBox(Format("スタンダードプランでは、顧客へのお知らせは使えません。`n`n"
        . "顧客 {1} 人ぶんの届け先（LINE・メール）が、この PC に残っています。`n`n"
        . "削除しますか？`n`n"
        . "［はい］届け先を削除します。30 日以内なら、同じ顧客を登録し直すと戻せます。`n"
        . "［いいえ］そのまま残します。プロプランへ戻れば、続けて使えます。"
        , keys.Length), APP_NAME . " - 届け先の削除", "YesNo Icon? Default2 4096")
    if (r = "Yes") {
        for key in keys
            ContactArchiveOne(key)
        ContactPurgeGone()
        Log("INFO", Format("スタンダードプランのため、顧客 {1} 人ぶんの届け先を削除しました（30 日は戻せます）", keys.Length))
        MsgBox(Format("顧客 {1} 人ぶんの届け先を削除しました。", keys.Length), APP_NAME, "Iconi 4096")
    } else {
        Log("INFO", Format("スタンダードプランで届け先が {1} 人ぶん残っています（削除しない選択）", keys.Length))
    }
}

; 取り下げた宛先が残っていれば返す
ContactGoneOf(key) {
    path := ContactPath()
    if !FileExist(path)
        return ""
    return Trim(IniGet(ContactAll(), "~" . ContactSec(key), "LineId", ""))
}

; 取り下げの記録そのものがあるか（LINE が空＝メールだけの顧客でも拾う）
ContactGoneAt(key) {
    if !FileExist(ContactPath())
        return ""
    return Trim(IniGet(ContactAll(), "~" . ContactSec(key), "RemovedAt", ""))
}

; 戻す
ContactRestore(key) {
    if (ContactGoneAt(key) = "")                   ; LINE が空でも記録はある
        return false
    got := ContactGoneOf(key)
    ContactSet(key, true, got)
    IniSetSection(ContactPath(), "~" . ContactSec(key), Map())
    Log("INFO", "取り下げていたお知らせの届け先を戻しました（" . key . "）")
    return true
}

; ★30 日で自動的に消す★ 使わない宛先を持ち続けない
ContactPurgeGone() {
    path := ContactPath()
    if !FileExist(path)
        return
    for sec, kv in ContactAll() {
        if (SubStr(sec, 1, 1) != "~")
            continue
        at := Trim(IniGet(ContactAll(), sec, "RemovedAt", ""))
        if (at = "" || DateDiff(A_Now, at, "Days") >= 30) {
            ; ★暗号化したメールも、ここで消す★
            ;   取り下げの間は残しておき、戻せるようにしている。
            ;   30 日たったら、まとめて消す（2026-10-03）。
            ContactMailSet(SubStr(sec, 2), "")
            NotifyBodyClear(SubStr(sec, 2))        ; 顧客ごとの文面も一緒に消す
            IniSetSection(path, sec, Map())
            Log("INFO", "取り下げから 30 日たった宛先を消しました（" . sec . "）")
        }
    }
}

ContactDelete(key) {
    if FileExist(ContactPath())
        IniSetSection(ContactPath(), ContactSec(key), Map())
}

;==============================================================================
;  通知を送る（V3・スケジュール運転との連動）
;==============================================================================
; ★送るのは、通知を「使う」にしているときだけ★
;   既定は「使わない」。意図して入にするまで、何があっても送らない。
; ★DryRun 中は送らない★ セラピーを行っていないのだから。
; ★送信の失敗で運転を止めない★ いったん貯めて、あとから送り直す。

NotifyOn() {
    if (!CB("NotifyEnabled"))
        return false
    if (CB("DryRun"))
        return false
    return true
}

; ★通知は事業者のみ★（3.10.3）一般では「新しく積む」入口を閉じる。
;   すでに送信待ちに入っている分は、NotifyOn() の側（送信係・見回り）で送り切る。
;   入口は NotifyAdmin と NotifyPatient の 2 つ。両方に置く。
NotifyAllowed() => !IsGeneralPlan()

; 新しく積んでよいか（設定で使う＋事業者）
NotifyNewOk() => (NotifyOn() && NotifyAllowed())

; 一般のとき、画面の入口で止める。止めたら true。
NotifyGateBox() {
    global APP_NAME
    if (NotifyAllowed())
        return false
    r := MsgBox("通知は、プロプランでご利用いただけます。`n`n"
        . "スタンダードプランでは、完了・異常のお知らせ、顧客へのお知らせ、顧客の登録（QR）は使えません。`n"
        . "登録済みの連絡先と文面は、そのまま残してあります。プロプランへ移行すれば、続けてお使いいただけます。`n`n"
        . "プロプランのご案内を開きますか？"
        , APP_NAME . " - スタンダードプラン", "YesNo Icon! 4096")
    if (r = "Yes")
        GuideOpen()
    return true
}

NotifyQueueDir() {
    dir := NotifyDir() . "\pending"
    if !DirExist(dir)
        DirCreate(dir)
    return dir
}

NotifyPendingCount() {
    n := 0
    Loop Files, NotifyQueueDir() . "\*.txt"
        n++
    return n
}

; まだ送る時刻が来ていないもの（翌朝にまとめる分）の数
NotifyWaitingCount() {
    n := 0
    Loop Files, NotifyQueueDir() . "\*.txt"
    {
        txt := ""
        try txt := FileRead(A_LoopFilePath, "UTF-8")
        parts := StrSplit(StrReplace(txt, Chr(0xFEFF), ""), "`n", "`r", 6)
        if (parts.Length >= 4 && Trim(parts[4]) != "" && A_Now < Trim(parts[4]))
            n++
    }
    return n
}

; いま試せる通知の数（時刻待ちを除く。LINE の月間上限に達している分は NotifyFlush で破棄するため対象に含める）（3.10.33）
NotifyReadyCount() {
    n := 0
    Loop Files, NotifyQueueDir() . "\*.txt"
    {
        txt := ""
        try txt := FileRead(A_LoopFilePath, "UTF-8")
        parts := StrSplit(StrReplace(txt, Chr(0xFEFF), ""), "`n", "`r", 6)
        if (parts.Length < 6)
            continue
        ch := Trim(parts[2])
        notTill := Trim(parts[4])
        if (notTill != "" && A_Now < notTill)
            continue
        if (ch = "LINE" ? !LineReady() : !MailReady())
            continue
        n++
    }
    return n
}

; LINE の月間送信数の上限（429）に達したあと、1 時間は自動の再試行を控える（3.10.32）
LineQuotaBlocked() {
    global STATEINI
    if !FileExist(STATEINI)
        return false
    at := Trim(IniGet(IniLoad(STATEINI), "Notify", "LineQuotaAt", ""))
    if (at = "" || StrLen(at) < 14)
        return false
    if (SubStr(A_Now, 1, 6) != SubStr(at, 1, 6)) {
        IniSet(STATEINI, "Notify", "LineQuotaAt", "")
        return false
    }
    return (SecSince(at) < 3600)
}

; ★顧客へのお知らせの状態を、記録に残す★（2026-10-12・A-17）
;   「確認待ち」に、顧客へ送ったか・保留中か・送れなかったかを出すための記録。
;   追記だけで書く（送信係と本体が同時に書いても壊れない）。1 行 = 時刻|送信待ちの名前|出来事|姓|名|経路|詳細
;   出来事: queued（送信待ちに積んだ）／sent（送った）／failed（送れず戻した）／discarded（7 日で捨てた）／skipped（送らない）
NotifyLogPath() => NotifyDir() . "\status.txt"

NotifyLogClean(t) => StrReplace(StrReplace(StrReplace(t, "|", " "), "`n", " "), "`r", " ")

NotifyLogAdd(base, event, sei := "", mei := "", channel := "", detail := "") {
    line := FormatTime(A_Now, "yyyyMMddHHmmss") . "|" . base . "|" . event . "|"
          . NotifyLogClean(sei) . "|" . NotifyLogClean(mei) . "|" . channel . "|" . NotifyLogClean(detail)
    try FileAppend(CRLF(line . "`n"), NotifyLogPath(), "UTF-8")
}

; 送信待ちのファイルの名前（拡張子なし）
NotifyBaseOf(path) {
    nm := ""
    SplitPath(path, , , , &nm)
    return nm
}

; ★送信待ちの内訳を 1 行で★（2026-10-12）
;   送信待ち＝まだ送れていない通知のファイル。管理者宛（宛先が空）・顧客宛・そのうち保留（時刻まで待つ分）を数える。
;   「メールの送信待ちが残っていないか」を、ファイルを開かずに確かめるため。
NotifyQueueSummary() {
    admin := 0, cust := 0, held := 0, stuck := 0, oldest := ""
    Loop Files, NotifyQueueDir() . "\*.txt"
    {
        txt := ""
        try txt := FileRead(A_LoopFilePath, "UTF-8")
        txt := StrReplace(txt, Chr(0xFEFF), "")
        parts := StrSplit(txt, "`n", "`r", 6)
        if (parts.Length < 4 || SubStr(txt, 1, 2) != "V2")
            continue
        if (Trim(parts[3]) = "")
            admin++
        else
            cust++
        notTill := Trim(parts[4])
        if (notTill != "" && A_Now < notTill)
            held++
        ct := A_LoopFileTimeCreated                ; ★FileGetTime を呼び直さない★ 列挙したあとに別のプロセスが改名すると、ファイルが見つからないエラーになる
        if (oldest = "" || ct < oldest)
            oldest := ct
    }
    Loop Files, NotifyQueueDir() . "\*.sending"
        stuck++
    n := admin + cust
    if (n = 0 && stuck = 0)
        return "送信待ちはありません。"
    out := Format("送信待ち {1} 件（管理者宛 {2}／顧客宛 {3}／うち時刻まで保留 {4}）", n, admin, cust, held)
    if (n - held > 0)
        out := "★" . out . "　送れていないものがあります（いちばん古いもの：" . FormatTime(oldest, "M/d HH:mm") . "）"
    if (stuck > 0)
        out .= "　送信中のまま止まったもの " . stuck . " 件"
    return out
}

; 確認待ちの 1 行に添える、顧客へのお知らせの状態。jobTs = 確認待ちの時刻（14 桁）。
NotifyStatusText(sei, mei, jobTs) {
    path := NotifyLogPath()
    if (!FileExist(path))
        return "記録なし"
    txt := ""
    try txt := FileRead(path, "UTF-8")
    txt := StrReplace(txt, Chr(0xFEFF), "")
    recs := Map()                                  ; 送信待ちの名前 → 状態
    order := []
    for line in StrSplit(txt, "`n", "`r") {
        f := StrSplit(line, "|")
        if (f.Length < 7)
            continue
        ts := f[1], base := f[2], ev := f[3]
        if (InStr(base, "_pre"))                   ; 事前のお知らせは、完了のお知らせの状態に混ぜない
            continue
        if (ev = "queued" || ev = "skipped") {
            if (f[4] != sei || f[5] != mei)
                continue
            if (StrLen(jobTs) = 14 && Abs(DateDiff(ts, jobTs, "Minutes")) > 15)
                continue                           ; この回の分だけ（別の日の分と混ぜない）
            recs[base] := Map("ev", ev, "ts", ts, "ch", f[6], "detail", f[7], "last", ev, "lastTs", ts)
            order.Push(base)
        } else if (recs.Has(base)) {
            recs[base]["last"] := ev, recs[base]["lastTs"] := ts
            if (f[7] != "")
                recs[base]["note"] := f[7]
        }
    }
    if (order.Length = 0)
        return "記録なし（この版より前の分、または送る対象ではありません）"
    out := ""
    for base in order {
        r := recs[base]
        ch := (r["ch"] = "MAIL") ? "メール" : ((r["ch"] = "LINE") ? "LINE" : "")
        if (r["ev"] = "skipped") {
            one := "送りません（" . r["detail"] . "）"
        } else if (r["last"] = "sent") {
            one := ch . " 送信済み（" . FormatTime(r["lastTs"], "M/d HH:mm") . "）"
        } else if (r["last"] = "discarded") {
            if (r.Has("note") && r["note"] != "")
                one := "★" . ch . " 破棄しました（" . r["note"] . "）"
            else
                one := "★" . ch . " 送れないまま 7 日が過ぎ、破棄しました"
        } else if (r["last"] = "failed") {
            one := "★" . ch . " 送信できませんでした（送り直します）"
        } else if (r["detail"] != "" && A_Now < r["detail"]) {
            one := ch . " 保留中（" . FormatTime(r["detail"], "M/d HH:mm") . " に送ります）"
        } else {
            one := "★" . ch . " 送信待ち（まだ送れていません）"
        }
        out .= (out = "" ? "" : " ／ ") . one
    }
    return out
}

; 送る内容を 1 件貯める
;   1 行目 = V2（形式の目印）
;   2 行目 = 送り方（MAIL / LINE）
;   3 行目 = 宛先（空なら管理者へ）
;   4 行目 = この時刻以降に送る（yyyyMMddHHmmss／空なら今すぐ）
;   5 行目 = 件名
;   6 行目以降 = 本文
NotifyPush(channel, subject, body, sendTo := "", notBefore := "", expires := "") {
    ; ★有効期限はファイル名に持たせる★（3.10.37）中身の形式（V2）を変えない。「_pre」は事前のお知らせの印
    path := NotifyQueueDir() . "\" . FormatTime(A_Now, "yyyyMMdd_HHmmss")
          . "_" . Random(1000, 9999) . (expires = "" ? "" : "_pre" . expires) . ".txt"
    txt := "V2`n" . channel . "`n" . sendTo . "`n" . notBefore . "`n"
         . subject . "`n" . body
    try FileAppend(CRLF(txt), path, "UTF-8")
    return path
}

; 貯まっている分を送る。送れたものから消す。
;   ★1 件でも失敗したら、その回はそこで止める★
;   ネットが落ちているときに何十回も試さない。
NotifyFlush() {
    ; ★片方だけの設定でも送る★ 顧客へのお知らせは LINE だけを使うので、
    ;   メールが未設定というだけで止めると、1 通も出ていかない（2026-09-30）。
    if (!MailReady() && !LineReady())
        return 0
    sent := 0
    NotifyRecoverStuck()                           ; 前回の途中で止まった分を戻す
    Loop Files, NotifyQueueDir() . "\*.txt"
    {
        ; ★古すぎるものは送らない★ いまさら届いても混乱するだけ
        ; ★FileGetTime を呼び直さない★（3.10.36）列挙したあと、送信係が同じファイルを改名すると、
        ;   「指定されたファイルが見つかりません」で、運転の画面に Error の窓が出て止まった（2026-11-01）。
        if (DateDiff(A_Now, A_LoopFileTimeCreated, "Days") >= 7) {
            Log("WARN", "7 日を過ぎた通知を捨てました: " . A_LoopFileName)
            NotifyLogAdd(NotifyBaseOf(A_LoopFilePath), "discarded")
            try FileDelete(A_LoopFilePath)
            continue
        }
        ; ★事前のお知らせは、古くなったら届けない★ 「ただいまから」が数時間後に届くのを防ぐ（3.10.37）
        if (RegExMatch(A_LoopFileName, "_pre(\d{14})\.txt$", &preExp) && A_Now >= preExp[1]) {
            Log("WARN", "有効期限を過ぎた事前のお知らせを破棄しました: " . A_LoopFileName)
            NotifyLogAdd(NotifyBaseOf(A_LoopFilePath), "discarded", , , , "有効期限切れ")
            try FileDelete(A_LoopFilePath)
            continue
        }
        txt := ""
        try txt := FileRead(A_LoopFilePath, "UTF-8")
        txt := StrReplace(txt, Chr(0xFEFF), "")
        if (SubStr(txt, 1, 2) != "V2") {           ; 古い形式は捨てる
            try FileDelete(A_LoopFilePath)
            continue
        }
        parts := StrSplit(txt, "`n", "`r", 6)
        if (parts.Length < 6) {
            try FileDelete(A_LoopFilePath)
            continue
        }
        channel  := Trim(parts[2])
        sendTo   := Trim(parts[3])
        notTill  := Trim(parts[4])
        subject  := Trim(parts[5])
        body     := parts[6]
        ; ★時刻を指定してあるものは、その時刻まで送らない★
        ;   顧客へのお知らせは、夜中に鳴らさず翌朝にまとめる。
        if (notTill != "" && A_Now < notTill)
            continue
        ; まだ設定していない経路は、飛ばして次へ（ここで止めない）
        if (channel = "LINE" ? !LineReady() : !MailReady())
            continue
        ; LINE の月間送信数の上限に達しているあいだは、溜めずに破棄する（翌月に古い通知がまとめて届くのを防ぐ）（3.10.33）
        if (channel = "LINE" && LineQuotaBlocked()) {
            NotifyLogAdd(NotifyBaseOf(A_LoopFilePath), "discarded", , , , "LINE の月間送信数の上限")
            try FileDelete(A_LoopFilePath)
            Log("WARN", "LINE の月間送信数の上限に達しているため、通知を破棄しました: " . A_LoopFileName)
            continue
        }
        ; ★送る前に、この 1 件を自分のものにする★
        ;   送信係が 2 つ動くと、同じ 1 件を両方が拾って二重に送る。
        ;   2026-10-01、完了通知がメール・LINE とも 2 通ずつ届いた。
        ;   名前を変えられた方だけが送る（変えられなければ、ほかが先に取った）。
        mine := A_LoopFilePath . ".sending"
        got := false
        try {
            FileMove(A_LoopFilePath, mine, false)  ; 上書きしない
            got := !FileExist(A_LoopFilePath) && FileExist(mine)
        }
        if (!got)
            continue
        err := ""
        okSend := false
        if (channel = "LINE")
            okSend := LineSend(sendTo = "" ? LineAdminId() : sendTo
                , LineText(subject, body), &err)
        else
            okSend := MailSend(sendTo = "" ? MailAdminAddr() : sendTo
                , subject, body, &err)
        if (!okSend) {
            if (channel = "LINE" && LineQuotaBlocked()) {
                NotifyLogAdd(NotifyBaseOf(A_LoopFilePath), "discarded", , , , "LINE の月間送信数の上限")
                try FileDelete(mine)
                Log("WARN", "LINE の月間送信数の上限に達しているため、通知を破棄しました: " . A_LoopFileName)
                continue
            }
            NotifyLogAdd(NotifyBaseOf(A_LoopFilePath), "failed", , , , SubStr(err, 1, 60))
            try FileMove(mine, A_LoopFilePath, true)   ; 戻して、次の機会に送り直す
            Log("INFO", "通知は送れませんでした。あとで送り直します（残り "
                . NotifyPendingCount() . " 件）")
            return sent
        }
        try FileDelete(mine)
        NotifyLogAdd(NotifyBaseOf(A_LoopFilePath), "sent")
        sent++
    }
    return sent
}

; 送っている途中でプロセスが落ちると .sending のまま残る。
;   5 分たっても残っていれば、送れなかったものとして戻す。
NotifyRecoverStuck() {
    Loop Files, NotifyQueueDir() . "\*.sending"
    {
        if (DateDiff(A_Now, A_LoopFileTimeModified, "Seconds") < 300)
            continue
        back := SubStr(A_LoopFilePath, 1, StrLen(A_LoopFilePath) - 8)
        try {
            FileMove(A_LoopFilePath, back, false)
            Log("WARN", "送信の途中で止まった通知を、送信待ちへ戻しました: " . A_LoopFileName)
        }
    }
}

; ★送ってよい瞬間か★
;   メールや LINE の送信は数秒から数十秒かかり、その間ツールは止まる。
;   指標を見張っている最中に止まると、その空白を「途切れ」と読み違え、
;   セラピーが早く終わったと誤判定しかねない。
;   だから【見張っていない時間帯】にだけ送る（2026-09-30）。
;   セラピーの合間や画面の移動中なら、数秒止まっても害がない。
NotifySafeNow() {
    global G
    static lastTry := ""
    if (!NotifyOn() || NotifyReadyCount() = 0)
        return false
    ; 調査中・セラピー中は、画面を見張っているので触らない
    if (G.state = "therapy_run" || G.state = "scan_running")
        return false
    if (lastTry != "" && SecSince(lastTry) < 60)
        return false                               ; 1 分に 1 回まで
    lastTry := A_Now
    return true
}

; 管理者へ 1 件知らせる（貯めてから、すぐ送ってみる）
; ★お試し送信★ その場で送って、結果をそのまま返す
;   ふだんの通知は送信係にまかせるが、お試しは「いま送れるか」を知りたいので
;   ここで送りきる（数秒止まっても、人が押したときなので害がない）。
NotifyTestNow(subject, body) {
    if (!NotifyAllowed())
        return false                               ; 一般は送らない（画面の入口でも止めている）
    okAny := false
    err := ""
    if (MailReady()) {
        if (MailSend(MailAdminAddr(), subject, body, &err))
            okAny := true
    }
    if (LineReady()) {
        if (LineSend(LineAdminId(), LineText(subject, body), &err))
            okAny := true
    }
    return okAny
}

; ============================================================================
;  顧客の登録（QR を 1 回読むだけ）
;    セラピストが合言葉つきの QR を渡す → 顧客が LINE で読む → 友だち追加まで流れる
;    → 中継（GAS）に合言葉と LINE ID が数分置かれる → この PC が引き取って消す
;    → 表示名を出して確認してから、予定に紐づける
;  ★中継に渡るのは合言葉と LINE ID だけ。氏名も生年月日も通らない★
; ============================================================================

RegReady() => (Trim(CS("LiffId")) != "" && Trim(CS("RegisterApi")) != "")

; 合言葉を作る。読み間違える文字（0 O 1 I）は使わない
RegCodeNew() {
    abc := "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    out := ""
    Loop 8 {
        if (A_Index = 5)
            out .= "-"
        out .= SubStr(abc, Random(1, StrLen(abc)), 1)
    }
    return out
}

; 文字を URL に載せられる形にする
UrlEnc(t) {
    out := ""
    for i, b in StrToUtf8Bytes(t)
        out .= (b >= 48 && b <= 57) || (b >= 65 && b <= 90) || (b >= 97 && b <= 122)
             || b = 45 || b = 46 || b = 95 || b = 126
             ? Chr(b) : Format("%{:02X}", b)
    return out
}

; 文字列を UTF-8 のバイト列にする
StrToUtf8Bytes(t) {
    n := StrPut(t, "UTF-8") - 1                    ; 終端は含めない
    buf := Buffer(n + 1, 0)
    StrPut(t, buf, "UTF-8")
    out := []
    Loop n
        out.Push(NumGet(buf, A_Index - 1, "UChar"))
    return out
}

; 顧客が読む QR の中身
;   ★LIFF ID は、こちら（QR の側）に入れる★
;   エンドポイント URL に付けた問い合わせ文字列は LINE 側で落ちることがあり、
;   実機で「URL が正しくありません」になった（2026-10-02）。
;   QR の側の問い合わせ文字列は、必ずページまで届く。
RegQrUrl(code) {
    id := Trim(CS("LiffId"))
    url := "https://liff.line.me/" . id . "?p=" . code . "&l=" . id
    ; 公式アカウントの ID を渡しておくと、友だち追加がまだのときに
    ;   ページから直接「友だち追加する」を押してもらえる（2026-10-03）
    oa := Trim(CS("LineOaId"))
    if (oa != "")
        url .= "&a=" . StrReplace(oa, "@", "%40")
    ; 誰からの案内かが分からないと、顧客は不審に思う（2026-10-03）
    shop := Trim(CS("ShopName"))
    if (shop != "")
        url .= "&s=" . UrlEnc(shop)
    return url
}

; セラピストが LIFF に登録する URL。誰でも同じ、ただの URL。
RegEndpointUrl() => Trim(CS("RegisterPage"))

; 発行した合言葉は、連絡先と同じ場所に覚えておく（予定のファイルには書かない）
; ★QR を発行し直しても、前の合言葉を見に行き続ける★（3.10.26）
;   顧客は、チャットに残った古いリンクを読み取ることがある。LINE には「登録を受け付けました」と出るのに、
;   PC は新しい合言葉しか見ておらず、いつまでも出てこない。直近の 2 つまで、14 日のあいだ残す。
RegPendSet(key, code) {
    m := ContactAll()
    sec := ContactSec(key)
    oldCode := Trim(IniGet(m, sec, "PendCode", ""))
    oldAt   := Trim(IniGet(m, sec, "PendAt", ""))
    olds := []
    if (oldCode != "" && oldCode != code && StrLen(oldAt) = 14 && DateDiff(A_Now, oldAt, "Days") < 14)
        olds.Push(oldCode . "@" . oldAt)
    for part in StrSplit(Trim(IniGet(m, sec, "PendOld", "")), ";") {
        if (olds.Length >= 2)
            break
        if (RegExMatch(Trim(part), "^([A-Z2-9]{4}-[A-Z2-9]{4})@(\d{14})$", &mm)
            && mm[1] != code && mm[1] != oldCode && DateDiff(A_Now, mm[2], "Days") < 14)
            olds.Push(mm[1] . "@" . mm[2])
    }
    joined := ""
    for s in olds
        joined .= (joined = "" ? "" : ";") . s
    IniSetMany(ContactPath(), sec
        , Map("PendCode", code, "PendAt", FormatTime(A_Now, "yyyyMMddHHmmss"), "PendOld", joined))
}
RegPendGet(key) {
    m := ContactAll()
    sec := ContactSec(key)
    olds := []
    for part in StrSplit(Trim(IniGet(m, sec, "PendOld", "")), ";") {
        if (RegExMatch(Trim(part), "^([A-Z2-9]{4}-[A-Z2-9]{4})@(\d{14})$", &mm))
            olds.Push(Map("code", mm[1], "at", mm[2]))
    }
    return Map("code", Trim(IniGet(m, sec, "PendCode", ""))
             , "at",   Trim(IniGet(m, sec, "PendAt", ""))
             , "old",  olds)
}
RegPendClear(key) {
    IniSetMany(ContactPath(), ContactSec(key), Map("PendCode", "", "PendAt", "", "PendOld", ""))
}

; 中継に「この合言葉の ID をください」と聞く。渡されたら中継からは消える。
RegTake(code, &userId, &why) {
    userId := "", why := ""
    url := Trim(CS("RegisterApi"))
    if (url = "") {
        why := "登録の窓口が設定されていません"
        return false
    }
    status := 0, reply := ""
    try {
        http := ComObject("WinHttp.WinHttpRequest.5.1")
        http.SetTimeouts(5000, 10000, 10000, 20000)
        ; keep=1：渡しても中継では消さない。受け取りの記録を書いてから、RegAck で消す。
        ;   応答が途中で切れても（待ちきれなかったとき）登録が失われない（3.10.26）。
        http.Open("GET", url . "?act=take&keep=1&p=" . code, false)
        http.Option[6] := true                     ; 転送を追う
        http.Send()
        status := http.Status
        reply  := HttpTextUtf8(http)
    } catch as e {
        why := "つながりませんでした（" . e.Message . "）"
        return false
    }
    if (status != 200) {
        why := "窓口が " . status . " を返しました"
        return false
    }
    if (InStr(reply, '"ok":true')) {
        if (RegExMatch(reply, '"id"\s*:\s*"(U[0-9a-f]{32})"', &m)) {
            userId := m[1]
            return true
        }
        why := "返事を読み取れませんでした"
        return false
    }
    why := InStr(reply, "notyet") ? "" : "窓口が受け付けませんでした"
    return false                                   ; why が空＝まだ登録されていないだけ
}

; 受け取りの記録を書いたあと、中継に「もう消してよい」と伝える。失敗しても登録は無事（中継で 14 日後に消える）。
RegAck(code) {
    url := Trim(CS("RegisterApi"))
    if (url = "")
        return false
    Loop 2 {
        try {
            http := ComObject("WinHttp.WinHttpRequest.5.1")
            http.SetTimeouts(5000, 10000, 10000, 20000)
            http.Open("GET", url . "?act=ack&p=" . code, false)
            http.Option[6] := true
            http.Send()
            if (http.Status = 200 && InStr(HttpTextUtf8(http), '"ok":true'))
                return true
        }
        Sleep(500)
    }
    Log("WARN", "中継への「消してよい」の連絡が通りませんでした（登録は受け取り済み。中継では 14 日で消えます）")
    return false
}

; ★応答は UTF-8 で読み直す★
;   ResponseText は、相手が文字コードを書いていないと別の符号化として読まれる。
;   2026-10-02、LINE の表示名が「âéç°ç´å®」と化けた。
HttpTextUtf8(http) {
    try {
        st := ComObject("ADODB.Stream")
        st.Type := 1                               ; いったんバイトのまま受ける
        st.Open()
        st.Write(http.ResponseBody)
        st.Position := 0
        st.Type := 2                               ; 文字として読み直す
        st.Charset := "utf-8"
        out := st.ReadText()
        st.Close()
        return out
    } catch {
        return http.ResponseText                   ; 読み直せないときは、そのまま
    }
}

; LINE の表示名を取る。友だちでなければ 404 になるので、そこで気づける。
LineProfile(userId, &name, &why) {
    name := "", why := ""
    token := SecretLoad("line_token")
    if (token = "") {
        why := "LINE のトークンが保存されていません"
        return false
    }
    status := 0, reply := ""
    try {
        http := ComObject("WinHttp.WinHttpRequest.5.1")
        http.SetTimeouts(5000, 10000, 10000, 20000)
        http.Open("GET", "https://api.line.me/v2/bot/profile/" . userId, false)
        http.SetRequestHeader("Authorization", "Bearer " . token)
        http.Send()
        status := http.Status
        reply  := HttpTextUtf8(http)
    } catch as e {
        why := "つながりませんでした（" . e.Message . "）"
        return false
    }
    if (status = 404) {
        why := "まだ友だち追加されていません"
        return false
    }
    if (status != 200) {
        why := "LINE が " . status . " を返しました"
        return false
    }
    if (RegExMatch(reply, '"displayName"\s*:\s*"([^"]*)"', &m))
        name := JsonUnesc(m[1])
    return true
}

; \uXXXX を文字に戻す（表示名に日本語が入るため）
JsonUnesc(t) {
    out := ""
    i := 1
    while (i <= StrLen(t)) {
        c := SubStr(t, i, 1)
        if (c = "\" && SubStr(t, i + 1, 1) = "u") {
            out .= Chr("0x" . SubStr(t, i + 2, 4))
            i += 6
            continue
        }
        if (c = "\") {
            n := SubStr(t, i + 1, 1)
            out .= (n = "n") ? "`n" : ((n = "t") ? "`t" : n)
            i += 2
            continue
        }
        out .= c
        i += 1
    }
    return out
}

; セラピストにお願いする手順。LINE の画面は変わることがあるので、
;   見つからないときは連絡してもらう（メール・LINE の手順書と同じ扱い）。
RegGuideText() {
    return "
    (
登録用 QR の設定 — 詳しい手順

QR を 1 回読んでもらうだけで、お知らせの宛先が決まる仕組みです。
顧客は文字を入力しません。友だち追加も、この流れの中で済みます。

ここでの作業は、最初に 1 回だけです。
設定の「LINE」が終わっていることが前提です。

─────────────────────────────

① LINE ログインのチャネルを作る

LINE Developers を開き、★「LINE」の設定で作ったプロバイダー★を選びます。
　・［新規チャネル作成］→［LINE ログイン］
　・チャネル名は、顧客に表示されます（例：ご自身の屋号）
　・アプリタイプは［ウェブアプリ］

★公式アカウントと同じプロバイダーの中に作ってください★
　別のプロバイダーに作ると、受け取る ID が別物になり、お知らせが届きません。

─────────────────────────────

② 公式アカウントを連携する

作ったチャネルの［チャネル基本設定］タブを開き、
いちばん下の「友だち追加オプション」まで下がります。
　・「リンクされた LINE 公式アカウント」で、ご自身の公式アカウントを選びます
　・［更新］を押します

これをしないと、③の「友だち追加オプション」が選べません。

─────────────────────────────

③ LIFF アプリを追加する

同じチャネルの［LIFF］タブ →［追加］。

　サイズ　　　　　　　Compact
　エンドポイント URL　AutoMeta の画面でコピーしたものを、そのまま貼り付け
　スコープ　　　　　　profile ★と★ openid（両方にチェック）
　友だち追加オプション　On (aggressive)

　★「On (normal)」にしないでください★
　　normal は同意画面にチェックボックスが出るだけで、しかも
　　★最初からオフ★の状態で表示されます（LINE の仕様で、変えられません）。
　　顧客が気づかずに進むと、友だち追加されず、お知らせが届きません。
　　aggressive なら、追加するかどうかの画面が別に出ます。

　★openid を忘れないでください★
　　これが無いと本人確認ができず、顧客の画面に
　　「セラピスト側の設定が足りません（LIFF の許可に openid が必要）」と出ます。

　★エンドポイント URL には、何も足さないでください★
　　顧客ごとの情報は QR の側に入っています。

　★「友だち追加オプション」を On にしてください★
　　ここが Off だと、顧客が友だち追加を忘れ、お知らせが届きません。

─────────────────────────────

④ チャネルを公開する

チャネル名の右に【開発中】と出ていれば、押して【公開済み】にします。

　★開発中のままでは、顧客は登録できません★
　　開発中は、このチャネルに権限のある人（ご自身など）しかログインできません。
　　顧客の画面には、LINE のエラーが出て先へ進めません。

　★公開済みにすると、開発中には戻せません★
　　先に、ご自身のスマホで一度お試しになることをおすすめします。
　　ご自身は権限があるので、開発中のままでも試せます。

─────────────────────────────

⑤ LIFF ID を AutoMeta に貼る

できあがった LIFF アプリの「LIFF ID」をコピーし、
AutoMeta の「登録用 QR」の画面の LIFF ID 欄に貼り付けて、保存します。

　1234567890-abcdEFGH のような形です。
　LIFF URL（https://liff.line.me/… ）ではなく、ID の方です。

─────────────────────────────

使い方

　1. 予定の編集画面を開き、「登録用の QR」を押します
　2. 登録用のページがブラウザで開きます
　　　・目の前にいる方 … 印刷するか、画面を見せます
　　　・遠くにいる方 　… リンクが控えてあるので、LINE やメールで送ります
　3. 顧客が QR を読むか、リンクを開き、「追加」を押します
　4. この PC に「登録がありました」と出るので、表示名を確かめて承認します
　5. 承認すると、顧客へ確認のメッセージが 1 通届きます
　　　これが届けば、準備は完了です

　・QR とリンクは 14 日で使えなくなります
　・顧客の画面にエラーが出たときは、その画面を見せてもらってください。
　　どこで止まったかが書いてあります
　・ご自身では登録できるのに顧客だけ失敗するときは、
　　チャネルが【開発中】のままでないか確かめてください
　・知らない表示名が出たときは承認せず、発行し直してください
　・受け取りは、スケジュール運転が動いているときに行います

─────────────────────────────

この手順書について

LINE の画面は、ときどき作りが変わります。
書かれている名前のボタンが見つからないときは、そのままお知らせください。
実際の画面に合わせて書き直します。
    )"
}

; ★名前は「そこで何をするか」★
;   「顧客の登録」では顧客を登録しない。登録するのは予定の編集の
;   「登録用の QR」。ここでやるのは、その QR を使えるようにする設定
;   （LIFF ID など）。名前が中身と合っていなかった（2026-10-03 指摘）。
;   順番も出す。LINE の設定（トークン）の上に乗っているため。
RegLabel() {
    if (!LineReady())
        return "登録用 QR の設定（先に LINE の設定）"
    if (RegReady())
        return "登録用 QR の設定（使えます）"
    return "登録用 QR の設定（まだ設定されていません）"
}

; 登録用 QR の設定。LIFF ID を入れてもらうだけ。
ModeRegister() {
    global C, CFG, APP_NAME
    dlg := Gui("+AlwaysOnTop", APP_NAME . " - 登録用 QR の設定" . VerTag())
    dlg.MarginX := 16, dlg.MarginY := 12

    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "w640", "QR を 1 回読むだけで、お知らせの宛先が決まります")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w640 cGray"
        , "顧客がすることは、QR を読んで「追加」を押すだけです。"
        . "文字の入力はありません。`n"
        . "お名前・生年月日・電話番号は、どこにも送られません。")

    dlg.SetFont("s10", "Meiryo UI")
    dlg.Add("Text", "xm w110", "LIFF ID")
    eLiff := dlg.Add("Edit", "x+6 yp-4 w260", Trim(CS("LiffId")))
    bHelp := dlg.Add("Button", "x+10 yp w240 h26", "詳しい手順を表示")

    dlg.Add("Text", "xm w110", "お名前・屋号")
    eShop := dlg.Add("Edit", "x+6 yp-4 w260", Trim(CS("ShopName")))
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "x+10 yp+4 w240 cGray", "登録用のページに出ます（空でも可）")

    dlg.SetFont("s10", "Meiryo UI")
    dlg.Add("Text", "xm w110", "公式アカウント ID")
    eOa := dlg.Add("Edit", "x+6 yp-4 w260", Trim(CS("LineOaId")))
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "x+10 yp+4 w240 cGray", "@ から始まるもの（例: @859abcde）")
    dlg.SetFont("s10", "Meiryo UI")
    dlg.Add("Text", "xm w640 cGray"
        , "友だち追加がまだの方に、登録用のページから直接追加してもらうために使います。")
    dlg.SetFont("s10", "Meiryo UI")

    dlg.Add("Text", "xm w160", "登録する URL")
    eEnd := dlg.Add("Edit", "x+6 yp-4 w400 ReadOnly", RegEndpointUrl())
    bCopy := dlg.Add("Button", "x+10 yp w60 h26", "コピー")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "xm w640 cGray"
        , "手順③で LIFF アプリの「エンドポイント URL」に、そのまま貼り付けます。")

    dlg.SetFont("s10", "Meiryo UI")
    bSave := dlg.Add("Button", "xm w310 h34 Default", "保存")
    bNo   := dlg.Add("Button", "x+20 yp w310 h34", "キャンセル")

    bHelp.OnEvent("Click",  (*) => ShowGuide("登録用 QR の設定 — 詳しい手順", RegGuideText()))
    bCopy.OnEvent("Click",  (*) => CopyEnd())
    bSave.OnEvent("Click",  (*) => SaveIt())
    bNo.OnEvent("Click",    (*) => ReopenAndExit(0))
    dlg.OnEvent("Close",    (*) => ReopenAndExit(0))
    if (!ScrollAttach(dlg))
        dlg.Show()
    return

    CopyEnd() {
        if (Trim(eEnd.Value) = "") {
            MsgBox("先に LIFF ID を登録してください。", APP_NAME, "Icon! 4096")
            return
        }
        A_Clipboard := Trim(eEnd.Value)
        MsgBox("コピーしました。`n`n"
            . "LINE Developers の LIFF アプリの「エンドポイント URL」に貼り付けてください。"
            , APP_NAME, "Iconi 4096")
    }
    SaveIt() {
        liff := Trim(eLiff.Value)
        if (liff != "" && !RegExMatch(liff, "^[0-9]{6,}-[0-9A-Za-z]{4,}$")) {
            if (MsgBox("LIFF ID の形が違うようです（いまの入力: 「" . liff . "」）。`n`n"
                . "1234567890-abcdEFGH のような形です。`n`n"
                . "このまま保存しますか？", APP_NAME, "YesNo Icon! 4096") != "Yes")
                return
        }
        oa := Trim(eOa.Value)
        if (oa != "" && SubStr(oa, 1, 1) != "@")
            oa := "@" . oa                         ; @ を忘れても直して保存する
        IniSetMany(CFG, "Notify"
            , Map("LiffId", liff, "ShopName", Trim(eShop.Value), "LineOaId", oa))
        C["LiffId"]   := liff
        C["ShopName"] := Trim(eShop.Value)
        C["LineOaId"] := oa
        eOa.Value := oa
        Log("INFO", "登録用 QR の設定を保存しました（LIFF ID " . (liff = "" ? "なし" : "あり") . "）")
        done := "予定の編集画面の「登録用の QR」が使えるようになりました。"
        yet  := "LIFF ID が空のため、登録用の QR はまだ発行できません。"
        MsgBox("保存しました。`n`n" . ((liff = "") ? yet : done), APP_NAME, "Iconi 4096")
        ScrollDetach(dlg.Hwnd)
        try dlg.Destroy()
        BackToSettings()
    }
}


; 発行済みの合言葉を順に見て、登録されていれば受け取る。
;   ★1 分に 1 回まで★ 窓口を叩きすぎない。
RegPollAll() {
    global SCHEDINI
    static lastTry := ""
    ; ★承認待ちは、いつでも聞く★
    ;   受け取りの設定を消しても、間引き中でも、
    ;   すでに受け取った分は承認してもらわないと宙に浮く。
    RegAskPending()
    ; ★取り下げた宛先の掃除を、定期的に回す★
    ;   これまで「ほかの予定を削除したとき」にしか走らなかったので、
    ;   誰も削除しなければ 30 日を過ぎても消えずに残り続けていた。
    ;   送信係が死んでいた件と同じ型（動くはずのものが黙って動かない）。
    static lastPurge := ""
    if (lastPurge = "" || SecSince(lastPurge) > 3600) {
        lastPurge := A_Now
        ContactPurgeGone()
    }
    if (!NotifyAllowed())
        return                                     ; 一般は、新しい登録を受け取らない（承認待ちは上で聞く）
    if (!RegReady())
        return
    if (lastTry != "" && SecSince(lastTry) < 60)
        return
    lastTry := A_Now
    path := ContactPath()
    if !FileExist(path)
        return
    for sec, kv in ContactAll() {
        if (sec = "" || sec = "Default" || SubStr(sec, 1, 1) = "~")
            continue
        pend := RegPendGet(sec)
        if (pend["code"] = "" && pend["old"].Length = 0)
            continue
        ; ★最新の合言葉と、前の合言葉（最大 2 つ）を、順に見に行く★
        cands := []
        if (pend["code"] != "")
            cands.Push(Map("code", pend["code"], "at", pend["at"], "latest", true))
        for o in pend["old"]
            cands.Push(Map("code", o["code"], "at", o["at"], "latest", false))
        got := false
        for cand in cands {
            ; 14 日を過ぎた合言葉は捨てる（窓口の側でも消えている）
            if (cand["at"] != "" && DateDiff(A_Now, cand["at"], "Days") >= 14) {
                if (!cand["latest"])
                    continue                       ; 古い方は、静かに見なくなる（次の発行のときに消える）
                RegPendClear(sec)
                ; ★黙って捨てない★ 顧客には「登録を受け付けました」と出ている。
                ;   こちらが気づかないと、いつまでも届かないままになる（2026-10-02）。
                who := SchedNameOf(sec)
                Log("WARN", "登録用の QR が期限切れになりました: " . sec)
                NotifyAdmin("AutoMeta 登録の期限切れ"
                    , "登録用の QR が、読み取られないまま 14 日を過ぎました。`n`n"
                    . "　顧客　　　" . Trim(who) . "`n"
                    . "　この PC 　" . A_ComputerName . "`n`n"
                    . "お知らせを届けるには、もう一度「登録用の QR」を発行してください。`n"
                    . "※ 顧客が読み取り済みの場合は、この PC が 14 日間"
                    . "一度も受け取りに行けなかった可能性があります。`n"
                    . "※ AutoMeta が自動でお送りしています。")
                break
            }
            userId := "", why := ""
            if (!RegTake(cand["code"], &userId, &why)) {
                if (why != "")
                    Log("INFO", "登録の受け取り: " . why)
                continue                           ; まだ登録されていないだけ
            }
            ; ★受け取ったら、まずファイルに残す★
            ;   承認するまで「承認待ち」として持っておく（2026-10-02）。
            ;   ★中継からは、書き終えたあとに消す★（3.10.26）受け取りの応答が途中で切れても失われない。
            IniSetMany(ContactPath(), ContactSec(sec)
                , Map("PendId", userId, "PendIdAt", FormatTime(A_Now, "yyyyMMddHHmmss")))
            RegPendClear(sec)
            RegAck(cand["code"])
            Log("INFO", "登録を受け取りました（" . sec . (cand["latest"] ? "" : "／前の QR から") . "）")
            got := true
            break                                  ; 1 人の登録は 1 回。残りの合言葉は RegPendClear で外した
        }
    }
    RegAskPending()                                ; 承認待ちがあれば聞く
}

; ★承認待ちは、すべて 1 つの窓に一覧で出す★（2026-10-08 指摘）
;   受け取り済みで、まだ承認していないもの。×で閉じても消さない（2 分後にまた出す）。
;   アプリが落ちても残る。
;   以前は 1 件ずつ窓を出し、席を外して時間がたつと、同じ登録の窓が何枚も重なった。
RegAskPending() {
    if (RegAsking())
        return                                     ; 窓がすでにある（どのプロセスのものでも）
    cache := Map()
    rows := RegPendRows(cache)
    if (rows.Length = 0)
        return
    RegAsking("1")
    RegConfirmAll(rows, cache)
}

; 承認待ちの一覧を作る（古い順）。
;   ★あとで・× を選んだ方は、しばらく入れない★ 同じ窓が出続けないように。
;   ただし長すぎると、間違えて閉じたときに待たされる（2026-10-03 指摘）。
;   プロフィールは窓口へ聞きに行くので、聞いた結果は cache に残して使い回す。
;   友だち追加がまだの方は、毎回聞き直す（追加されたかを見るため）。
RegPendRows(cache) {
    out := []
    if !FileExist(ContactPath())
        return out
    m := ContactAll()
    for sec, kv in m {
        if (sec = "" || sec = "Default" || SubStr(sec, 1, 1) = "~")
            continue
        pid := Trim(IniGet(m, sec, "PendId", ""))
        if (pid = "")
            continue
        snz := Trim(IniGet(m, sec, "PendIdSnooze", ""))
        if (snz != "" && SecSince(snz) < 120)
            continue
        prof := cache.Has(pid) ? cache[pid] : ""
        if (!IsObject(prof) || !prof["ok"]) {
            name := "", why := ""
            okp := LineProfile(pid, &name, &why)
            nameShown := ""
            if (okp)
                nameShown := (name = "") ? "（表示名なし）" : name
            prof := Map("ok", okp, "name", nameShown, "why", why)
            cache[pid] := prof
        }
        whom := SchedNameOf(sec)
        if (whom = "")                             ; 保存前などで読めないとき
            whom := "（" . sec . "）"
        row := Map("key", sec, "userId", pid, "at", Trim(IniGet(m, sec, "PendIdAt", ""))
                 , "whom", whom, "ok", prof["ok"], "who", prof["name"], "why", prof["why"])
        ; 古い順に並べる（受け取った順）
        pos := out.Length + 1
        Loop out.Length {
            if (row["at"] < out[A_Index]["at"]) {
                pos := A_Index
                break
            }
        }
        out.InsertAt(pos, row)
    }
    return out
}

; 一覧の中身が変わったか調べるための印
RegRowsSig(rows) {
    t := ""
    for r in rows
        t .= r["key"] . "/" . r["userId"] . "/" . (r["ok"] ? "1" : "0") . ";"
    return t
}

; 予定の氏名を読む。
;   ★schedule.ini を IniRead で読まない★
;   このファイルは UTF-8 で書かれているが、Windows の ini 読み出しは
;   そのまま別の文字コードとして読むため、日本語が化ける
;   （2026-10-03、承認の画面に「骼橋伐 諢1蠟ｿ」と出た）。
;   本体と同じ読み方（IniLoad で丸ごと読んで解析）を使う。
SchedNameOf(key) {
    err := ""
    for p in LoadSchedule(&err) {
        if (p["key"] = key)
            return Trim(p["sei"] . " " . p["mei"])
    }
    return ""
}

; この宛先が、ほかの予定にも付いていないか調べる
;   付いたままだと、1 回のセラピーで同じ方へ複数通届く（2026-10-02）。
ContactOwnerOf(lineId, exceptKey) {
    path := ContactPath()
    if (!FileExist(path) || lineId = "")
        return ""
    m := ContactAll()
    for sec, kv in m {
        if (sec = "" || sec = "Default" || SubStr(sec, 1, 1) = "~"
            || sec = ContactSec(exceptKey))
            continue
        if (Trim(IniGet(m, sec, "LineId", "")) = lineId)
            return sec
    }
    return ""
}

; 承認待ちを消す（承認した／登録しないを選んだ）
RegPendIdClear(key) {
    IniSetMany(ContactPath(), ContactSec(key)
        , Map("PendId", "", "PendIdAt", "", "PendIdSnooze", ""))
}

; ★承認の窓は、画面全体で 1 つだけ★（2026-10-08 指摘）
;   席を外して時間がたつと、同じ登録の窓が何枚も重なって出ていた。原因は 2 つ。
;     ① 「出している最中」の印が 10 分で自動的に外れ、開いたままの窓の上に、また窓を出した
;     ② 印がプロセスごとに別で、メニュー・予定の編集・運転中の本体が、それぞれ窓を出した
;   だから印ではなく、窓が実際にあるかを画面全体で見る。
RegWinTitle() {
    global APP_NAME
    return APP_NAME . " - 顧客の登録"
}

RegWinExists() => WinExist(RegWinTitle()) ? true : false

; 承認の窓を出している最中か。窓があれば true。
;   印だけが残っているとき（窓を作れなかった）は、60 秒で外す。
RegAsking(set := "") {
    static since := ""                             ; 立てた時刻。空＝立っていない
    if (set != "") {
        since := (set = "1") ? A_Now : ""
        return (since != "")
    }
    if (RegWinExists())
        return true
    if (since != "" && SecSince(since) <= 60)
        return true
    since := ""
    return false
}
RegAskDone() {
    RegAsking("0")
}

; 表示名を見せて、本当にこの方かを確かめてから紐づける。
;   ★MsgBox を使わない★ 見回りの最中に出すので、
;   誰も PC にいない夜中に出ると、押されるまで運転が止まってしまう
;   （2026-10-01、実運用を想定して気づいた）。
;   ★登録は 1 つの窓に一覧で出す★ 件数が増えても、窓は 1 つ。
;   開いている間も、新しい登録が届けば行を足す（10 秒ごとに見直す）。
RegConfirmAll(firstRows, cache) {
    global APP_NAME
    title := RegWinTitle()
    ; ★内側の関数から書き換える値は、引数ではなく普通の変数にする★
    rows  := firstRows
    marks := Map()                                 ; 顧客ごとのチェック（作り直しても保つ）
    dlg := Gui("+AlwaysOnTop +ToolWindow", title)
    dlg.MarginX := 18, dlg.MarginY := 14
    dlg.SetFont("s11 Bold", "Meiryo UI")
    tHead := dlg.Add("Text", "w640", "LINE の登録がありました")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w640 cGray"
        , "表示名を確かめて、知らない方はチェックを外してください。`n"
        . "チェックを外した方は、2 分後にもう一度お尋ねします。")
    dlg.SetFont("s10", "Meiryo UI")
    lv := dlg.Add("ListView", "xm w640 r7 Checked Grid -Multi NoSortHdr"
        , ["顧客（予定）", "LINE の表示名", "状態", "番号"])
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "xm w640 cGray"
        , "友だち追加が済んでいない方は、チェックが外れています（顧客に「追加」を押していただいてください）。")
    dlg.SetFont("s10", "Meiryo UI")
    bYes := dlg.Add("Button", "xm w230 h34 Default", "チェックした方を紐づける")
    bNo  := dlg.Add("Button", "x+10 yp w230 h34", "チェックした方を登録しない")
    bLtr := dlg.Add("Button", "x+10 yp w150 h34", "あとで確認")
    bYes.OnEvent("Click", (*) => Bind())
    bNo.OnEvent("Click",  (*) => Skip())
    bLtr.OnEvent("Click", (*) => Later(true))
    dlg.OnEvent("Close",  (*) => Later(true))      ; ×は保留。2 分後にまた聞く
    Fill()
    dlg.Show()
    ; ★ほかのプロセスと同時に開いたときは、先に作られた 1 つだけを残す★
    ;   同じ画面を、メニューと運転中の本体が同時に作ることがある。
    wins := WinGetList(title . " ahk_class AutoHotkeyGUI")
    if (wins.Length > 1) {
        keep := wins[1]
        for h in wins {
            if (h < keep)
                keep := h
        }
        if (keep != dlg.Hwnd) {
            try dlg.Destroy()
            RegAskDone()
            return
        }
    }
    SetTimer(Refresh, 10000)
    return

    ; いまの行のチェックを覚える（作り直しても、利用者が付け外ししたものを保つため）
    Remember() {
        Loop lv.GetCount() {
            idx := ToInt(Trim(lv.GetText(A_Index, 4)), 0)
            if (idx >= 1 && idx <= rows.Length)
                marks[rows[idx]["key"]] := (lv.GetNext(A_Index - 1, "C") = A_Index) ? 1 : 0
        }
    }

    Fill() {
        lv.Delete()
        for i, r in rows {
            want := r["ok"]
            if (marks.Has(r["key"]))
                want := (want && marks[r["key"]] = 1)
            lv.Add(want ? "Check" : "", r["whom"], r["who"], r["ok"] ? "確認できました" : r["why"], i)
        }
        lv.ModifyCol(1, 190), lv.ModifyCol(2, 220), lv.ModifyCol(3, 210), lv.ModifyCol(4, 0)
        tHead.Value := "LINE の登録がありました（" . rows.Length . " 件）"
    }

    ; 新しい登録が届いた・別の場所で処理された、を一覧に反映する
    Refresh() {
        newRows := RegPendRows(cache)
        if (RegRowsSig(newRows) = RegRowsSig(rows))
            return
        Remember()
        rows := newRows
        if (rows.Length = 0) {
            Shut()
            RegAskDone()
            return
        }
        Fill()
    }

    Shut() {
        SetTimer(Refresh, 0)
        try dlg.Destroy()
    }

    ; チェックの付いた行／付いていない行を、番号から引いて分ける
    ;   ★表示の行番号を配列の位置に使わない★ 4 列目に本当の位置を持たせてある。
    Picked(&checked, &others) {
        checked := [], others := []
        Loop lv.GetCount() {
            idx := ToInt(Trim(lv.GetText(A_Index, 4)), 0)
            if (idx < 1 || idx > rows.Length)
                continue
            if (lv.GetNext(A_Index - 1, "C") = A_Index)
                checked.Push(rows[idx])
            else
                others.Push(rows[idx])
        }
    }

    SnoozeAll(list) {
        for r in list
            IniSetMany(ContactPath(), ContactSec(r["key"])
                , Map("PendIdSnooze", FormatTime(A_Now, "yyyyMMddHHmmss")))
    }

    ; あとで／×
    Later(tell) {
        SnoozeAll(rows)
        Log("INFO", "登録の承認を保留しました（" . rows.Length . " 件／2 分後にまた聞きます）")
        Shut()
        RegAskDone()
        ; ★消えていないことを知らせる★
        ;   × で閉じたとき、何も出ないと「消してしまった」と思わせる（2026-10-03 指摘）。
        if (tell)
            try TrayTip("登録はそのままです"
                , rows.Length . " 件の承認を保留しました。`n2 分後にもう一度お尋ねします。", 1)
    }

    Bind() {
        global APP_NAME
        Picked(&checked, &others)
        if (checked.Length = 0) {
            MsgBox("紐づける方にチェックを入れてください。", APP_NAME . " - 顧客の登録", "Icon! 4096")
            return
        }
        ; 友だち追加が済んでいない方は、紐づけられない（送れない）。見合わせて、あとでまた聞く
        ready := [], notYet := []
        for r in checked {
            if (r["ok"])
                ready.Push(r)
            else
                notYet.Push(r)
        }
        SnoozeAll(others)
        SnoozeAll(notYet)
        ; ★押したら、まず閉じる★
        ;   この先で失敗しても「押しても閉じない」状態にしない（2026-10-03）。
        Shut()
        RegAskDone()
        res := []
        for r in ready {
            try {
                res.Push(RegBindOne(r["key"], r["userId"], r["whom"]))
            } catch as e {
                Log("WARN", "登録の処理で止まりました（" . r["key"] . "）：" . e.Message)
                res.Push(Map("whom", r["whom"], "state", "error", "detail", e.Message))
            }
        }
        RegBindSummary(res, notYet.Length)
        RegAskPending()                            ; 残りがあれば、また 1 つの窓で聞く
    }

    Skip() {
        global APP_NAME
        Picked(&checked, &others)
        if (checked.Length = 0) {
            MsgBox("登録しない方にチェックを入れてください。", APP_NAME . " - 顧客の登録", "Icon! 4096")
            return
        }
        names := ""
        for r in checked
            names .= "　・" . r["whom"] . "`n"
        ; ★取り消せない操作は、失うものを書く★
        if (MsgBox(checked.Length . " 件を、登録しません。`n`n" . names . "`n"
            . "この方々は、「登録用の QR」を発行し直すまで登録できません。`n"
            . "よろしいですか？"
            , APP_NAME . " - 顧客の登録", "YesNo Icon? 4096") != "Yes")
            return
        for r in checked {
            RegPendIdClear(r["key"])
            Log("INFO", "登録しないを選びました（" . r["key"] . "）")
        }
        SnoozeAll(others)
        Shut()
        RegAskDone()
        RegAskPending()
    }
}

; 1 人ぶんを紐づける。結果を返す（画面は出さない。まとめて知らせるため）。
;   戻り値 Map("whom", 名前, "state", bound／sendfail／held／error, "detail", 理由)
RegBindOne(key, userId, whom) {
    global APP_NAME, REGUI
    ; ★同じ宛先が二重に付かないようにする★
    dup := ContactOwnerOf(userId, key)
    if (dup != "") {
        dwho := SchedNameOf(dup)
        if (dwho = "")
            dwho := "（" . dup . "）"
        ans := MsgBox("この宛先は、すでに別の予定に登録されています。`n`n"
            . "　いまの登録先　" . dwho . "`n"
            . "　新しい登録先　" . whom . "`n`n"
            . "両方に残すと、1 回のセラピーで同じ方へ 2 通届きます。`n`n"
            . "「はい」で、いまの登録先から外して、こちらに付け替えます。`n"
            . "「いいえ」で、何もしません。"
            , APP_NAME . " - 顧客の登録", "YesNo Icon! 4096")
        if (ans != "Yes") {
            ; 見合わせた分は、すぐにまた聞かない
            IniSetMany(ContactPath(), ContactSec(key)
                , Map("PendIdSnooze", FormatTime(A_Now, "yyyyMMddHHmmss")))
            Log("INFO", "二重の宛先のため登録を見合わせました（" . key . "）")
            return Map("whom", whom, "state", "held", "detail", "すでに別の予定に登録されています")
        }
        ContactSet(dup, false, "")
        Log("INFO", "宛先を付け替えました（" . dup . " → " . key . "）")
    }
    ContactSet(key, true, userId)
    RegPendIdClear(key)
    ; 編集画面が開いていれば、その欄にも入れる（空で上書きされるのを防ぐ）
    if (REGUI.Has("key") && REGUI["key"] = key) {
        try {
            REGUI["line"].Value := userId
            REGUI["on"].Value   := 1
        }
    }
    Log("INFO", "顧客を登録しました（" . key . " ／ 宛先 " . LineMask(userId) . "）")
    ; ★ここで 1 通送って、本当に届くか確かめる★
    ;   友だち追加のあいさつは「友だちになれた」ことしか示さない。
    ;   この公式アカウントからその方へ送れるかは別で、
    ;   確かめずにいると、初回のセラピーまで誰も気づけない（2026-10-02 指摘）。
    err := ""
    ok := LineSend(userId
        , "登録が完了しました。`n`n"
        . "これから、セラピーが終わったときに、このトークへお知らせが届きます。`n`n"
        . "※ 受け取りをやめたいときは、お申し付けください。", &err)
    if (ok)
        return Map("whom", whom, "state", "bound", "detail", "")
    Log("WARN", "確認のメッセージを送れませんでした（" . key . "）：" . err)
    return Map("whom", whom, "state", "sendfail", "detail", err)
}

; まとめて 1 回だけ知らせる（件数が増えても、押す回数を増やさない）
RegBindSummary(res, notYetCount) {
    global APP_NAME
    nOk := 0, nBad := 0
    lines := ""
    for r in res {
        if (r["state"] = "bound") {
            nOk++
            lines .= "　・" . r["whom"] . "　確認のメッセージをお送りしました`n"
        } else if (r["state"] = "sendfail") {
            nOk++, nBad++
            lines .= "　・" . r["whom"] . "　登録しましたが、確認のメッセージを送れませんでした（" . r["detail"] . "）`n"
        } else if (r["state"] = "held") {
            lines .= "　・" . r["whom"] . "　見合わせました（" . r["detail"] . "）`n"
        } else {
            nBad++
            lines .= "　・" . r["whom"] . "　途中で止まりました（" . r["detail"] . "）`n"
        }
    }
    head := nOk . " 件を登録しました。"
    if (res.Length = 0)
        head := "登録した方はいません。"
    tail := ""
    if (nBad > 0)
        tail := "`n確認のメッセージが届かない方は、セラピーのお知らせも届きません。`n"
              . "設定 →「LINE」で「テスト送信」が通るか確かめてください。`n"
    if (notYetCount > 0)
        tail .= "`n友だち追加が済んでいない " . notYetCount . " 件は、2 分後にもう一度お尋ねします。`n"
    if (lines = "" && tail = "")
        return
    MsgBox(head . "`n`n" . lines . tail
        , APP_NAME . " - 顧客の登録", (nBad > 0) ? "Icon! 4096" : "Iconi 4096")
}

; 渡す紙を作って、ブラウザで開く。
;   QR はこの PC の中で描くので、合言葉がよそへ出ることはない。
RegSheetOpen(sei, mei, code) {
    url  := RegQrUrl(code)
    path := NotifyDir() . "\register_" . StrReplace(code, "-", "") . ".html"
    html := "
    (
<!doctype html>
<html lang='ja'><head><meta charset='utf-8'>
<title>お知らせの登録</title>
<script src='https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js'></script>
<style>
  body{font-family:'Meiryo UI',sans-serif;margin:0;background:#eceff1;color:#1b1f23}
  .sheet{width:148mm;min-height:200mm;margin:14px auto;background:#fff;
         padding:16mm 14mm;box-sizing:border-box;border-radius:6px}
  h1{font-size:19pt;margin:0 0 4mm;text-align:center}
  .shop{font-size:11pt;color:#555;text-align:center;margin:0 0 2mm}
  .shop:empty{display:none}
  .lead{font-size:11pt;color:#444;text-align:center;margin:0 0 8mm;line-height:1.8}
  #qr{display:flex;justify-content:center;margin:0 0 6mm}
  ol{font-size:12pt;line-height:2.1;margin:0 0 8mm;padding-left:1.4em}
  .who{text-align:center;font-size:11pt;color:#666;margin:0 0 2mm}
  .note{font-size:10pt;color:#666;line-height:1.9;border-top:1px solid #ddd;padding-top:5mm}
  .btn{display:block;width:60mm;margin:4mm auto 0;padding:3mm;text-align:center;
       font-size:11pt;border:1px solid #bbb;border-radius:4px;background:#f7f7f7;cursor:pointer}
  .urlhead{font-size:10pt;color:#666;margin:0 0 1mm;text-align:center}
  .url{font-size:9pt;color:#333;font-family:Consolas,monospace;word-break:break-all;
       text-align:center;background:#f5f7f9;border:1px solid #e0e4e8;border-radius:4px;
       padding:2.5mm 3mm;margin:0 0 6mm}
  @media print{ body{background:#fff} .sheet{margin:0;border-radius:0} .btn{display:none} }
</style></head><body>
<div class='sheet'>
  <p class='shop'>%SHOP%</p>
  <h1>セラピーのお知らせを LINE で受け取る</h1>
  <p class='lead'>セラピーが終わったことを、LINE でお知らせします。<br>
     受け取りたい方は、下の QR を読み取ってください。</p>
  <div id='qr'></div>
  <ol>
    <li>スマートフォンのカメラで QR を読み取る</li>
    <li>LINE が開くので、画面の案内に沿って進む</li>
    <li>「追加」を押す（これを押さないとお知らせが届きません）</li>
  </ol>
  <p class='urlhead'>QR が読めないときは、こちらを開いてください</p>
  <p class='url' id='u'>%URL%</p>
  <p class='who'>%WHO%</p>
  <div class='note'>
    ・生年月日やご連絡先をご入力いただくことはありません。<br>
    ・受け取りをやめたいときは、いつでもお申し付けください。<br>
    ・この QR は、お渡しした方ご本人のものです。<br>
    ・2 週間を過ぎると使えなくなります。お早めにお願いします。
  </div>
  <div class='btn' onclick='window.print()'>印刷する</div>
  <div class='btn' onclick='cp()'>リンクをコピー</div>
</div>
<script>
new QRCode(document.getElementById('qr'),
  { text:'%URL%', width:240, height:240, correctLevel:QRCode.CorrectLevel.M });
function cp(){
  var t = document.getElementById('u').textContent;
  navigator.clipboard.writeText(t).then(
    function(){ alert('リンクをコピーしました。\n\nLINE やメールで、ご本人にだけお送りください。'); },
    function(){ alert('コピーできませんでした。リンクを選んでコピーしてください。'); });
}
</script>
</body></html>
    )"
    html := StrReplace(html, "%URL%",  url)
    html := StrReplace(html, "%SHOP%", Trim(CS("ShopName")))
    html := StrReplace(html, "%WHO%",  Trim(sei . " " . mei) . " 様")

    ; ★失敗を握りつぶさない★
    ;   2026-10-02、ページが開かないのに「開きました」と出て、原因が分からなかった。
    dir := NotifyDir()
    if (!DirExist(dir)) {
        try DirCreate(dir)
        catch as e {
            Log("WARN", "登録用のページを置く場所を作れません: " . e.Message)
            return "置き場所を作れませんでした（" . dir . "）"
        }
    }
    try FileDelete(path)
    try {
        FileAppend(html, path, "UTF-8")
    } catch as e {
        Log("WARN", "登録用のページを書き出せません: " . e.Message)
        return "ファイルを書き出せませんでした（" . path . "）"
    }
    if (!FileExist(path)) {
        Log("WARN", "登録用のページが作られませんでした: " . path)
        return "ファイルを作れませんでした（" . path . "）"
    }
    try {
        Run(path)
    } catch as e {
        Log("WARN", "登録用のページを開けません: " . e.Message)
        return "ページは作りましたが、ブラウザで開けませんでした。`n`n"
             . "　場所　" . path . "`n`n"
             . "このファイルをダブルクリックすると開きます。"
    }
    Log("INFO", "登録用のページを作りました（合言葉 " . code . "）")
    return ""                                      ; 空＝うまくいった
}

; LINE の本文を組み立てる。
;   ★件名が空なら、くっつけない★ 空の件名でも改行 2 つが残り、
;   顧客へのお知らせの冒頭に空行が 2 行できていた（2026-10-01 指摘）。
LineText(subject, body) {
    subject := Trim(subject, " `t`r`n")
    body    := Trim(body, " `t`r`n")
    if (subject = "")
        return body
    if (body = "")
        return subject
    return subject . "`n`n" . body
}

; ★設定してある宛先ぜんぶに送る★ メールと LINE の両方でも、片方だけでもよい
; ★LINE は緊急のときだけ★（3.10.37）LINE の月間送信数は、顧客へのお知らせと分け合う。
;   2026-10 の実機で、LINE 196 通のうち 130 通が管理者宛（うち完了の知らせが 103 通）だった。
;   urgent=false はメールへ。メールが未設定のときだけ LINE へ（知らせが消えないように）。
NotifyAdmin(subject, body, urgent := true) {
    if (!NotifyOn())
        return false
    if (!NotifyAllowed()) {
        Log("INFO", "スタンダードプランのため、通知は送信しません：" . subject)
        return false
    }
    ways := ""
    if (MailReady()) {
        NotifyPush("MAIL", subject, body)
        ways .= "メール"
    }
    if (LineReady() && (urgent || !MailReady())) {
        NotifyPush("LINE", subject, body)
        ways .= (ways = "" ? "" : "と ") . "LINE"
    }
    if (ways = "") {
        Log("INFO", "通知を送れません（メールも LINE も設定がまだです）：" . subject)
        return false
    }
    Log("INFO", "管理者へ " . ways . " で通知を送信します：" . subject)
    NotifierEnsure()                               ; 運ぶのは送信係（本体は止まらない）
    return true
}

; ★顧客へ「終わりました」を送る★（V3 ステップ 2）
;   ・完了したときだけ。失敗や要確認は送らない（不安にさせるため）
;   ・氏名の照合が済んでいるときだけ（取り違えたまま送らない）
;   ・夜中に鳴らさない。設定した時刻（既定 8:00）にまとめて届く
NotifyPatient(code, summary) {
    global G
    if (code != 0)
        return                                     ; 完了のとき以外は、顧客へは送らない（設計）
    if (!NotifyNewOk()) {
        NotifyLogAdd("skip_" . A_Now . Random(100, 999), "skipped", G.wantSei, G.wantMei, ""
            , NotifyAllowed() ? "通知を使わない設定" : "スタンダードプランは通知なし")
        return
    }
    if (G.schedCurrent = "") {
        Log("INFO", "「1人だけ実行」のため、顧客へは送りません（予定から実行したときだけ）")
        NotifyLogAdd("skip_" . A_Now . Random(100, 999), "skipped", G.wantSei, G.wantMei, "", "1 人だけ実行")
        return
    }
    if (G.gotSei = "") {
        Log("INFO", "氏名の照合が完了していないため、顧客へは送信しません")
        NotifyLogAdd("skip_" . A_Now . Random(100, 999), "skipped", G.wantSei, G.wantMei, "", "氏名の照合が未完了")
        return
    }
    who := ContactGet(G.schedCurrent)
    if (!who["on"]) {                              ; この方には送らない設定
        NotifyLogAdd("skip_" . A_Now . Random(100, 999), "skipped", G.gotSei, G.gotMei, "", "この方には送らない設定")
        return
    }
    mail := ContactMailGet(G.schedCurrent)
    toLine := (who["line"] != "" && LineReady())
    toMail := (mail != "" && MailReady())
    if (!toLine && !toMail) {
        why := "届け先が未登録"
        if (who["line"] != "" && !LineReady()) {
            Log("INFO", "顧客へ送れません（LINE の設定がまだです）")
            why := "LINE の設定がまだ"
        } else if (mail != "" && !MailReady()) {
            Log("INFO", "顧客へ送れません（メールの設定がまだです）")
            why := "メールの設定がまだ"
        }
        NotifyLogAdd("skip_" . A_Now . Random(100, 999), "skipped", G.gotSei, G.gotMei, "", why)
        return
    }
    ; ★0 の行は落とす★ 調査をしない予定で「全身 0 か所」と届くのを防ぐ
    ;   ★顧客ごとの文面があれば、そちらを使う★ 無ければ共通（3.9）
    tpl := NotifyTemplateFor(G.schedCurrent)
    tpl := NotifyDropZero(tpl, "回数",   G.cycle)
    tpl := NotifyDropZero(tpl, "項目数", G.scanItems)
    body := NotifyFill(tpl, Map(
        "宛名",   NotifyAddressee(G.gotSei, G.gotMei),
        "日付",   FormatTime(A_Now, "M月d日(ddd)"),
        "開始",   FormatTime(G.startTS, "H:mm"),
        "終了",   FormatTime(A_Now, "H:mm"),
        "回数",   G.cycle,
        "項目数", G.scanItems))
    sendAt := NotifySendAt()
    ways := ""
    if (toLine) {
        pth := NotifyPush("LINE", "", body, who["line"], sendAt)
        NotifyLogAdd(NotifyBaseOf(pth), "queued", G.gotSei, G.gotMei, "LINE", sendAt)
        ways := "LINE " . LineMask(who["line"])
    }
    if (toMail) {
        pth := NotifyPush("MAIL", NotifyMailSubject(), body, mail, sendAt)
        NotifyLogAdd(NotifyBaseOf(pth), "queued", G.gotSei, G.gotMei, "MAIL", sendAt)
        ways .= (ways = "" ? "" : " ／ ") . "メール " . MailMask(mail)
    }
    NotifierEnsure()
    held := "保留し、" . FmtHHMM(SubStr(sendAt, 9, 4)) . " に送信します"
    when := (sendAt = "") ? "すぐに送信します" : held
    Log("INFO", Format("顧客へのお知らせは{1}（宛先 {2}）", when, ways))
}

; ★いつ送るかを決める★
;   送信しない時間帯（既定 21:00〜08:00）に終わった分 → その時間帯の終わりにまとめて
;   それ以外に終わった分 → すぐ
;   空文字を返したら「すぐ送る」の意味。
NotifySendAt() {
    quietFrom := QuietStart()
    quietTo   := QuietEnd()
    nowHHMM := FormatTime(A_Now, "HHmm")
    inQuiet := false
    if (quietFrom = quietTo)
        inQuiet := false                           ; 送信しない時間帯なし＝いつでもすぐ
    else if (quietFrom > quietTo)                  ; 夜をまたぐ（21:00〜08:00）
        inQuiet := (nowHHMM >= quietFrom || nowHHMM < quietTo)
    else                                           ; またがない（12:00〜14:00）
        inQuiet := (nowHHMM >= quietFrom && nowHHMM < quietTo)
    ; ★判断の材料をログに残す★
    ;   2026-09-30、23:00〜08:00 にしたのに 22:31 の分が保留された。
    ;   どの値で判断したかが残っていなかったため、突き止めるのに時間がかかった。
    Log("INFO", Format("送信の判断: 現在 {1}／送信しない時間帯 {2}〜{3} → {4}"
        , FmtHHMM(nowHHMM), FmtHHMM(quietFrom), FmtHHMM(quietTo)
        , inQuiet ? "保留" : "即時"))
    if (!inQuiet)
        return ""                                  ; 時間帯の外は、すぐ送る
    return NextStampAt(quietTo, "0800")            ; ★明けたら送る★
}

; 送信しない時間帯のはじまり。
;   ★両端を同じ場所から読む★ 片方を C（起動時の値）、片方を ini（いまの値）から
;   読んでいたため、設定を変えた直後に「古いはじまり ＋ 新しい終わり」が混ざり、
;   23:00〜08:00 にしたのに 21:00〜08:00 で判断していた（2026-09-30 実機）。
;   運転を始めたあとに設定を変えても効くよう、判断のたびに ini を読む。
QuietStart() {
    global CFG
    t := NormTime(IniRead(CFG, "Notify", "QuietFrom", ""))
    if (t = "")
        t := NormTime(Trim(CS("QuietFrom")))
    if (t = "")
        t := "2100"
    return t
}

; 送信しない時間帯の終わり。ためた分は、この時刻に出ていく。
;   3.6.4 以前は MorningTime が同じ役目だったので、そちらを引き継ぐ。
QuietEnd() {
    global CFG
    t := NormTime(IniRead(CFG, "Notify", "QuietTo", ""))
    if (t = "")
        t := NormTime(Trim(CS("MorningTime")))
    if (t = "")
        t := "0800"
    return t
}

; 差し込みの値が 0 なら、その行ごと落とす。
;   「セラピー 0 回」「全身 0 か所」が顧客へ届くのを防ぐ。
;   ただし全部消えてしまうときは、元の文面をそのまま使う。
NotifyDropZero(tpl, name, value) {
    mark := "{" . name . "}"
    if (ToInt(value, 0) != 0 || !InStr(tpl, mark))
        return tpl
    out := ""
    for oneLine in StrSplit(tpl, "`n", "`r") {
        if (InStr(oneLine, mark))
            continue
        out .= (out = "" ? "" : "`r`n") . oneLine
    }
    return (Trim(out, " `t`r`n") = "") ? tpl : out
}

; 通知がいつ出ていくかを、ひと言で（予定の画面などで使う）
NotifyWhenWord() {
    f := QuietStart()
    t := QuietEnd()
    if (f = "" || f = t)
        return "即時送信"
    return "即時（保留 " . FmtHHMM(t) . "）"
}

; 設定をそのまま日本語で読み返す（入れた瞬間に意味が見えるように）
QuietWord(f, t) {
    if (f = "" || t = "")
        return "→ 時刻を読み取れません"
    if (f = t)
        return "→ 保留なし（常に即時送信）"
    return "→ 保留分は " . FmtHHMM(t) . " に送信"
}

; 次に来る「その時刻」の日時を作る（過ぎていれば翌日）
NextStampAt(hhmm, fallback) {
    if (StrLen(hhmm) != 4)
        hhmm := fallback
    stamp := FormatTime(A_Now, "yyyyMMdd") . hhmm . "00"
    if (A_Now >= stamp) {
        nextDay := DateAdd(A_Now, 1, "Days")
        stamp := FormatTime(nextDay, "yyyyMMdd") . hhmm . "00"
    }
    return stamp
}

; 実行結果を知らせる。完了は既定で送らない（顧客向けができるまでの足場）
; 設定を確かめられなかったことを表す短い言葉（件名に付ける）。無ければ ""。
OptWarnTag() {
    global G
    w := G.optWarn
    if (w = "")
        return ""
    if (InStr(w, "調査タイプ"))
        return "調査タイプ未確認"
    if (InStr(w, "マニュアル選択"))
        return "マニュアル選択未確認"
    return "設定未確認"
}

NotifyJobResult(code, reason, summary) {
    global G
    if (!NotifyOn())
        return
    if (!NotifyAllowed()) {
        Log("INFO", "スタンダードプランのため、完了・異常の通知は送信しません")
        return
    }
    kind := "失敗"
    if (code = 0)
        kind := "完了"
    else if (code = 4)
        kind := "要確認"
    ; ★確かめられなかった設定があるときは、完了でも管理者へ知らせる★
    ;   「完了時の通知はオフ」の設定でも、これは見落とせないので送る。
    warnTag := OptWarnTag()
    if (code = 0 && warnTag != "")
        kind := "完了（" . warnTag . "）"
    if (code = 0 && warnTag = "" && !CB("NotifyAdminOnDone")) {
        Log("INFO", "完了しましたが、管理者への通知は設定で切ってあります")
        NotifyPatient(code, summary)               ; 顧客へのお知らせは別枠
        return
    }
    NotifyPatient(code, summary)                   ; 顧客へのお知らせ（完了のみ）
    who := Trim(G.wantSei . " " . G.wantMei)
    subject := "AutoMeta " . kind . "：" . (who = "" ? "（顧客なし）" : who)
    pre := ""
    if (code != 0 && G.schedCurrent != "" && PreNoticeSent(G.schedCurrent, G.schedDueTs))
        pre := "★この方には、事前のお知らせを送信しています。`n`n"
    body := pre . summary . "`n"
          . "──────────`n"
          . "この PC 　" . A_ComputerName . "`n"
          . "知らせた時刻　" . FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss") . "`n"
          . "※ AutoMeta が自動でお送りしています。"
    NotifyAdmin(subject, body, code != 0)
}

;==============================================================================
;  事前のお知らせ（3.10.37・F-9）
;==============================================================================
;  送信しない時間帯の外の予定 → 氏名の照合が通った直後に「開始の知らせ」
;  送信しない時間帯の中の予定 → 時間帯が始まる前に「予告」（開始のときは送らない）
;  ★完了しなければ、顧客へは自動で送らない★ セラピストへ必ず知らせて、確認待ちにも残す。
;  送った記録は state.ini の [PreNotice.予定のキー]。完了を確かめたら消す。

PreNoticeLeadList() => [30, 60, 120, 180]

PreNoticeEnabled() {
    global CFG
    if (!FeatureOn("prenotice"))
        return false
    return (Trim(IniGet(IniLoad(CFG), "Notify", "PreNotifyEnabled", "0")) = "1")
}

; 機能が使えるか。開発版では常にオン。本番では FEATURES の値（名前の書き間違いは _check.py が止める）
FeatureOn(name) {
    global APP_CHANNEL, FEATURES
    if (APP_CHANNEL != "")
        return true
    return FEATURES.Has(name) && FEATURES[name]
}

PreNoticeOn() => (NotifyNewOk() && PreNoticeEnabled())

PreNoticeLeadMin() {
    global CFG
    v := ToInt(IniGet(IniLoad(CFG), "Notify", "PreNotifyLeadMin", "30"), 30)
    for n in PreNoticeLeadList() {
        if (n = v)
            return v
    }
    return 30
}

ContactPreGet(key) => (FeatureOn("prenotice") && Trim(key) != ""
    && Trim(IniGet(ContactAll(), ContactSec(key), "PreNotify", "0")) = "1")

ContactPreSet(key, onOff) {
    IniSetMany(ContactPath(), ContactSec(key), Map("PreNotify", onOff ? 1 : 0))
}

; 次の「送信しない時間帯」の始まりと終わり。時間帯が無ければ false。
PreNoticeNight(&startTs, &endTs) {
    f := QuietStart(), t := QuietEnd()
    startTs := "", endTs := ""
    if (f = t)
        return false
    startTs := NextStampAt(f, "2100")
    endTs := SubStr(startTs, 1, 8) . t . "00"
    if (endTs <= startTs)
        endTs := FormatTime(DateAdd(startTs, 1, "Days"), "yyyyMMdd") . t . "00"
    return true
}

; 画面に出す、いまの状態のひとこと
PreNoticeWord() {
    if (!PreNoticeEnabled())
        return "事前のお知らせ：オフ"
    if (!PreNoticeNight(&sTs, &eTs))
        return "事前のお知らせ：オン（開始時に送信）"
    return "事前のお知らせ：オン（時間帯の中の予定の予告は " . FormatTime(DateAdd(sTs, -PreNoticeLeadMin(), "Minutes"), "H:mm") . " に送信）"
}

PreNoticeStartPath() => A_ScriptDir . "\notify_start.txt"
PreNoticeAdvancePath() => A_ScriptDir . "\notify_advance.txt"

PreNoticeDefault(kind) {
    if (kind = "start")
        return "{宛名}様`r`n`r`nただいまからセラピーを開始します。"
    return "{宛名}様`r`n`r`n{時間帯}、セラピーを行う予定です。"
}

PreNoticeTemplate(kind) {
    path := (kind = "start") ? PreNoticeStartPath() : PreNoticeAdvancePath()
    txt := ""
    if FileExist(path)
        try txt := FileRead(path, "UTF-8")
    txt := StrReplace(txt, Chr(0xFEFF), "")
    ; 3.10.39 までのデフォルトをそのまま保存している場合は、新しいデフォルトへ
    if (kind = "advance" && Trim(StrReplace(txt, "`r", ""), " `n") = "{宛名}様`n`n今夜、セラピーを行う予定です。")
        txt := ""
    return (Trim(txt) = "") ? PreNoticeDefault(kind) : txt
}

PreNoticeBadPlaceholder(txt) {
    work := StrReplace(StrReplace(StrReplace(txt, "{宛名}", ""), "{日付}", ""), "{時間帯}", "")
    if (RegExMatch(work, "\{([^}]*)\}", &mm))
        return mm[1]
    return ""
}

PreNoticeMailSubject() {
    shop := Trim(CS("ShopName"))
    return (shop = "") ? "セラピーのお知らせ" : (shop . "　セラピーのお知らせ")
}

; 送信の時点から見た、開始の時間帯の言い方。開始の時刻は約束しない。
PreNoticeWhenWord(ts) {
    if (ts = "")
        return "本日"
    hh := Integer(SubStr(ts, 9, 2))
    if (SubStr(ts, 1, 8) = FormatTime(A_Now, "yyyyMMdd"))
        return (hh >= 17) ? "今夜" : "本日"
    if (hh < 5)
        return "今夜"
    return (hh < 12) ? "明朝" : "明日"
}

; 1 人ぶんを送信待ちに積む。積んだ通数を返す。
PreNoticePush(key, sei, mei, kind, expires, whenTs := "") {
    who := ContactGet(key)
    if (!who["on"])
        return 0
    mail := ContactMailGet(key)
    toLine := (who["line"] != "" && LineReady())
    toMail := (mail != "" && MailReady())
    if (!toLine && !toMail) {
        Log("INFO", "事前のお知らせを送れません（届け先または送信の設定がありません）: " . key)
        return 0
    }
    body := NotifyFill(PreNoticeTemplate(kind), Map(
        "宛名", NotifyAddressee(sei, mei),
        "日付", FormatTime(A_Now, "M月d日(ddd)"),
        "時間帯", PreNoticeWhenWord(whenTs)))
    n := 0
    if (toLine) {
        pth := NotifyPush("LINE", "", body, who["line"], "", expires)
        NotifyLogAdd(NotifyBaseOf(pth), "queued", sei, mei, "LINE", "")
        n++
    }
    if (toMail) {
        pth := NotifyPush("MAIL", PreNoticeMailSubject(), body, mail, "", expires)
        NotifyLogAdd(NotifyBaseOf(pth), "queued", sei, mei, "MAIL", "")
        n++
    }
    NotifierEnsure()
    return n
}

PreNoticeSent(key, dueTs) {
    global STATEINI
    if (key = "" || dueTs = "")
        return false
    return (Trim(IniGet(IniLoad(STATEINI), "PreNotice." . key, "Due", "")) = dueTs)
}

PreNoticeRemember(key, dueTs, kind, endTs, sei, mei) {
    global STATEINI
    IniSetMany(STATEINI, "PreNotice." . key
        , Map("Due", dueTs, "Kind", kind, "End", endTs, "Sei", sei, "Mei", mei))
}

; ★開始の知らせ★ 氏名の照合が通った直後に呼ぶ。続きの実行でも 1 回の予定につき 1 通。
PreNoticeAtStart() {
    global G
    if (G.preDone)
        return
    G.preDone := true
    key := G.schedCurrent
    if (key = "" || G.manualJob || !PreNoticeOn() || !ContactPreGet(key))
        return
    if (PreNoticeSent(key, G.schedDueTs))
        return
    if (NotifySendAt() != "") {
        Log("INFO", "送信しない時間帯のため、開始の知らせは送りません: " . key)
        NotifyAdmin("AutoMeta 事前のお知らせなしで開始しました（" . Trim(G.gotSei . " " . G.gotMei) . "）"
            , "送信しない時間帯に入るまでに予告を送信できなかったため、事前のお知らせなしでセラピーを開始しました。`n"
            . "完了のお知らせは、送信しない時間帯のあとに届きます。`n"
            . "──────────`n"
            . "この PC 　" . A_ComputerName, false)
        return
    }
    if (PreNoticePush(key, G.gotSei, G.gotMei, "start", DateAdd(A_Now, 30, "Minutes")) > 0) {
        PreNoticeRemember(key, G.schedDueTs, "start"
            , DateAdd(A_Now, CI("ResumeMaxHours") + 1, "Hours"), G.gotSei, G.gotMei)
        Log("INFO", "開始の知らせを送信します: " . key)
    }
}

; 予告の見回り。予定の見回りから呼ぶ。送れる時刻は「時間帯の始まりの N 分前〜始まり」だけ。
;   始まりの 5 分前に、まだ始まっていない予定を見直す（前の方が長引いて時間帯に入る予定へ送るため）。
PreNoticeTick() {
    global G, STATEINI
    static lastTS := ""
    if (lastTS != "" && SecSince(lastTS) < 60)
        return
    lastTS := A_Now
    PreNoticeCheckUndone()
    static crowdTS := ""
    if (crowdTS = "" || SecSince(crowdTS) >= 600) {    ; 時間帯を問わず、10 分に 1 回
        crowdTS := A_Now
        SchedCrowdNote(SchedPlanAhead())
    }
    if (!PreNoticeNight(&sTs, &eTs))
        return
    if (A_Now < DateAdd(sTs, -PreNoticeLeadMin(), "Minutes"))
        return
    m := IniLoad(STATEINI)
    isFinal := (A_Now >= DateAdd(sTs, -5, "Minutes"))
    doneFirst := (Trim(IniGet(m, "PreNotice", "LastNight", "")) = sTs)
    if (doneFirst && (!isFinal || Trim(IniGet(m, "PreNotice", "LastFinal", "")) = sTs))
        return
    plan := SchedPlanAhead()
    targets := []
    if (PreNoticeOn()) {
        for w in plan {
            if (w["held"] || w["at"] >= eTs || !ContactPreGet(w["p"]["key"]))
                continue
            ; 時間帯より前の時刻指定は、最後の見直しまで開始の知らせを待つ
            if (isFinal || w["p"]["timemode"] = "queue" || w["due"] >= sTs)
                targets.Push(w)
        }
    }
    if (targets.Length > 0) {
        ; ★動かない見込みの夜には送らない★ 時間帯が始まるまでは、毎分確かめ直す
        why := ""
        exe := CS("ExeName")
        if (exe != "" && !FindPidByExe(exe))
            why := "対象ソフトが起動していません"
        else if (G.schedFailStreak > 0)
            why := "直前の予定が失敗しています"
        if (why != "") {
            if (Trim(IniGet(m, "PreNotice", "LastWarn", "")) != sTs) {
                IniSet(STATEINI, "PreNotice", "LastWarn", sTs)
                Log("WARN", "予告を保留しました: " . why)
                NotifyAdmin("AutoMeta 予告を保留しています"
                    , why . "。`n送信しない時間帯の予定 " . targets.Length . " 件の予告を保留しています。`n`n"
                    . "送信しない時間帯（" . FormatTime(sTs, "H:mm") . "〜）までに解消すれば送信します。"
                    . "解消しない場合、予告は送信しません。`n`n"
                    . "　この PC 　" . A_ComputerName)
            }
            return
        }
    }
    IniSet(STATEINI, "PreNotice", "LastNight", sTs)   ; 先に印を置く（二重に送らない）
    if (isFinal)
        IniSet(STATEINI, "PreNotice", "LastFinal", sTs)
    for w in targets {
        p := w["p"]
        if (PreNoticeSent(p["key"], w["due"]))
            continue
        if (PreNoticePush(p["key"], p["sei"], p["mei"], "advance", sTs, w["at"]) > 0) {
            PreNoticeRemember(p["key"], w["due"], "advance", eTs, p["sei"], p["mei"])
            Log("INFO", Format("予告を送信します: {1}（開始の見込み {2}）", p["key"], FormatTime(w["at"], "M/d H:mm")))
        }
    }
}

; ★運転が止まったまま、予告の時刻を迎えた★ 見張りから呼ぶ。運転が止まっていると、予告も予定も動かない。
;   手で止めたあとは自動で再開しないので、知らせないと翌朝まで誰も気づかない（2026-11-02 の夜）。
SchedStoppedNote() {
    global STATEINI
    if (!PreNoticeNight(&sTs, &eTs) || A_Now < DateAdd(sTs, -PreNoticeLeadMin(), "Minutes"))
        return
    if (Trim(IniGet(IniLoad(STATEINI), "PreNotice", "LastStopWarn", "")) = sTs)
        return
    names := "", n := 0
    for w in SchedPlanAhead() {
        if (w["held"] || w["at"] >= eTs)
            continue
        names .= "　" . Trim(w["p"]["sei"] . " " . w["p"]["mei"]) . "（" . FormatTime(w["at"], "M/d H:mm") . " の見込み）`n"
        n++
    }
    if (n = 0)
        return
    IniSet(STATEINI, "PreNotice", "LastStopWarn", sTs)  ; 先に印を置く（1 晩に 1 回）
    Log("WARN", Format("運転が停止したまま、予告の時刻になりました（予定 {1} 件）", n))
    NotifyAdmin("AutoMeta 運転が停止しています（予定 " . n . " 件）"
        , "スケジュール運転が停止しているため、予告は送信されず、次の予定も実行されません。`n"
        . "実行する場合は、運転を開始してください。`n`n"
        . names . "`n"
        . "この PC 　" . A_ComputerName)
}

; ★送ったのに完了していない方を見つける★ 見つけた件数を返す。
;   運転中の見回りと、メニューを開いたとき（電源断のあと）に呼ぶ。
PreNoticeCheckUndone() {
    global G, STATEINI
    found := 0
    m := IniLoad(STATEINI)
    for sec, kv in m {
        if (SubStr(sec, 1, 10) != "PreNotice.")
            continue
        due := Trim(IniGet(m, sec, "Due", ""))
        if (due = "")
            continue
        key := SubStr(sec, 11)
        last := HistLastRun(key)
        if (last != "" && last >= due && Trim(IniGet(m, "History." . key, "LastResult", "")) = "ok") {
            IniSetSection(STATEINI, sec, Map())    ; 完了したので、記録は要らない
            continue
        }
        if (A_Now < Trim(IniGet(m, sec, "End", "")))
            continue
        if (G.schedRunning && G.schedCurrent = key)
            continue                               ; いま実行中。結果を待つ
        IniSetSection(STATEINI, sec, Map())        ; 先に消す（二重に知らせない）
        PreNoticeAlert(Trim(IniGet(m, sec, "Kind", "")), Trim(IniGet(m, sec, "Sei", "")), Trim(IniGet(m, sec, "Mei", "")), due)
        found++
    }
    return found
}

PreNoticeAlert(kind, sei, mei, due) {
    what := (kind = "start") ? "開始の知らせ" : "予告"
    who := Trim(sei . " " . mei)
    PendingAddRaw(false, sei, mei, "★" . what . "を送信しましたが、セラピーは完了していません。顧客へご連絡ください")
    Log("WARN", Format("事前のお知らせのあと、完了していません（{1}／予定 {2}）", what, FormatTime(due, "M/d HH:mm")))
    NotifyAdmin("AutoMeta 要対応：" . what . "のあと未完了（" . who . "）"
        , who . " さんへ" . what . "を送信しましたが、セラピーは完了していません。`n"
        . "顧客へは、自動で送信していません。`n`n"
        . "　予定　" . FormatTime(due, "M/d H:mm") . "`n`n"
        . "ご連絡の文面の例：`n"
        . "　本日予定していたセラピーを行うことができませんでした。改めてご連絡いたします。`n`n"
        . "同じ日にやり直して完了すれば、完了のお知らせが届きます。`n"
        . "──────────`n"
        . "この PC 　" . A_ComputerName)
}

; メニューを開いたとき。運転が止まっていて判定できなかった分を、人に見せる。
PreNoticeMenuCheck() {
    global APP_NAME
    n := PreNoticeCheckUndone()
    if (n > 0)
        MsgBox("事前のお知らせを送信した顧客のうち、" . n . " 名のセラピーが完了していません。`n`n"
            . "顧客へは、自動で送信していません。ご連絡をお願いします。`n"
            . "顧客の名前は、運転パネルの確認待ちで確認できます。"
            , APP_NAME . " - 要対応", "Icon! 4096")
}

; 事前のお知らせの画面
PreNoticeDialog() {
    global APP_NAME, CFG
    done := false
    leads := PreNoticeLeadList()
    dlg := Gui("+AlwaysOnTop +ToolWindow", APP_NAME . " - 事前のお知らせ")
    dlg.MarginX := 16, dlg.MarginY := 12
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "w560", "セラピーの前に、顧客へお知らせします")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w560 cGray", "顧客ごとのオン／オフは「お知らせの届け先」の画面で設定します。LINE の送信数が増えます。")
    dlg.SetFont("s10", "Meiryo UI")
    cUse := dlg.Add("Checkbox", "w560" . (PreNoticeEnabled() ? " Checked" : ""), "事前のお知らせを使う")
    dlg.Add("Text", "xm w120", "予告を送る時刻")
    leadHead := PreNoticeNight(&sTs0, &eTs0) ? (FormatTime(sTs0, "H:mm") . " の ") : ""
    dLead := dlg.Add("DropDownList", "x+6 yp-4 w190"
        , [leadHead . "30 分前", leadHead . "1 時間前", leadHead . "2 時間前", leadHead . "3 時間前"])
    for idx, n in leads {
        if (n = PreNoticeLeadMin())
            dLead.Value := idx
    }
    tEcho := dlg.Add("Text", "x+10 yp+4 w228", "")
    dlg.SetFont("s9", "Meiryo UI")
    tRule := dlg.Add("Text", "xm w560 h90", "")
    dlg.SetFont("s10", "Meiryo UI")
    dlg.Add("Text", "xm w560", "開始の知らせ")
    eStart := dlg.Add("Edit", "xm w560 h80 Multi WantReturn", PreNoticeTemplate("start"))
    dlg.Add("Text", "xm w560", "予告")
    eAdv := dlg.Add("Edit", "xm w560 h80 Multi WantReturn", PreNoticeTemplate("advance"))
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "xm w560 cGray", "使用できる差し込みは {宛名} {日付} {時間帯}（今夜・明朝など）の 3 つです。症状・効果は記述しないでください。")
    dlg.SetFont("s10", "Meiryo UI")
    bInit := dlg.Add("Button", "xm w180 h30", "文面をデフォルトに戻す")
    bSave := dlg.Add("Button", "xm w270 h34 Default", "保存")
    bNo   := dlg.Add("Button", "x+20 yp w270 h34", "キャンセル")
    dLead.OnEvent("Change", (*) => PreEcho())
    bInit.OnEvent("Click", (*) => PreReset())
    bSave.OnEvent("Click", (*) => PreKeep())
    bNo.OnEvent("Click", (*) => PreLeave())
    dlg.OnEvent("Close", (*) => PreLeave())
    PreEcho()
    dlg.Show()
    while (!done)
        Sleep(60)
    try dlg.Destroy()
    return

    PreEcho() {
        if (!PreNoticeNight(&sTs, &eTs)) {
            tEcho.Value := "→ 送信しない時間帯がありません"
            tRule.Value := "すべての予定：開始時に「開始の知らせ」を送信"
            return
        }
        sendAt := FormatTime(DateAdd(sTs, -leads[dLead.Value], "Minutes"), "H:mm")
        fromAt := FormatTime(sTs, "H:mm")
        tEcho.Value := "→ " . sendAt . " に送信"
        tRule.Value := "送信しない時間帯（" . fromAt . "〜" . FormatTime(eTs, "H:mm") . "）の外に始まる予定：開始時に「開始の知らせ」を送信`n"
            . "送信しない時間帯の中に始まる予定：開始時刻にかかわらず " . sendAt . " に「予告」を送信`n"
            . "順番待ちの予定：" . sendAt . " の時点で待っていれば「予告」を送信`n"
            . "外の予定が " . FormatTime(DateAdd(sTs, -5, "Minutes"), "H:mm") . " の時点で始まっていない場合：「予告」を送信`n"
            . "順番が回らない見込みの予定：送信せず、セラピストへ通知"
    }
    PreReset() {
        if (MsgBox("文面をデフォルトに戻します。よろしいですか？`n`nいま編集中の内容は失われます。"
            , APP_NAME, "YesNo Icon? 4096") != "Yes")
            return
        eStart.Value := PreNoticeDefault("start")
        eAdv.Value := PreNoticeDefault("advance")
    }
    PreKeep() {
        global CFG
        for box in [eStart, eAdv] {
            bad := PreNoticeBadPlaceholder(box.Value)
            if (bad != "") {
                MsgBox("文面に、使えない差し込みがあります: {" . bad . "}`n`n"
                    . "使えるのは {宛名} {日付} {時間帯} だけです。", APP_NAME, "Icon! 4096")
                return
            }
        }
        IniSetMany(CFG, "Notify", Map("PreNotifyEnabled", cUse.Value ? 1 : 0, "PreNotifyLeadMin", leads[dLead.Value]))
        IniWriteBody(PreNoticeStartPath(), eStart.Value)
        IniWriteBody(PreNoticeAdvancePath(), eAdv.Value)
        Log("INFO", Format("事前のお知らせの設定を保存しました（使う={1} 予告={2} 分前）"
            , cUse.Value ? "はい" : "いいえ", leads[dLead.Value]))
        done := true
    }
    PreLeave() {
        done := true
    }
}

;==============================================================================
;  /notify  通知の設定（V3）
;==============================================================================
ModeNotify() {
    global CFG, APP_NAME, C
    if (NotifyGateBox())                           ; 一般は、通知の設定を開かない
        return
    dlg := Gui("+AlwaysOnTop", APP_NAME . " - 通知の設定" . VerTag())
    dlg.MarginX := 20, dlg.MarginY := 10
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "w640", "セラピーの終了を、顧客に通知します")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w640 cRed"
        , "LINE の ID を登録した顧客へ、予定から実行したときのみ通知します。")

    dlg.SetFont("s10", "Meiryo UI")
    cOn := dlg.Add("CheckBox", "w640 " . (CB("NotifyEnabled") ? "Checked" : "")
        , "通知を使う（オフの間は送信しません）")
    cDone := dlg.Add("CheckBox", "xm w640 " . (CB("NotifyAdminOnDone") ? "Checked" : "")
        , "完了時も管理者に通知する（メールで送信。メールが未設定なら LINE）")

    dlg.Add("Text", "xm w70", "宛名")
    nameList := ["なし", "姓のみ（例: 山田）", "姓と名（例: 山田 花子）"]
    dName := dlg.Add("DropDownList", "x+6 yp-4 w230", nameList)
    curStyle := Trim(CS("NameStyle"))
    dName.Value := (curStyle = "none") ? 1 : ((curStyle = "full") ? 3 : 2)
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "xm w640 cGray"
        , "宛名は、誤って別の方に届いたときの被害を小さくするため「姓のみ」が既定です。")

    ; ★欄は 2 つだけ★ 送信時刻を別に持つと、時間帯の外を指せてしまい、
    ;   「送らないはずの時刻に送る」矛盾した設定が作れる（2026-09-30 に整理）。
    dlg.SetFont("s10 Bold", "Meiryo UI")
    dlg.Add("Text", "xm w640", "送る時刻")
    dlg.SetFont("s10", "Meiryo UI")
    dlg.Add("Text", "xm w640"
        , "通知は、終了後すぐに送信します。下の時間帯に終了した分は保留します。")
    dlg.Add("Text", "xm w130", "送信しない時間帯")
    eQuiet := dlg.Add("Edit", "x+6 yp-4 w80", FmtHHMM(QuietStart()))
    dlg.Add("Text", "x+6 yp+4 w20", "〜")
    eQuietTo := dlg.Add("Edit", "x+6 yp-4 w80", FmtHHMM(QuietEnd()))
    tQuiet := dlg.Add("Text", "x+14 yp+4 w300", "")
    echoQuiet := (*) => tQuiet.Value := QuietWord(NormTime(eQuiet.Value), NormTime(eQuietTo.Value))
    eQuiet.OnEvent("Change", echoQuiet)
    eQuietTo.OnEvent("Change", echoQuiet)
    echoQuiet.Call()                               ; 変数に入れた関数は .Call() で呼ぶ

    dlg.SetFont("s10 Bold", "Meiryo UI")
    dlg.Add("Text", "xm w640", "文面")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w640 cGray"
        , "使用できる差し込みは {宛名} {日付} {開始} {終了} {回数} {項目数} の 6 つです。"
        . "敬称は {宛名} の後ろに記述します。`n"
        . "★お名前を直接書かないでください★（宛名の設定が無効になります）")
    dlg.SetFont("s10", "Meiryo UI")
    eTpl := dlg.Add("Edit", "xm w640 h150 Multi WantReturn", NotifyTemplate())

    ; 4 つで 640（152 × 4 ＋ 8 × 3 ＝ 632）。はみ出さない幅にそろえる
    bView := dlg.Add("Button", "xm w152 h34", "プレビュー")
    bMine := dlg.Add("Button", "x+8 yp w152 h34", "テスト送信")
    bInit := dlg.Add("Button", "x+8 yp w152 h34", "文面をデフォルトに戻す")
    bTry  := dlg.Add("Button", "x+8 yp w152 h34", "異常通知をテスト送信")

    ; ★共通を直しても、個別の文面を持つ顧客には届かない★
    ;   気づけないと困るので、いま何名そうなっているかを出す（3.9）。
    dlg.SetFont("s9", "Meiryo UI")
    tOwn := dlg.Add("Text", "xm w470 cGray", NotifyBodyOwnersWord())
    bOwn := dlg.Add("Button", "x+8 yp-6 w162 h26", "顧客ごとの文面")
    tPre := "", bPre := ""
    if (FeatureOn("prenotice")) {
        tPre := dlg.Add("Text", "xm w470 cGray", PreNoticeWord())
        bPre := dlg.Add("Button", "x+8 yp-6 w162 h26", "事前のお知らせ")
    }
    dlg.SetFont("s10", "Meiryo UI")

    bSave := dlg.Add("Button", "xm w310 h38 Default", "保存")
    bNo   := dlg.Add("Button", "x+20 yp w310 h38", "キャンセル")

    bView.OnEvent("Click", (*) => ShowSample())
    bMine.OnEvent("Click", (*) => SendSample())
    bTry.OnEvent("Click",  (*) => TryAlert())
    bInit.OnEvent("Click", (*) => ResetTpl())
    bOwn.OnEvent("Click",  (*) => ShowOwners())
    if (bPre != "")
        bPre.OnEvent("Click",  (*) => ShowPreNotice())
    bSave.OnEvent("Click", (*) => SaveIt())
    bNo.OnEvent("Click",   (*) => ReopenAndExit(0))
    dlg.OnEvent("Close",   (*) => ReopenAndExit(0))
    if (!ScrollAttach(dlg))
        dlg.Show()
    return

    StyleNow() {
        if (dName.Value = 1)
            return "none"
        if (dName.Value = 3)
            return "full"
        return "family"
    }

    ShowSample() {
        global C
        ; ★画面にある文面で組み立てる★ 保存しなくても確かめられるように
        keepStyle := CS("NameStyle")
        C["NameStyle"] := StyleNow()
        body := NotifyFill(eTpl.Value, Map(
            "宛名",   NotifyAddressee("見本", "花子"),
            "日付",   FormatTime(A_Now, "M月d日"),
            "開始",   "1:05",
            "終了",   "1:22",
            "回数",   "3",
            "項目数", "42"))
        C["NameStyle"] := keepStyle
        MsgBox("この形でお送りします。`n`n"
            . "────────────────`n"
            . body . "`n"
            . "────────────────"
            , APP_NAME . " - プレビュー", "Iconi 4096")
    }

    ; ★自分の LINE へ 1 通送る★
    ;   文面を直したとき、LINE でどう見えるかは画面の文字だけでは分からない
    ;   （改行の入り方、長い行の折り返し、絵文字の大きさ）。
    ;   顧客には送らず、設定してあるご自身の宛先へ送る（2026-10-03 指摘）。
    SendSample() {
        global C
        if (!LineReady()) {
            MsgBox("LINE の設定が済んでいません。`n`n"
                . "設定 →「LINE」で、トークンとユーザー ID を登録してください。"
                , APP_NAME, "Icon! 4096")
            return
        }
        keepStyle := CS("NameStyle")
        C["NameStyle"] := StyleNow()
        body := NotifyFill(eTpl.Value, Map(
            "宛名",   NotifyAddressee("見本", "花子"),
            "日付",   FormatTime(A_Now, "M月d日"),
            "開始",   "1:05",
            "終了",   "1:22",
            "回数",   "3",
            "項目数", "42"))
        C["NameStyle"] := keepStyle
        err := ""
        if (LineSend(LineAdminId(), body, &err)) {
            MsgBox("ご自身の LINE へお送りしました。`n`n"
                . "　宛先　" . LineMask(LineAdminId()) . "`n`n"
                . "実際に顧客へ届くのと同じ文面・同じ見え方です。`n"
                . "差し込みの部分は見本の値（見本 花子／3 回／42 か所）に置き換えています。"
                , APP_NAME . " - テスト送信", "Iconi 4096")
            return
        }
        MsgBox("送れませんでした。`n`n"
            . "　理由　" . err . "`n`n"
            . "設定 →「LINE」で「テスト送信」が通るか確かめてください。"
            , APP_NAME . " - テスト送信", "Icon! 4096")
    }

    ; ★本物の経路で試す★ 失敗を待たずに、連動を確かめられるように
    TryAlert() {
        global C
        if (NotifyGateBox())
            return
        if (!cOn.Value) {
            MsgBox("「通知を使う」がオフです。`n`n"
                . "チェックを入れてから、もう一度押してください。"
                , APP_NAME, "Icon! 4096")
            return
        }
        if (!MailReady() && !LineReady()) {
            MsgBox("メールも LINE も、まだ設定されていません。`n`n"
                . "設定 →「メール」か「LINE」を先に済ませてください。"
                , APP_NAME, "Icon! 4096")
            return
        }
        keep := CS("NotifyEnabled")
        C["NotifyEnabled"] := "1"              ; 保存前でも試せるように
        ; ★お試しは、その場で送って結果を見せる★
        ;   送信係にまかせると、渡した直後は「未送信」に見えて
        ;   送れたのに「送れませんでした」と出てしまう（2026-09-30）。
        ok := NotifyTestNow("AutoMeta 異常の知らせ（お試し）"
            , "これは、異常のときにお送りする知らせの見本です。`n`n"
            . "　例）セラピー 1 回目が 00:40 で終わりました（想定より短い）`n"
            . "　　　セラピーが正しく行われていない可能性があるため停止しました。`n`n"
            . "　この PC 　" . A_ComputerName . "`n"
            . "　送信時刻　" . FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss") . "`n`n"
            . "実際の運転では、失敗・要確認・対象ソフトの停止のときに届きます。`n"
            . "※ AutoMeta が自動でお送りしています。")
        C["NotifyEnabled"] := keep
        if (ok) {
            dest := MailReady() ? ("メール " . MailAdminAddr()) : ""
            if (LineReady())
                dest .= (dest = "" ? "" : " ／ ") . "LINE " . LineMask(LineAdminId())
            MsgBox("お送りしました。`n`n"
                . "　宛先　" . dest . "`n`n"
                . "これと同じ経路で、運転中の異常もお知らせします。"
                , APP_NAME . " - 送信の結果", "Iconi 4096")
            return
        }
        ; ★お試しは貯めない★ ここで「貯めました」と言うと嘘になる（2026-09-30）
        MsgBox("送れませんでした。`n`n"
            . "　このお試しは貯めません（もう一度押してください）。`n"
            . "　運転中の知らせは貯めて、つながったときに送り直します。`n`n"
            . "理由はログの最後の行に出ています（その他 →「ログを見る」）。"
            , APP_NAME . " - 送信の結果", "Icon! 4096")
    }

    ShowPreNotice() {
        PreNoticeDialog()
        tPre.Value := PreNoticeWord()              ; 閉じたら表示を入れ直す
    }

    ShowOwners() {
        NotifyBodyListDialog()
        tOwn.Value := NotifyBodyOwnersWord()       ; 閉じたら表示を入れ直す
    }

    ResetTpl() {
        if (MsgBox("文面をデフォルトに戻します。よろしいですか？`n`n"
            . "いま編集中の内容は失われます。"
            , APP_NAME, "YesNo Icon? 4096") = "Yes")
            eTpl.Value := NotifyTemplateDefault()
    }

    SaveIt() {
        global CFG, C
        ; ★使えない差し込みが残っていないか調べる★ 打ち間違いをそのまま送らない
        bad := NotifyBadPlaceholder(eTpl.Value)
        if (bad != "") {
            MsgBox("文面に、使えない差し込みがあります: {" . bad . "}`n`n"
                . "使えるのは {宛名} {日付} {開始} {終了} {回数} {項目数} だけです。"
                , APP_NAME, "Icon! 4096")
            return
        }
        quiet := NormTime(eQuiet.Value)
        if (quiet = "") {
            MsgBox("送信しない時間帯のはじまりを読み取れませんでした（いまの入力: 「"
                . Trim(eQuiet.Value) . "」）。`n`n"
                . "こう入れてください`n"
                . "　21:00 ／ 2100 ／ 21", APP_NAME, "Icon! 4096")
            return
        }
        eQuiet.Value := FmtHHMM(quiet)             ; 読み取った形に整えて見せる
        quietTo := NormTime(eQuietTo.Value)
        if (quietTo = "") {
            MsgBox("送信しない時間帯の終わりを読み取れませんでした（いまの入力: 「"
                . Trim(eQuietTo.Value) . "」）。`n`n"
                . "こう入れてください`n"
                . "　08:00 ／ 0800 ／ 8", APP_NAME, "Icon! 4096")
            return
        }
        eQuietTo.Value := FmtHHMM(quietTo)
        IniSetMany(CFG, "Notify", Map(
            "NotifyEnabled",     cOn.Value ? 1 : 0,
            "NotifyAdminOnDone", cDone.Value ? 1 : 0,
            "NameStyle",         StyleNow(),
            "QuietFrom",         quiet,
            "QuietTo",           quietTo,
            "MorningTime",       quietTo))         ; 古い版と行き違わないよう揃えておく
        C["QuietFrom"]         := quiet
        C["QuietTo"]           := quietTo
        C["MorningTime"]       := quietTo
        C["NotifyEnabled"]     := cOn.Value ? "1" : "0"
        C["NotifyAdminOnDone"] := cDone.Value ? "1" : "0"
        C["NameStyle"]         := StyleNow()
        NotifyTemplateSave(eTpl.Value)
        quietWord := (quiet = quietTo) ? "なし" : (FmtHHMM(quiet) . "〜" . FmtHHMM(quietTo))
        Log("INFO", Format("通知の設定を保存しました"
            . "（使う={1} 完了も知らせる={2} 宛名={3} 送信しない時間帯={4}）"
            , cOn.Value ? "はい" : "いいえ", cDone.Value ? "はい" : "いいえ"
            , StyleNow(), quietWord))
        msg := "※ 通知は「使わない」のままです。"
        if (cOn.Value)
            msg := "※ 通知は「使う」になっています。"
        MsgBox("保存しました。`n`n" . msg, APP_NAME, "Iconi 4096")
        ScrollDetach(dlg.Hwnd)
        try dlg.Destroy()
        BackToSettings()
    }
}


;==============================================================================
;  縦にスクロールできる窓
;==============================================================================
; ★項目が増えても下が切れないようにする★
;   AHK には「中身をスクロールする箱」が無い。窓そのものに縦バーを付け、
;   動かされたぶんだけ中の部品を一緒にずらす。
;   2026-09-26、設定の項目が増えて下が見えなくなったため追加。
;
;   使い方: 部品を全部置いたあとに ScrollAttach(dlg) を呼び、
;           そのあと dlg.Show(...) する。
;   ★収まるときは何もしない★ 余計なバーを出さない。
ScrollAttach(sgui, bottomPad := 24) {
    global G
    ; いま必要な高さ（いちばん下の部品の位置）を測る
    need := 0
    for ctl in sgui {
        ; ★部品自身に位置を聞く★ ControlGetPos は窓の座標系が混ざるので使わない
        cy := 0, ch := 0
        try ctl.GetPos(, &cy, , &ch)
        if (!IsSet(cy) || !IsSet(ch))
            continue
        if (cy + ch > need)
            need := cy + ch
    }
    need += bottomPad
    if (need <= 0)
        return false
    ; 画面の使える高さ（タスクバーを除く）
    wl := 0, wt := 0, wr := A_ScreenWidth, wb := A_ScreenHeight
    try MonitorGetWorkArea(, &wl, &wt, &wr, &wb)
    if (!IsSet(wt) || !IsSet(wb))
        wt := 0, wb := A_ScreenHeight
    ; ★部品の位置は「拡大率をかけた単位」、作業領域は「実画素」★
    ;   混ぜると判定を誤る（2026-09-22 にパネルの位置で踏んだのと同じ話）。
    dpi := A_ScreenDPI / 96
    view := Floor(((wb - wt) - 90) / dpi)      ; 枠とタイトル分を引く
    ; ★はみ出したら、どの画面かを WARN で残す★
    ;   2026-10-06、ログに「中身 867／表示できる高さ 752」と出ていたが
    ;   画面の名前が無く、どこが溢れているのか突き止められなかった。
    ;   配る前の _check.py は目安でしかない。実機の実測がいちばん確かなので、
    ;   ここを本当の関門にする。
    title := ""
    try title := sgui.Title
    if (need > view) {
        Log("WARN", Format("画面がはみ出しています: {1}（中身 {2} / 表示できる高さ {3}"
            . " / 画面 {4}px・拡大 {5}%）→ スクロールバーを出します"
            , title, need, view, wb - wt, Round(dpi * 100)))
    } else {
        Log("DEBUG", Format("スクロール判定: {1}（中身 {2} / 表示できる高さ {3}）→ そのまま"
            , title, need, view))
    }
    if (need <= view)
        return false                               ; 収まるならバーは出さない
    st := Map("pos", 0, "need", need, "view", view)
    ScrollState(sgui.Hwnd, st)
    ; ★先に窓を出してから、枠にバーを付ける★
    ;   作る前に付けても、枠が描き直されずバーが出ないことがある。
    sgui.Show("h" view)
    sgui.Opt("+0x200000")                          ; WS_VSCROLL
    ; 枠が変わったことを窓に知らせる（これが無いとバーが現れない）
    DllCall("SetWindowPos", "Ptr", sgui.Hwnd, "Ptr", 0
        , "Int", 0, "Int", 0, "Int", 0, "Int", 0
        , "UInt", 0x0027)                          ; NOSIZE|NOMOVE|NOZORDER|FRAMECHANGED
    ScrollSetInfo(sgui.Hwnd, 0, need, view)
    OnMessage(0x0115, ScrollOnBar)                 ; WM_VSCROLL
    OnMessage(0x020A, ScrollOnWheel)               ; WM_MOUSEWHEEL
    return true
}

; 窓を閉じるときは、覚えている状態も捨てる（別の窓が同じ番号を使うため）
ScrollDetach(hwnd) {
    ScrollState(hwnd, "forget")
}

; 窓ごとのスクロール状態を持つ（複数の窓でも混ざらないように）
ScrollState(hwnd, setTo := 0) {
    static box := Map()
    if (setTo = "forget") {                        ; 閉じたので忘れる
        if (box.Has(hwnd))
            box.Delete(hwnd)
        return ""
    }
    if (IsObject(setTo)) {                         ; 入れ物を渡されたら覚える
        box[hwnd] := setTo
        return setTo
    }
    return box.Has(hwnd) ? box[hwnd] : ""
}

ScrollSetInfo(hwnd, pos, need, view) {
    si := Buffer(28, 0)
    NumPut("UInt", 28, si, 0)
    NumPut("UInt", 0x7, si, 4)                     ; RANGE | PAGE | POS
    NumPut("Int", 0, si, 8)
    NumPut("Int", need, si, 12)
    NumPut("UInt", view, si, 16)
    NumPut("Int", pos, si, 20)
    DllCall("SetScrollInfo", "Ptr", hwnd, "Int", 1, "Ptr", si, "Int", true)
}

; いまつまみがどこにあるか（つまみを引きずったとき用）
ScrollTrackPos(hwnd) {
    si := Buffer(28, 0)
    NumPut("UInt", 28, si, 0)
    NumPut("UInt", 0x10, si, 4)                    ; SIF_TRACKPOS
    DllCall("GetScrollInfo", "Ptr", hwnd, "Int", 1, "Ptr", si)
    return NumGet(si, 24, "Int")
}

ScrollMoveTo(hwnd, want) {
    st := ScrollState(hwnd)
    if (!IsObject(st))
        return
    maxPos := st["need"] - st["view"]
    if (maxPos < 0)
        maxPos := 0
    if (want < 0)
        want := 0
    if (want > maxPos)
        want := maxPos
    delta := st["pos"] - want
    if (delta = 0)
        return
    st["pos"] := want
    DllCall("ScrollWindow", "Ptr", hwnd, "Int", 0, "Int", delta, "Ptr", 0, "Ptr", 0)
    ScrollSetInfo(hwnd, want, st["need"], st["view"])
}

ScrollOnBar(wParam, lParam, msg, hwnd) {
    st := ScrollState(hwnd)
    if (!IsObject(st))
        return
    code := wParam & 0xFFFF
    want := st["pos"]
    if (code = 0)                                  ; 上の矢印
        want -= 40
    else if (code = 1)                             ; 下の矢印
        want += 40
    else if (code = 2)                             ; 1 画面上へ
        want -= st["view"] - 40
    else if (code = 3)                             ; 1 画面下へ
        want += st["view"] - 40
    else if (code = 5 || code = 4)                 ; つまみを動かした
        want := ScrollTrackPos(hwnd)
    else
        return
    ScrollMoveTo(hwnd, want)
    return 0
}

ScrollOnWheel(wParam, lParam, msg, hwnd) {
    st := ScrollState(hwnd)
    if (!IsObject(st)) {
        ; ★ボタンの上で回したときは、その親の窓を探す★
        root := DllCall("GetAncestor", "Ptr", hwnd, "UInt", 2, "Ptr")
        st := ScrollState(root)
        if (!IsObject(st))
            return
        hwnd := root
    }
    notch := (wParam >> 16) & 0xFFFF
    if (notch > 0x7FFF)
        notch -= 0x10000
    ScrollMoveTo(hwnd, st["pos"] - (notch // 120) * 90)
    return 0
}

;==============================================================================
;  /secretcheck  秘密の保管を確認する（診断）
;==============================================================================
; ★この PC で、秘密を安全にしまえるか確かめる★
;   会社の設定によっては暗号化が使えないことがある。
;   メールや LINE の設定を作る前に、ここで分かるようにしておく。
; ★表示するだけ★ ほかの画面からも呼ぶので、ここでは画面を移動しない
SecretSelfTest() {
    global APP_NAME
    ; ★何をしたのかを、そのまま見せる★
    ;   「安全にしまえます」だけでは、何が起きたのか分からない（2026-09-26 指摘）。
    word   := "あいうえお-" . A_TickCount
    okSave := SecretSave("selftest", word)
    back   := SecretLoad("selftest")
    okRead := (back = word)
    SecretSave("selftest", "")                 ; 後片付け
    okGone := !SecretHas("selftest")
    ; 入れ子の関数を増やさず、素直に組み立てる
    yes := "OK", no := "★NG★"
    steps := "　① 暗号化して保存　　　… " . (okSave ? yes : no) . "`n"
           . "　② 読み戻して照合　　　… " . (okRead ? yes : no) . "`n"
           . "　③ 試したファイルを削除… " . (okGone ? yes : no)
    if (okSave && okRead) {
        MsgBox("保管の仕組みを確認しました。`n`n"
            . steps . "`n`n"
            . "この PC では、メールのパスワードや LINE の鍵を`n"
            . "安全に保管できます。`n`n"
            . "　保管場所　" . SecretDir() . "`n"
            . "　・Google ドライブには同期されません`n"
            . "　・ほかの PC にコピーしても復号できません`n`n"
            . "※ 動作の確認のみです。設定は保存していません。`n"
            . "　 このまま設定を続けてください。"
            , APP_NAME . " - 確認の結果", "Iconi 4096")
        return
    }
    MsgBox("保管の仕組みを確認しました。`n`n"
        . steps . "`n`n"
        . "この PC では、暗号化して保管する仕組みが使えません。`n"
        . "このままではメールや LINE の設定を保存できません。`n`n"
        . "　確認した場所　" . SecretDir() . "`n`n"
        . "詳しい内容をログに記録しました。ご連絡ください。"
        , APP_NAME . " - 確認の結果", "Iconx 4096")
}

; 設定の「調整・診断」から開いたとき。確認したら設定へ戻る
ModeSecretCheck() {
    SecretSelfTest()
    BackToSettings()
}


;==============================================================================
;  メール送信（V3・その PC の Gmail から直接送る）
;==============================================================================
; ★こちら（開発側）のサーバーを経由しない★
;   差出人が本人のアドレスになり、ほかの人のメール履歴にも残らない。
;   アプリパスワードは DPAPI で暗号化し、その PC の中だけに置く。
;   （2026-09-26 の設計。詳しくは V3_実装計画.md）
;
;   Windows 標準の CDO を使う。追加の部品は要らない。
MailFromAddr() => Trim(CS("MailFrom"))

; 異常の知らせ先。空なら差出人と同じところへ送る
MailAdminAddr() {
    addr := Trim(CS("MailAdmin"))
    return (addr = "") ? MailFromAddr() : addr
}

; アドレスを伏せてログに出す（hir***@example.com）
MailMask(addr) {
    at := InStr(addr, "@")
    if (at < 2)
        return "***"
    head := SubStr(addr, 1, Min(3, at - 1))
    return head . "***" . SubStr(addr, at)
}

MailReady() {
    return (MailFromAddr() != "" && SecretHas("mail_pass"))
}

; 1 通送る。送れたら true。err に理由が入る。
MailSend(sendTo, subject, body, &err) {
    err := ""
    from := MailFromAddr()
    pass := SecretLoad("mail_pass")
    if (from = "") {
        err := "差出人のアドレスが設定されていません"
        return false
    }
    if (pass = "") {
        err := "アプリパスワードが保存されていません"
        return false
    }
    if (Trim(sendTo) = "") {
        err := "宛先がありません"
        return false
    }
    ; ★465 が塞がれている環境がある★ だめなら 587 でもう一度試す
    for tryPort in [465, 587] {
        if (MailTry(from, pass, sendTo, subject, body, tryPort, &err)) {
            Log("INFO", Format("メールを送りました（宛先 {1} ／ポート {2}）"
                , MailMask(sendTo), tryPort))
            return true
        }
        Log("DEBUG", Format("メール送信に失敗（ポート {1}）: {2}", tryPort, err))
    }
    ; ★ログにも日本語の理由を残す★
    ;   画面には出るのに、ログは英数字だけだった（2026-09-26 のログ確認）。
    Log("WARN", Format("メールを送れませんでした（宛先 {1}）：{2}"
        , MailMask(sendTo), StrReplace(MailErrorHint(err), "`n", " ")))
    Log("DEBUG", "メール送信の生の理由: " . err)
    return false
}

MailTry(from, pass, sendTo, subject, body, usePort, &err) {
    err := ""
    try {
        pre := "http://schemas.microsoft.com/cdo/configuration/"
        msg := ComObject("CDO.Message")
        fld := msg.Configuration.Fields
        fld.Item[pre . "sendusing"]             := 2      ; ネットワークで送る
        fld.Item[pre . "smtpserver"]            := "smtp.gmail.com"
        fld.Item[pre . "smtpserverport"]        := usePort
        fld.Item[pre . "smtpauthenticate"]      := 1
        fld.Item[pre . "sendusername"]          := from
        fld.Item[pre . "sendpassword"]          := pass
        fld.Item[pre . "smtpusessl"]            := true
        fld.Item[pre . "smtpconnectiontimeout"] := 30
        fld.Update()
        msg.BodyPart.Charset := "utf-8"                   ; 日本語が化けないように
        msg.From    := from
        msg.To      := sendTo
        msg.Subject := subject
        msg.TextBody := body
        msg.Send()
    } catch as e {
        err := e.Message
        return false
    }
    return true
}


;==============================================================================
;  LINE 送信（V3・その PC から、そのセラピストの公式アカウントで送る）
;==============================================================================
; ★トークンはこの PC の中だけ★ DPAPI で暗号化して保管する。
;   利用者ごとに自分の公式アカウントを持つので、顧客から見た送り主は
;   「そのセラピスト」になる（2026-09-26 の設計）。

LineAdminId() => Trim(CS("LineAdminId"))
LineReady() => (LineAdminId() != "" && SecretHas("line_token"))

; ID を伏せてログに出す（U1a2***）
LineMask(id) {
    if (StrLen(id) < 6)
        return "***"
    return SubStr(id, 1, 5) . "***"
}

; ★日本語は \uXXXX に直して送る★
;   送り先の受け取り方に左右されず、文字化けを起こさない。
JsonEsc(t) {
    out := ""
    Loop Parse, t
    {
        ch := A_LoopField
        code := Ord(ch)
        if (ch = Chr(34))
            out .= "\" . Chr(34)
        else if (ch = "\")
            out .= "\\"
        else if (code = 10)
            out .= "\n"
        else if (code = 13)
            out .= "\r"
        else if (code = 9)
            out .= "\t"
        else if (code > 0xFFFF) {
            vv := code - 0x10000
            out .= Format("\u{:04X}\u{:04X}", 0xD800 + (vv >> 10), 0xDC00 + (vv & 0x3FF))
        }
        else if (code < 32 || code > 126)
            out .= Format("\u{:04X}", code)
        else
            out .= ch
    }
    return out
}

; LINE の返事を、原因のことばに言い換える
LineErrorHint(status, body) {
    if (status = 401)
        return "トークンが違うか、期限が切れています。発行し直してください。"
    if (status = 403)
        return "このアカウントからは送れません。Messaging API が有効か確かめてください。"
    if (status = 400 && InStr(body, "not") && InStr(body, "friend"))
        return "その公式アカウントを、まだ友だち追加していないようです。`n"
             . "ご自分のスマホで友だち追加してから、もう一度お試しください。"
    if (status = 400)
        return "宛先のユーザー ID が違うようです。`n"
             . "LINE Developers の「あなたのユーザー ID」を貼り直してください。"
    if (status = 429)
        return "今月の送信数の上限に達しました。LINE のプランをご確認ください。"
    if (status = 0)
        return "インターネットにつながりませんでした。"
    return "LINE から " . status . " が返りました。"
}

; 1 通送る。送れたら true。
LineSend(sendTo, text, &err) {
    global STATEINI
    err := ""
    token := SecretLoad("line_token")
    if (token = "") {
        err := "LINE のトークンが保存されていません"
        return false
    }
    if (Trim(sendTo) = "") {
        err := "送り先のユーザー ID がありません"
        return false
    }
    body := '{"to":"' . JsonEsc(sendTo) . '","messages":[{"type":"text","text":"'
          . JsonEsc(text) . '"}]}'
    status := 0, reply := ""
    try {
        http := ComObject("WinHttp.WinHttpRequest.5.1")
        http.SetTimeouts(5000, 10000, 10000, 20000)
        http.Open("POST", "https://api.line.me/v2/bot/message/push", false)
        http.SetRequestHeader("Content-Type", "application/json; charset=utf-8")
        http.SetRequestHeader("Authorization", "Bearer " . token)
        http.Send(body)
        status := http.Status
        reply  := HttpTextUtf8(http)
    } catch as e {
        err := "つながりませんでした（" . e.Message . "）"
        Log("WARN", "LINE を送れませんでした：" . err)
        return false
    }
    if (status = 200) {
        if (FileExist(STATEINI) && Trim(IniGet(IniLoad(STATEINI), "Notify", "LineQuotaAt", "")) != "")
            IniSet(STATEINI, "Notify", "LineQuotaAt", "")
        Log("INFO", "LINE を送りました（宛先 " . LineMask(sendTo) . "）")
        return true
    }
    if (status = 429)
        IniSet(STATEINI, "Notify", "LineQuotaAt", FormatTime(A_Now, "yyyyMMddHHmmss"))
    err := LineErrorHint(status, reply)
    Log("WARN", "LINE を送れませんでした：" . StrReplace(err, "`n", " "))
    Log("DEBUG", "LINE の生の返事 " . status . "：" . SubStr(reply, 1, 200))
    return false
}

;==============================================================================
;  /mail  メールの設定（V3）
;==============================================================================
; ★つまずくのは「Google のどこを押すか」★
;   仕組みではなく手順で迷う（2026-09-26 指摘）。
;   ページを開くボタンを置き、貼り付けの空白も自動で取り除く。

; よくある失敗を、原因のことばに言い換える
MailErrorHint(err) {
    low := StrLower(err)
    ; ★メール部品（CDO）の番号を、言葉にする★（2026-10-13）
    ;   0x80040213＝サーバーにつながらなかった／0x80040212＝つながったあとで切れた。
    ;   Windows の文言が「タブレット PC 手書き入力のエラー コード」と的外れに出るので、番号で見分ける。
    ;   原因は、ほとんどがネットワークの一時的な不通。送信待ちに戻り、あとで自動で送り直す。
    if (InStr(low, "80040213") || InStr(low, "80040212"))
        return "Gmail のサーバーにつながりませんでした（ネットワークの一時的な不通など）。`n"
             . "　・送信待ちに戻しました。つながり次第、自動で送り直します`n"
             . "　・何度も続くときは、インターネットの接続を確かめてください"
    if (InStr(low, "5.7.8") || InStr(low, "535") || InStr(low, "authenticat")
        || InStr(low, "username and password"))
        return "アプリパスワードが違うようです。`n"
             . "　・ふだんログインに使うパスワードでは送れません`n"
             . "　・16 桁を発行し直して、貼り直してください"
    if (InStr(low, "connect") || InStr(low, "timeout") || InStr(low, "transport"))
        return "Google のサーバーにつながりませんでした。`n"
             . "　・インターネットにつながっているか`n"
             . "　・社内のネットワークで送信がふさがれていないか"
    if (InStr(low, "5.7.0") || InStr(low, "not accepted"))
        return "Google に断られました。2 段階認証が有効か確かめてください。"
    return "原因を特定できませんでした。ログに記録しています。"
}

ModeMail() {
    global CFG, APP_NAME, C
    dlg := Gui("+AlwaysOnTop", APP_NAME . " - メールの設定" . VerTag())
    dlg.MarginX := 20, dlg.MarginY := 14
    dlg.SetFont("s12 Bold", "Meiryo UI")
    dlg.Add("Text", "w660", "お使いの Gmail から、直接お送りします")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w660 cGray"
        , "差出人はご自身のアドレスになります。こちらのサーバーは通りません。`n"
        . "パスワードは暗号化して、この PC の中だけに保存します。")

    ; --- はじめての方への案内 ---
    dlg.Add("Text", "w660 h1 0x10")
    dlg.SetFont("s10 Bold", "Meiryo UI")
    dlg.Add("Text", "w430 cNavy", "はじめての方へ　3 つの手順で準備できます")
    bHelp := dlg.Add("Button", "x+10 yp-4 w200 h30", "詳しい手順を表示")
    dlg.SetFont("s10", "Meiryo UI")
    dlg.Add("Text", "xm w400", "① Google の 2 段階認証をオンにする")
    b2fa := dlg.Add("Button", "x+10 yp-4 w230 h30", "設定ページを開く")
    dlg.Add("Text", "xm w400", "② アプリパスワード（16 桁）を発行する")
    bApp := dlg.Add("Button", "x+10 yp-4 w230 h30", "発行ページを開く")
    dlg.Add("Text", "xm w660", "③ 下の欄に貼り付けて「テスト送信」を押す")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "xm+12 w648 cGray"
        , "　※ ①をしていないと、②のページは出てきません。`n"
        . "　※ アプリパスワードは、ふだんログインに使うパスワードとは別物です。")

    ; --- 入力 ---
    dlg.Add("Text", "xm w660 h1 0x10")
    dlg.SetFont("s10", "Meiryo UI")
    dlg.Add("Text", "xm w210", "差出人（Gmail のアドレス）")
    eFrom := dlg.Add("Edit", "x+10 yp-4 w420", MailFromAddr())

    dlg.Add("Text", "xm w210", "アプリパスワード")
    ePass := dlg.Add("Edit", "x+10 yp-4 w420 Password")
    dlg.SetFont("s9", "Meiryo UI")
    havePass := SecretHas("mail_pass")
    hint := "　まだ保存されていません。②で発行した 16 桁を貼ってください"
    if (havePass)
        hint := "　保存済みです。変えるときだけ入力してください（空のままなら今のまま）"
    dlg.Add("Text", "xm+12 w648 " . (havePass ? "cGreen" : "cGray"), hint)
    dlg.Add("Text", "xm+12 w648 cGray"
        , "　4 桁ずつ空いた形（例 abcd efgh ijkl mnop）で貼り付けても構いません。"
        . "空白は自動で取り除きます。")

    dlg.SetFont("s10", "Meiryo UI")
    dlg.Add("Text", "xm w210", "異常の知らせ先")
    eAdmin := dlg.Add("Edit", "x+10 yp-4 w420", Trim(CS("MailAdmin")))
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "xm+12 w648 cGray"
        , "　空のままなら、差出人と同じアドレスへお送りします")

    dlg.Add("Text", "xm w660 h1 0x10")
    dlg.SetFont("s10", "Meiryo UI")
    bTest := dlg.Add("Button", "xm w320 h36", "テスト送信（自分宛に 1 通）")
    bChk  := dlg.Add("Button", "x+20 yp w320 h36", "保管の仕組みを確認")
    bSave := dlg.Add("Button", "xm w320 h40 Default", "保存")
    bNo   := dlg.Add("Button", "x+20 yp w320 h40", "キャンセル")

    bHelp.OnEvent("Click",  (*) => ShowGuide("メールの設定 — 詳しい手順", MailGuideText()))
    b2fa.OnEvent("Click",  (*) => OpenPage("https://myaccount.google.com/signinoptions/twosv"))
    bApp.OnEvent("Click",  (*) => OpenPage("https://myaccount.google.com/apppasswords"))
    bTest.OnEvent("Click", (*) => DoTest())
    bChk.OnEvent("Click",  (*) => SecretSelfTest())   ; ここでは画面を移動しない
    bSave.OnEvent("Click", (*) => DoSave())
    bNo.OnEvent("Click",   (*) => ReopenAndExit(0))
    dlg.OnEvent("Close",   (*) => ReopenAndExit(0))
    if (!ScrollAttach(dlg))
        dlg.Show()
    return

    OpenPage(url) {
        try {
            Run(url)
        } catch as e {
            MsgBox("ページを開けませんでした。`n`n"
                . "お使いのブラウザで、次を開いてください。`n`n　" . url
                , APP_NAME, "Icon! 4096")
        }
    }

    ; 画面の内容をいったん保存する（保存しないと送れないため）
    Keep() {
        global C, CFG
        addr := Trim(eFrom.Value)
        adm  := Trim(eAdmin.Value)
        IniSetMany(CFG, "Notify", Map("MailFrom", addr, "MailAdmin", adm))
        C["MailFrom"]  := addr
        C["MailAdmin"] := adm
        ; ★貼り付けの空白を取り除く★
        ;   Google は 4 桁ずつ空けて表示するので、そのまま貼ると通らない。
        raw := RegExReplace(ePass.Value, "\s", "")
        if (raw != "") {
            SecretSave("mail_pass", raw)
            ePass.Value := ""
        }
        return raw
    }

    DoTest() {
        raw := Keep()
        if (MailFromAddr() = "") {
            MsgBox("差出人のアドレスを入れてください。", APP_NAME, "Icon! 4096")
            return
        }
        if (!SecretHas("mail_pass")) {
            MsgBox("アプリパスワードを入れてください。`n`n"
                . "上の「② 発行ページを開く」で作れます（16 桁）。"
                , APP_NAME, "Icon! 4096")
            return
        }
        if (raw != "" && StrLen(raw) != 16) {
            ans := MsgBox("入力されたのは " . StrLen(raw) . " 文字です。"
                . "アプリパスワードは 16 桁です。`n`n"
                . "ログインのパスワードを入れていませんか？`n`n"
                . "このまま試しますか？", APP_NAME, "YesNo Icon! 4096")
            if (ans != "Yes")
                return
        }
        sendTo := MailAdminAddr()
        body := "AutoMeta からのテスト送信です。`n`n"
              . "　送信日時　" . FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss") . "`n"
              . "　この PC 　" . A_ComputerName . "`n"
              . "　差出人　　" . MailFromAddr() . "`n`n"
              . "このメールが届いていれば、送信の準備は完了です。`n"
              . "これはテスト送信です。セラピーの通知とは別の文面です。"
        err := ""
        if (MailSend(sendTo, "AutoMeta テスト送信", body, &err)) {
            MsgBox("送信しました。`n`n"
                . "　宛先　" . sendTo . "`n`n"
                . "受信箱をご確認ください。数分たっても届かないときは、`n"
                . "迷惑メールフォルダをご確認ください。"
                , APP_NAME . " - 送信の結果", "Iconi 4096")
            return
        }
        MsgBox("送信できませんでした。`n`n"
            . "　宛先　" . sendTo . "`n`n"
            . MailErrorHint(err) . "`n`n"
            . "───── 詳しい内容 ─────`n" . err
            , APP_NAME . " - 送信の結果", "Iconx 4096")
    }

    DoSave() {
        Keep()
        Log("INFO", Format("メールの設定を保存しました（差出人 {1} ／ 知らせ先 {2}）"
            , MailMask(MailFromAddr()), MailMask(MailAdminAddr())))
        MsgBox("保存しました。`n`n"
            . "※ セラピーの通知とは別に、これはテストです。`n"
            . "　 顧客への通知は、予定から実行したときに送信します。"
            , APP_NAME, "Iconi 4096")
        ScrollDetach(dlg.Hwnd)
        try dlg.Destroy()
        BackToSettings()
    }
}

;==============================================================================
;  /diag  詳細な診断（ふだんは使わないもの）
;==============================================================================
; ★設定の一覧が長くなりすぎたので、奥へ移した★
;   2026-09-26 指摘。よく使うものだけを設定に残し、
;   調べるための道具はここにまとめる。
ModeDiag() {
    global G, APP_NAME
    dlg := Gui("+AlwaysOnTop", APP_NAME . " - お問い合わせ・診断" . VerTag())
    dlg.MarginX := 20, dlg.MarginY := 14
    dlg.SetFont("s12 Bold", "Meiryo UI")
    dlg.Add("Text", "w620", "お問い合わせ・診断")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w620 cGray", SupportNote())
    dlg.SetFont("s10", "Meiryo UI")
    bLn := dlg.Add("Button", "w300 h34", "LINE で問い合わせる")
    bMl := dlg.Add("Button", "x+20 yp w300 h34", "メールで問い合わせる")
    bDr := dlg.Add("Button", "xm w620 h34", "診断結果を作成（問い合わせに添付）")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "xm w620 cGray"
        , "診断結果には、設定ファイルの内容（メールアドレス・利用者コードなど）が入ります。`n"
        . "添付する前に、中身をご確認ください。")
    dlg.Add("Text", "xm w620 h1 0x10")

    dlg.SetFont("s10 Bold", "Meiryo UI")
    dlg.Add("Text", "w620 cNavy", "調べるための道具（ふだんは使いません）")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "xm w620 cGray", "対象ソフトは操作しません。読み取るだけです。")
    dlg.SetFont("s10 Bold", "Meiryo UI")
    dlg.Add("Text", "xm w620 cNavy", "対象ソフトを確認")
    dlg.SetFont("s10", "Meiryo UI")
    b1 := dlg.Add("Button", "w300 h34", "操作を記録")
    b2 := dlg.Add("Button", "x+20 yp w300 h34", "読み取り可否を確認")
    b3 := dlg.Add("Button", "xm w300 h34", "画面とボタンを一覧")
    b4 := dlg.Add("Button", "x+20 yp w300 h34", "変化を監視")

    dlg.Add("Text", "xm w620 h1 0x10")
    dlg.SetFont("s10 Bold", "Meiryo UI")
    dlg.Add("Text", "w620 cNavy", "この PC の状態を確認")
    dlg.SetFont("s10", "Meiryo UI")
    b5 := dlg.Add("Button", "w300 h34", "保管の仕組みを確認")
    b6 := dlg.Add("Button", "x+20 yp w300 h34", "利用確認の自己診断（公開鍵）")
    b7 := dlg.Add("Button", "xm w300 h34", "稼働の記録とログの送信 →")
    b8 := dlg.Add("Button", "x+20 yp w300 h34", "ログを送信 →")

    dlg.Add("Text", "xm w620 h1 0x10")
    dlg.SetFont("s10", "Meiryo UI")
    bBack := dlg.Add("Button", "w620 h34 Default", G.backTo = "menu" ? "← メニューに戻る" : "← 設定に戻る")

    bLn.OnEvent("Click",  (*) => ContactLine())
    bMl.OnEvent("Click",  (*) => ContactMail())
    bDr.OnEvent("Click",  (*) => Go("doctor"))
    b1.OnEvent("Click",   (*) => Go("trace"))
    b2.OnEvent("Click",   (*) => Go("listread"))
    b3.OnEvent("Click",   (*) => Go("inspect"))
    b4.OnEvent("Click",   (*) => Go("watchall"))
    b5.OnEvent("Click",   (*) => SecretSelfTest())
    b6.OnEvent("Click",   (*) => Go("verifytest"))
    b7.OnEvent("Click",   (*) => TelemetryDialog())
    b8.OnEvent("Click",   (*) => LogReportDialog())
    bBack.OnEvent("Click",(*) => Leave())
    dlg.OnEvent("Close",  (*) => Leave())
    if (!ScrollAttach(dlg))
        dlg.Show()
    return

    Go(mode) {
        global G
        ScrollDetach(dlg.Hwnd)
        dlg.Destroy()
        G.mode := mode
        switch mode {
            case "trace":      ModeTrace()
            case "listread":   ModeListRead()
            case "inspect":    ModeInspect()
            case "watchall":   ModeWatchAll()
            case "verifytest": ModeVerifyTest()
            case "doctor":     ModeDoctor()
            default:           ModeMore()
        }
    }

    Leave() {
        global G
        ScrollDetach(dlg.Hwnd)
        dlg.Destroy()
        if (G.backTo = "menu")
            ModeMenu()
        else
            ModeMore()
    }
}

;==============================================================================
;  稼働の記録・ログの送信
;==============================================================================
; ★目的★ 運転が止まった・失敗した、に早く気づき、原因をログから読んで直すため。
;   ① 稼働の記録（全員）：10 分ごと。★名前を含まない★ 版・機種・運転中か・最後のジョブの終了・
;      本日の完了と失敗の件数・失敗の種類。
;   ② ログの送信（本人がオンにしたときだけ）：10 分ごと、増えた行を送る。顧客の氏名は「顧客 12345」の
;      ような仮名に置き換え、メール・LINE の ID・Windows のユーザー名は送らない。
;   ★運転とは別のプロセス（5 分ごとの見張り）が送る★ 通信の待ちで、運転の画面操作を止めない。
;   ★送れなくても、何も止めない★ 失敗したら 30 分あけ、次の回に増えた分もまとめて送る。
TeleIni() => NotifyDir() . "\telemetry.ini"

TelemetryTick() {
    global G
    if (G.mode != "resume")
        return
    code := Trim(CS("UserCode"))
    if (code = "")
        return
    st := IniLoad(TeleIni())
    failAt := Trim(IniGet(st, "Tele", "FailAt", ""))
    if (failAt != "" && SecSince(failAt) < 1800)
        return                                     ; つながらなかったあとは 30 分あける
    hbAt := Trim(IniGet(st, "Tele", "HbAt", ""))
    if (hbAt = "" || SecSince(hbAt) >= CI("TeleHbSec")) {
        ok := false
        try ok := TeleSendHb(code)
        if (!ok) {
            IniSet(TeleIni(), "Tele", "FailAt", A_Now)
            return
        }
        IniSetMany(TeleIni(), "Tele", Map("HbAt", A_Now, "FailAt", ""))
    }
    if (CB("LogShare")) {
        ok := true
        try ok := TeleShipLog(code)
        if (!ok)
            IniSet(TeleIni(), "Tele", "FailAt", A_Now)
    }
}

; ① 稼働の記録
TeleSendHb(code) {
    global APP_VER, LICENSE_URL
    live := ReadLive()
    age := ""
    if (live.Has("At") && RegExMatch(live["At"], "^\d{14}$"))
        age := DateDiff(A_Now, live["At"], "Seconds")
    s := TeleLogStats()
    url := LICENSE_URL . "?act=hb&code=" . UriEncode(code) . "&dev=" . DeviceId()
        . "&v=" . UriEncode(VerNumOnly(APP_VER))
        . "&model=" . UriEncode(Trim(CS("ModelName")))
        . "&on=" . ((live["SchedOn"] = "1") ? 1 : 0)
        . "&run=" . ((live["Running"] = "1") ? 1 : 0)
        . "&age=" . age
        . "&state=" . UriEncode(live["State"])
        . "&lastEnd=" . UriEncode(s["lastEnd"])
        . "&done=" . s["done"] . "&fail=" . s["fail"]
        . "&lastFail=" . UriEncode(s["lastFail"])
        . "&lastReason=" . UriEncode(SubStr(TeleMask(s["lastReason"]), 1, 150))
        . "&share=" . (CB("LogShare") ? 1 : 0)
        . "&pc=" . UriEncode(A_ComputerName)
    body := ""
    try {
        http := ComObject("WinHttp.WinHttpRequest.5.1")
        http.SetTimeouts(3000, 5000, 5000, 8000)
        http.Open("GET", url, false)
        http.Send()
        body := http.ResponseText
    } catch {
        return false
    }
    return JBool(body, "ok")
}

; 今日のログから、本日の件数と、最後のジョブの終了・失敗を数える（顧客の氏名は読まない・送らない）
TeleLogStats() {
    global LOGDIR
    out := Map("done", 0, "fail", 0, "lastEnd", "", "lastFail", "", "lastReason", "")
    path := LOGDIR . "\" . FormatTime(A_Now, "yyyy-MM-dd") . ".log"
    if !FileExist(path)
        return out
    txt := ""
    try txt := FileRead(path, "UTF-8")
    for line in StrSplit(txt, "`n", "`r") {
        if !RegExMatch(line, "^(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d) \[\w+\] ジョブ終了 code=(\d+) reason=(.*)$", &m)
            continue
        out["lastEnd"] := m[1]
        if (m[2] = "0") {
            out["done"] += 1
        } else {
            out["fail"] += 1
            out["lastFail"] := TeleFailKind(m[3])
            out["lastReason"] := m[3]
        }
    }
    return out
}

; 失敗の種類を、短いコードにする（氏名を含まない）
TeleFailKind(reason) {
    if InStr(reason, "同じものを") {
        st := ""
        if RegExMatch(reason, "状態\s*:\s*(\w+)", &m)
            st := ":" . m[1]
        return "stuck_click" . st
    }
    if InStr(reason, "実行時間が上限")
        return "job_timeout"
    if InStr(reason, "起動していません")
        return "app_down"
    if InStr(reason, "照合")
        return "verify"
    return "other"
}

; ② ログの送信。増えた行だけ。送れたら位置を進める（送れなかった分は次の回に）
TeleShipLog(code) {
    global LOGDIR
    ini := TeleIni()
    st := IniLoad(ini)
    today := FormatTime(A_Now, "yyyy-MM-dd")
    file := Trim(IniGet(st, "Log", "File", ""))
    pos  := ToInt(IniGet(st, "Log", "Pos", "0"), 0)
    if (file = "") {
        ; ★オンにした時点から先を送る★ それより前の分は、同意の前なので送らない
        file := today
        pos := 0
        p0 := LOGDIR . "\" . today . ".log"
        if FileExist(p0)
            pos := FileGetSize(p0)
        IniSetMany(ini, "Log", Map("File", file, "Pos", pos))
        return true
    }
    Loop 6 {
        path := LOGDIR . "\" . file . ".log"
        size := FileExist(path) ? FileGetSize(path) : 0
        if (pos > size)
            pos := 0                               ; ファイルが作り直された
        if (pos >= size) {
            if (file >= today)
                return true
            file := FormatTime(DateAdd(StrReplace(file, "-") . "000000", 1, "Days"), "yyyy-MM-dd")   ; 次の日へ
            pos := 0
            IniSetMany(ini, "Log", Map("File", file, "Pos", pos))
            continue
        }
        txt := ""
        try {
            f := FileOpen(path, "r", "UTF-8")
            f.Pos := pos
            txt := f.Read(16000)
            f.Close()
        }
        cut := InStr(txt, "`n", , -1)
        if (cut = 0)
            return true                            ; 行が書き終わるのを待つ
        chunk := SubStr(txt, 1, cut)
        body := '{"code":"' . code . '","dev":"' . DeviceId() . '","share":"1","date":"' . file . '","from":' . pos
              . ',"text":"' . JsonEsc(TeleMask(chunk)) . '"}'
        if (!TelePost(body))
            return false
        pos += StrPut(chunk, "UTF-8") - 1
        IniSetMany(ini, "Log", Map("File", file, "Pos", pos, "SentAt", A_Now))
    }
    return true
}

; POST。GAS は POST のあと 302 で結果の場所を返すので、転送は自分で追う（POST のまま転送されないように）
TelePost(body, act := "log") {
    global LICENSE_URL
    try {
        http := ComObject("WinHttp.WinHttpRequest.5.1")
        http.SetTimeouts(3000, 5000, 15000, 15000)
        http.Option[6] := false
        http.Open("POST", LICENSE_URL . "?act=" . act, false)
        http.SetRequestHeader("Content-Type", "text/plain;charset=utf-8")
        http.Send(body)
        stt := http.Status
        if (stt = 301 || stt = 302 || stt = 303 || stt = 307) {
            loc := http.GetResponseHeader("Location")
            h2 := ComObject("WinHttp.WinHttpRequest.5.1")
            h2.SetTimeouts(3000, 5000, 10000, 10000)
            h2.Open("GET", loc, false)
            h2.Send()
            return (h2.Status = 200 && JBool(h2.ResponseText, "ok"))
        }
        return (stt = 200 && JBool(http.ResponseText, "ok"))
    } catch {
        return false
    }
}

; ★ログをボタンで送信★（3.10.41・F-11）常時の送信のオン／オフとは別。押した 1 回だけ。
;   送る人は利用者コードで分かるので、連絡も受付番号も要らない。
;   ★運転とは別のプロセス（メニュー）で動く★ 通信の待ちで運転を止めない。
LogReportParts(days, maxChars, &lineCount, &rangeText) {
    global LOGDIR
    parts := []
    lineCount := 0, rangeText := ""
    room := maxChars
    Loop days {                                    ; 新しい日から。多いときは古い分を落とす
        day := FormatTime(DateAdd(A_Now, -(A_Index - 1), "Days"), "yyyy-MM-dd")
        path := LOGDIR . "\" . day . ".log"
        if (room <= 0 || !FileExist(path))
            continue
        body := ""
        try {
            Loop Parse, FileRead(path, "UTF-8"), "`n", "`r"
            {
                if (A_LoopField = "" || InStr(A_LoopField, "[DEBUG]"))
                    continue
                body .= A_LoopField . "`n"
            }
        }
        body := TeleMask(body)
        if (StrLen(body) > room) {
            body := SubStr(body, -room)
            cut := InStr(body, "`n")
            body := cut ? SubStr(body, cut + 1) : body
        }
        if (body = "")
            continue
        room -= StrLen(body)
        parts.InsertAt(1, Map("date", day, "text", body))
        StrReplace(body, "`n", "`n", , &added)
        lineCount += added
    }
    if (parts.Length > 0)
        rangeText := FormatTime(StrReplace(parts[1]["date"], "-") . "000000", "M/d") . "〜"
            . FormatTime(StrReplace(parts[parts.Length]["date"], "-") . "000000", "M/d")
    return parts
}

; 1 塊を送る。つながらないときは 1 回だけ送り直す
LogReportPost(body, act) {
    if (TelePost(body, act))
        return true
    Sleep(3000)
    return TelePost(body, act)
}

LogReportSend(memo, progress) {
    global APP_VER
    code := Trim(CS("UserCode"))
    parts := LogReportParts(3, 300000, &lineCount, &rangeText)
    if (parts.Length = 0)
        return "none"
    ticket := "T" . A_Now
    head := '{"code":"' . code . '","dev":"' . DeviceId() . '","share":"1","ticket":"' . ticket . '"'
    total := 0
    for part in parts
        total += StrLen(part["text"])
    sent := 0, seq := 0
    for part in parts {
        pos := 1, whole := part["text"]
        while (pos <= StrLen(whole)) {
            chunk := SubStr(whole, pos, 16000)
            if (pos + 16000 <= StrLen(whole)) {
                cut := InStr(chunk, "`n", , -1)
                if (cut > 0)
                    chunk := SubStr(chunk, 1, cut)
            }
            seq++
            body := head . ',"date":"' . part["date"] . '","from":' . seq . ',"text":"' . JsonEsc(chunk) . '"}'
            if (!LogReportPost(body, "log"))
                return "fail"
            pos += StrLen(chunk)
            sent += StrLen(chunk)
            try progress.Value := "送信中… " . Round(sent * 100 / total) . "%"
        }
    }
    closing := head . ',"pc":"' . JsonEsc(A_ComputerName) . '","v":"' . JsonEsc(StrSplit(APP_VER, " ")[1])
        . '","memo":"' . JsonEsc(TeleMask(memo)) . '","range":"' . JsonEsc(rangeText) . '","lines":' . lineCount . '}'
    if (!LogReportPost(closing, "ticket"))
        return "fail"
    Log("INFO", Format("ログを送信しました（受付 {1}／{2}／{3} 行）", ticket, rangeText, lineCount))
    return "ok"
}

; 通信待ちを運転へ持ち込まない。専用プロセスで既存の送信画面を開く。
OpenLogReportWindow() {
    global APP_NAME
    try {
        Run('"' A_AhkPath '" "' A_ScriptFullPath '" /logreport', A_ScriptDir)
    } catch as err {
        MsgBox("ログの送信画面を開けませんでした。`n`n" . err.Message
            . "`nもう一度「ログ」を押してください。解消しない場合は、開発者へご連絡ください。", APP_NAME, "Icon! 4096")
    }
}

ModeLogReport() {
    global APP_NAME
    static reportMutex := 0
    ; ジョブの排他とは別。連打や別のパネルからの重複起動を防ぐ。
    reportMutex := DllCall("CreateMutexW", "Ptr", 0, "Int", 1
        , "Str", "AutoMeta_LogReport_" . TeleHash(A_ScriptFullPath), "Ptr")
    alreadyOpen := (A_LastError = 183)
    if (!reportMutex) {
        MsgBox("ログの送信画面を準備できませんでした。`nもう一度「ログ」を押してください。", APP_NAME, "Icon! 4096")
        ExitApp()
    }
    if (alreadyOpen) {
        try WinActivate(APP_NAME . " - ログを送信" . VerTag())
        ExitApp()
    }
    LogReportDialog(true)
}

LogReportDialog(exitOnClose := false) {
    global APP_NAME
    if (Trim(CS("UserCode")) = "") {
        MsgBox("利用者コードが登録されていないため、ログを送信できません。`n`n"
            . "送信者を確認できないためです。利用者コードを登録してから、もう一度お試しください。"
            , APP_NAME, "Icon! 4096")
        if (exitOnClose)
            ExitApp()
        return
    }
    dlg := Gui("+AlwaysOnTop", APP_NAME . " - ログを送信" . VerTag())
    dlg.MarginX := 20, dlg.MarginY := 14
    dlg.SetFont("s12 Bold", "Meiryo UI")
    dlg.Add("Text", "w560", "ログを送信")
    dlg.SetFont("s10", "Meiryo UI")
    dlg.Add("Text", "xm w560", "直近 3 日の動作ログを、開発者へ 1 回だけ送信します。ご連絡は不要です。")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "xm w560 cGray"
        , "顧客の氏名は番号に置き換え、メールアドレス・LINE の ID・Windows のユーザー名は送信しません。`n"
        . "原因の調査には AI を使用します。量が多いときは、新しい分だけを送信します。")
    dlg.SetFont("s10", "Meiryo UI")
    dlg.Add("Text", "xm w560", "伝えたいこと（任意。顧客の氏名は記述しないでください）")
    eMemo := dlg.Add("Edit", "xm w560 r2 Limit300")
    tProg := dlg.Add("Text", "xm w560 cGray", "")
    bGo := dlg.Add("Button", "xm w270 h34 Default", "送信")
    bNo := dlg.Add("Button", "x+20 yp w270 h34", "キャンセル")
    bGo.OnEvent("Click", (*) => ReportGo())
    bNo.OnEvent("Click", (*) => CloseReport())
    dlg.OnEvent("Close", (*) => CloseReport())
    dlg.Show()
    return

    CloseReport() {
        dlg.Destroy()
        if (exitOnClose)
            ExitApp()
    }

    ReportGo() {
        bGo.Enabled := false, bNo.Enabled := false
        tProg.Value := "送信中…"
        res := "fail"
        try res := LogReportSend(eMemo.Value, tProg)
        if (res = "ok") {
            dlg.Destroy()
            MsgBox("ログの送信が完了しました。`n`nご連絡は不要です。", APP_NAME, "Iconi 4096")
            if (exitOnClose)
                ExitApp()
            return
        }
        bGo.Enabled := true, bNo.Enabled := true
        tProg.Value := ""
        if (res = "none")
            MsgBox("送信できるログがありません。`n`n直近 3 日のログが、この PC に見つかりませんでした。"
                , APP_NAME, "Icon! 4096")
        else
            MsgBox("ログの送信に失敗しました。`n`nインターネットに接続できないか、窓口が応答していません。`n"
                . "接続を確認し、もう一度「送信」を押してください。", APP_NAME, "Icon! 4096")
    }
}

; ★送る前に、顧客の氏名と個人の値を置き換える★
;   顧客の氏名は、予定の一覧（姓・名・予定のキー）から作った表で置き換える。同じ顧客は、いつも同じ仮名
;   （傾向は追える）。元の氏名との対応は、この PC の中にしか無い。
TeleMask(text) {
    t := text
    for r in TeleNameTable()
        t := StrReplace(t, r["from"], r["to"])
    t := RegExReplace(t, "U[0-9a-f]{32}", "U***")
    t := RegExReplace(t, "[A-Za-z0-9._%+*\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}", "***@***")
    ; 円記号は、正規表現では \x5C と書く（文字列の中の円記号 2 つは、検査で止まる）
    t := RegExReplace(t, "i)([A-Z]:\x5CUsers\x5C)[^\x5C\r\n]+", "$1***")
    return t
}

TeleHash(s) {
    h := 5381
    Loop Parse, s
        h := Mod(h * 33 + Ord(A_LoopField), 99991)
    return h
}

TeleNameTable() {
    static tbl := ""
    if (IsObject(tbl))
        return tbl
    tbl := []
    list := []
    err := ""
    try list := LoadSchedule(&err)
    for p in list {
        sei := Trim(p["sei"]), mei := Trim(p["mei"]), key := Trim(p["key"])
        lab := "顧客" . Format("{:05d}", TeleHash(key != "" ? key : (sei . mei)))
        if (key != "")
            tbl.Push(Map("from", key, "to", lab))
        if (sei != "" && mei != "") {
            tbl.Push(Map("from", sei . " " . mei, "to", lab))
            tbl.Push(Map("from", sei . "　" . mei, "to", lab))
            tbl.Push(Map("from", sei . mei, "to", lab))
        }
        ; 姓だけ・名だけは、2 文字以上のときだけ（1 文字だと、ふつうの語を壊す）
        if (StrLen(sei) >= 2)
            tbl.Push(Map("from", sei . "さん", "to", lab))
    }
    ; 長いものから置き換える（短いものが先だと、長い氏名が途中で壊れる）
    Loop tbl.Length - 1 {
        i := A_Index
        Loop tbl.Length - i {
            j := A_Index
            if (StrLen(tbl[j]["from"]) < StrLen(tbl[j + 1]["from"])) {
                tmp := tbl[j]
                tbl[j] := tbl[j + 1]
                tbl[j + 1] := tmp
            }
        }
    }
    return tbl
}

; 設定の画面（お問い合わせ・診断 → 稼働の記録とログの送信）
TelemetryDialog() {
    global APP_NAME, CFG
    st := IniLoad(TeleIni())
    dlg := Gui("+AlwaysOnTop", APP_NAME . " - 稼働の記録とログの送信" . VerTag())
    dlg.MarginX := 20, dlg.MarginY := 14
    dlg.SetFont("s12 Bold", "Meiryo UI")
    dlg.Add("Text", "w620", "稼働の記録とログの送信")
    dlg.SetFont("s10 Bold", "Meiryo UI")
    dlg.Add("Text", "xm w620 cNavy", "稼働の記録（全員・自動）")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "xm w620 cGray"
        , "10 分ごとに送ります。名前は含みません。`n"
        . "版・機種・運転中か・最後のジョブの終了時刻・本日の完了と失敗の件数・失敗の種類です。`n"
        . "止まったときに、すぐ気づいて直すために使います。")
    dlg.SetFont("s10 Bold", "Meiryo UI")
    dlg.Add("Text", "xm w620 cNavy", "ログの送信（任意）")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "xm w620 cGray"
        , "オンにすると、オンにしたあとの動作ログを、10 分ごとに送ります。`n"
        . "顧客の氏名は「顧客 12345」のような番号に置き換えて送ります。`n"
        . "メールアドレス・LINE の ID・Windows のユーザー名は送りません。いつでもオフにできます。")
    dlg.SetFont("s10", "Meiryo UI")
    cOn := dlg.Add("CheckBox", "xm w620" . (CB("LogShare") ? " Checked" : ""), "動作ログを送信する")
    sent := Trim(IniGet(st, "Log", "SentAt", ""))
    hb   := Trim(IniGet(st, "Tele", "HbAt", ""))
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "xm w620 cGray"
        , "最後に送信　稼働の記録: " . (StrLen(hb) = 14 ? FormatTime(hb, "yyyy-MM-dd HH:mm") : "まだありません")
        . "　／　ログ: " . (StrLen(sent) = 14 ? FormatTime(sent, "yyyy-MM-dd HH:mm") : "まだありません"))
    dlg.SetFont("s10", "Meiryo UI")
    bOk := dlg.Add("Button", "xm w300 h34 Default", "保存")
    bNo := dlg.Add("Button", "x+20 yp w300 h34", "キャンセル")
    bOk.OnEvent("Click", (*) => Save())
    bNo.OnEvent("Click", (*) => dlg.Destroy())
    dlg.OnEvent("Close", (*) => dlg.Destroy())
    dlg.Show()
    return

    Save() {
        global APP_NAME, CFG
        want := cOn.Value ? "1" : "0"
        dlg.Destroy()
        if (want = (CB("LogShare") ? "1" : "0"))
            return
        IniSet(CFG, "Telemetry", "LogShare", want)
        LoadConfig()
        if (want = "1") {
            ; オンにした時点の末尾から送る。位置をつけ直す
            IniSetMany(TeleIni(), "Log", Map("File", "", "Pos", "0", "SentAt", ""))
            MsgBox("ログの送信をオンにしました。`n`nオンにしたあとの動作ログを、10 分ごとに送ります。", APP_NAME, "Iconi 4096")
        } else {
            MsgBox("ログの送信をオフにしました。`n`n稼働の記録（名前を含まない）は、引き続き送ります。", APP_NAME, "Iconi 4096")
        }
    }
}

;==============================================================================
;  くわしい手順を見せる窓（使い回し）
;==============================================================================
; ★長い説明は別の窓に逃がす★
;   本体の画面を縦に伸ばさないため（上限 700／2026-09-26 のルール）。
;   読み取り専用の入力欄に入れるので、文字をコピーできる。
ShowGuide(title, body) {
    global APP_NAME
    gd := Gui("+AlwaysOnTop +Resize", APP_NAME . " - " . title . VerTag())
    gd.MarginX := 16, gd.MarginY := 12
    gd.SetFont("s11 Bold", "Meiryo UI")
    gd.Add("Text", "w700", title)
    gd.SetFont("s10", "Meiryo UI")
    gd.Add("Edit", "w700 h520 ReadOnly Multi +VScroll", body)
    gd.SetFont("s10", "Meiryo UI")
    bc := gd.Add("Button", "w700 h34 Default", "閉じる")
    bc.OnEvent("Click", (*) => gd.Destroy())
    gd.OnEvent("Close", (*) => gd.Destroy())
    gd.Show()
}

LineGuideText() {
    return ""
. "LINE でお知らせを送るには、セラピストごとに「LINE 公式アカウント」が必要です。`r`n"
. "無料で作れます。ふだんお使いの個人の LINE とは別のものです。`r`n"
. "`r`n"
. "───────────────────────────────`r`n"
. "① LINE 公式アカウントを作る`r`n"
. "───────────────────────────────`r`n"
. "「申し込みページを開く」を押します。`r`n"
. "・ふだんお使いの LINE アカウントでログインできます`r`n"
. "・アカウント名は、顧客に表示される名前です（例：ご自身の屋号）`r`n"
. "・業種などを選んで作成します。審査はありません`r`n"
. "`r`n"
. "すでにお持ちの公式アカウントがあれば、それを使って構いません。`r`n"
. "`r`n"
. "───────────────────────────────`r`n"
. "② Messaging API を使えるようにする`r`n"
. "───────────────────────────────`r`n"
. "「管理画面を開く」を押します（LINE Official Account Manager）。`r`n"
. "・右上の［設定］→ 左の［Messaging API］`r`n"
. "・［Messaging API を利用する］を押します`r`n"
. "・「プロバイダー」を選ぶか、新しく作ります`r`n"
. "　　プロバイダーとは、発信する事業者の名前です。屋号で構いません`r`n"
. "`r`n"
. "`r`n"
. "───────────────────────────────`r`n"
. "③ 開発者ページを開き、自分のチャネルを選ぶ`r`n"
. "───────────────────────────────`r`n"
. "②の管理画面から、直接たどれます。`r`n"
. "`r`n"
. "・右上の［設定］→ 左の［応答設定］を開く`r`n"
. "・いちばん下の「Webhook」の欄にある`r`n"
. "　　【Messaging API の設定画面を開く】を押す`r`n"
. "`r`n"
. "開発者ページ（LINE Developers）が開きます。`r`n"
. "ここから先が分かりにくいので、順番に。`r`n"
. "`r`n"
. "　１. プロバイダーの一覧が出ます`r`n"
. "　　　②で作った（選んだ）プロバイダーを押します`r`n"
. "　　　　※ プロバイダー ＝ 発信する事業者の名前。屋号で作ったものです`r`n"
. "　２. その中にチャネルが並びます`r`n"
. "　　　公式アカウントと同じ名前のものを押します`r`n"
. "　３. 上にタブが並びます（ここで④に進みます）`r`n"
. "`r`n"
. "───────────────────────────────`r`n"
. "④ トークンとユーザー ID を控える`r`n"
. "───────────────────────────────`r`n"
. "2 つを取りますが、★それぞれ別のタブにあります★。`r`n"
. "　・トークン　　… ［Messaging API 設定］タブ`r`n"
. "　・ユーザー ID … ［チャネル基本設定］タブ`r`n"
. "`r`n"
. "◆ チャネルアクセストークン（長期）`r`n"
. "　・ページのいちばん下までスクロールします`r`n"
. "　・［発行］を押すと、長い文字列が出ます`r`n"
. "　・コピーして、AutoMeta の欄に貼ります`r`n"
. "`r`n"
. "　★この文字列は、あなたの公式アカウントの鍵です★`r`n"
. "　　人に見せないでください。`r`n"
. "　　AutoMeta は暗号化して、この PC の中だけに保管します。`r`n"
. "　　漏れたときは同じ画面で［再発行］すれば、古いものは使えなくなります。`r`n"
. "`r`n"
. "◆ あなたのユーザー ID（★別のタブです★）`r`n"
. "　・上のタブを［チャネル基本設定］に切り替えます`r`n"
. "　・その中に「あなたのユーザー ID」があります`r`n"
. "　・U で始まる 33 文字です`r`n"
. "`r`n"
. "　★公式アカウントの ID ではありません★`r`n"
. "　　同じ画面にある「ボット情報」や「チャネル ID」とは別のものです。`r`n"
. "　　異常のお知らせを受け取る、あなた自身の LINE の ID です。`r`n"
. "`r`n"
. "───────────────────────────────`r`n"
. "⑤ 自分のスマホで友だち追加する（いちばん忘れやすい）`r`n"
. "───────────────────────────────`r`n"
. "LINE は、友だちでない相手には送れません。`r`n"
. "`r`n"
. "・［Messaging API 設定］のページに QR コードがあります`r`n"
. "・ご自分のスマホの LINE で読み取って、友だち追加してください`r`n"
. "`r`n"
. "これを忘れると、テスト送信が`r`n"
. "「まだ友だち追加していないようです」で失敗します。`r`n"
. "`r`n"
. "───────────────────────────────`r`n"
. "料金について`r`n"
. "───────────────────────────────`r`n"
. "無料プランは月 200 通までです。`r`n"
. "異常のお知らせだけなら、月に数通で収まります。`r`n"
. "顧客へのお知らせを始めると増えるので、そのときに見直してください。`r`n"
. "（目安：1 日 6 人までなら無料の範囲に収まります）`r`n"
. "`r`n"
. "───────────────────────────────`r`n"
. "この手順書について`r`n"
. "───────────────────────────────`r`n"
. "LINE の画面は、ときどき作りが変わります。`r`n"
. "書かれている名前のボタンが見つからないときは、そのままお知らせください。`r`n"
. "実際の画面に合わせて書き直します。`r`n"
}

MailGuideText() {
    return ""
. "AutoMeta は、お使いの Gmail から直接メールをお送りします。`r`n"
. "差出人はご自身のアドレスになり、こちらのサーバーは通りません。`r`n"
. "`r`n"
. "そのために「アプリパスワード」というものが必要です。`r`n"
. "ふだんログインに使うパスワードとは別の、ソフト専用の 16 桁です。`r`n"
. "`r`n"
. "───────────────────────────────`r`n"
. "なぜ、ふだんのパスワードではいけないのか`r`n"
. "───────────────────────────────`r`n"
. "Google は、ソフトからのログインにふだんのパスワードを使わせません。`r`n"
. "アプリパスワードなら、`r`n"
. "・そのソフトだけに使えます`r`n"
. "・いつでも取り消せます（取り消しても、ほかには影響しません）`r`n"
. "・万一漏れても、Google アカウント全体は守られます`r`n"
. "`r`n"
. "───────────────────────────────`r`n"
. "① 2 段階認証をオンにする`r`n"
. "───────────────────────────────`r`n"
. "「設定ページを開く」を押します。`r`n"
. "・画面の案内どおりに進めてください（電話番号の確認などがあります）`r`n"
. "・すでにオンの方は、そのまま②へ`r`n"
. "`r`n"
. "★これをしないと、②のページが出てきません★`r`n"
. "`r`n"
. "───────────────────────────────`r`n"
. "② アプリパスワードを発行する`r`n"
. "───────────────────────────────`r`n"
. "「発行ページを開く」を押します。`r`n"
. "・名前を聞かれるので「AutoMeta」と入れます（何でも構いません）`r`n"
. "・［作成］を押すと、16 桁が表示されます`r`n"
. "・4 桁ずつ空いて見えますが、空白はそのままで構いません`r`n"
. "　　そのまま貼っていただければ、AutoMeta が取り除きます`r`n"
. "`r`n"
. "★この画面を閉じると、二度と表示されません★`r`n"
. "　閉じてしまったら、新しく作り直してください（何個作っても構いません）。`r`n"
. "`r`n"
. "───────────────────────────────`r`n"
. "③ 貼り付けて、テスト送信`r`n"
. "───────────────────────────────`r`n"
. "・差出人には、そのアドレス（○○@gmail.com）を入れます`r`n"
. "・アプリパスワードの欄に、16 桁を貼ります`r`n"
. "・［テスト送信］を押すと、自分宛に 1 通届きます`r`n"
. "`r`n"
. "───────────────────────────────`r`n"
. "正しく動作しないとき`r`n"
. "───────────────────────────────`r`n"
. "・「アプリパスワードが違うようです」`r`n"
. "　　→ ふだんのパスワードを入れていませんか。②で作り直してください`r`n"
. "・「つながりませんでした」`r`n"
. "　　→ インターネット、または社内のネットワークの制限を確認してください`r`n"
. "・届かない`r`n"
. "　　→ 迷惑メールフォルダをご確認ください`r`n"
. "`r`n"
. "保管について`r`n"
. "　入力したパスワードは暗号化して、この PC の中だけに保管します。`r`n"
. "　ほかの PC にコピーしても読めません。`r`n"
. "　設定 →「お問い合わせ・診断」→「保管の仕組みを確認」で確認できます。`r`n"
}

;==============================================================================
;  /line  LINE の設定（V3）
;==============================================================================
ModeLine() {
    global CFG, APP_NAME, C
    dlg := Gui("+AlwaysOnTop", APP_NAME . " - LINE の設定" . VerTag())
    dlg.MarginX := 20, dlg.MarginY := 12
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "w660", "ご自身の LINE 公式アカウントから、直接お送りします")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w660 cGray"
        , "顧客から見た送り主は、ご自身の公式アカウントになります。"
        . "鍵はこの PC の中だけに暗号化して保管します。")

    dlg.SetFont("s10 Bold", "Meiryo UI")
    dlg.Add("Text", "xm w430 cNavy", "はじめての方へ　順番に進めてください")
    bHelp := dlg.Add("Button", "x+10 yp-4 w200 h30", "詳しい手順を表示")
    dlg.SetFont("s10", "Meiryo UI")
    dlg.Add("Text", "xm w420", "① LINE 公式アカウントを作る（無料）")
    b1 := dlg.Add("Button", "x+10 yp-4 w210 h30", "申し込みページを開く")
    dlg.Add("Text", "xm w420", "② Messaging API を使えるようにする")
    b2 := dlg.Add("Button", "x+10 yp-4 w210 h30", "管理画面を開く")
    dlg.Add("Text", "xm w420", "③ 開発者ページで、プロバイダーとチャネルを選ぶ")
    b3 := dlg.Add("Button", "x+10 yp-4 w210 h30", "開発者ページを直接開く")
    dlg.Add("Text", "xm w660", "④ トークンを発行し、「あなたのユーザー ID」も控える")
    dlg.Add("Text", "xm w660", "⑤ ご自分のスマホで、その公式アカウントを友だち追加する")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "xm+12 w648 cRed"
        , "　★⑤を忘れると送れません★　友だちでない相手には LINE が届きません。")

    dlg.SetFont("s10", "Meiryo UI")
    dlg.Add("Text", "xm w210", "チャネルアクセストークン")
    eTok := dlg.Add("Edit", "x+10 yp-4 w420 Password")
    dlg.SetFont("s9", "Meiryo UI")
    haveTok := SecretHas("line_token")
    tokHint := "　まだ保存されていません（③で発行した長い文字列）"
    if (haveTok)
        tokHint := "　保存済みです。変えるときだけ入力してください（空のままなら今のまま）"
    dlg.Add("Text", "xm+12 w648 " . (haveTok ? "cGreen" : "cGray"), tokHint)

    dlg.SetFont("s10", "Meiryo UI")
    dlg.Add("Text", "xm w210", "あなたのユーザー ID")
    eUid := dlg.Add("Edit", "x+10 yp-4 w420", LineAdminId())
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "xm+12 w648 cGray", "　U で始まる 33 文字です（④で控えたもの）")

    dlg.SetFont("s10", "Meiryo UI")
    bTest := dlg.Add("Button", "xm w320 h36", "テスト送信（自分の LINE へ 1 通）")
    bSave := dlg.Add("Button", "x+20 yp w320 h36", "保存")
    bNo   := dlg.Add("Button", "xm w660 h34", "キャンセル")

    bHelp.OnEvent("Click",(*) => ShowGuide("LINE の設定 — 詳しい手順", LineGuideText()))
    b1.OnEvent("Click",   (*) => OpenPage("https://entry.line.biz/start/jp/"))
    b2.OnEvent("Click",   (*) => OpenPage("https://manager.line.biz/"))
    b3.OnEvent("Click",   (*) => OpenPage("https://developers.line.biz/console/"))
    bTest.OnEvent("Click",(*) => DoTest())
    bSave.OnEvent("Click",(*) => DoSave())
    bNo.OnEvent("Click",  (*) => ReopenAndExit(0))
    dlg.OnEvent("Close",  (*) => ReopenAndExit(0))
    if (!ScrollAttach(dlg))
        dlg.Show()
    return

    OpenPage(url) {
        try {
            Run(url)
        } catch as e {
            MsgBox("ページを開けませんでした。`n`n"
                . "お使いのブラウザで、次を開いてください。`n`n　" . url
                , APP_NAME, "Icon! 4096")
        }
    }

    Keep() {
        global C, CFG
        uid := Trim(eUid.Value)
        IniSet(CFG, "Notify", "LineAdminId", uid)
        C["LineAdminId"] := uid
        tok := Trim(eTok.Value)
        if (tok != "") {
            SecretSave("line_token", tok)
            eTok.Value := ""
        }
    }

    DoTest() {
        Keep()
        if (!SecretHas("line_token")) {
            MsgBox("チャネルアクセストークンを入れてください。`n`n"
                . "上の「③ 開発者ページを開く」で発行できます。"
                , APP_NAME, "Icon! 4096")
            return
        }
        if (LineAdminId() = "") {
            MsgBox("あなたのユーザー ID を入れてください。`n`n"
                . "③と同じ画面の下の方に出ています（U で始まる 33 文字）。"
                , APP_NAME, "Icon! 4096")
            return
        }
        err := ""
        text := "AutoMeta からのテスト送信です。" . Chr(10)
              . FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss") . Chr(10)
              . "この PC：" . A_ComputerName . Chr(10) . Chr(10)
              . "これが届いていれば、LINE の準備は整っています。"
        if (LineSend(LineAdminId(), text, &err)) {
            MsgBox("お送りしました。`n`n"
                . "ご自分の LINE をご確認ください。"
                , APP_NAME . " - 送信の結果", "Iconi 4096")
            return
        }
        MsgBox("送信できませんでした。`n`n" . err . "`n`n"
            . "よくある原因`n"
            . "　・⑤の友だち追加がまだ`n"
            . "　・トークンを途中で切って貼っている`n"
            . "　・ユーザー ID が公式アカウントのものになっている（U で始まる自分の ID です）"
            , APP_NAME . " - 送信の結果", "Iconx 4096")
    }

    DoSave() {
        Keep()
        Log("INFO", "LINE の設定を保存しました（宛先 " . LineMask(LineAdminId()) . "）")
        MsgBox("保存しました。`n`n"
            . "※ 顧客への通知は、予定から実行したときに送信します。`n"
            . "　 顧客への通知は、予定から実行したときに送信します。"
            , APP_NAME, "Iconi 4096")
        ScrollDetach(dlg.Hwnd)
        try dlg.Destroy()
        BackToSettings()
    }
}

ModeMore() {
    global APP_NAME, APP_VER
    dlg := Gui("+AlwaysOnTop", APP_NAME " - 設定" VerTag())
    dlg.MarginX := 20, dlg.MarginY := 10
    dlg.SetFont("s11 Bold", "Meiryo UI")
    dlg.Add("Text", "w620", "設定")
    dlg.SetFont("s9", "Meiryo UI")
    mdlNow := Trim(CS("ModelName"))
    exeNow := Trim(CS("ExeName"))
    planWord := ""
    try planWord := PlanLabel()
    dlg.Add("Text", "w620 cNavy"
        , "対象ソフト: " (exeNow = "" ? "（未設定）" : exeNow)
        . "　／　モデル: " (mdlNow = "" ? "（未設定）" : mdlNow)
        . (planWord = "" ? "" : "　／　ご利用: " . planWord))
    ; ★どの場所のツールを動かしているか出す★
    ;   2026-09-22、zip を配り直すうちに同じ PC に 2 つ置かれ、
    ;   「設定したのに反映されない」ことがあり得る。設定ファイルは
    ;   ツールと同じ場所にあるので、ここが違えば別物を動かしている。
    dlg.Add("Text", "w620 cGray", "いまの場所: " A_ScriptDir)

    ; ★整頓の方針（2026-10-11）★
    ;   ・番号をやめて、見出しだけにする（順番にやるものではない）
    ;   ・各ボタンに、いまの値を出す（押さなくても設定済みかが分かる）
    ;   ・お知らせ【Pro】の項目は、スタンダードプラン・サポートプランでは開けない（【Pro】は見出しにだけ付ける）
    ;   ・最初の設定は「はじめての設定」が案内する。やり直しは下の画面へ
    isPro := !IsGeneralPlan()
    dlg.Add("Text", "w620 h1 0x10")
    dlg.SetFont("s10", "Meiryo UI")
    bWiz  := dlg.Add("Button", "w620 h36", SetupWizLabel())

    dlg.SetFont("s10 Bold", "Meiryo UI")
    dlg.Add("Text", "xm w620 cNavy", "この PC")
    dlg.SetFont("s10", "Meiryo UI")
    bMs   := dlg.Add("Button", "w300 h34", "測定値を設定し直す →")
    bSC   := dlg.Add("Button", "x+20 yp w300 h34", "ショートカットを作成")
    bSU   := dlg.Add("Button", "xm w620 h34", StartupLabel())
    bWD   := dlg.Add("Button", "xm w620 h34", WatchdogLabel())

    dlg.SetFont("s10 Bold", "Meiryo UI")
    dlg.Add("Text", "xm w620 cNavy", "お知らせ　【Pro】")
    dlg.SetFont("s10", "Meiryo UI")
    bNT   := dlg.Add("Button", "w300 h34", "通知：" . (CB("NotifyEnabled") ? "オン" : "オフ"))
    bML   := dlg.Add("Button", "x+20 yp w300 h34", "メール：" . (MailReady() ? "設定済み" : "未設定"))
    bLN   := dlg.Add("Button", "xm w300 h34", "LINE：" . (LineReady() ? "設定済み" : "未設定"))
    bRG   := dlg.Add("Button", "x+20 yp w300 h34"
        , "登録用 QR：" . (!LineReady() ? "先に LINE" : (RegReady() ? "使えます" : "未設定")))
    if (!isPro) {
        ; ★開かない★ 使えない項目は押せなくし、プロプランの案内を添える
        for bx in [bNT, bML, bLN, bRG]
            bx.Enabled := false
        dlg.SetFont("s9", "Meiryo UI")
        dlg.Add("Text", "xm w420 cGray", "お知らせの項目は、プロプランでご利用いただけます。")
        bPro := dlg.Add("Button", "x+20 yp-5 w180 h28", "プロプランのご案内")
        bPro.OnEvent("Click", (*) => GuideOpen())
        dlg.SetFont("s10", "Meiryo UI")
    }

    dlg.SetFont("s10 Bold", "Meiryo UI")
    dlg.Add("Text", "xm w620 cNavy", "ご利用")
    dlg.SetFont("s10", "Meiryo UI")
    codeNow := Trim(CS("UserCode"))
    bCode := dlg.Add("Button", "w300 h34", codeNow = "" ? "利用者コードを登録（未登録）" : "利用者コード：" . codeNow)
    bUp   := dlg.Add("Button", "x+20 yp w300 h34", "新しい版を確認して更新")

    dlg.Add("Text", "xm w620 h1 0x10")
    bHelp := dlg.Add("Button", "xm w300 h34", "お問い合わせ・診断 →")
    bBack := dlg.Add("Button", "x+20 yp w300 h34 Default", "← 戻る")

    bWiz.OnEvent("Click", (*) => Jump("wizard"))
    bMs.OnEvent("Click",  (*) => Jump("measure"))
    bNT.OnEvent("Click",  (*) => Jump("notify"))
    bML.OnEvent("Click",  (*) => Jump("mail"))
    bLN.OnEvent("Click",  (*) => Jump("line"))
    bRG.OnEvent("Click",  (*) => Jump("register"))
    bCode.OnEvent("Click",(*) => Jump("code"))
    bSC.OnEvent("Click",  (*) => ShortcutNow())
    bUp.OnEvent("Click",  (*) => Jump("update"))
    bSU.OnEvent("Click",  (*) => StartupClicked())
    bWD.OnEvent("Click",  (*) => WatchdogClicked())
    bHelp.OnEvent("Click",(*) => Jump("diag"))
    bBack.OnEvent("Click",(*) => Jump("menu"))
    dlg.OnEvent("Close",  (*) => Jump("menu"))
    ; ★項目が増えても下が切れないように★（2026-09-26 指摘）
    if (!ScrollAttach(dlg))
        dlg.Show()
    return

    StartupClicked() {
        ToggleStartup()
        bSU.Text := StartupLabel()                 ; 押したあとの表示を合わせる
    }

    WatchdogClicked() {
        ToggleWatchdog()
        bWD.Text := WatchdogLabel()
    }

    Jump(mode) {
        global G, APP_NAME
        ScrollDetach(dlg.Hwnd)
        dlg.Destroy()
        G.mode := mode
        G.fromMenu := true                     ; 人が画面をたどっている
        G.backTo := "more"                     ; やめたら「設定」へ戻す
        switch mode {
            case "menu":     ModeMenu()
            case "run":      ModeRun()
            case "setup":    ModeSetup()
            case "pickrow":  ModePickRow()
            case "teachscan": ModeTeachScan()
            case "teachcount": ModeTeachCount()
            case "measure":  ModeMeasure()
            case "wizard":   ModeWizard()
            case "code":     ModeCode()
            case "verifytest": ModeVerifyTest()
            case "update":     ModeUpdate()
            case "model":      ModeModel()
            case "schemename": ModeSchemeNames()
            case "notify":   ModeNotify()
            case "secretcheck": ModeSecretCheck()
            case "mail":     ModeMail()
            case "line":     ModeLine()
            case "register": ModeRegister()
            case "diag":     ModeDiag()
            case "trace":    ModeTrace()
            case "listread": ModeListRead()
            case "inspect":  ModeInspect()
            case "watchall": ModeWatchAll()
            case "doctor":   ModeDoctor()
            default:
                MsgBox("行き先「" mode "」が実装されていません。", APP_NAME, "Iconx 4096")
                Log("ERROR", "未実装の行き先: " mode)
                ModeMenu()
        }
    }
}

; ★お問い合わせ★（2026-10-11）
;   窓口の返事（通行証）の LINE・メールを使い、届かないときの既定は SupportInfo が持つ。
;   プランごとの案内文には、金額を書かない（金額は商品設計の側で決める）。
SupportNote() {
    if (!IsGeneralPlan())
        return "プロプランは、優先して対応します。LINE またはメールでご連絡ください。"
    return "チャットでのご相談を受け付けています（LINE）。お返事には、数営業日いただきます。`n"
         . "電話・Zoom でのご相談をご希望のときは、LINE でお知らせください。"
}

ContactLine() {
    global APP_NAME
    u := SupportInfo()["line"]
    try {
        Run(u)
    } catch {
        MsgBox("LINE を開けませんでした。`n`n次のところへお問い合わせください。`n`n　" . u, APP_NAME, "Icon! 4096")
    }
}

ContactMail() {
    global APP_NAME, APP_VER
    mail := SupportInfo()["mail"]
    body := "（ここに、お困りの内容をお書きください）`n`n`n"
          . "──────────`n"
          . "AutoMeta " . APP_VER . "`n"
          . "ご利用: " . PlanLabel() . "`n"
          . "利用者コード: " . Trim(CS("UserCode")) . "`n"
    ; ★mailto: は使わない★ 既定のメールソフトが無い PC では「何で開くか」が出て、Chrome を選ぶと
    ;   Chrome が立ち上がるだけでメール画面にならない（2026-10-13、カマヤンの確認）。
    ;   Gmail の作成画面を、ブラウザで直接開く。
    url := "https://mail.google.com/mail/?view=cm&fs=1&to=" . UriEncode(mail)
         . "&su=" . UriEncode("AutoMeta のお問い合わせ")
         . "&body=" . UriEncode(body)
    try {
        Run(url)
    } catch {
        MsgBox("メールを開けませんでした。`n`n次のアドレスへご連絡ください。`n`n　" . mail, APP_NAME, "Icon! 4096")
    }
}

; ★測定値を設定し直す★（設定の下の画面）
;   最初の設定は「はじめての設定」が案内する。ここは、やり直したいときに使う。
;   各項目に、いまの値と、先に開いておく画面を出す。
ModeMeasure() {
    global APP_NAME
    dlg := Gui("+AlwaysOnTop", APP_NAME " - 測定値を設定し直す" VerTag())
    dlg.MarginX := 20, dlg.MarginY := 12
    dlg.SetFont("s12 Bold", "Meiryo UI")
    dlg.Add("Text", "w620", "測定値を設定し直す")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "w620 cGray"
        , "最初の設定は「はじめての設定」が案内します。ここは、やり直したいときに使います。`n"
        . "測った値はこの PC にだけ残ります。")
    dlg.Add("Text", "w620 h1 0x10")
    dlg.SetFont("s10", "Meiryo UI")
    vals := Map(), scrs := Map()
    for st in SetupSteps(false) {
        vals[st["mode"]] := (st["v"] = "" ? "未登録" : st["v"])
        scrs[st["mode"]] := st["scr"]
    }
    bSet  := dlg.Add("Button", "w620 h34", "対象ソフトを選ぶ（" . vals["setup"] . "）")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "xm+8 w600 cGray", scrs["setup"])
    dlg.SetFont("s10", "Meiryo UI")
    bRow  := dlg.Add("Button", "xm w620 h34", "一覧の 1 行目と 2 行目を登録（" . vals["pickrow"] . "）")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "xm+8 w600 cGray", scrs["pickrow"])
    dlg.SetFont("s10", "Meiryo UI")
    bTS   := dlg.Add("Button", "xm w620 h34", "調査タイプ／マニュアル選択の位置を登録")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "xm+8 w600 cGray", scrs["teachscan"] . "　／　記録: " . vals["teachscan"])
    dlg.SetFont("s10", "Meiryo UI")
    bRC   := dlg.Add("Button", "xm w620 h34", "調査履歴の件数の位置を登録（" . vals["teachcount"] . "）")
    dlg.SetFont("s9", "Meiryo UI")
    dlg.Add("Text", "xm+8 w600 cGray", scrs["teachcount"])
    dlg.SetFont("s10", "Meiryo UI")
    bSN   := dlg.Add("Button", "xm w620 h34", "スキームの名前を変更（マニュアル選択の 1〜5 番目）")
    dlg.Add("Text", "xm w620 h1 0x10")
    bBack := dlg.Add("Button", "w620 h34 Default", "← 設定に戻る")

    bSet.OnEvent("Click", (*) => Go("setup"))
    bRow.OnEvent("Click", (*) => Go("pickrow"))
    bTS.OnEvent("Click",  (*) => Go("teachscan"))
    bRC.OnEvent("Click",  (*) => Go("teachcount"))
    bSN.OnEvent("Click",  (*) => Go("schemename"))
    bBack.OnEvent("Click",(*) => Leave())
    dlg.OnEvent("Close",  (*) => Leave())
    if (!ScrollAttach(dlg))
        dlg.Show()
    return

    Go(mode) {
        global G
        ScrollDetach(dlg.Hwnd)
        dlg.Destroy()
        G.mode := mode
        G.fromMenu := true
        G.backTo := "more"                         ; 終わったら「設定」へ戻す
        switch mode {
            case "setup":      ModeSetup()
            case "pickrow":    ModePickRow()
            case "teachscan":  ModeTeachScan()
            case "teachcount": ModeTeachCount()
            case "schemename": ModeSchemeNames()
            default:           ModeMore()
        }
    }

    Leave() {
        ScrollDetach(dlg.Hwnd)
        dlg.Destroy()
        ModeMore()
    }
}

;==============================================================================
;  ユーティリティ
;==============================================================================
; Windows のメモ帳で崩れないよう、書き出す文字列の改行を CRLF に揃える
CRLF(txt) {
    txt := StrReplace(txt, "`r`n", "`n")
    return StrReplace(txt, "`n", "`r`n")
}

FmtDur(sec) {
    sec := Max(0, Integer(sec))
    if (sec >= 3600)
        return Format("{1:02}:{2:02}:{3:02}", sec // 3600, Mod(sec // 60, 60), Mod(sec, 60))
    return Format("{1:02}:{2:02}", sec // 60, Mod(sec, 60))
}

OpenFile(p) {
    try Run('notepad.exe "' p '"')
}
