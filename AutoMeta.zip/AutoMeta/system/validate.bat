@echo off
rem === syntax check only - this does NOT operate the software ===
rem     works from a Parallels shared folder (\\Mac\Home\...) thanks to pushd
pushd "%~dp0"
call "%~dp0_ahk.bat"
if errorlevel 1 (popd & exit /b 1)

echo.
echo  Checking AutoMeta.ahk for syntax errors ...
echo  (the tool is NOT started - the script is only parsed)
echo.

"%AHKEXE%" /ErrorStdOut /validate "%~dp0AutoMeta.ahk" > "%~dp0validate_result.txt" 2>&1
set RC=%errorlevel%
type "%~dp0validate_result.txt"
echo.
if "%RC%"=="0" (
  echo  [OK]  No syntax error. The tool should start.
) else (
  echo  [NG]  Something is wrong. See validate_result.txt
  echo        NOTE: if it says the script file was not found, this
  echo              AutoHotkey build may not support /validate.
)
echo.
popd
pause
