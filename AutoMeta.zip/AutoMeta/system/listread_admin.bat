@echo off
rem === check readability (as admin) ===
cd /d "%~dp0"
call "%~dp0_ahk.bat"
if errorlevel 1 exit /b 1
powershell -NoProfile -Command "Start-Process -Verb RunAs -FilePath '%AHKEXE%' -ArgumentList '\"%~dp0AutoMeta.ahk\"','/listread'"
