@echo off
rem === stop every AutoHotkey process (unlocks files for overwriting) ===
echo Stopping AutoHotkey processes...
taskkill /f /im AutoHotkey64.exe >nul 2>&1
taskkill /f /im AutoHotkey32.exe >nul 2>&1
echo.
tasklist /fi "imagename eq AutoHotkey64.exe" | find /i "AutoHotkey" >nul
if errorlevel 1 (
  echo  [OK] No AutoHotkey process is running. You can overwrite the files now.
) else (
  echo  [WARN] Something is still running. Use Task Manager ^(Ctrl+Shift+Esc^).
)
echo.
pause
