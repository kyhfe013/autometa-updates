@echo off
rem === resolve AutoHotkey v2 (release) executable, or explain what is wrong ===
set "AHKEXE="
if exist "%~dp0AutoHotkey64.exe" set "AHKEXE=%~dp0AutoHotkey64.exe"
if not defined AHKEXE if exist "%~dp0AutoHotkey32.exe" set "AHKEXE=%~dp0AutoHotkey32.exe"
if defined AHKEXE exit /b 0

echo.
if exist "%~dp0AutoHotkeyU64.exe" goto OLDNAME
if exist "%~dp0AutoHotkeyU32.exe" goto OLDNAME
if exist "%~dp0AutoHotkeyA32.exe" goto OLDNAME

echo  [ERROR] AutoHotkey v2 (release) is NOT in this folder.
goto HOWTO

:OLDNAME
echo  [ERROR] Wrong AutoHotkey build.
echo.
echo   Found : AutoHotkeyU64.exe / U32 / A32
echo           =  AutoHotkey v1.1,  OR  an old v2 ALPHA build (2.0-a###)
echo           Neither of them can run this script.
echo.
echo   The "U" in the filename means it is NOT the v2 release.

:HOWTO
echo.
echo   Needed file name :  AutoHotkey64.exe      (no "U")
echo.
echo   How to tell the version apart:
echo      2.0.19        =  RELEASE   -^>  OK
echo      2.0-a076      =  ALPHA     -^>  NG   (has a letter after 2.0-)
echo      1.1.37        =  v1        -^>  NG
echo.
echo   Where to get it:
echo      github.com/AutoHotkey/AutoHotkey/releases
echo         -^> Assets  -^>  AutoHotkey_2.0.xx.zip   (no "alpha" / "beta")
echo         -^> extract, you get AutoHotkey32.exe and AutoHotkey64.exe
echo.
echo      or  autohotkey.com  -^>  Download  -^>  "Download v2.0"
echo         -^> if you only get the installer, install it and copy
echo            C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe  here
echo.
pause
exit /b 1
