@echo off
rem === record the first row position of the patient list ===
cd /d "%~dp0"
call "%~dp0_ahk.bat"
if errorlevel 1 exit /b 1
start "" "%AHKEXE%" "%~dp0AutoMeta.ahk" /pickrow
