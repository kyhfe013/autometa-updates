@echo off
rem ===================================================================
rem   AutoMeta  check watcher  (runs INSIDE the Windows VM, C:\AutoMetaVM)
rem
rem   Leave this window open. It starts by itself at sign-in (Startup).
rem   The Mac puts files here with "utmctl file push" and reads the
rem   results with "utmctl file pull" (UTM guest agent).
rem
rem     _check_request.txt  -> AutoHotkey /validate the named file
rem                            -> validate_result.txt (last line OK / NG)
rem     _run_request.txt    -> run the named test script (_vmtest*.ahk)
rem                            -> the script writes vmtest_result.txt
rem
rem   Set up by _vm_setup.py on the Mac. Close the window to stop.
rem ===================================================================
title AutoMeta check watcher
pushd "%~dp0"
call "%~dp0_ahk.bat"
if errorlevel 1 (popd & pause & exit /b 1)

echo  Watching %~dp0 ...
echo  (close this window to stop)
echo.

:LOOP
if not exist "%~dp0_check_request.txt" goto RUNREQ
set "T="
set /p T=<"%~dp0_check_request.txt"
del "%~dp0_check_request.txt" >nul 2>&1
if "%T%"=="" goto WAIT
echo [%TIME%] checking %T% ...
rem  Warnings (#Warn) would open a dialog and freeze this window, and at
rem  real start-up the user would see the same dialog. So validate through
rem  a wrapper that prints warnings, and treat any warning as NG.
> "%~dp0_validate_wrap.ahk" echo #Warn Unreachable, StdOut
>> "%~dp0_validate_wrap.ahk" echo #Warn VarUnset, StdOut
>> "%~dp0_validate_wrap.ahk" echo #Include %T%
"%AHKEXE%" /ErrorStdOut /validate "%~dp0_validate_wrap.ahk" > "%~dp0validate_result.txt" 2>&1
if errorlevel 1 goto NG
findstr /c:"==> Warning:" "%~dp0validate_result.txt" >nul && goto NG
echo [%TIME%] OK
echo OK>> "%~dp0validate_result.txt"
goto WAIT
:NG
echo [%TIME%] NG  - see validate_result.txt
echo NG>> "%~dp0validate_result.txt"
goto WAIT

:RUNREQ
if not exist "%~dp0_run_request.txt" goto WAIT
set "T="
set /p T=<"%~dp0_run_request.txt"
del "%~dp0_run_request.txt" >nul 2>&1
if /i not "%T:~0,7%"=="_vmtest" goto WAIT
if /i not "%T:~-4%"==".ahk" goto WAIT
if not exist "%~dp0%T%" goto WAIT
echo [%TIME%] running test %T% ...
rem Route AHK warnings to the result file before they can open a modal dialog.
> "%~dp0_vmtest_watch_wrap.ahk" echo #Warn All, StdOut
>> "%~dp0_vmtest_watch_wrap.ahk" echo #Include %T%
"%AHKEXE%" /ErrorStdOut /validate "%~dp0_vmtest_watch_wrap.ahk" > "%~dp0vmtest_stderr.txt" 2>&1
if errorlevel 1 goto RUNNG
findstr /c:"==> Warning:" "%~dp0vmtest_stderr.txt" >nul && goto RUNNG
"%AHKEXE%" /ErrorStdOut "%~dp0_vmtest_watch_wrap.ahk" > "%~dp0vmtest_stderr.txt" 2>&1
if errorlevel 1 if not exist "%~dp0vmtest_result.txt" goto RUNNG
if not exist "%~dp0vmtest_result.txt" goto RUNNG
echo [%TIME%] test finished
goto WAIT

:RUNNG
type "%~dp0vmtest_stderr.txt" > "%~dp0vmtest_result.txt"
echo.>> "%~dp0vmtest_result.txt"
echo Test script failed or exited without a result.>> "%~dp0vmtest_result.txt"
echo NG>> "%~dp0vmtest_result.txt"

:WAIT
ping -n 3 127.0.0.1 >nul
goto LOOP
