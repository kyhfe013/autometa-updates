@echo off
rem ===================================================================
rem   AutoMeta  syntax-check watcher  (run this INSIDE the Windows VM)
rem
rem   Leave this window open. Whenever _check_request.txt appears in
rem   this folder, the script is parsed and the result is written to
rem   validate_result.txt  -  which is readable from the Mac side.
rem
rem   Close the window to stop. Nothing is installed.
rem ===================================================================
pushd "%~dp0"
call "%~dp0_ahk.bat"
if errorlevel 1 (popd & pause & exit /b 1)

echo  Watching for _check_request.txt ...
echo  (close this window to stop)
echo.

:OLD_
rem ======================================================
rem ======================================================
rem ======================================================
rem ======================================================
rem ======================================================
rem ======================================================
rem ================================
ping -n 3 127.0.0.1 >nul
goto LOOP
rem -------------------------------------------------------------------
rem  2026-11-07: the request file may name the file to check (one line,
rem  a file in this folder). "request" or empty = AutoMeta.ahk.
rem  The lines above are kept at the same byte positions on purpose, so a
rem  watcher window that was already open keeps working after this edit
rem  (cmd re-reads a running .bat by position).
rem -------------------------------------------------------------------
:LOOP
if not exist "%~dp0_check_request.txt" goto WAIT
set "T="
set /p T=<"%~dp0_check_request.txt"
del "%~dp0_check_request.txt" >nul 2>&1
if "%T%"=="" set "T=AutoMeta.ahk"
if /i "%T%"=="request" set "T=AutoMeta.ahk"
echo [%TIME%] checking %T% ...
"%AHKEXE%" /ErrorStdOut /validate "%~dp0%T%" > "%~dp0validate_result.txt" 2>&1
if errorlevel 1 goto NG
echo [%TIME%] OK
echo OK>> "%~dp0validate_result.txt"
goto WAIT
:NG
echo [%TIME%] NG  - see validate_result.txt
echo NG>> "%~dp0validate_result.txt"
:WAIT
ping -n 3 127.0.0.1 >nul
goto LOOP
