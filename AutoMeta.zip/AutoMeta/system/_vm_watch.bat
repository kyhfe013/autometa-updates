@echo off
rem ===================================================================
rem   AutoMeta  syntax-check watcher  (run this INSIDE the Windows VM)
rem
rem   Leave this window open. Whenever _check_request.txt appears in
rem   this folder, the script is parsed and the result is written to
rem   validate_result.txt  -  which is readable from the Mac side.
rem
rem   Close the window to stop. Nothing is installed.
rem ===================================================================
pushd "%~dp0"
call "%~dp0_ahk.bat"
if errorlevel 1 (popd & pause & exit /b 1)

echo  Watching for _check_request.txt ...
echo  (close this window to stop)
echo.

:LOOP
if exist "%~dp0_check_request.txt" (
  del "%~dp0_check_request.txt" >nul 2>&1
  echo [%TIME%] checking ...
  "%AHKEXE%" /ErrorStdOut /validate "%~dp0AutoMeta.ahk" > "%~dp0validate_result.txt" 2>&1
  if errorlevel 1 (
    echo [%TIME%] NG  - see validate_result.txt
    echo NG>> "%~dp0validate_result.txt"
  ) else (
    echo [%TIME%] OK
    echo OK>> "%~dp0validate_result.txt"
  )
)
ping -n 3 127.0.0.1 >nul
goto LOOP
