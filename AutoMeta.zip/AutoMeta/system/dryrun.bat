@echo off
rem === dryrun ===
cd /d "%~dp0"
call "%~dp0_ahk.bat"
if errorlevel 1 exit /b 1
start "" "%AHKEXE%" "%~dp0AutoMeta.ahk" /dryrun
