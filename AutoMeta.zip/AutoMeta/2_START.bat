@echo off
rem === DAILY USE : open the survey menu ===
cd /d "%~dp0"
call "%~dp0system\_ahk.bat"
if errorlevel 1 exit /b 1
start "" "%AHKEXE%" "%~dp0system\AutoMeta.ahk" /menu
